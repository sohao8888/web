# Local Note Publisher

Local-first Obsidian plugin inspired by `note-to-mp`, rebuilt for personal use with all data stored locally.

## Features

- Side-panel preview for the current Markdown note
- Built-in article themes and code styles
- Custom CSS note support
- Copy styled HTML with images inlined locally
- Send the current note to a WeChat official account draft
- Open the Zhihu editor with rich HTML pre-copied
- Publish one or more notes into a local article bundle
- Export the current note into multiple 9:16 PNG pages automatically, with page breaks preferring paragraphs, headings, lists, images, tables, and code blocks
- Export a standalone HTML file
- Save timestamped local snapshots
- File-menu actions for notes, note selections, and folders

## Local Storage

- Plugin settings and history: `.obsidian/plugins/local-note-publisher/data.json`
- Published bundles: `_local-note-publisher/exports`
- Snapshots: `_local-note-publisher/snapshots`

## Frontmatter

Optional keys:

```yaml
title: Published title
description: Short summary
author: Your name
date: 2026-03-26
local-publisher-theme: ocean
local-publisher-highlight: midnight
local-publisher-css: Custom CSS
```

Supported aliases:

- `title` / `标题`
- `description` / `摘要`
- `author` / `作者`
- `date` / `日期`
- `theme` / `样式`
- `highlight` / `代码高亮`

## Commands

- `Open local publisher`
- `Publish current note locally`
- `Send current note to WeChat draft`
- `Send current note to Zhihu editor`
- `Export current note to 9:16 PNG pages`
- `Export current note to standalone HTML`
- `Save current note snapshot`
- `Open publish folder`
- `Open snapshot folder`

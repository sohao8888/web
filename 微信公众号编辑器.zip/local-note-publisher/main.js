"use strict";

const obsidian = require("obsidian");
const path = require("path");
const { shell, clipboard } = require("electron");

const VIEW_TYPE = "local-note-publisher-view";

const DEFAULT_SETTINGS = {
  defaultTheme: "paper",
  defaultHighlight: "default",
  exportFolder: "_local-note-publisher/exports",
  snapshotFolder: "_local-note-publisher/snapshots",
  pngExportFolder: "_local-note-publisher/png-exports",
  pngPageWidth: 1080,
  customCssNote: "",
  wechatAppId: "",
  wechatAppSecret: "",
  wechatCover: "",
  zhihuWriteUrl: "https://zhuanlan.zhihu.com/write",
  autoRefresh: true,
  openFolderAfterPublish: true,
  historyLimit: 30,
  history: []
};

const THEMES = {
  paper: {
    label: "Warm Paper",
    css: `
.lnp-article {
  --lnp-text: #34281f;
  --lnp-muted: #7c6859;
  --lnp-link: #925324;
  --lnp-border: #e7d9c7;
  --lnp-surface: #f7efe4;
  --lnp-code-bg: #2d241d;
  --lnp-code-text: #f7efe5;
  background: #fffaf2;
  color: var(--lnp-text);
  border: 1px solid #ebdfcf;
  box-shadow: 0 22px 60px rgba(87, 62, 39, 0.12);
}
.lnp-article h1,
.lnp-article h2,
.lnp-article h3,
.lnp-article h4,
.lnp-article h5,
.lnp-article h6 {
  color: #2d221b;
}
.lnp-article h2 {
  border-left: 4px solid #d28742;
  padding-left: 0.7em;
}
.lnp-article blockquote,
.lnp-article .callout {
  background: rgba(210, 135, 66, 0.08);
}
`
  },
  ocean: {
    label: "Ocean Column",
    css: `
.lnp-article {
  --lnp-text: #1e3447;
  --lnp-muted: #60778a;
  --lnp-link: #1569a8;
  --lnp-border: #d8e7f3;
  --lnp-surface: #eef6fb;
  --lnp-code-bg: #122536;
  --lnp-code-text: #eff6fc;
  background: #ffffff;
  color: var(--lnp-text);
  border: 1px solid #d4e4f5;
  box-shadow: 0 18px 44px rgba(31, 76, 112, 0.08);
}
.lnp-article h1,
.lnp-article h2,
.lnp-article h3,
.lnp-article h4,
.lnp-article h5,
.lnp-article h6 {
  color: #183349;
}
.lnp-article h2 {
  border-left: 4px solid #4aa3df;
  padding-left: 0.7em;
}
.lnp-article blockquote,
.lnp-article .callout {
  background: rgba(74, 163, 223, 0.09);
}
`
  },
  charcoal: {
    label: "Charcoal Night",
    css: `
.lnp-article {
  --lnp-text: #e8eef5;
  --lnp-muted: #9aa8b7;
  --lnp-link: #7dd3fc;
  --lnp-border: #334155;
  --lnp-surface: #202732;
  --lnp-code-bg: #0b1016;
  --lnp-code-text: #e7eef7;
  background: #171b21;
  color: var(--lnp-text);
  border: 1px solid #2b3440;
  box-shadow: 0 18px 48px rgba(15, 23, 42, 0.22);
}
.lnp-article h1,
.lnp-article h2,
.lnp-article h3,
.lnp-article h4,
.lnp-article h5,
.lnp-article h6 {
  color: #f8fafc;
}
.lnp-article h2 {
  border-left: 4px solid #38bdf8;
  padding-left: 0.7em;
}
.lnp-article blockquote,
.lnp-article .callout {
  background: rgba(255, 255, 255, 0.05);
}
.lnp-article table th,
.lnp-article table td {
  border-color: #334155;
}
`
  },
  obsidian: {
    label: "Obsidian Slate",
    css: `
.lnp-article {
  --lnp-text: #dbe2ea;
  --lnp-muted: #9aa6b2;
  --lnp-link: #8ec5ff;
  --lnp-border: #3a4654;
  --lnp-surface: #202833;
  --lnp-code-bg: #11161d;
  --lnp-code-text: #e6edf5;
  background: linear-gradient(180deg, #1e2630 0%, #171d25 100%);
  color: var(--lnp-text);
  border: 1px solid #2f3947;
  box-shadow: 0 20px 46px rgba(9, 14, 24, 0.24);
}
.lnp-article h1,
.lnp-article h2,
.lnp-article h3,
.lnp-article h4,
.lnp-article h5,
.lnp-article h6 {
  color: #f1f5f9;
}
.lnp-article h2 {
  border-left: 4px solid #72b7ff;
  padding-left: 0.7em;
}
.lnp-article blockquote,
.lnp-article .callout {
  background: rgba(114, 183, 255, 0.09);
}
`
  }
};

const HIGHLIGHTS = {
  default: {
    label: "Default",
    css: `
.lnp-article pre {
  background: var(--lnp-code-bg);
  color: var(--lnp-code-text);
}
.lnp-article code {
  color: inherit;
}
`
  },
  solarized: {
    label: "Solarized",
    css: `
.lnp-article pre {
  background: #fdf6e3;
  color: #586e75;
  border-color: rgba(88, 110, 117, 0.14);
}
.lnp-article :not(pre) > code {
  background: rgba(101, 123, 131, 0.11);
  color: #586e75;
}
`
  },
  midnight: {
    label: "Midnight",
    css: `
.lnp-article pre {
  background: #0a1020;
  color: #dbeafe;
  border-color: rgba(147, 197, 253, 0.14);
}
.lnp-article :not(pre) > code {
  background: rgba(59, 130, 246, 0.14);
  color: #dbeafe;
}
`
  }
};

const BASE_ARTICLE_CSS = `
* {
  box-sizing: border-box;
}
body {
  margin: 0;
  padding: 32px 20px;
  background:
    radial-gradient(circle at top, rgba(120, 170, 220, 0.12), transparent 42%),
    linear-gradient(180deg, #edf2f7 0%, #f7fafc 100%);
  font-family: "Segoe UI", "Microsoft YaHei", "PingFang SC", sans-serif;
}
.lnp-article {
  width: 100%;
  max-width: 860px;
  margin: 0 auto;
  padding: 46px 52px;
  border-radius: 28px;
  line-height: 1.85;
  font-size: 16px;
  overflow-wrap: anywhere;
}
.lnp-article * {
  box-sizing: border-box;
}
.lnp-article h1,
.lnp-article h2,
.lnp-article h3,
.lnp-article h4,
.lnp-article h5,
.lnp-article h6 {
  margin: 1.6em 0 0.7em;
  line-height: 1.35;
  font-weight: 700;
}
.lnp-article h1 {
  margin-top: 0;
  font-size: 2.2em;
}
.lnp-article h2 {
  font-size: 1.55em;
}
.lnp-article h3 {
  font-size: 1.28em;
}
.lnp-article p,
.lnp-article ul,
.lnp-article ol,
.lnp-article blockquote,
.lnp-article table,
.lnp-article pre {
  margin: 0 0 1.05em;
}
.lnp-article a {
  color: var(--lnp-link);
  text-decoration: none;
  border-bottom: 1px solid rgba(0, 0, 0, 0.12);
}
.lnp-article strong {
  font-weight: 700;
}
.lnp-article img {
  display: block;
  max-width: 100%;
  height: auto;
  margin: 1.2em auto;
  border-radius: 18px;
}
.lnp-article blockquote,
.lnp-article .callout {
  margin: 1.2em 0;
  padding: 0.9em 1em;
  border-left: 4px solid var(--lnp-border);
  border-radius: 14px;
}
.lnp-article hr {
  border: 0;
  border-top: 1px solid var(--lnp-border);
  margin: 2em 0;
}
.lnp-article ul,
.lnp-article ol {
  padding-left: 1.5em;
}
.lnp-article li + li {
  margin-top: 0.35em;
}
.lnp-article table {
  width: 100%;
  border-collapse: collapse;
  border-spacing: 0;
  overflow: hidden;
  border-radius: 16px;
}
.lnp-article th,
.lnp-article td {
  padding: 12px 14px;
  border: 1px solid var(--lnp-border);
  text-align: left;
  vertical-align: top;
}
.lnp-article th {
  background: var(--lnp-surface);
  font-weight: 700;
}
.lnp-article pre {
  overflow-x: auto;
  padding: 16px 18px;
  border-radius: 18px;
  border: 1px solid transparent;
}
.lnp-article pre code {
  background: transparent;
  padding: 0;
  border-radius: 0;
  white-space: pre;
}
.lnp-article :not(pre) > code {
  padding: 0.18em 0.45em;
  border-radius: 8px;
  background: rgba(128, 128, 128, 0.12);
  font-size: 0.92em;
}
.lnp-article figure {
  margin: 1.4em 0;
}
.lnp-article figcaption {
  margin-top: 0.7em;
  color: var(--lnp-muted);
  text-align: center;
  font-size: 0.92em;
}
.lnp-article .math-block,
.lnp-article .math-inline {
  overflow-x: auto;
}
`;

function debounceFn(fn, wait) {
  let timer = null;
  return (...args) => {
    if (timer) {
      clearTimeout(timer);
    }
    timer = setTimeout(() => fn(...args), wait);
  };
}

function normalizeVaultPath(input) {
  return String(input || "")
    .replace(/\\/g, "/")
    .replace(/^\/+/, "")
    .replace(/\/+/g, "/")
    .replace(/\/$/, "");
}

function joinVaultPath(...parts) {
  return normalizeVaultPath(parts.filter(Boolean).join("/"));
}

function stripFrontmatter(markdown) {
  if (!markdown || !markdown.startsWith("---")) {
    return markdown || "";
  }
  return markdown.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n?/, "");
}

function firstNonEmpty(...values) {
  for (const value of values) {
    if (value === null || value === undefined) {
      continue;
    }
    const text = Array.isArray(value) ? value[0] : value;
    if (text === null || text === undefined) {
      continue;
    }
    const normalized = String(text).trim();
    if (normalized) {
      return normalized;
    }
  }
  return "";
}

function slugify(value) {
  const normalized = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fa5-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  return normalized || "note";
}

function safeFilename(value) {
  return String(value || "note")
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 80) || "note";
}

function formatTimestamp(date) {
  const pad = (num) => String(num).padStart(2, "0");
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate())
  ].join("") + "-" + [pad(date.getHours()), pad(date.getMinutes()), pad(date.getSeconds())].join("");
}

function escapeHtml(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function getFrontmatterValue(frontmatter, key) {
  if (!frontmatter || !(key in frontmatter)) {
    return "";
  }
  const value = frontmatter[key];
  return Array.isArray(value) ? value[0] : value;
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function urlToDataUrl(src) {
  const response = await fetch(src);
  if (!response.ok) {
    throw new Error(`Failed to fetch image: ${response.status}`);
  }
  return blobToDataUrl(await response.blob());
}

async function fetchBlobFromSrc(src) {
  const response = await fetch(src);
  if (!response.ok) {
    throw new Error(`Failed to fetch image: ${response.status}`);
  }
  return response.blob();
}

function inferFilenameFromSrc(src, fallback) {
  try {
    const parsed = new URL(src);
    const pathname = parsed.pathname || "";
    const name = pathname.split("/").pop();
    if (name) {
      return safeFilename(decodeURIComponent(name));
    }
  } catch (error) {
    console.warn("Unable to infer filename from source", src, error);
  }
  return fallback || "image.png";
}

const INLINE_STYLE_PROPS = [
  "display",
  "position",
  "top",
  "right",
  "bottom",
  "left",
  "z-index",
  "width",
  "max-width",
  "min-width",
  "height",
  "max-height",
  "min-height",
  "margin",
  "margin-top",
  "margin-right",
  "margin-bottom",
  "margin-left",
  "padding",
  "padding-top",
  "padding-right",
  "padding-bottom",
  "padding-left",
  "border",
  "border-top",
  "border-right",
  "border-bottom",
  "border-left",
  "border-radius",
  "background",
  "background-color",
  "background-image",
  "background-size",
  "background-position",
  "background-repeat",
  "box-shadow",
  "color",
  "font",
  "font-family",
  "font-size",
  "font-style",
  "font-weight",
  "line-height",
  "letter-spacing",
  "text-align",
  "text-decoration",
  "text-transform",
  "white-space",
  "word-break",
  "overflow-wrap",
  "list-style",
  "list-style-type",
  "opacity",
  "overflow",
  "overflow-x",
  "overflow-y",
  "vertical-align",
  "gap",
  "grid-template-columns",
  "grid-template-rows",
  "flex",
  "flex-direction",
  "justify-content",
  "align-items"
];

function inlineComputedStyles(root) {
  const elements = [root, ...root.querySelectorAll("*")];
  for (const element of elements) {
    const computed = window.getComputedStyle(element);
    const styles = [];
    for (const prop of INLINE_STYLE_PROPS) {
      const value = computed.getPropertyValue(prop);
      if (value && value !== "initial" && value !== "normal" && value !== "none" && value !== "rgba(0, 0, 0, 0)") {
        styles.push(`${prop}:${value}`);
      }
    }
    if (styles.length) {
      element.setAttribute("style", styles.join(";"));
    }
  }
}

function waitForAnimationFrames(count = 2) {
  return new Promise((resolve) => {
    const step = () => {
      if (count <= 0) {
        resolve();
        return;
      }
      count -= 1;
      requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
}

async function waitForImages(root) {
  const images = Array.from(root.querySelectorAll("img"));
  await Promise.all(images.map(async (image) => {
    if (image.complete && image.naturalWidth > 0) {
      return;
    }
    try {
      if (typeof image.decode === "function") {
        await image.decode();
        return;
      }
    } catch (error) {
      console.warn("Image decode failed", error);
    }
    await new Promise((resolve) => {
      image.onload = () => resolve();
      image.onerror = () => resolve();
    });
  }));
}

function getSmartBreakCandidates(articleEl) {
  const selector = [
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "p",
    "blockquote",
    "pre",
    "table",
    "figure",
    "img",
    "ul",
    "ol",
    ".callout",
    "hr"
  ].join(",");

  const articleRect = articleEl.getBoundingClientRect();
  return Array.from(articleEl.querySelectorAll(selector))
    .map((element) => {
      const rect = element.getBoundingClientRect();
      return {
        top: Math.max(0, Math.round(rect.top - articleRect.top)),
        bottom: Math.max(0, Math.round(rect.bottom - articleRect.top)),
        height: Math.max(0, Math.round(rect.height)),
        tag: element.tagName.toLowerCase()
      };
    })
    .filter((item) => item.height > 0)
    .sort((a, b) => a.top - b.top);
}

function computeSmartPageOffsets(articleHeight, contentHeight, candidates) {
  if (articleHeight <= contentHeight) {
    return [0];
  }

  const offsets = [0];
  const minFill = Math.round(contentHeight * 0.55);
  const hardMinFill = Math.round(contentHeight * 0.35);

  while (true) {
    const currentOffset = offsets[offsets.length - 1];
    if (currentOffset + contentHeight >= articleHeight) {
      break;
    }

    const idealEnd = currentOffset + contentHeight;
    const preferredStart = currentOffset + minFill;
    const fallbackStart = currentOffset + hardMinFill;

    let nextOffset = 0;

    const preferred = candidates.filter((candidate) => candidate.top > preferredStart && candidate.top < idealEnd);
    if (preferred.length) {
      nextOffset = preferred[preferred.length - 1].top;
    }

    if (!nextOffset) {
      const fallback = candidates.filter((candidate) => candidate.top > fallbackStart && candidate.top < idealEnd);
      if (fallback.length) {
        nextOffset = fallback[fallback.length - 1].top;
      }
    }

    if (!nextOffset) {
      const overshoot = candidates.find((candidate) => candidate.top > idealEnd && candidate.top - idealEnd <= Math.round(contentHeight * 0.12));
      if (overshoot) {
        nextOffset = overshoot.top;
      }
    }

    if (!nextOffset || nextOffset <= currentOffset) {
      nextOffset = idealEnd;
    }

    if (articleHeight - nextOffset < Math.round(contentHeight * 0.28)) {
      break;
    }

    offsets.push(nextOffset);
  }

  return offsets;
}

function getTopLevelPageBlocks(articleEl) {
  const articleRect = articleEl.getBoundingClientRect();
  return Array.from(articleEl.children)
    .map((element, index) => {
      const rect = element.getBoundingClientRect();
      return {
        index,
        element,
        top: Math.max(0, Math.round(rect.top - articleRect.top)),
        bottom: Math.max(0, Math.round(rect.bottom - articleRect.top)),
        height: Math.max(0, Math.round(rect.height)),
        tag: element.tagName.toLowerCase()
      };
    })
    .filter((block) => block.height > 0);
}

function buildSmartPagePlan(blocks, contentHeight) {
  if (!blocks.length) {
    return [{ mode: "empty" }];
  }

  const pages = [];
  let index = 0;

  while (index < blocks.length) {
    const first = blocks[index];

    if (first.height > Math.round(contentHeight * 1.08)) {
      let localOffset = 0;
      while (localOffset < first.height) {
        pages.push({
          mode: "clip",
          blockIndex: index,
          localOffset
        });
        localOffset += contentHeight;
      }
      index += 1;
      continue;
    }

    let endIndex = index;
    while (endIndex + 1 < blocks.length) {
      const next = blocks[endIndex + 1];
      if (next.bottom - first.top > contentHeight) {
        break;
      }
      endIndex += 1;
    }

    pages.push({
      mode: "blocks",
      startIndex: index,
      endIndex
    });
    index = endIndex + 1;
  }

  return pages;
}

async function inlineImagesInElement(root) {
  const images = Array.from(root.querySelectorAll("img"));
  for (const image of images) {
    const src = image.getAttribute("src");
    if (!src || src.startsWith("data:")) {
      continue;
    }
    try {
      const dataUrl = await urlToDataUrl(src);
      image.setAttribute("src", dataUrl);
      image.removeAttribute("srcset");
    } catch (error) {
      console.warn("Failed to inline image", src, error);
    }
  }
}

async function renderMarkdownInto(app, markdown, container, sourcePath, component) {
  if (typeof obsidian.MarkdownRenderer.render === "function") {
    return obsidian.MarkdownRenderer.render(app, markdown, container, sourcePath, component);
  }
  return obsidian.MarkdownRenderer.renderMarkdown(markdown, container, sourcePath, component);
}

async function ensureFolder(adapter, folderPath) {
  const normalized = normalizeVaultPath(folderPath);
  if (!normalized) {
    return;
  }
  const parts = normalized.split("/");
  let current = "";
  for (const part of parts) {
    current = current ? `${current}/${part}` : part;
    if (!(await adapter.exists(current))) {
      await adapter.mkdir(current);
    }
  }
}

function truncateHistory(history, limit) {
  return history.slice(0, Math.max(1, limit));
}

class LocalPublishModal extends obsidian.Modal {
  constructor(app, plugin, files) {
    super(app);
    this.plugin = plugin;
    this.files = files;
    this.statusMap = new Map();
    this.finishedPath = "";
    this.publishButton = null;
    this.resultEl = null;
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    this.titleEl.setText(this.files.length > 1 ? "批量本地发布" : "本地发布");

    const shellEl = contentEl.createDiv({ cls: "lnp-modal-shell" });
    shellEl.createDiv({
      cls: "lnp-modal-copy",
      text: this.files.length > 1
        ? `将把 ${this.files.length} 篇笔记打包到同一个本地文章目录里。`
        : "将把当前笔记保存为一个本地文章包。"
    });

    const listEl = shellEl.createDiv({ cls: "lnp-modal-list" });
    this.files.forEach((file) => {
      const row = listEl.createDiv({ cls: "lnp-modal-item" });
      row.createDiv({ cls: "lnp-modal-item-title", text: file.path });
      const statusEl = row.createDiv({ cls: "lnp-modal-item-status" });
      statusEl.dataset.status = "pending";
      statusEl.setText("待处理");
      this.statusMap.set(file.path, statusEl);
    });

    this.resultEl = shellEl.createDiv({ cls: "lnp-modal-result" });
    this.resultEl.hide();

    const actions = shellEl.createDiv({ cls: "lnp-modal-actions" });
    const openButton = actions.createEl("button", { text: "打开目录" });
    openButton.disabled = true;
    openButton.onclick = async () => {
      if (this.finishedPath) {
        await this.plugin.openVaultPath(this.finishedPath);
      }
    };

    const cancelButton = actions.createEl("button", { text: "关闭" });
    cancelButton.onclick = () => this.close();

    this.publishButton = actions.createEl("button", { text: "开始发布" });
    this.publishButton.onclick = async () => {
      if (this.publishButton) {
        this.publishButton.disabled = true;
      }
      try {
        const bundlePath = await this.plugin.publishNotes(this.files, {
          openAfter: false,
          onProgress: (file, status, message) => {
            const statusEl = this.statusMap.get(file.path);
            if (!statusEl) {
              return;
            }
            statusEl.dataset.status = status;
            statusEl.setText(message);
          }
        });
        this.finishedPath = bundlePath;
        this.resultEl.show();
        this.resultEl.setText(`已保存到: ${bundlePath}`);
        openButton.disabled = false;
      } catch (error) {
        new obsidian.Notice(`本地发布失败: ${error.message}`);
        if (this.publishButton) {
          this.publishButton.disabled = false;
        }
      }
    };
  }

  onClose() {
    this.contentEl.empty();
  }
}

class LocalPublisherView extends obsidian.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.file = null;
    this.renderComponent = null;
    this.pendingRefresh = debounceFn(() => {
      this.renderCurrentFile().catch((error) => {
        this.setStatus(`渲染失败: ${error.message}`, true);
      });
    }, 200);
  }

  getViewType() {
    return VIEW_TYPE;
  }

  getDisplayText() {
    return "Local Publisher";
  }

  getIcon() {
    return "clipboard-paste";
  }

  async onOpen() {
    this.buildLayout();
    await this.renderCurrentFile();
  }

  async onClose() {
    this.teardownRenderComponent();
  }

  buildLayout() {
    const root = this.contentEl;
    root.empty();
    root.addClass("lnp-view");

    const toolbar = root.createDiv({ cls: "lnp-toolbar" });
    const leftGroup = toolbar.createDiv({ cls: "lnp-toolbar-group" });
    const themeSelect = leftGroup.createEl("select");
    Object.entries(THEMES).forEach(([value, item]) => {
      const option = themeSelect.createEl("option", { text: item.label });
      option.value = value;
    });
    themeSelect.value = this.plugin.settings.defaultTheme;
    themeSelect.onchange = async () => {
      this.plugin.settings.defaultTheme = themeSelect.value;
      await this.plugin.saveSettings();
      await this.renderCurrentFile();
    };

    const highlightSelect = leftGroup.createEl("select");
    Object.entries(HIGHLIGHTS).forEach(([value, item]) => {
      const option = highlightSelect.createEl("option", { text: item.label });
      option.value = value;
    });
    highlightSelect.value = this.plugin.settings.defaultHighlight;
    highlightSelect.onchange = async () => {
      this.plugin.settings.defaultHighlight = highlightSelect.value;
      await this.plugin.saveSettings();
      await this.renderCurrentFile();
    };

    toolbar.createDiv({ cls: "lnp-toolbar-spacer" });
    const actions = toolbar.createDiv({ cls: "lnp-toolbar-group" });
    this.refreshButton = actions.createEl("button", { text: "刷新" });
    this.copyButton = actions.createEl("button", { text: "复制 HTML" });
    this.wechatButton = actions.createEl("button", { text: "Send WeChat" });
    this.zhihuButton = actions.createEl("button", { text: "Send Zhihu" });
    this.publishButton = actions.createEl("button", { text: "本地发布" });
    this.pngButton = actions.createEl("button", { text: "Export PNG" });
    this.exportButton = actions.createEl("button", { text: "导出 HTML" });
    this.snapshotButton = actions.createEl("button", { text: "存快照" });
    this.folderButton = actions.createEl("button", { text: "打开目录" });

    this.refreshButton.onclick = async () => {
      await this.renderCurrentFile();
      new obsidian.Notice("预览已刷新");
    };
    this.copyButton.onclick = async () => {
      if (!this.file) {
        return;
      }
      await this.plugin.copyNoteAsHtml(this.file);
      this.setStatus(`已复制 ${this.file.basename} 的富 HTML`);
    };
    this.wechatButton.onclick = async () => {
      if (!this.file) {
        return;
      }
      const mediaId = await this.plugin.sendNoteToWeChat(this.file);
      this.setStatus(`WeChat draft created: ${mediaId}`);
    };
    this.zhihuButton.onclick = async () => {
      if (!this.file) {
        return;
      }
      await this.plugin.sendNoteToZhihu(this.file);
      this.setStatus("Zhihu editor opened and rich HTML copied");
    };
    this.publishButton.onclick = async () => {
      if (!this.file) {
        return;
      }
      const bundlePath = await this.plugin.publishNotes([this.file], { openAfter: this.plugin.settings.openFolderAfterPublish });
      this.setStatus(`已发布到 ${bundlePath}`);
    };
    this.pngButton.onclick = async () => {
      if (!this.file) {
        return;
      }
      try {
        const folderPath = await this.plugin.exportNoteAsPngPages(this.file, { openAfter: this.plugin.settings.openFolderAfterPublish });
        this.setStatus(`PNG pages exported: ${folderPath}`);
      } catch (error) {
        this.setStatus(`PNG export failed: ${error.message}`, true);
        new obsidian.Notice(`PNG export failed: ${error.message}`);
      }
    };
    this.exportButton.onclick = async () => {
      if (!this.file) {
        return;
      }
      await this.plugin.exportNoteAsDownload(this.file);
      this.setStatus(`已导出 ${this.file.basename}.html`);
    };
    this.snapshotButton.onclick = async () => {
      if (!this.file) {
        return;
      }
      const snapshotPath = await this.plugin.saveSnapshot(this.file, { openAfter: false });
      this.setStatus(`已保存快照到 ${snapshotPath}`);
    };
    this.folderButton.onclick = async () => {
      await this.plugin.openVaultPath(this.plugin.settings.exportFolder);
    };

    this.statusEl = root.createDiv({ cls: "lnp-status" });
    this.previewShell = root.createDiv({ cls: "lnp-preview-shell" });
    this.previewRoot = this.previewShell.createDiv({ cls: "lnp-preview-root" });
    this.previewStyleEl = this.previewRoot.createEl("style");
    this.articleEl = this.previewRoot.createDiv({ cls: "lnp-empty", text: "打开一个 Markdown 笔记后，这里会显示本地发布预览。" });
    this.updateButtons();
  }

  setStatus(message, isError) {
    if (!this.statusEl) {
      return;
    }
    this.statusEl.style.color = isError ? "var(--text-error)" : "var(--text-muted)";
    this.statusEl.setText(message || "");
  }

  teardownRenderComponent() {
    if (this.renderComponent) {
      this.renderComponent.unload();
      this.renderComponent = null;
    }
  }

  updateButtons() {
    const disabled = !(this.file instanceof obsidian.TFile) || this.file.extension.toLowerCase() !== "md";
    [this.refreshButton, this.copyButton, this.wechatButton, this.zhihuButton, this.publishButton, this.pngButton, this.exportButton, this.snapshotButton].forEach((button) => {
      if (button) {
        button.disabled = disabled;
      }
    });
  }

  async renderCurrentFile(forceFile) {
    const file = forceFile || this.app.workspace.getActiveFile();
    this.file = file instanceof obsidian.TFile ? file : null;
    this.updateButtons();
    this.teardownRenderComponent();

    if (!(this.file instanceof obsidian.TFile) || this.file.extension.toLowerCase() !== "md") {
      this.previewStyleEl.setText("");
      this.articleEl.empty();
      this.articleEl.addClass("lnp-empty");
      this.articleEl.setText("打开一个 Markdown 笔记后，这里会显示本地发布预览。");
      this.setStatus("");
      return;
    }

    const renderMeta = this.plugin.getNoteMeta(this.file);
    const css = await this.plugin.buildCss(this.file, renderMeta);
    const markdown = stripFrontmatter(await this.app.vault.cachedRead(this.file));

    this.previewStyleEl.setText(css);
    this.articleEl.empty();
    this.articleEl.removeClass("lnp-empty");
    this.articleEl.addClass("lnp-article");

    this.renderComponent = new obsidian.Component();
    this.renderComponent.load();
    await renderMarkdownInto(this.app, markdown, this.articleEl, this.file.path, this.renderComponent);
    this.setStatus(`预览: ${this.file.path}`);
  }
}

class LocalPublisherSettingTab extends obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Local Note Publisher" });

    new obsidian.Setting(containerEl)
      .setName("默认主题")
      .setDesc("预览和本地发布默认使用的文章主题。")
      .addDropdown((dropdown) => {
        Object.entries(THEMES).forEach(([value, theme]) => dropdown.addOption(value, theme.label));
        dropdown.setValue(this.plugin.settings.defaultTheme);
        dropdown.onChange(async (value) => {
          this.plugin.settings.defaultTheme = value;
          await this.plugin.saveSettings();
          await this.plugin.refreshOpenView();
        });
      });

    new obsidian.Setting(containerEl)
      .setName("默认代码风格")
      .setDesc("本地预览和导出时使用的代码块样式。")
      .addDropdown((dropdown) => {
        Object.entries(HIGHLIGHTS).forEach(([value, highlight]) => dropdown.addOption(value, highlight.label));
        dropdown.setValue(this.plugin.settings.defaultHighlight);
        dropdown.onChange(async (value) => {
          this.plugin.settings.defaultHighlight = value;
          await this.plugin.saveSettings();
          await this.plugin.refreshOpenView();
        });
      });

    new obsidian.Setting(containerEl)
      .setName("发布目录")
      .setDesc("本地文章包的输出位置，相对于当前 Vault。")
      .addText((text) => {
        text.setValue(this.plugin.settings.exportFolder);
        text.onChange(async (value) => {
          this.plugin.settings.exportFolder = normalizeVaultPath(value) || DEFAULT_SETTINGS.exportFolder;
          await this.plugin.saveSettings();
        });
        text.inputEl.style.width = "360px";
      })
      .addButton((button) => {
        button.setButtonText("打开");
        button.onClick(async () => {
          await this.plugin.openVaultPath(this.plugin.settings.exportFolder);
        });
      });

    new obsidian.Setting(containerEl)
      .setName("快照目录")
      .setDesc("保存历史快照的位置，相对于当前 Vault。")
      .addText((text) => {
        text.setValue(this.plugin.settings.snapshotFolder);
        text.onChange(async (value) => {
          this.plugin.settings.snapshotFolder = normalizeVaultPath(value) || DEFAULT_SETTINGS.snapshotFolder;
          await this.plugin.saveSettings();
        });
        text.inputEl.style.width = "360px";
      })
      .addButton((button) => {
        button.setButtonText("打开");
        button.onClick(async () => {
          await this.plugin.openVaultPath(this.plugin.settings.snapshotFolder);
        });
      });

    new obsidian.Setting(containerEl)
      .setName("PNG export folder")
      .setDesc("9:16 PNG pages are saved here.")
      .addText((text) => {
        text.setValue(this.plugin.settings.pngExportFolder || DEFAULT_SETTINGS.pngExportFolder);
        text.onChange(async (value) => {
          this.plugin.settings.pngExportFolder = normalizeVaultPath(value) || DEFAULT_SETTINGS.pngExportFolder;
          await this.plugin.saveSettings();
        });
        text.inputEl.style.width = "360px";
      })
      .addButton((button) => {
        button.setButtonText("Open");
        button.onClick(async () => {
          await this.plugin.openVaultPath(this.plugin.settings.pngExportFolder);
        });
      });

    new obsidian.Setting(containerEl)
      .setName("PNG page width")
      .setDesc("Export width in pixels. Height is derived automatically as 9:16.")
      .addText((text) => {
        text.setValue(String(this.plugin.settings.pngPageWidth || DEFAULT_SETTINGS.pngPageWidth));
        text.onChange(async (value) => {
          const parsed = Number.parseInt(value, 10);
          this.plugin.settings.pngPageWidth = Number.isFinite(parsed) && parsed >= 720 ? parsed : DEFAULT_SETTINGS.pngPageWidth;
          await this.plugin.saveSettings();
        });
        text.inputEl.style.width = "120px";
      });

    new obsidian.Setting(containerEl)
      .setName("自定义 CSS 笔记")
      .setDesc("可以填写 CSS 文件路径，或一个含有首个 ```css``` 代码块的 Markdown 笔记。")
      .addText((text) => {
        text.setValue(this.plugin.settings.customCssNote);
        text.onChange(async (value) => {
          this.plugin.settings.customCssNote = value.trim();
          await this.plugin.saveSettings();
          await this.plugin.refreshOpenView();
        });
        text.inputEl.style.width = "360px";
      });

    new obsidian.Setting(containerEl)
      .setName("WeChat AppID")
      .setDesc("Used for WeChat official account draft publishing.")
      .addText((text) => {
        text.setValue(this.plugin.settings.wechatAppId || "");
        text.onChange(async (value) => {
          this.plugin.settings.wechatAppId = value.trim();
          this.plugin.wechatTokenCache = null;
          await this.plugin.saveSettings();
        });
        text.inputEl.style.width = "360px";
      });

    new obsidian.Setting(containerEl)
      .setName("WeChat AppSecret")
      .setDesc("Stored locally in plugin data. WeChat draft publishing uses this to request access_token.")
      .addText((text) => {
        text.setValue(this.plugin.settings.wechatAppSecret || "");
        text.onChange(async (value) => {
          this.plugin.settings.wechatAppSecret = value.trim();
          this.plugin.wechatTokenCache = null;
          await this.plugin.saveSettings();
        });
        text.inputEl.type = "password";
        text.inputEl.style.width = "360px";
      });

    new obsidian.Setting(containerEl)
      .setName("WeChat cover")
      .setDesc("Optional default cover path or URL. Frontmatter `wechat-cover`, `cover`, or `封面` overrides it.")
      .addText((text) => {
        text.setValue(this.plugin.settings.wechatCover || "");
        text.onChange(async (value) => {
          this.plugin.settings.wechatCover = value.trim();
          await this.plugin.saveSettings();
        });
        text.inputEl.style.width = "360px";
      });

    new obsidian.Setting(containerEl)
      .setName("Zhihu write URL")
      .setDesc("Default is https://zhuanlan.zhihu.com/write . The plugin opens this page and pre-copies rich HTML.")
      .addText((text) => {
        text.setValue(this.plugin.settings.zhihuWriteUrl || "");
        text.onChange(async (value) => {
          this.plugin.settings.zhihuWriteUrl = value.trim() || DEFAULT_SETTINGS.zhihuWriteUrl;
          await this.plugin.saveSettings();
        });
        text.inputEl.style.width = "360px";
      });

    new obsidian.Setting(containerEl)
      .setName("自动刷新预览")
      .setDesc("切换文件或当前笔记发生修改时自动刷新侧边预览。")
      .addToggle((toggle) => {
        toggle.setValue(this.plugin.settings.autoRefresh);
        toggle.onChange(async (value) => {
          this.plugin.settings.autoRefresh = value;
          await this.plugin.saveSettings();
        });
      });

    new obsidian.Setting(containerEl)
      .setName("发布后自动打开目录")
      .setDesc("从侧边栏执行本地发布后，自动打开对应输出目录。")
      .addToggle((toggle) => {
        toggle.setValue(this.plugin.settings.openFolderAfterPublish);
        toggle.onChange(async (value) => {
          this.plugin.settings.openFolderAfterPublish = value;
          await this.plugin.saveSettings();
        });
      });

    new obsidian.Setting(containerEl)
      .setName("历史记录保留条数")
      .setDesc("控制插件本地 history 的长度。")
      .addSlider((slider) => {
        slider.setLimits(5, 100, 1);
        slider.setValue(this.plugin.settings.historyLimit);
        slider.setDynamicTooltip();
        slider.onChange(async (value) => {
          this.plugin.settings.historyLimit = value;
          this.plugin.settings.history = truncateHistory(this.plugin.settings.history, value);
          await this.plugin.saveSettings();
          this.display();
        });
      });

    const history = Array.isArray(this.plugin.settings.history) ? this.plugin.settings.history : [];
    const historyEl = containerEl.createDiv({ cls: "lnp-history" });
    if (!history.length) {
      historyEl.setText("最近没有本地发布或快照记录。");
      return;
    }

    historyEl.createEl("strong", { text: "最近记录" });
    history.slice(0, 10).forEach((entry) => {
      historyEl.createDiv({
        text: `[${entry.type}] ${entry.title} -> ${entry.path}`
      });
    });
  }
}

module.exports = class LocalNotePublisherPlugin extends obsidian.Plugin {
  async onload() {
    await this.loadSettings();

    this.registerView(VIEW_TYPE, (leaf) => new LocalPublisherView(leaf, this));

    this.addRibbonIcon("clipboard-paste", "Open local publisher", async () => {
      await this.activateView();
    });

    this.addCommand({
      id: "open-local-publisher",
      name: "Open local publisher",
      callback: async () => {
        await this.activateView();
      }
    });

    this.addCommand({
      id: "publish-current-note-locally",
      name: "Publish current note locally",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!(file instanceof obsidian.TFile) || file.extension.toLowerCase() !== "md") {
          new obsidian.Notice("请先打开一个 Markdown 笔记。");
          return;
        }
        new LocalPublishModal(this.app, this, [file]).open();
      }
    });

    this.addCommand({
      id: "export-current-note-to-html",
      name: "Export current note to standalone HTML",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!(file instanceof obsidian.TFile) || file.extension.toLowerCase() !== "md") {
          new obsidian.Notice("请先打开一个 Markdown 笔记。");
          return;
        }
        await this.exportNoteAsDownload(file);
      }
    });

    this.addCommand({
      id: "export-current-note-to-png-pages",
      name: "Export current note to 9:16 PNG pages",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!(file instanceof obsidian.TFile) || file.extension.toLowerCase() !== "md") {
          new obsidian.Notice("Please open a Markdown note first.");
          return;
        }
        const folderPath = await this.exportNoteAsPngPages(file, { openAfter: this.settings.openFolderAfterPublish });
        new obsidian.Notice(`PNG pages exported: ${folderPath}`);
      }
    });

    this.addCommand({
      id: "save-current-note-snapshot",
      name: "Save current note snapshot",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!(file instanceof obsidian.TFile) || file.extension.toLowerCase() !== "md") {
          new obsidian.Notice("请先打开一个 Markdown 笔记。");
          return;
        }
        await this.saveSnapshot(file, { openAfter: false });
      }
    });

    this.addCommand({
      id: "send-current-note-to-wechat",
      name: "Send current note to WeChat draft",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!(file instanceof obsidian.TFile) || file.extension.toLowerCase() !== "md") {
          new obsidian.Notice("Please open a Markdown note first.");
          return;
        }
        const mediaId = await this.sendNoteToWeChat(file);
        new obsidian.Notice(`WeChat draft created: ${mediaId}`);
      }
    });

    this.addCommand({
      id: "send-current-note-to-zhihu",
      name: "Send current note to Zhihu editor",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!(file instanceof obsidian.TFile) || file.extension.toLowerCase() !== "md") {
          new obsidian.Notice("Please open a Markdown note first.");
          return;
        }
        await this.sendNoteToZhihu(file);
        new obsidian.Notice("Zhihu editor opened and rich HTML copied.");
      }
    });

    this.addCommand({
      id: "open-publish-folder",
      name: "Open publish folder",
      callback: async () => {
        await this.openVaultPath(this.settings.exportFolder);
      }
    });

    this.addCommand({
      id: "open-snapshot-folder",
      name: "Open snapshot folder",
      callback: async () => {
        await this.openVaultPath(this.settings.snapshotFolder);
      }
    });

    this.addSettingTab(new LocalPublisherSettingTab(this.app, this));

    this.registerEvent(this.app.workspace.on("file-open", async (file) => {
      if (!this.settings.autoRefresh) {
        return;
      }
      await this.refreshOpenView(file);
    }));

    this.registerEvent(this.app.vault.on("modify", async (file) => {
      if (!this.settings.autoRefresh) {
        return;
      }
      const activeFile = this.app.workspace.getActiveFile();
      if (activeFile && file instanceof obsidian.TFile && file.path === activeFile.path) {
        await this.refreshOpenView(file);
      }
    }));

    this.registerEvent(this.app.workspace.on("file-menu", (menu, file) => {
      if (file instanceof obsidian.TFile && file.extension.toLowerCase() === "md") {
        menu.addItem((item) => {
          item
            .setTitle("本地发布为文章包")
            .setIcon("clipboard-paste")
            .onClick(() => {
              new LocalPublishModal(this.app, this, [file]).open();
            });
        });
        menu.addItem((item) => {
          item
            .setTitle("Export to 9:16 PNG pages")
            .setIcon("image")
            .onClick(async () => {
              const folderPath = await this.exportNoteAsPngPages(file, { openAfter: this.settings.openFolderAfterPublish });
              new obsidian.Notice(`PNG pages exported: ${folderPath}`);
            });
        });
        menu.addItem((item) => {
          item
            .setTitle("Send to WeChat draft")
            .setIcon("send")
            .onClick(async () => {
              const mediaId = await this.sendNoteToWeChat(file);
              new obsidian.Notice(`WeChat draft created: ${mediaId}`);
            });
        });
        menu.addItem((item) => {
          item
            .setTitle("Send to Zhihu editor")
            .setIcon("send")
            .onClick(async () => {
              await this.sendNoteToZhihu(file);
              new obsidian.Notice("Zhihu editor opened and rich HTML copied.");
            });
        });
      }

      if (file instanceof obsidian.TFolder) {
        menu.addItem((item) => {
          item
            .setTitle("本地发布文件夹内 Markdown")
            .setIcon("folder-open")
            .onClick(() => {
              const notes = this.collectFolderNotes(file);
              if (!notes.length) {
                new obsidian.Notice("这个文件夹里没有 Markdown 笔记。");
                return;
              }
              new LocalPublishModal(this.app, this, notes).open();
            });
        });
      }
    }));

    this.registerEvent(this.app.workspace.on("files-menu", (menu, files) => {
      const notes = files.filter((file) => file instanceof obsidian.TFile && file.extension.toLowerCase() === "md");
      if (!notes.length) {
        return;
      }
      menu.addItem((item) => {
          item
            .setTitle("本地批量发布所选笔记")
            .setIcon("clipboard-paste")
          .onClick(() => {
            new LocalPublishModal(this.app, this, notes).open();
          });
      });
    }));
  }

  onunload() {
    this.app.workspace.getLeavesOfType(VIEW_TYPE).forEach((leaf) => leaf.detach());
  }

  async loadSettings() {
    const data = await this.loadData();
    this.settings = Object.assign({}, DEFAULT_SETTINGS, data || {});
    if (!Array.isArray(this.settings.history)) {
      this.settings.history = [];
    }
    this.settings.exportFolder = normalizeVaultPath(this.settings.exportFolder) || DEFAULT_SETTINGS.exportFolder;
    this.settings.snapshotFolder = normalizeVaultPath(this.settings.snapshotFolder) || DEFAULT_SETTINGS.snapshotFolder;
  }

  async saveSettings() {
    this.settings.history = truncateHistory(this.settings.history || [], this.settings.historyLimit);
    await this.saveData(this.settings);
  }

  async activateView() {
    const { workspace } = this.app;
    let leaf = workspace.getLeavesOfType(VIEW_TYPE)[0];
    if (!leaf) {
      leaf = workspace.getRightLeaf(false);
      await leaf.setViewState({ type: VIEW_TYPE, active: true });
    }
    await workspace.revealLeaf(leaf);
    await this.refreshOpenView();
  }

  getOpenView() {
    const leaf = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    return leaf ? leaf.view : null;
  }

  async refreshOpenView(file) {
    const view = this.getOpenView();
    if (view && typeof view.renderCurrentFile === "function") {
      await view.renderCurrentFile(file);
    }
  }

  collectFolderNotes(folder) {
    return folder.children
      .filter((child) => child instanceof obsidian.TFile && child.extension.toLowerCase() === "md")
      .sort((a, b) => a.path.localeCompare(b.path));
  }

  getNoteMeta(file) {
    const frontmatter = this.app.metadataCache.getFileCache(file)?.frontmatter || {};
    const theme = firstNonEmpty(
      getFrontmatterValue(frontmatter, "local-publisher-theme"),
      getFrontmatterValue(frontmatter, "样式"),
      getFrontmatterValue(frontmatter, "theme"),
      this.settings.defaultTheme
    );
    const highlight = firstNonEmpty(
      getFrontmatterValue(frontmatter, "local-publisher-highlight"),
      getFrontmatterValue(frontmatter, "代码高亮"),
      getFrontmatterValue(frontmatter, "highlight"),
      this.settings.defaultHighlight
    );
    return {
      title: firstNonEmpty(
        getFrontmatterValue(frontmatter, "title"),
        getFrontmatterValue(frontmatter, "标题"),
        file.basename
      ),
      description: firstNonEmpty(
        getFrontmatterValue(frontmatter, "description"),
        getFrontmatterValue(frontmatter, "摘要")
      ),
      author: firstNonEmpty(
        getFrontmatterValue(frontmatter, "author"),
        getFrontmatterValue(frontmatter, "作者")
      ),
      date: firstNonEmpty(
        getFrontmatterValue(frontmatter, "date"),
        getFrontmatterValue(frontmatter, "日期")
      ),
      theme: THEMES[theme] ? theme : this.settings.defaultTheme,
      highlight: HIGHLIGHTS[highlight] ? highlight : this.settings.defaultHighlight,
      cssNote: firstNonEmpty(
        getFrontmatterValue(frontmatter, "local-publisher-css"),
        getFrontmatterValue(frontmatter, "css-note"),
        getFrontmatterValue(frontmatter, "custom-css-note")
      )
    };
  }

  findFile(nameOrPath, baseFile) {
    const direct = this.app.metadataCache.getFirstLinkpathDest(nameOrPath, baseFile ? baseFile.path : "");
    if (direct) {
      return direct;
    }

    const normalized = normalizeVaultPath(nameOrPath);
    if (normalized) {
      const byPath = this.app.vault.getFileByPath(normalized);
      if (byPath) {
        return byPath;
      }
    }

    return this.app.vault.getAllLoadedFiles().find((file) => file instanceof obsidian.TFile && (file.path === nameOrPath || file.name === nameOrPath || file.basename === nameOrPath)) || null;
  }

  async loadCustomCss(file, meta) {
    const target = firstNonEmpty(meta && meta.cssNote, this.settings.customCssNote);
    if (!target) {
      return "";
    }
    const customFile = this.findFile(target, file);
    if (!(customFile instanceof obsidian.TFile)) {
      new obsidian.Notice(`找不到自定义 CSS 笔记: ${target}`);
      return "";
    }
    const content = await this.app.vault.cachedRead(customFile);
    if (customFile.extension.toLowerCase() === "css") {
      return content;
    }
    const raw = stripFrontmatter(content);
    const fenced = raw.match(/```css\s*([\s\S]*?)```/i);
    if (fenced) {
      return fenced[1].trim();
    }
    return raw.trim();
  }

  async buildCss(file, meta) {
    const theme = THEMES[meta.theme] || THEMES[DEFAULT_SETTINGS.defaultTheme];
    const highlight = HIGHLIGHTS[meta.highlight] || HIGHLIGHTS[DEFAULT_SETTINGS.defaultHighlight];
    const customCss = await this.loadCustomCss(file, meta);
    return [BASE_ARTICLE_CSS, theme.css, highlight.css, customCss].filter(Boolean).join("\n\n");
  }

  buildHtmlDocument(title, css, articleHtml) {
    return [
      "<!DOCTYPE html>",
      "<html lang=\"zh-CN\">",
      "<head>",
      "<meta charset=\"utf-8\" />",
      "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />",
      `<title>${escapeHtml(title)}</title>`,
      `<style>${css}</style>`,
      "</head>",
      "<body>",
      articleHtml,
      "</body>",
      "</html>"
    ].join("");
  }

  async createRenderArtifacts(file, options = {}) {
    const meta = this.getNoteMeta(file);
    const css = await this.buildCss(file, meta);
    const sandbox = document.createElement("div");
    document.body.appendChild(sandbox);
    sandbox.style.position = "fixed";
    sandbox.style.left = "-100000px";
    sandbox.style.top = "0";
    sandbox.style.width = "860px";
    sandbox.style.opacity = "0";
    sandbox.style.pointerEvents = "none";

    const styleEl = document.createElement("style");
    styleEl.textContent = css;
    sandbox.appendChild(styleEl);

    const articleEl = document.createElement("div");
    articleEl.className = "lnp-article";
    sandbox.appendChild(articleEl);
    const component = new obsidian.Component();
    component.load();

    try {
      const markdown = stripFrontmatter(await this.app.vault.cachedRead(file));
      await renderMarkdownInto(this.app, markdown, articleEl, file.path, component);
      if (options.inlineStyles) {
        inlineComputedStyles(articleEl);
      }
      if (options.inlineImages) {
        await inlineImagesInElement(articleEl);
      }

      const articleHtml = articleEl.outerHTML;
      const text = articleEl.textContent ? articleEl.textContent.trim() : "";
      return {
        meta,
        css,
        articleHtml,
        text,
        documentHtml: this.buildHtmlDocument(meta.title, css, articleHtml)
      };
    } finally {
      component.unload();
      sandbox.remove();
    }
  }

  async copyNoteAsHtml(file) {
    const artifacts = await this.createRenderArtifacts(file, { inlineStyles: true, inlineImages: true });
    clipboard.write({
      html: artifacts.articleHtml,
      text: artifacts.text
    });
    new obsidian.Notice(`已复制 ${file.basename} 的富 HTML`);
  }

  async exportNoteAsDownload(file) {
    const artifacts = await this.createRenderArtifacts(file, { inlineImages: true });
    const blob = new Blob([artifacts.documentHtml], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${safeFilename(artifacts.meta.title)}.html`;
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    new obsidian.Notice(`已导出 ${artifacts.meta.title}.html`);
  }

  async getWeChatAccessToken() {
    if (!this.settings.wechatAppId || !this.settings.wechatAppSecret) {
      throw new Error("Please set WeChat AppID and AppSecret in plugin settings first.");
    }

    const now = Date.now();
    if (this.wechatTokenCache && this.wechatTokenCache.expiresAt > now + 60 * 1000) {
      return this.wechatTokenCache.value;
    }

    const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${encodeURIComponent(this.settings.wechatAppId)}&secret=${encodeURIComponent(this.settings.wechatAppSecret)}`;
    const response = await obsidian.requestUrl({
      url,
      method: "GET",
      throw: false
    });
    const data = response.json || {};
    if (response.status !== 200 || data.errcode || !data.access_token) {
      throw new Error(data.errmsg || `Unable to get WeChat access token (${response.status}).`);
    }

    this.wechatTokenCache = {
      value: data.access_token,
      expiresAt: now + (data.expires_in || 7200) * 1000
    };

    return this.wechatTokenCache.value;
  }

  async uploadWeChatImageBlob(accessToken, blob, filename, permanent = false) {
    const endpoint = permanent
      ? `https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=${accessToken}&type=image`
      : `https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=${accessToken}`;
    const form = new FormData();
    form.append("media", blob, filename || "image.png");
    const response = await fetch(endpoint, {
      method: "POST",
      body: form
    });
    const data = await response.json();
    if (!response.ok || data.errcode) {
      throw new Error(data.errmsg || `WeChat image upload failed (${response.status}).`);
    }
    return data;
  }

  async resolveBlobFromValue(value, baseFile) {
    if (!value) {
      return null;
    }

    const cleaned = String(value)
      .trim()
      .replace(/^!\[\[/, "")
      .replace(/^\[\[/, "")
      .replace(/\]\]$/, "");

    if (/^https?:\/\//i.test(cleaned)) {
      return fetchBlobFromSrc(cleaned);
    }

    const file = this.findFile(cleaned, baseFile);
    if (!(file instanceof obsidian.TFile)) {
      return null;
    }

    const binary = await this.app.vault.readBinary(file);
    return new Blob([binary]);
  }

  getWeChatCoverValue(file) {
    const frontmatter = this.app.metadataCache.getFileCache(file)?.frontmatter || {};
    return firstNonEmpty(
      getFrontmatterValue(frontmatter, "wechat-cover"),
      getFrontmatterValue(frontmatter, "local-publisher-cover"),
      getFrontmatterValue(frontmatter, "cover"),
      getFrontmatterValue(frontmatter, "封面"),
      this.settings.wechatCover
    );
  }

  async sendNoteToWeChat(file) {
    const accessToken = await this.getWeChatAccessToken();
    const artifacts = await this.createRenderArtifacts(file, { inlineStyles: true });
    const articleDoc = document.createElement("div");
    articleDoc.innerHTML = artifacts.articleHtml;
    const articleEl = articleDoc.firstElementChild;

    if (!articleEl) {
      throw new Error("Unable to build WeChat article content.");
    }

    const uploadedImages = [];
    const imageElements = Array.from(articleEl.querySelectorAll("img"));
    for (let index = 0; index < imageElements.length; index += 1) {
      const imageEl = imageElements[index];
      const src = imageEl.getAttribute("src");
      if (!src) {
        continue;
      }
      const blob = await fetchBlobFromSrc(src);
      uploadedImages.push({
        blob,
        filename: inferFilenameFromSrc(src, `image-${index + 1}.png`)
      });
      const uploaded = await this.uploadWeChatImageBlob(accessToken, blob, uploadedImages[uploadedImages.length - 1].filename, false);
      if (uploaded.url) {
        imageEl.setAttribute("src", uploaded.url);
      }
    }

    let coverBlob = await this.resolveBlobFromValue(this.getWeChatCoverValue(file), file);
    if (!coverBlob && uploadedImages.length) {
      coverBlob = uploadedImages[0].blob;
    }
    if (!coverBlob) {
      throw new Error("WeChat draft requires a cover. Set frontmatter `cover`/`封面`, plugin setting `WeChat cover`, or add at least one image to the note.");
    }

    const coverUpload = await this.uploadWeChatImageBlob(accessToken, coverBlob, "cover.png", true);
    if (!coverUpload.media_id) {
      throw new Error("WeChat cover upload did not return media_id.");
    }

    const response = await obsidian.requestUrl({
      url: `https://api.weixin.qq.com/cgi-bin/draft/add?access_token=${accessToken}`,
      method: "POST",
      throw: false,
      contentType: "application/json",
      body: JSON.stringify({
        articles: [
          {
            title: artifacts.meta.title,
            author: artifacts.meta.author || "",
            digest: artifacts.meta.description || "",
            content: articleEl.outerHTML,
            thumb_media_id: coverUpload.media_id
          }
        ]
      })
    });
    const data = response.json || {};
    if (response.status !== 200 || data.errcode || !data.media_id) {
      throw new Error(data.errmsg || `WeChat draft publish failed (${response.status}).`);
    }

    this.pushHistory({
      type: "wechat-draft",
      title: artifacts.meta.title,
      path: `wechat:${data.media_id}`,
      createdAt: new Date().toISOString()
    });

    return data.media_id;
  }

  async sendNoteToZhihu(file) {
    const writeUrl = this.settings.zhihuWriteUrl || "https://zhuanlan.zhihu.com/write";
    const artifacts = await this.createRenderArtifacts(file, { inlineStyles: true, inlineImages: true });
    clipboard.write({
      html: artifacts.articleHtml,
      text: artifacts.text
    });
    await shell.openExternal(writeUrl);
    this.pushHistory({
      type: "zhihu-copy",
      title: artifacts.meta.title,
      path: writeUrl,
      createdAt: new Date().toISOString()
    });
    return writeUrl;
  }

  async renderPageElementToPngBlob(pageElement, width, height) {
    const mount = document.createElement("div");
    mount.style.position = "fixed";
    mount.style.left = "-100000px";
    mount.style.top = "0";
    mount.style.opacity = "0";
    mount.style.pointerEvents = "none";
    mount.appendChild(pageElement);
    document.body.appendChild(mount);

    try {
      await waitForImages(pageElement);
      await waitForAnimationFrames(2);

      const clone = pageElement.cloneNode(true);
      clone.setAttribute("xmlns", "http://www.w3.org/1999/xhtml");
      const serialized = new XMLSerializer().serializeToString(clone);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><foreignObject width="100%" height="100%">${serialized}</foreignObject></svg>`;
      const svgUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;

      try {
        const image = new Image();
        await new Promise((resolve, reject) => {
          image.onload = () => resolve();
          image.onerror = (error) => reject(error || new Error("Unable to load SVG page into image."));
          image.src = svgUrl;
        });

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext("2d");
        if (!context) {
          throw new Error("Unable to create 2D canvas context.");
        }
        context.drawImage(image, 0, 0, width, height);

        const pngBlob = await new Promise((resolve, reject) => {
          canvas.toBlob((blob) => {
            if (blob) {
              resolve(blob);
              return;
            }
            reject(new Error("Canvas export returned an empty PNG blob."));
          }, "image/png");
        });

        return pngBlob;
      }
    } finally {
      mount.remove();
    }
  }

  buildPngPageElement(articleTemplate, blocks, pagePlan, options, pageNumber, totalPages) {
    const page = document.createElement("div");
    page.style.boxSizing = "border-box";
    page.style.width = `${options.pageWidth}px`;
    page.style.height = `${options.pageHeight}px`;
    page.style.padding = `${options.paddingTop}px ${options.paddingX}px ${options.paddingBottom}px`;
    page.style.background = "radial-gradient(circle at top, rgba(120, 170, 220, 0.12), transparent 42%), linear-gradient(180deg, #edf2f7 0%, #f7fafc 100%)";
    page.style.position = "relative";
    page.style.overflow = "hidden";

    const viewport = document.createElement("div");
    viewport.style.width = "100%";
    viewport.style.height = `${options.contentHeight}px`;
    viewport.style.overflow = "hidden";
    viewport.style.display = "flex";
    viewport.style.justifyContent = "center";
    viewport.style.position = "relative";

    const articleEl = articleTemplate.cloneNode(false);
    articleEl.style.margin = "0 auto";

    if (pagePlan.mode === "blocks") {
      for (let index = pagePlan.startIndex; index <= pagePlan.endIndex; index += 1) {
        articleEl.appendChild(blocks[index].element.cloneNode(true));
      }
    } else if (pagePlan.mode === "clip") {
      const wrapper = document.createElement("div");
      wrapper.style.height = `${options.contentHeight}px`;
      wrapper.style.overflow = "hidden";

      const shifted = document.createElement("div");
      shifted.style.transform = `translateY(-${pagePlan.localOffset}px)`;
      shifted.style.willChange = "transform";
      shifted.appendChild(blocks[pagePlan.blockIndex].element.cloneNode(true));

      wrapper.appendChild(shifted);
      articleEl.appendChild(wrapper);
    }

    viewport.appendChild(articleEl);
    page.appendChild(viewport);

    const badge = document.createElement("div");
    badge.textContent = `${pageNumber}/${totalPages}`;
    badge.style.position = "absolute";
    badge.style.right = `${options.paddingX}px`;
    badge.style.bottom = "36px";
    badge.style.fontFamily = "\"Segoe UI\", \"Microsoft YaHei\", sans-serif";
    badge.style.fontSize = "24px";
    badge.style.color = "#748091";
    badge.style.letterSpacing = "0.04em";
    page.appendChild(badge);

    return page;
  }

  async exportNoteAsPngPages(file, options = {}) {
    const artifacts = await this.createRenderArtifacts(file, { inlineStyles: true, inlineImages: true });
    const pageWidth = Math.max(720, Number(this.settings.pngPageWidth) || DEFAULT_SETTINGS.pngPageWidth);
    const pageHeight = Math.round(pageWidth * 16 / 9);
    const paddingX = Math.round(pageWidth * 0.1);
    const paddingTop = Math.round(pageWidth * 0.11);
    const paddingBottom = Math.round(pageWidth * 0.11);
    const contentHeight = pageHeight - paddingTop - paddingBottom;

    const measureHost = document.createElement("div");
    measureHost.style.position = "fixed";
    measureHost.style.left = "-100000px";
    measureHost.style.top = "0";
    measureHost.style.width = `${pageWidth}px`;
    measureHost.style.padding = `${paddingTop}px ${paddingX}px ${paddingBottom}px`;
    measureHost.style.boxSizing = "border-box";
    measureHost.style.opacity = "0";
    measureHost.style.pointerEvents = "none";
    measureHost.innerHTML = artifacts.articleHtml;
    document.body.appendChild(measureHost);

    try {
      await waitForImages(measureHost);
      await waitForAnimationFrames(2);

      const articleEl = measureHost.firstElementChild;
      if (!articleEl) {
        throw new Error("Unable to measure article height for PNG export.");
      }
      articleEl.style.margin = "0 auto";

      const blocks = getTopLevelPageBlocks(articleEl);
      const pagePlan = buildSmartPagePlan(blocks, contentHeight);
      const pageCount = Math.max(1, pagePlan.length);
      const timestamp = formatTimestamp(new Date());
      const exportFolder = joinVaultPath(this.settings.pngExportFolder || DEFAULT_SETTINGS.pngExportFolder, `${timestamp}-${slugify(file.basename)}`);
      await ensureFolder(this.app.vault.adapter, exportFolder);

      for (let index = 0; index < pagePlan.length; index += 1) {
        const pageElement = this.buildPngPageElement(articleEl, blocks, pagePlan[index], {
          pageWidth,
          pageHeight,
          paddingX,
          paddingTop,
          paddingBottom,
          contentHeight
        }, index + 1, pageCount);
        const pngBlob = await this.renderPageElementToPngBlob(pageElement, pageWidth, pageHeight);
        const pngPath = joinVaultPath(exportFolder, `${String(index + 1).padStart(2, "0")}.png`);
        await this.app.vault.adapter.writeBinary(pngPath, await pngBlob.arrayBuffer());
      }

      await this.app.vault.adapter.write(joinVaultPath(exportFolder, "manifest.json"), JSON.stringify({
        sourcePath: file.path,
        title: artifacts.meta.title,
        createdAt: new Date().toISOString(),
        pageWidth,
        pageHeight,
        aspectRatio: "9:16",
        pageCount,
        pagePlan: pagePlan.map((item) => {
          if (item.mode === "blocks") {
            return {
              mode: item.mode,
              startIndex: item.startIndex,
              endIndex: item.endIndex
            };
          }
          return {
            mode: item.mode,
            blockIndex: item.blockIndex,
            localOffset: item.localOffset
          };
        })
      }, null, 2));

      this.pushHistory({
        type: "png-export",
        title: artifacts.meta.title,
        path: exportFolder,
        createdAt: new Date().toISOString()
      });

      if (options.openAfter) {
        await this.openVaultPath(exportFolder);
      }

      return exportFolder;
    } finally {
      measureHost.remove();
    }
  }

  async publishNotes(files, options = {}) {
    const markdownFiles = files.filter((file) => file instanceof obsidian.TFile && file.extension.toLowerCase() === "md");
    if (!markdownFiles.length) {
      throw new Error("没有可发布的 Markdown 笔记。");
    }

    const timestamp = formatTimestamp(new Date());
    const bundleLabel = markdownFiles.length === 1 ? slugify(markdownFiles[0].basename) : `bundle-${markdownFiles.length}-notes`;
    const bundlePath = joinVaultPath(this.settings.exportFolder, `${timestamp}-${bundleLabel}`);
    await ensureFolder(this.app.vault.adapter, bundlePath);

    const manifest = {
      createdAt: new Date().toISOString(),
      noteCount: markdownFiles.length,
      files: []
    };

    for (let index = 0; index < markdownFiles.length; index += 1) {
      const file = markdownFiles[index];
      const onProgress = options.onProgress;
      if (onProgress) {
        onProgress(file, "running", "处理中");
      }
      try {
        const artifacts = await this.createRenderArtifacts(file, { inlineImages: true });
        const stem = `${String(index + 1).padStart(2, "0")}-${safeFilename(artifacts.meta.title)}`;
        const htmlPath = joinVaultPath(bundlePath, `${stem}.html`);
        const metaPath = joinVaultPath(bundlePath, `${stem}.json`);
        await this.app.vault.adapter.write(htmlPath, artifacts.documentHtml);
        await this.app.vault.adapter.write(metaPath, JSON.stringify({
          sourcePath: file.path,
          title: artifacts.meta.title,
          description: artifacts.meta.description,
          author: artifacts.meta.author,
          date: artifacts.meta.date,
          theme: artifacts.meta.theme,
          highlight: artifacts.meta.highlight,
          createdAt: new Date().toISOString()
        }, null, 2));
        manifest.files.push({
          title: artifacts.meta.title,
          sourcePath: file.path,
          htmlPath,
          metaPath
        });
        if (onProgress) {
          onProgress(file, "done", "已完成");
        }
      } catch (error) {
        if (options.onProgress) {
          options.onProgress(file, "error", "失败");
        }
        throw error;
      }
    }

    await this.app.vault.adapter.write(joinVaultPath(bundlePath, "manifest.json"), JSON.stringify(manifest, null, 2));
    this.pushHistory({
      type: "publish",
      title: markdownFiles.length === 1 ? markdownFiles[0].basename : `${markdownFiles.length} notes`,
      path: bundlePath,
      createdAt: new Date().toISOString()
    });

    if (options.openAfter) {
      await this.openVaultPath(bundlePath);
    }

    new obsidian.Notice(`本地发布完成: ${bundlePath}`);
    return bundlePath;
  }

  async saveSnapshot(file, options = {}) {
    const artifacts = await this.createRenderArtifacts(file, { inlineImages: true });
    const timestamp = formatTimestamp(new Date());
    const stem = `${timestamp}-${safeFilename(artifacts.meta.title)}`;
    const htmlPath = joinVaultPath(this.settings.snapshotFolder, `${stem}.html`);
    const metaPath = joinVaultPath(this.settings.snapshotFolder, `${stem}.json`);
    await ensureFolder(this.app.vault.adapter, this.settings.snapshotFolder);
    await this.app.vault.adapter.write(htmlPath, artifacts.documentHtml);
    await this.app.vault.adapter.write(metaPath, JSON.stringify({
      sourcePath: file.path,
      title: artifacts.meta.title,
      description: artifacts.meta.description,
      author: artifacts.meta.author,
      date: artifacts.meta.date,
      theme: artifacts.meta.theme,
      highlight: artifacts.meta.highlight,
      createdAt: new Date().toISOString()
    }, null, 2));

    this.pushHistory({
      type: "snapshot",
      title: artifacts.meta.title,
      path: htmlPath,
      createdAt: new Date().toISOString()
    });

    if (options.openAfter) {
      await this.openVaultPath(this.settings.snapshotFolder);
    }

    new obsidian.Notice(`快照已保存: ${htmlPath}`);
    return htmlPath;
  }

  pushHistory(entry) {
    this.settings.history = [entry, ...(this.settings.history || [])];
    this.settings.history = truncateHistory(this.settings.history, this.settings.historyLimit);
    this.saveSettings();
  }

  async openVaultPath(vaultPath) {
    const adapter = this.app.vault.adapter;
    if (typeof adapter.getBasePath !== "function") {
      new obsidian.Notice("当前适配器不支持打开本地目录。");
      return;
    }

    const normalized = normalizeVaultPath(vaultPath);
    if (normalized && !/\.[a-z0-9]+$/i.test(normalized)) {
      await ensureFolder(adapter, normalized);
    }
    const absolute = path.join(adapter.getBasePath(), normalized);
    await shell.openPath(absolute);
  }
};

param(
    [switch]$OverwriteExisting
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$repoRoot = "F:\github\sohao-AI"
$inboxDir = Join-Path $repoRoot "00_Inbox"
$sourcesDir = Join-Path $repoRoot "01_Sources"

function Escape-DoubleQuotedYaml {
    param(
        [AllowNull()]
        [string]$Value
    )

    if ($null -eq $Value) {
        return ""
    }

    return $Value.Replace('\', '\\').Replace('"', '\"')
}

function Get-MetadataValue {
    param(
        [string[]]$Lines,
        [string]$Prefix
    )

    $line = $Lines | Where-Object { $_ -like "$Prefix*" } | Select-Object -First 1
    if (-not $line) {
        return ""
    }

    return $line.Substring($Prefix.Length).Trim()
}

function Get-SourceUrl {
    param(
        [string]$RawValue
    )

    if ([string]::IsNullOrWhiteSpace($RawValue)) {
        return ""
    }

    if ($RawValue -match '\((https?://[^)]+)\)') {
        return $matches[1].Trim()
    }

    if ($RawValue -match 'https?://\S+') {
        return $matches[0].Trim()
    }

    return $RawValue.Trim()
}

if (-not (Test-Path -LiteralPath $sourcesDir)) {
    New-Item -ItemType Directory -Path $sourcesDir | Out-Null
}

$created = 0
$skipped = 0

Get-ChildItem -LiteralPath $inboxDir -File -Filter *.md | Sort-Object Name | ForEach-Object {
    $inboxFile = $_
    $targetFile = Join-Path $sourcesDir $inboxFile.Name

    if ((Test-Path -LiteralPath $targetFile) -and (-not $OverwriteExisting)) {
        $skipped++
        return
    }

    $rawLines = Get-Content -LiteralPath $inboxFile.FullName -Encoding utf8
    $rawLink = Get-MetadataValue -Lines $rawLines -Prefix "视频链接："
    $publishedDate = Get-MetadataValue -Lines $rawLines -Prefix "视频发布时间："
    $channel = Get-MetadataValue -Lines $rawLines -Prefix "频道名："

    $sourceUrl = Get-SourceUrl -RawValue $rawLink

    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($inboxFile.Name)
    $title = $baseName
    $fileDate = ""

    if ($baseName -match '^(\d{4}-\d{2}-\d{2})\+(.*)$') {
        $fileDate = $matches[1]
        $title = $matches[2]
    }

    if ([string]::IsNullOrWhiteSpace($publishedDate)) {
        $publishedDate = $fileDate
    }

    $sourceType = if ([string]::IsNullOrWhiteSpace($sourceUrl)) { "转录来源" } else { "视频转录" }
    $channelDisplay = if ([string]::IsNullOrWhiteSpace($channel)) { "待补充" } else { $channel }
    $dateDisplay = if ([string]::IsNullOrWhiteSpace($publishedDate)) { "待补充" } else { $publishedDate }
    $linkDisplay = if ([string]::IsNullOrWhiteSpace($sourceUrl)) { "待补充" } else { "[原始链接]($sourceUrl)" }

    $summary = "该来源已从 00_Inbox 标准化迁移到 01_Sources；当前保留原始标题、链接、频道与转录，待进一步精读拆卡。"

    $content = @"
---
type: 来源
title: "$(Escape-DoubleQuotedYaml $title)"
date: "$(Escape-DoubleQuotedYaml $publishedDate)"
status: 待拆解
summary: "$(Escape-DoubleQuotedYaml $summary)"
my_take: ""
source_notes: []
related_notes:
  - "[[00_Inbox/$(Escape-DoubleQuotedYaml $baseName)]]"
tags:
  - 来源
  - AI研究
  - Inbox迁移
source_type: "$(Escape-DoubleQuotedYaml $sourceType)"
source_url: "$(Escape-DoubleQuotedYaml $sourceUrl)"
author: "$(Escape-DoubleQuotedYaml $channel)"
---

# $title

## 一、来源信息
- 来源名称：$channelDisplay
- 日期：$dateDisplay
- 链接：$linkDisplay
- 原始文件：[[00_Inbox/$baseName]]

## 二、内容摘要
1. 当前已完成从 ``00_Inbox`` 到 ``01_Sources`` 的标准化收录。
2. 该来源原始主题见标题：$title
3. 原始转录内容仍保留在 Inbox 文件中，待进一步精读与拆卡。

## 三、可拆解对象
### 人物
- 待精读判断

### 公司
- 待精读判断

### 产品
- 待精读判断

### 市场
- 待精读判断

## 四、初步信号
- 该来源已进入来源库，待后续按“人物 / 公司 / 产品 / 市场 / thesis”继续拆解。
- 原始链接与转录已保留，适合作为后续研究的可回溯证据。

## 五、我的判断
这条内容更像人物思想、公司动作、产品更新，还是市场反馈？
它值不值得继续拆成结构化对象？

## 六、原始转录
- 见：[[00_Inbox/$baseName]]
"@

    Set-Content -LiteralPath $targetFile -Value $content -Encoding utf8
    $created++
}

Write-Output "Created=$created"
Write-Output "Skipped=$skipped"

---
type: 产品
name: "Claude Cowork"
date: "2026-04-20"
status: 进行中
summary: "当前来源把 Claude Cowork 描述为从编码代理外溢到企业知识工作的代表性产品：它不只会聊天，而是能调用工具、使用本地文件、拆解任务并持续执行。"
my_take: ""
source_notes:
  - "[[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]"
  - "[[01_Sources/2026-04-12+Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡]]"
related_notes:
  - "[[03_Companies/Anthropic]]"
  - "[[05_Markets/AI代理与企业知识工作市场]]"
tags:
  - 产品
  - AI研究
  - 代理
  - 企业知识工作
  - Anthropic
company: "Anthropic"
category: "企业代理 / 知识工作代理"
target_users: "非技术知识工作者 / 企业团队"
---

# 产品研究卡

## 产品概况

- 所属公司：Anthropic
- 产品类别：企业代理 / 知识工作代理
- 目标用户：非技术知识工作者、企业团队

## 核心功能

- 处理复杂多步骤任务，而不只是单轮对话。
- 使用本地计算机、本地文件和工具链完成工作。
- 能把通用任务拆成多个子任务并持续执行。
- 通过 `skills` 这种 markdown 指令层来复用能力。
- 记忆主要由 harness 层承载，而不是完全依赖模型内部状态。

## 典型场景

- 法律、销售、营销等非技术知识工作。
- 企业中的综合资料整理、工作流执行、文档与文件操作。
- 需要访问本地环境或本地文件的任务。
- 来源中还提到在医疗相关知识工作里也有帮助。

## 市场用途与反馈

- 来源把 Cowork 视为 AI 代理从 coding 场景迈向 general knowledge work 的关键产品。
- 市场把其某些文件能力扩展解读为 `SaaS apocalypse` 信号之一，说明外界认为它可能侵蚀垂直 SaaS 价值。
- 产品侧最核心的难点之一不是单次能力，而是如何逐步建立用户信任。

## 竞争替代

- 替代对象之一：纯聊天式 AI 助手。
- 替代对象之二：只会编码、不会处理更广泛知识工作的 coding agents。
- 替代对象之三：缺乏本地工具访问和任务拆解能力的 cloud-only agent 体验。

## 证据来源

- [[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie|来源：OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]
- [[01_Sources/2026-04-12+Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡|来源：Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡]]

## 我的判断

- 暂不补充额外判断，等待更多真实企业采用案例。

## 待验证问题

- 本地优先设计是否会成为知识工作代理的长期主流。
- `skills + memory + tool use` 这套组合是否足以形成稳定护城河。

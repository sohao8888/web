---
type: 产品
name: "Claude Opus 4.7"
date: "2026-04-20"
status: 进行中
summary: "当前多条来源把 Claude Opus 4.7 描述为一次可靠且偏产品化的模型升级，重点在 advanced software engineering、vision、reasoning 配置和 agent 工作流可用性。"
my_take: ""
source_notes:
  - "[[01_Sources/2026-04-19+萨姆·奥特曼的攻击、亚马逊与星链之争，以及 Opus 4.7 的真正含义 #248]]"
  - "[[01_Sources/2026-04-17+Claude Opus 4.7 太疯狂了——这是目前为止最好的型号吗？]]"
related_notes:
  - "[[03_Companies/Anthropic]]"
tags:
  - 产品
  - AI研究
  - 模型发布
  - Agent
  - computer use
company: "Anthropic"
category: "大模型 / Agent 工作流产品"
target_users: "开发者 / 企业工作流用户"
---

# 产品研究卡

## 产品概况

- 所属公司：Anthropic
- 产品类别：大模型 / Agent 工作流产品
- 目标用户：开发者、企业工作流用户

## 核心功能

- 图像输入尺寸较此前版本显著提升。
- 在 computer use 场景中的能力被描述为提升。
- 更适合 agent 工作流与较长上下文任务。
- 控制接口上，显式参数旋钮减少，更依赖 prompt 进行控制。
- 相比 Opus 4.6，在 advanced software engineering 上被描述为有明显提升。
- vision / multimodal 能力被描述为进一步增强。
- 新增 `X high` reasoning effort，位于 high 和 max 之间。
- 在部分界面中出现 `adaptive thinking`，弱化旧的 extended thinking toggle。

## 典型场景

- 在 Cursor 中直接切换使用。
- 在 Claude Code 中配合开发工作流使用。
- 处理企业场景中的图表、PowerPoint、PDF 等视觉材料。
- 通过多代理或并行代理完成复杂任务。
- 可参与网络安全研究计划中的特定使用场景。

## 市场用途与反馈

- 来源评价其为一次“solid release”，即稳健可靠，但并非跨代式跃迁。
- 使用体验上被描述为更快、更能处理 agent 场景，但预算消耗也更大。
- 新来源补充了其公开价格：每百万输入 tokens 5 美元、每百万输出 tokens 25 美元。
- 相比“参数交给用户调”，产品交互更倾向于把复杂配置封装到模型默认行为里。

## 竞争替代

- 直接对比对象：Opus 4.6。
- 预期对比对象：节目中提到的 Mythos。
- 更广义的替代对象：其他 frontier model，但当前来源未展开细节。
- 新来源点名的比较框架还包括 GPT-5.4 与 Gemini 3.1 Pro。

## 证据来源

- [[01_Sources/2026-04-19+萨姆·奥特曼的攻击、亚马逊与星链之争，以及 Opus 4.7 的真正含义 #248|来源：萨姆·奥特曼的攻击、亚马逊与星链之争，以及 Opus 4.7 的真正含义 #248]]
- [[01_Sources/2026-04-17+Claude Opus 4.7 太疯狂了——这是目前为止最好的型号吗？|来源：Claude Opus 4.7 太疯狂了——这是目前为止最好的型号吗？]]

## 我的判断

- 暂不补充额外判断，等待更多官方文档和用户实测来源。

## 待验证问题

- 其预算上升是否能被更高的任务完成质量覆盖。
- prompt 取代显式参数后，开发者的可控性会提升还是下降。

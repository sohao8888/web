---
type: 产品
name: "Claude Managed Agents"
date: "2026-04-20"
status: 进行中
summary: "当前来源把 Claude Managed Agents 描述为 Anthropic 面向开发者的代理运行时产品：它不只提供模型调用，而是提供会话、沙箱环境、工具、记忆、MCP 和多代理协作，用来把 agent 作为可部署系统运行。"
my_take: ""
source_notes:
  - "[[01_Sources/2026-04-10+什么是托管代理？]]"
related_notes:
  - "[[03_Companies/Anthropic]]"
  - "[[05_Markets/AI代理与企业知识工作市场]]"
tags:
  - 产品
  - AI研究
  - Agent
  - Anthropic
  - 开发者工具
company: "Anthropic"
category: "代理运行时 / 开发者 API"
target_users: "开发者、企业内部平台团队、代理产品构建者"
---

# 产品研究卡

## 产品概况

- 所属公司：Anthropic
- 产品类别：代理运行时 / 开发者 API
- 目标用户：开发者、企业内部平台团队、代理产品构建者

## 核心功能

- 定义带有工具、persona 和能力边界的 agent。
- 为每个 agent 会话配置隔离沙箱环境，包括文件系统、bash、网络控制和 web search。
- 支持多会话并行、grader 回路、memory store、MCP 集成和多代理协作。
- 允许开发者先定义“完成标准”，再让 Claude 在环境里持续工作直到达成结果。

## 典型场景

- 挂载代码库、自动跑 Lighthouse / Puppeteer，并根据 rubric 反复迭代网页性能。
- 按周追踪 SaaS 价格、功能变化和合同影响，生成分析报告并回写系统。
- 接收监控告警后，由 coordinator + specialist agents 协同诊断并生成 incident summary。

## 市场用途与反馈

- 这个产品把 frontier model 从“回答问题”往“可托管执行系统”推进了一层。
- 来源强调它的价值不只是模型推理，而是能让企业把环境、工具、记忆和审批流一起编排进去。
- 从产品语言看，它瞄准的是“在自己应用里嵌入 agent”的开发者，而不是纯终端用户聊天场景。

## 竞争替代

- 替代对象之一：纯模型 API。
- 替代对象之二：需要工程团队手工拼接的 agent orchestration 栈。
- 替代对象之三：依赖人工脚本、手工 runbook 和多工具切换的旧运营流程。

## 证据来源

- [[01_Sources/2026-04-10+什么是托管代理？|来源：什么是托管代理？]]

## 我的判断

- 暂不补充额外判断，等待更多外部开发者案例和定价资料。

## 待验证问题

- 开发者会把它当成“更强的 API”，还是当成新一代 agent 平台层。
- 记忆、grader、MCP 和多代理协作，哪些会成为真正的产品粘性来源。

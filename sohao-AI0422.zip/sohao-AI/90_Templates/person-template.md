---
type: person
name:
company:
role:
date:
status: draft
themes: []
markets: []
core_beliefs: []
keywords: []
important_quotes: []
prediction_style:
change_log: []
related_companies: []
related_products: []
related_markets: []
source_notes: []
summary:
my_take:
tags:
  - ai
  - person
---

# {{name}}

## 一、人物简介
- 公司：
- 职位：
- 关注方向：

## 二、核心思想
1.
2.
3.

## 三、他反复强调的关键词
- 
- 
- 

## 四、判断框架
### 1. 他最重视什么
### 2. 他如何理解 AI 的发展路径
### 3. 他如何理解竞争、产品和商业化

## 五、重要原话或代表性表达
>

## 六、观点变化
### 过去怎么说
### 现在怎么说
### 有没有明显转向

## 七、相关公司
- [[ ]]

## 八、相关产品
- [[ ]]

## 九、相关市场
- [[ ]]

## 十、来源笔记
- [[ ]]

## 十一、我的判断
这类人物最值得长期跟踪的地方是什么？
他的思想会影响哪些公司、产品或市场？

视频链接：[https://www.youtube.com/watch?v=eqPljh_9C9Y&list=WL&index=2&pp=iAQBsAgC](https://www.youtube.com/watch?v=eqPljh_9C9Y&list=WL&index=2&pp=iAQBsAgC)
视频发布时间：2026-04-12
频道名：Peter Yang

## 转录内容

00:00 If you're a PM and you think that your job is to make documents and slide decks for upwards review and alignment, you're going to love this new world that we're in. You get to make things too. People

00:10 need to see that leaders in their organization are making things too. And that is what inspires and actually creates the inflection. We're entering a world where design is the new code.

00:19 You'll be designing in a visual first way and you'll be able to do a pull request right to production. Direct manipulation on the canvas is just clearly superior to prompting and

00:29 probably design direct manipulation is superior to code editing. As we move ahead, the world gets a lot more visually interesting, too. I'm hopeful that this will be like a renaissance

00:38 period for that. All right. Hey everyone, I'm really excited to host Dylan today. Dylan is the co-founder and CEO of Figma, one of my favorite tools by by far. And uh

00:50 there's a lot changing in the world. also really excited to chat with him about designer's role in the age of AI and you know craft and everything else. So welcome sir.

00:57 >> Thank you so much Peter. Appreciate you having me. >> You know if I could start my career over again I'll be a designer. >> You can still do it. Not too late.

01:06 >> I mean especially nowadays where everyone just a builder. Everyone is wearing multiple hats. Um, but I think but I think you know there's like a lot the world's changing fast and there's a

01:15 lot of things happening and you kind of made a bunch of podcast appearances lately saying that you know AI is not going to take all our jobs like human taste still matters right so I'm just

01:26 curious like what is your definition of taste or like how does someone even get good at taste >> it's funny how Silicon Valley is so excited about taste and I think that uh

01:36 craft is also maybe overlapping but distinct as Well, and then there's point of view where you can have taste uh as a person and you can build with craft and intention uh and still have a very clear

01:51 point of view even though you were incredibly craftful. And so I think that um as you kind of think about what are those different territories to me um taste is really about navigating the

02:04 possibilities of what's out there and having preferences that are really clear that you can articulate. Uh and also being able to um help others understand what it is and what it is not that uh

02:18 you're going for. Craft to me though is really pushing past where others might push and thinking about things uh in their entirety and down to the micro and small level

02:30 >> as well as the macro level. It's like all the different levels of abstraction. You make sure they fit together. And then there's point of view. And I think that for point of view, you really want

02:40 to actually be expressing through a product or a design um something that is uh unique that you see in the world >> and doing it in a way where uh you're almost bringing some insight or some

02:56 take to life that is moving some conversation forward and I think that uh across many products that are consumer enterprise whatever uh in software and hardware. Uh I I think that the best

03:10 products actually do have a point of view about the future. They do have a point of view about how things should be and how people should live their lives or work. Uh you know, and I think that

03:20 um if everyone agrees to your point of view, you're probably not uh having much of a point of view. >> Yeah. Yeah. Exactly. If you don't have a if you don't have a point of view, then

03:28 like you know, the stakeholders or the users would define your point of view, right? >> Exactly. Yeah. >> Yeah.

03:33 >> And I think it's fine to have some interplay there. uh in fact it's really good to listen to users and customers to get to all sorts of local maximum but uh point of view I think is maybe global

03:45 maximum or it's going to get you to the next local maximum rather >> uh or the first one and otherwise you're just kind of iterating around sort of where you're locally are. I think that

03:55 um it's always interesting to ask designers about uh taste or ask them what good design is and you know first of all just the number of definitions you can get about design itself from a

04:08 number of designers is amazing but also you know if you do a design crit with like really experienced designers and you have five in a room and you you kind of like argue through from a aesthetic

04:20 standpoint or from a UX standpoint or both you know what is uh the best design uh here on the table, you know, you might get like a 100 different answers uh from those five designers. And so I I

04:32 think it's um a sort of thing where there's just so many different places you can go and then it's about like how do you actually narrow down that possibility space and traverse that tree

04:42 properly. >> And I guess like you kind of developed the point of view and taste just from obviously talking to users and like kind of your past experiences. It's It's kind

04:50 of like, you know, you're kind of giving context to AI to a certain extent, like it's kind of your own personal context, right? Yeah. >> I think that over time, um, absolutely

04:59 you can. Um, but there's also always the cultural influences of any given moment that I think really matter. And uh I would just say that I find that the most interesting points of inflection are

05:11 where you're kind of on a frontier and you're pushing further than anyone else has pushed already and then you're kind of like rapidly updating real time. Uh and then you get a few observations out

05:23 whether it be on design or aesthetic or strategy and then you kind of um make a leap rather than try to like iterate one step locally if that makes any sense. >> Got it. Um I I I guess I I'll share like

05:36 a specific example like you know I started using open call like a couple weeks ago and I mean it's a pretty janky product right it doesn't doesn't always work all the time and it keeps breaking

05:45 but it definitely like kind of warped my mind on like oh like these agents can actually do like basically whatever I wanted to do. So like maybe instead of making people come to this website that

05:54 I'm building maybe they can just get their agent to come and like do do their stuff instead. So like that that was kind of like totally warmed my mind. Yeah.

06:02 >> Yeah. And you know, I don't know if it's the funny thing about open call is you don't know who posting about it is actually especially if you don't know the person who is actually like laring

06:12 uh being an agent or who's actually like reflecting on what the agent actually did. >> Yeah. Yeah. It's hard to wrap your head around it for for sure.

06:20 >> This episode is brought to you by linear. When engineers use tools like cursor, clock code, and codecs, a lot of work happens invisibly. Someone can go from a bug report in Slack to a shipped

06:31 fix without creating any record of what happened outside of the code editor. And that's fine for speed, but it makes coordination harder as you scale. Linear integrates with the very best agent

06:41 coding tools directly like cursor and codecs. That way, anyone can see what an agent is working on and who assigned them to the task. You get the speed of agents without losing visibility across

06:52 the team. product teams at OpenAI, RAMP, and Block are all using Linear to collaborate with AI agents. And I use Linear myself to run my creator business. So check it out at linear.app/

07:05 aents. That's linear.app/ aents. Now, back to our episode. Do you think agents and AI can learn taste? like like like you know I can if I'm a really good designer I can just like put

07:17 like a clock scale or something and like here's some principles I have and here's kind of what you should do and not do and and maybe it can stop doing purple slop after that but do you think you can

07:27 actually like do you think we can train our agents to learn this stuff or >> I think that models have already gotten to a place where um their visual output for example with the Gemini 3.0 release

07:39 3.1 but even 3.0 Oh, I thought uh if you prompted it the right way, you know, complex prompt for sure, but if you gave it references, it understood uh and you push it hard enough, you could get to

07:52 some pretty incredible outputs. And so, uh I think those those outputs are again like you're you're lighting up this possibility space. You're you're creating uh these different places that

08:04 you could explore. And then from there uh though I think it's it I never found myself um as I explored what I could do with it or where I give a 3.1 feeling like oh great I got my answer one shot

08:19 done like even more than sort of um an average output that you might see or what you're referring to as purple slop like I think I actually had more opinions about the thing with point of

08:30 view and that I actually had a direction to it uh than I did the purple sloth. Um, you know, purple sloth for average output. You're just like, cool. Uh, it does the thing. You know, there's a lot

08:43 more I would push it to do myself or a lot more expression I could have here visually, uh, or experientially. And, you know, but but it works. And once you actually go another step further and you

08:55 have some intent behind it, I think that's the point at which you get to uh interesting places where that dynamic loop starts to occur and you really want to go push it further yourself. Um and

09:07 prompting is not always like the way to do it. I think a lot of times actually what you need to do is uh push it forward as a human and in order to actually iterate to the right place

09:17 that's necessary. >> I see. Um and I think uh like like A really good designer is not just gonna I told this before it's not just going to be like hey here's a prompt and here's

09:27 the code and okay I'm going to go with this uh website that I built right like uh they need to explore divergent perspectives and then converge again that's kind of what a good designer

09:36 should do and so I'm curious like um because there's basically trying to get from idea to product that's basically trying to do and there's like a lot of intermediate steps and back then dude

09:45 when I was working at Microsoft and some of these companies like we had to write like 16 page PRDS and all this kind of crap like there's a lot of intermediate artifacts that had to happen before even

09:53 the product. But now like code is like basically free and you can kind of do this stuff. So yeah, even even internally in Figma teams like how do you guys go from idea to product now?

10:02 Like do you prototype a bunch of variations first and then go to the Figma or like it depends. Yeah. >> Mhm. >> I I think it totally depends. I think um

10:12 there are times that we start uh with like deep discussion. M >> there are times where um you know one of us is just ideating away on you know with pencil and paper and uh a notebook.

10:27 >> I think there are times where we're in design or you know in a collaborative brainstorm or we're uh like literally in code or you know >> uh making designs. Um, and there's so

10:40 many different ways that I think you can start now, uh, including from an existing, uh, setup or website or app that you already have. And >> uh I think that wherever you start um

10:53 our job is to make sure that as you hop around between the different stages uh of or what were stages I think in a linear process before you know between ideiation and uh alignment and uh design

11:09 and actual production. you know, you could start anywhere, but you might want to go everywhere in that process. And I want to make sure that we can enable that fully on the Figma platform. Uh

11:20 because that's what I see happening more and more is it's not even right to call it a loop. Uh because, you know, it's not like you're always looping back to the same thing, but it's all these hops

11:29 that could occur as you're really trying to explore. And uh that includes a lot of divergence and convergence. Um, but it's, you know, the diamond shapes like they stack on top of each other and they

11:42 could be from any point to any other point in terms of where the artifact is or what it is. >> Yeah. Like, you know, like people keep asking me, "Hey, Peter, like is the

11:49 design done? Is the spec done?" It's like, it's never done, man. It's never done till the product ships or even afterwards. >> I mean, that's the beauty of digital is

11:58 that you never have to say it's done. And you talk to people that are trained in, you know, industrial design or uh, you know, the physical world, you know, they they try to uh really make sure

12:11 that they go through a process that can complete and that at the end the process it's like you're shipping it off >> and if you don't like it, too bad because like you cannot update this

12:21 thing >> and then in the software world of bits instead of atoms like we get to update constantly. It's an amazing amazing world to live in and uh what a luxury to

12:32 be able to do that. Um but also yeah uh you know very much the case that now uh the velocity you know or perception of velocity even increasing >> you want to be able to push further

12:45 faster and I think it's just really important to not make it so that you're just running towards something. >> You need to run but you need to run towards the right thing. Uh so keep the

12:54 velocity but have some sense of cardality like know where you're going. >> Yeah. You don't want to run in circles. I I I guess. Yeah. >> Yeah.

13:02 >> And like along the same lines like I think uh you know Figma MCP great great product and um now you can go from uh you know code back to the Figma canvas, right? And and some people online are

13:14 like you know why did Figma ship this? Why would I want to go from code to Figma canvas, right? And and I think it is kind of going back to those like uh diamond shapes and stuff, right? Maybe

13:23 maybe can explain why you guys should ship that. >> I mean, I think that um you might start in design, you might start in code or somewhere else. And if you're in code uh

13:32 as a place to start making a prototype just to get something built that you can play with. Cool. Uh you can do that in so many ways. And >> uh we want to make it so that you're

13:42 then able to go at some point and diverge and to actually uh use Figma for the stuff that is better to use Figma with. for example, anything from spacing to color to uh you know, properties of

13:56 the canvas um that you can directly manipulate. And being able to have that rapid feedback loop where you're able to do that direct manipulation on the canvas is just clearly superior to

14:06 prompting. Uh you know, I would say code editing itself is superior to prompting and probably design direct manipulation is superior to code editing when you're adjusting things like that. And then in

14:18 terms of the breath, I think the canvas is a natural place. I mean, it's an infinite canvas where you can go and uh see all the possibilities of flows of uh different ways that you could iterate on

14:30 a screen. Um and you can do it all in the same spot. And um I think that uh it's important to be able to go from design to code, from code to design. That round trip we have to make as high

14:41 quality as as possible, as efficient as possible. And really important to advance that forward and have that loop be really tight no matter where you start.

14:49 >> Got it. And and maybe like hopefully nothing gets lost along the way like still. Yeah. >> Yeah. I mean the high quality part like we are always increasing the quality and

14:57 making sure it gets better and better. >> Okay. All right. I'm going to ask you a tough question now. So there's some startup there's some startups out there that kind of look like Figma and and

15:05 then they have these like things where like yeah you can I saw this thing the other day where like you can put a prompt like design a design a you know do cafe website or or something and and

15:16 then it has this like swarm of AI agents that come in and just like starts designing stuff and like it looks pretty impressive man and um it can you can also like manually edit the stuff

15:26 afterwards. Um, and I'm wondering just like, you know, since Figma is kind of the go-to design tool, like how do you think about stuff like like that? Do you think at the same time, I think a lot of

15:36 designers are kind of like very averse to prompted design, right? They're like kind of like you're kind of threat threatening my job or my craft. Yeah. So, I I guess it's a tough situation,

15:45 but how do you think about all this? Like >> um >> yeah, >> you know, again, it's like I think um

15:52 it's a mistake to think of a output of a prompt as a final result. That's right. Yeah. >> And uh whether it's something like uh exploring divergent possibilities

16:03 through lots of agents on a canvas >> um that are you know going to paint the possibility space a bit for you and then you're going to go iterate from there with something some of the possibilities

16:13 you like. That could be visual style. It could be uh you know different structures of IIA. It could be different flows. Um, it's limited by how good is the agent at this. Uh, ultimately you're

16:26 the judgment of the system. You're the one that's going to figure out what is good and worth exploring. Uh, because the possibilities are likely almost infinite.

16:35 >> Um, and so, you know, you're the one who's trying to figure out what path should I look at? And if you can do even more exploration with the help of agents, great. Uh I also think that a

16:48 similar sort of story is with Weevi wearing the shirt right now. Uh the W. Uh but I think that it's really important to also think about this with uh media generation.

17:01 >> And when you're actually doing work that's creative, you're again not going to take the first prompt and it's not going to be your final result. Instead, you're take that first prompt and it's

17:12 like clay that you mold, that you shape, and you're going to try to put it through a process where you get it to the spot that you want. And um there's a lot of things that are possible when you

17:22 actually think about these workflows like that as an iterative process you're going through. >> Uh divergent and then you're going to cut off some of the branches of the tree

17:30 post talk and then you're going to uh continue on and refine. >> Yeah. I I I think some of some of the vibe coding tours are like you just put in a prompt and I'll build the full

17:39 stack for you. up the back end, the database and everything and then boom, here's the app. And it never it never gets it right, man. It never gets it right in one shot. And then it's

17:47 actually more work for me to try to change it afterwards because it's like has has all this code that's actually not necessary to explore the problem space and solution space.

17:56 >> Yeah, I think the opportunity with something like Figma make is, >> you know, how do we both make it more powerful and make it so that it's able to be more divergent. Um, right now it's

18:07 something that's very linear. is the opposite of what I'm saying. Uh, and you look at the Figma canvas and that's very divergent and lets you explore by default. That's the gravitational pole.

18:17 >> And I think that um ultimately it's like how do you combine the power of code and canvas so that it's an and not an or. It's like there needs to be a way to bring them together rather than be like,

18:29 oh yeah, you could like be in code or you could design, >> you know, which one will it be? >> You know, instead you want to have that tight loop.

18:37 >> Got it. Yeah. So I guess uh you're not really opinionated about whether people should start in the canvas or make or whatever. It's it's just like whatever it takes to explore the idea.

18:44 >> I think it's just start like do something uh get something on paper uh in a dock, put a uh a design together, you know, make a prototype, whatever. As soon as you get started,

18:57 you're going to want to make it better. At least I do. >> Uh that's my perception when I see something is like great, how can we make it better? And there's a question of

19:07 okay, is it the right time to make it better? Should we get it out? Um what do you have to push on and what are the things that are actually what's the right way to approach this?

19:17 >> But having any stake in the ground that you can try and use um can be helpful. I mean even with uh I had a designer via this week where at the start of the week um one of our designers brought me uh

19:28 and our chief design officer Lord Anna who's amazing a bunch of concepts of you know very structurally different ways to explore a problem that we're excited about uh addressing and we basically

19:40 said look uh you're actually you're really thinking about this holistically that's great but like okay stop like a third of the way through that um uh what you just showed us you know those

19:52 twothirds of the design you might end up there but like this first one/ird that you explored like that is enough to go prototype now and you're going to learn from using it. So go make it uh it'll be

20:04 fast to make and then go and explore more options from there once you know sort of the physics of the system that you're creating. >> Yeah, I I uh maybe this we can talk

20:14 about company culture a little bit too. Like I I always kind of hesitate when there's like a lot of internal exploration without talking to a real you user or showing this stuff to real

20:23 customers and like there's like a natural tendency to do that man just like just like you know oh we got to present a dead end so let's let's do like uh five rounds of internal reviews

20:31 before he sees anything and then you never know if this is the right thing or not like how do you how do you manage this? How do you uh do you how do you discourage this or do you think this is

20:40 the right thing to do or like how do you get the customer feedback loop going fa faster man? Uh yeah, never talk to customers. 20 rounds of internal review. Yeah, it's great. Uh

20:48 >> yeah, >> I mean like the Apple said, uh I think that we're always talking with customers. We're always trying to make sure that designers, non-designers

20:56 alike, uh are having a chance to learn about what customer needs are. Um we have an amazing research team. We have amazing support team. We have an amazing sales team. like uh there's so many

21:10 functions outside of product engineering design uh that are you know functionally part of product engineering design I mean I I think research should be included in those uh uh in that set for

21:22 sure um and then if you get sales to be operating the right headsp space to be operating the right headsp space they're bringing insights too I mean I'm seeing um our research team use Figma make in

21:35 incredible ways so so that they can rather than just like here are my insights. I've made a report. It's like here's a functioning prototype for what I think would address the needs that

21:46 users have right now or or maybe not even just one. It's like five >> prototypes that we could explore. um or you know here's an eval that we're considering uh adding and on the support

21:59 side uh people are building like internal tools and figuring out uh how to actually advance processes and sales as well is really getting familiar with the ways to go build here. I mean, you

22:12 know, something like 60% uh of these designs are being created by non-designers. And I think that um it's really exciting about make how more PMs are getting involved in the process too.

22:25 You know, if you're a PM and you think that your job is to make documents and uh slide decks for upwards review and alignment, >> like uh you know, you're going to love

22:35 this new world that we're in. You get to make things, too. >> Yeah. Yeah. And uh you know you don't have to think about yourself that way anymore. Uh company culture is more

22:45 different. I respect and acknowledge that. And I think uh what I will say though is that so many are changing. I think that um people need to see that the leaders in their organization are

22:57 making things too >> and that is what inspires and actually creates the inflection. So, how do you like uh like encourage the product teams to like not

23:08 uh you know like to talk to customer or maybe it's not happening already but to like not go crazy on the internal prep to have a review with you. How do you >> how do you did you try to do that?

23:18 >> Yeah. >> I mean whenever I hear about lots of uh rounds or whatever even if it's just two or three >> it's like just just bring it directly as

23:27 long as I'm not the rate limiter. And also I think there's not I don't have to see everything. um you know if you're actually going to go fast you you can't have one person be the bottleneck on

23:36 everything right there's some stuff that if we change it uh it will really affect a lot of users so like you know if you're going to change like a core thing about the product for Figma design uh

23:48 yeah I should see it um and make sure that just because I've got a lot of context there >> um that we're doing the right thing for our customers and you know you got make

23:57 that loop fast and I'm always trying to get faster but I think that the best times where you're iterating fastest and the team is learning the most >> Yeah.

24:06 >> are when the team is able to be in just rapid cycles. So if you're putting like a block in the cycle, that is uh not ideal. And I'm not saying that we're perfect. Like we are updating and

24:16 learning just like everybody else is. >> Uh that's my push is to try to uh determine where we need to do what and how to get to that rapid cycle uh overall of learning. And I think

24:28 structurally find ways for teams to create prototypes internally and share them. >> Uh have less pressure about getting in front of uh users in a way that's going

24:39 to be like a long-term commitment. Um that is one hack. Uh I think that you know making lots of things is another hack. um you know if you're not sure about the direction you should go lots

24:52 of prototyping um is one way to learn and then you can it's the opposite you can put them right in front of customers it's like here are five ideas what do you think and you'll get a lot of

25:01 feedback and no one will think that you're like committed forever to going this direction because you just showed them five different ideas so they can go in either direction there but um you

25:11 just have to maximize learning >> got it and and um you know figma config is one of my favorite conferences and Um there's always some big product announcements there. Um but I think

25:21 lately the world is changing so fast that like I'm I'm curious how long your road map actually is, you know, cuz like people keep saying like, hey, you got to have like a two-year road map and I I

25:31 just have no no idea what the hell is going to happen in two two years, you know, or do you still have to have a point of view of the vision or how do you balance the long term and the short

25:38 term? I think that there's like areas of our company where we're working um in these very long-term ways on projects that are very hard and very deterministic.

25:48 >> Got it. >> Uh and they might have like a non-eterministic component but much more deterministic than not. And uh those are ones where you know you can actually

25:58 kind of plan for the long term. And then on the other side it's like yeah there's there's stuff where you just have to be watching what's developing and reacting really really rapidly. And the faster

26:07 you can react, the better. >> You have to set yourself up to be able to do that. >> Um, I think the velocity that we had last year was really strong. I mean, I

26:17 think we did we should have something like 200 features and um, we spin our product line quite a bit as well. And that's all learning. And this year, I think we're going to do a lot more, you

26:27 know, at least in terms of magnitude. Perhaps there will be some initiives that are bigger and because it's not enough to say, oh yeah, you know, 200 features and this year we'll do a

26:37 thousand features. Like that's no one wants to hear that. It's that could be unnecessary complexity. >> Yeah. Yeah. >> But I think the magnitude of what we do

26:43 will be even greater than last year in terms of its impact on users. >> Awesome. Yeah, that that's super exciting. I I have a I have a quick product feedback for you. So, as as a

26:54 PM, uh, and I've tweeted about this before, so it's probably not a surprise, but like um, and this might be a hot take for designers, but I feel like stuff like design systems and even like

27:03 auto layout, like it kind of just constrains my ability as a beginner in Figma to actually move stuff around and like do crazy things. And uh, I understand the point is like make it

27:14 consistent and make it easy to to use. But do you kind of feel this tension between, you know, creativity and consistency and kind of like this kind of or even like designers versus other

27:21 types of users? Yeah, I think that um the more structure that is there, >> unless you know how to navigate it, uh it makes it so that you're um not able to work as fluidly as if you were just

27:36 in a world where everything's flat and you can just move things around. So that's like a inherent tension. Um and whatever structures in an auto layout, you know, frame that's uh or or nested

27:48 auto layouts, um you know, that is less uh structure that you probably have in your codebase at the same time, right? So there's levels to this. Uh but I think that yeah, that's the core tension

28:00 that I think matters. um is how do you let people be as free form as possible and like be in as much data flow as they can possibly be in uh while also um creating ways for folks to structure

28:13 things the way that they will actually work and to uh be more productive you know I think that with auto layout you definitely see how someone experience with it uh an experience you can build

28:25 that experience very fast it is a learning curve but it's a fast learning curve and at the same time um you So it can both intimidate and it can make it so that you can work a lot faster as

28:35 well. So you know my perfect world is one where you're able to uh you know kind of go in and out of auto layout as fast as you can and you're able to like you know kind of ignore it, flatten it

28:48 and then you can like reapply it. Um we haven't gotten there quite yet but that would be the ideal is if you're able to not be bound by it but get all the utility. Uh, but you know, some stuff is

28:59 hard to get your cake needed to, and this is one of them. >> Yeah. I mean, it does improve my relation with my designer because I have to ask her for help all the time to move

29:06 a box around. So, >> Oh, that helps. >> I mean, that's not ideal. >> Yeah, that's not ideal. Yeah. Yeah. Okay, that makes sense. Um, how about

29:16 how about um uh how like everyone's talking about being AI native and all this stuff like how are you guys operating differently or like type of people that you hire? like how how has

29:25 that has that changed with this whole AI thing? Are you looking for people who like thinker of stuff who like use AI on the side? Like how has this changed? Yeah,

29:34 >> I think um probably as long as you're not totally averse to AI, if you're someone that likes to make things, >> uh you're someone that likes to learn about technology, then if you don't have

29:45 philosophical opposition, then yes, you're going to go lean in and try to figure out uh how to use AI to your benefit. And >> yeah,

29:52 >> what I think is interesting too is that we're we're just now getting to a point uh I would say in you know we're talking February 27th uh 2026 and I feel like it's like the last month or two that for

30:05 someone that's a a good engineer or a very good engineer that they're starting to really understand the utility of AI uh on the coding side um and how it is like obviously better than them um at

30:18 some not all things but some things and how they can deploy it because you know the very good engineers could often times still work faster than you know they might be able to and managing like

30:30 a bunch of or even a few agents uh that might end up writing things that then they have to redo. And so uh now we're at a point on the code side where if you know the model well enough, you know the

30:41 setup well enough, you can know uh how to direct it and have it do some level of task for you. Now, in some code bases or some setups might be able to have it do a lot for you and some it's less. But

30:52 yeah, I I think that um it's just a skill to learn just like anything else. Uh and ultimately you still need the basics and uh the wisdom that can be accumulated over years of building

31:04 software systems in order to guide the model properly as well. And um uh I think that when we're looking on the more product side or design side, we're looking for people who are technical but

31:15 also people that have craft and have that judgment. Um and I think that the judgment is extremely important. So I'm always trying to figure out as well who are the folks that are really bleeding

31:30 edge and are consistently um navigating these new paradigms in the right way. uh and coming up with new approaches because that is something I think is um really exciting when you find folks who

31:45 are uh just like inspiring in their thinking and the way they can push these technologies in in in sort of inventive ways that others haven't yet. uh but overall I mean I think that there is a

31:57 lot of engineering work that um you know can be done through design now and ultimately as I fast forward even more I think we're entering a world where design is the new code you'll be

32:11 designing in a visual first way and you'll be able to do a pull request right to production and um that doesn't mean that everyone will prefer that method it doesn't mean your pull request

32:22 will not be reviewed Yeah, >> but I think you'll be able to do it straight from Figma. Uh I think it's coming. So like uh I think that's where we're headed.

32:31 >> Yeah. Uh that that's why I like vibe coding, man, because my uh my little apps never need any pull requests. I just merge to prod directly. So yeah, that that's why that that

32:43 that's how I get in the zone, you know, it just keeps keep going. Yeah, we on a larger team with the established companies. Not saying that everyone should just uh you know go right to prod

32:52 no pull request but uh but I I mean I think there's there's always room to learn from others but also >> yeah I think that uh there's no reason why the value doesn't move up the stack

33:02 in terms in the ability to actually go influence a complex system. >> Yeah. um cannot be done from the level of you know the blueprint rather than sort of like you know the very very

33:13 detailed specification that is code. >> Yeah. And I think and I think hopefully teams will get uh smaller like you know three or four people can just like build a really good product cuz I I didn't I

33:23 don't like this whole trend towards like hyper specialization where you have someone who just like edits copy and someone who like only does design and then you kind like you can't like if you

33:33 wear multiple hats they're like oh why you step on my toes it just doesn't feel fun man like it's more fun when everyone's just a builder and can't just do a little bit of

33:40 everything. Yeah, I go back and forth. I mean, like for decade or so, I was always thinking that it'd be merging of roles because that's what I was seeing was, you know, early signs that might be

33:51 happening before AI even. And I feel like more what I'm seeing right now, despite more talk than ever about merging of roles >> is more merging of responsibilities. So

34:00 more people wearing lots of hats but still like kind of specializing in one area. uh so yeah I think it's it is the case that like there is a craft uh that you

34:11 can apply if you are an expert in an area >> you know for example you said UX writing like I have worked with UX writers that and do work with UX writers that are are

34:23 just incredible um and it is a a very hard thing to figure out how to create a string that is like the right amount of space and communicates with the right uh you know sort of feeling what you're

34:40 trying to do and what you're trying to get across to the user. I mean it's it's it's tough at least for me it's tough. Uh so yeah I think um uh at the same time you know if you have that um sense

34:54 of what is the type of copy you want to create and what are the sort of style what's the style guide of your copy >> then yes you could probably have um a bunch of stuff that is pre-populated

35:07 uh with a skill. >> Um that doesn't mean you're going to get to the like last final answer there. you might still want to like actually really push it forward past the ideas that are

35:16 there, but it's a starting point. And so I think that that this like mindset of use AI is a starting point, push with craft and intention and care towards the final output that you want to get to.

35:29 It's applicable for pretty much all the disciplines. Um, and that's mainly what I'm trying to get across here. >> Yeah, maybe like you can collaborate on 90% and the last 10% is still manual

35:40 taste and craft, right? That's kind of >> I mean I think it depends. It depends on the problem and >> you know what you're trying to achieve. Writing as an example for uh just more

35:50 general longer form writing like uh when I'm writing something I do often use AI but oftent times it's for or most all times actually it's it's really to understand like what are the obvious

36:03 cliche ways of saying something. It's getting that blank page problem fixed. Yeah. Like I don't know about you, but I find it very hard to start a piece of writing. And so for some reason, if I

36:13 can just like, you know, ramble type, you know, what I'm trying to get across in a kind of incoherent way and then uh say what are the 10 obvious ways to say this, you know, almost never do I use

36:23 the result of that in any form. But it always gets me going and gets my brain spinning on, okay, what is the right way to say this? >> Yeah. because you know the cliche stuff

36:34 is not what I want to go do but I want to say something that's unique uh or at least um is helping express like a point of view that I have and usually when I'm writing something longer form I am

36:46 trying to say something that's not been said before. >> That's right. Yeah. Cool. Well, I mean I mean let me ask you one last question. I don't want to respect your time, but um

36:53 let's imagine let's just imagine like a year from now like end of end end of the year like 2027 like um where do you think we'll we'll be with these tools like you know with Figma or maybe can't

37:04 share too much but with Figma or some of these tools that we use to create and maybe also personally what are you thinking with now you know in the AI space

37:13 >> you know it's really this entire conversation what I'm exploring most which is just not only for design uh but also So for ideiation and arbitrary problems, just how do you get to the

37:25 most divergent space possible and >> how do you properly use AI to really explore possibilities um but at a more abstract level too and yeah that's something that I had a really good time

37:39 just enjoying the exploration of that and you know figuring out systems for myself to help solve problems and I hope they're applicable to Figma 2. Uh so we'll see. But I think if we fast

37:51 forward a year or more uh and we're in end of 2027, we're in a world where yeah, wherever you start, Figma is a place where you can bring things together and uh whether it's building a

38:03 digital product or creating ways to reach customers and uh express your point of view. I I think that there's so many different forms that it can take, so many ways we can bring the ideas from

38:17 your head onto a screen. >> Yeah. >> And enable all of them. And whether you're doing that all in Figma or you're doing it with Figma and other tools, any

38:25 number of other tools, what it makes is that you can have those loops of divergence, convergence, and uh really push forward and create more unique things in the world.

38:34 >> Yes, it's kind of surprising how many of these AI tools don't do this divergence, convergence thing. It's I just like I haven't done it, you know? Like I I I can force the model to be like, "Hey,

38:44 give me like five variations and here's some descriptions." But it it doesn't make it e easy, man. Yeah. Don't think about this. >> It's a there's a lot to explore. We're

38:52 at the very start. And um I think that the industry as a whole is going to look back on this time and be like, "Wow, it was like so early >> to the world of AI still and how that

39:04 fits into um just the products that we're building." And I think that um at the end of the day uh to go back to the start of the conversation I mean we were talking about agents and how uh you know

39:16 it might be interesting to think about the design implications of you know what does it mean to design for an agent but um I think at the end of the day it's about designing for humans too uh and

39:25 actually humans are the most important case still uh even for agents you got to audit them you have to understand what they're doing uh you know and maybe if it's depend on how high you're using

39:36 open claw I think you're probably having it fire off your PRDS or your uh design uh materials for your team, you know, to uh some like uh uh review or whatever. Um yeah, and you probably are giving a

39:51 lot of feedback on things and your your digital twin is not doing it for you. >> And I think that uh yeah, I think that we're all going to just push the world forward a lot more uh with the tools

40:02 available. And I'm hoping that as we move ahead, the world gets a lot more visually interesting, too. >> Uh, aesthetically, I think we've been in a bit of a rut for a while as a design

40:12 industry. And, um, there's nothing wrong with the styles that tech companies have explored, >> but I think there's so much more out there that we could push towards and so

40:22 many more interaction paradigms and ways that we could uh, really craft amazing experiences for people. And I'm hopeful that uh this will be like a renaissance period for that.

40:33 >> Yeah, because it's it's going to be cheaper to explore your stuff and more people will be able to explore stuff because you know there's no the technical barrier has come come down. So

40:41 it's going to be very exciting, I think. >> I think so, too. >> Cool. D. Well, thank thanks so much, man. Uh keep keep going, dude. I I can't wait to hear what you announce at.

40:50 >> Thanks, man. Well, we're gonna watch a lot of stuff before then, too. I hope so. Uh yeah, keep tuned. Thank you so much. Thank you.

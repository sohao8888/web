视频链接：[https://www.youtube.com/watch?v=dvt_74kV-RM&list=WL&index=9&pp=iAQBsAgC](https://www.youtube.com/watch?v=dvt_74kV-RM&list=WL&index=9&pp=iAQBsAgC)
视频发布时间：2026-04-08
频道名：a16z

## 转录内容

00:00 The diffusion of AI capability is going to take longer than people in Silicon Valley realize. >> It's just absurd to think you're going to vibe code your way to like SAP. All

00:08 of that domain knowledge, it's not just represented in some well orchestrated data layer. >> The engineering compute budget conversation is going to be the most

00:17 wild one in the next couple years. >> The biggest problem right now is everybody is trying to figure out the economics of all of this when they're off by at least an order of magnitude on

00:26 how big the opportunity is. If you have a hundred or a thousand times more agents than people, then your software has to be built for agents. >> People in the abstract say things like,

00:35 "Now you're marketing to agents that you're like an API. You've got a good IDL." I actually think that's almost exactly wrong, which is >> wow, this is breaking podcast news.

00:45 >> If you start to imagine that we all have to build software for agents, I think we're like all clear on that, right? So like that trend is happening which is like we spend as much time now thinking

00:56 about the agent interface to our tool as we do the human interface. Sure. And the reason we're doing that is because our hypothesis would be that if you have a hundred or a thousand times more agents

01:06 than people >> then your software has to be built for agents. And then what what is the way that those agents are going to interact with your system? It's going to be

01:13 through an API or a CLI or MCP or whatever. And the the paradigm that appears to be taking off and is quite successful so far in terms of efficacy is what if you give a coding agent

01:25 access to your SAS tools and uh a coding agent access to you know your your knowledge work sort of workflows and context and that kind of becomes this superpower which is it's not just like

01:38 the agent is not only capable of like you know reading some data understanding some information it can actually code its way or uses APIs you know through whatever task it's trying to achieve.

01:48 That appears to be like a like a paradigm that is is starting to compound. And you know that was the that's the claw cloud co-work phenomenon. That's the whatever OpenAI

01:59 is is kind of cooking up. Um you know with the super app perplexity computer etc. And uh and I actually think it it it kind of makes sense as like the ultimate manifestation of this stuff.

02:09 >> I think I mean I think you're right. It it it makes sense in a in an theoretical way. Yeah. >> But in a in a practical way, we have to be really careful in that

02:23 >> that the way to say it is algorithmic thinking >> Yeah. >> is really really really hard for the vast majority of people who have jobs.

02:32 >> Yeah. >> And and so the the easiest way to think about it is if you were to go into any person and ask them to create a flowchart for a particular thing that

02:40 they have to go do, they would probably fail. Yeah. At producing that flowchart. Yep. >> There. So within any organization, you know, say doing a marketing plan and

02:50 there's 50 marketing people working on a giant product line. Yep. >> One person probably understands and could document the flowchart >> 100%.

02:58 >> So if you put one of these agents >> or you put this this this tool, this co-working tool in front of people to create these things, their ability to explain to it

03:09 >> what to do is really really limited >> 100%. So then you're >> but what if that becomes the new this is the new way you have to interface with computers and you just have to cycle

03:19 that through. >> Well then you're what you you're basically you you just go back to you're basically just developing the next abstraction layer for how people

03:29 interact. Yeah. And the developing an abstraction layer has historically at each level of the abstraction layer been a highly skilled very specific individual within an organization

03:40 developing that. And then the little parts that they build just become little toollets in the world of people doing particular tasks. And some people are able to stitch them together and some

03:52 can't. But that happened with paper clips and thumbtacks before and it's going to happen with whatever we do next. >> I I think that I I think basically the

04:01 timeless part is is the job just moves up a rung and and and you learn a new set of skills and and that's why I actually don't think anything about this is any different. Uh it's just now the

04:12 leverage you get is obviously you know fantastic. Uh there was this viral um uh kind of tweet that went around which was the anthropic growth marketer. Did you guys see this? It's basically one person

04:21 and and he was using claude code at the time to basically you know more or less automate what maybe five or 10 people would have done in various kind of silo jobs. And um uh and I think the reason

04:33 why it's interesting is is yeah you had to have been a systems thinker to be able to accomplish that. So like clearly he already was technical enough to be able to pull that off. But it did kind

04:43 of represent like what would each of these jobs look like if you had like imagine you had you know X job in the economy and right next to that person was an infinite pool of engineers that

04:52 could automate whatever that person wanted and you know what would that job look like in the future as a result of that automation that now is possible. Yes, I agree that you'd have to find a

05:01 way to like you know think through your job as a system to be able to pull that off. Maybe the agent gets better and better over time at being able to like nudge you in that direction. But I like

05:10 it does it does sort of stand a reason that like you will start to, you know, try and automate a lot of that that kind of work of like, well, why don't I take like the keywords that are working in

05:20 this in Google Adwords and then port them over to Facebook and make sure that those are replicated and then take in the new signal from what's happening in the market.

05:28 >> That's a big leap. Like so one thing first. >> I almost had you. You were nodding a little bit and then I sh I said something that went too far.

05:35 >> The anthropic growth person as an example like that's a job that is the rest of yeah I could do that job is infinite and you've got the best >> like when demand is infinite and frankly

05:46 supply is infinite. This is not a difficult job and and so let's >> guy that runs the petrol pup in Australia right now is amazing. >> Right. Right. So like be instead be the

05:56 $600 PC marketing person and see how you can do against the Neo. That's a real job. >> All right, fine. We need a better we need a better uh example.

06:04 >> But there is I mean it is it it is really interesting. Like I here let me do an old example an old person example like my my cousin MBA elite school joined her first job. She's a little

06:17 older than me. Joined with right on the cusp of computing. like she actually didn't use a spreadsheet in in grad school and then they all a spreadsheet showed up but she wasn't a spreadsheet

06:28 person so instead they told her hire as many interns as you want and so her first year on the job she like supervised like essentially a whole room of agents.

06:38 >> Yeah. >> And the the the kids who was me not literally but they were in college came and just did all the spreadsheeting. >> Yeah. But then what happened sort of

06:48 this over magically over the next couple years was she and her cohort all became the spreadsheet people. >> Yeah. >> And then this idea that you being a

06:58 manager in a bank or just a two years in meant you had a cadre of people doing spreadsheet. No, the whole abstraction layer moved up. And the old job before those interns was you just sat there

07:10 with basically calculators and an HP an HP calculator figuring out the model for some M&A deal or whatever and you only got to do like two iterations before you had to put put out the the pitch deck or

07:22 just go to the customer or the client or whatever and then all of a sudden they're doing 30 iterations themselves. But they see and so I think where we are with agents is just at this step where

07:33 you think you need 50 and the abstraction layer is such that we're dividing up in these really small pieces with one super smart person coordinating them all and and pretty soon that that

07:42 whole thing is just gonna they're all going to collapse on each other and there is just going to be like a skill set >> amount of code call it an agent that is

07:51 like marketingish. Yes. >> And you'll be able to ask it marketing stuff. Yeah. And then the next step will be and have it go do things. I'm I'm a little skeptical of the until the the

08:01 whole like non-reproducible, non-random element of this AI stuff goes away, the doing stuff is going to get very costly and and so then you get into the human in a loop discussion and all of that.

08:13 But I think we're just we're at that exact I feel like when I talk to people trying to do stuff Yeah. that we're right at I'm feel like I'm at Thanksgiving dinner talking to my cousin

08:21 six months in her job when when I'm using a spreadsheet already and I'm and I'm like I don't know why this is so hard. You should just use one >> and then two years later she's doing it.

08:32 >> And and I think this right now you have to be an absolute you have to be a rocket scientist and the growth marketing person to create 42 agents and spin them all up and do all of this

08:41 stuff. But the rocket science part of it just is going to evaporate in very short order >> and then you're talking about wow there's a giant chunk of domain

08:50 expertise that >> it goes back to the domain expert. >> So I I I actually think something that you said I'll take the other side of which is I think it's very tempting to

08:57 be like these agents are going to code and do X. Yeah, >> but I think we're going the opposite way. So I think actually where we started was we'd like take like a piece

09:04 of SAS software and we'd add AI. Yeah. >> And then that's like the new kind of like AI enabled. So that's like the extreme version of using code for these types of things. But now what are we

09:13 actually doing? We're like okay the SAS software is still SAS software and the agent uses it as a computer because like it's actually very good at that. So I'd say like we started with code

09:23 >> then we went to the terminal which is actually less code. Yeah. >> And now this year is going to be the year of computer use. Yes. So it's almost like they're much more like

09:31 humans using computers than them generating code. And that feels like very much like this mezzanine step. Yeah. And I actually come from like the generating code type of the world. Like

09:40 I would argue that that's happening less, not more. >> Yeah. I think um so uh to me whether it's computer use, API use, or writing code on the fly, uh I I kind of maybe

09:51 erroneously put that all in one blank category. >> They're very different. >> They're very different. But but but what we we have an agent uh that that we're

09:57 working on where you it just makes a determination whether it should use an existing skill, it should using an existing tool from Box, or it should write code to solve that problem. And

10:06 its ability to do any one of those three at any moment ends up being incredibly useful because sometimes there's just some specific operation you want to be able to do where writing code to be able

10:16 to do that operation is just faster and we don't have to we don't we can't possibly you know kind of pre-plan for every thing that anybody would ever want to do on their documents. And so the

10:25 fact that the the model is good enough to also write code on the fly for that use case ends up just being like an amazing property even though maybe 90% of the things that it's going to do

10:34 should just be using an existing time predto takes over and over time there's like literally like seven apps on her iPhone there's seven SAS apps we end up like over time these things tend to

10:43 consolidate >> what but the but the seven apps on the iPhone is is a is a issue of humans don't want to learn these things over and over again and so I as a human I

10:52 don't I can't I don't have the mental bandwidth to learn that many apps but an agent that is going to use tools and APIs and be able to code things doesn't have any of the same constraints that we

11:01 have so I I don't know like I I don't mind >> well you could argue that there's just so many things to do and you can make interfaces sufficiently general.

11:10 >> Yeah, fair. >> I Let me I think I like what I like what you said then because I'm back. We're back. Okay, >> we're we're we're aligned. We're

11:18 aligned. No, but but I think there's something super interesting here which I do really really like which is that that where software has evolved, you know, like I use SAP all day. I work in

11:29 finance. I have to go and generate all these reports and then somebody shows up and says I want a a report that does this view slice this way and I'm like oh god I don't know how to make that right

11:39 and like now let me go wade through the SAP help system and try to find it. One thing that that let's just say AI could be very good at is it actually can navigate that surface area much much

11:52 better. you know the help is all there and so it's a matter of finding it mapping language and humans have been a bottleneck in tapping the past 25 years of software capabilities I mean like I

12:04 spent my life my life with sitting next to people on airplanes saying how can I make PowerPoint do X >> just go to the ribbon >> well and and you know it was because it

12:13 it hurt physically hurt to watch somebody suffering with bullets and numbering in Word or trying to figure out you know like oh let me just make a two-sided a two axis graph in Excel

12:23 which like is rocket science like almost no one can do that but yet it's super common and so people are like have not and so that impedance mismatch was a human user interface

12:34 >> I totally buy it on the consumption layer I totally buy it which is like the the the perfectly fluid like UI or consumption layer I just feel the backend like the systems of record it'll

12:46 probably converge into like some database >> like some generic set of APIs like that they'll connect to and like that seems seems to be the direction it's going.

12:53 >> I agree. I think you got to start >> well like so I spent all weekend like implementing my nano cloud bot and when you first start out it's like you're building an integration for everything.

13:03 The nano cloud is very like like OpenCloud has all of the integrations. NanoCloud has very few of them and so you haven't built all of its own tools >> but after you know two or three days of

13:11 these like you know you kind of have the tool integrations that you need and you know like >> yeah but back to the I mean we're talking about personal productivity

13:19 probably like you're like organizing your life or something. Well, it's work productivity. >> Okay, fine. Work productivity and then an SAP system and like and like and so

13:26 so there's like an inf like there's an infinite amount of complexity when you get to okay some company that has a global supply chain and they're dealing with 75 pieces of information across you

13:36 know 30 different systems that does require a certain amount of of horsepower from the agent that is just we've I mean we just haven't been able to get from from any architecture up

13:48 until now. But like take but that what you just described is literally what it has been doing for 50 years and will continue to do which is you know I have a friend who was the CIO of of uh the VA

14:00 >> and and he spent all he spent his time on was gluing those 75 VA systems together and it's all just integration redundancy >> perfect for integr Yeah. This I totally

14:12 agree. Okay, great. >> For integration, these things are the best, but but it's integration, right? It's literally how do I stitch these two systems,

14:18 >> but it's in but now the thing that I think is happening is it's kind of like integration on demand. >> It's it's my it's my new query in the system that that the IT team didn't

14:28 pre-wire. Now I need it to happen at runtime. >> Uh let me get off my lawn. Okay. Okay. So, okay. So, the reason I I just was in a room filled with a bunch of CFOs and

14:39 CIOS and this they all looked at me when I said something along these lines, although not as optimistic as you can imagine, but they just b they realism. No, it it caused like six of them to

14:49 come running up afterwards and say, "You're insane. You've lost all credibility with me." Because it's >> Wait, wait, what? What specifically that the the agents are going to do

14:58 integration? >> That this that the integration is a problem that will get a lot easier. Yes, >> they were against that. >> No, they're No one's against

15:07 practical, >> but their their fear is like unleashing not just the agents themselves but humans to do integration because you put people creating new integrations and you

15:18 just say please break my system of record. >> Oh yeah. And so this idea that you just create like a new API between you know system 27 and system 38

15:27 >> and and then you're that might be fine for a report because if that person wants to be wrong that's their business but you're not >> I think I think we have a readonly

15:35 version of this for a number of years before >> where N is N is very large >> and and a lot of it's just the consumption layer where the consumer is

15:43 a human being it really feels right now a lot of the a stuff is consumption >> but uh yeah I mean it's um uh you We actually have so we just rolled out the official box CLI. Thank you for the

15:54 liking the tweet on that. >> I I've been I I used it. I have some feedback. We'll talk about >> I'll take I'll take all the feedback. But it's a really interesting thing. So

16:01 we we had these all these debates internally of like okay you give Claude code the box CLI and you can now interact with your entire box system via natural language and you get the

16:12 horsepower of Opus 46 being the orchestrator of doing a bunch of operations and it's like it's like you know blows your mind. I guess I'll get some feedback, but it blows your mind in

16:20 some ways because you could just be like, upload this entire folder from my desktop into box and it'll work or process all these documents in this folder and it'll work. And um and it's

16:29 amazing. And then we started thinking through like well let's say you were a company with with you know 5,000 employees and everybody had access to some shared repository like you know

16:39 engineering documentation and you know marketing assets or whatever and everybody had cla um you know running with the CLI. Wow. We now have some really interesting new

16:50 challenges which is like like how do you coordinate you know possibly the fact that you might be hitting the system >> like you know 10,000 times an hour or something. Not from a like a performance

17:01 standpoint but just like how how do you make sure that people didn't move like a file from one thing accidentally from one folder to another folder while the other person was trying to do a write

17:09 operation and somebody else was trying to delete something because you have these agents running wild. This is this is going to be like the new big question that every CFO, CIO, etc. is running

17:19 around trying to with their hair on fire. >> There's just that's exactly what I ran into which is I played around with your example which is create the video

17:26 example which is create like a a marketing plan directory or something and like all of a sudden I'm like in some loop creating directories like >> it's going to go on as long as it can,

17:36 >> right? And and I was like I wonder what the limit is on box for nested directories because I'm about to hit it. >> Uh actually we're gonna find out too. >> Yeah. Yeah. Yeah, but it it does feel to

17:45 me that that a like a a lot of the intuition is to like build a new layer of controls and whatever. But what's actually happening on the ground is is is is the opposite. So I'll give you an

17:55 example. Like when we all picked up a lot of these personal agents, we would like give them our API keys. Yeah. We would give them our email addresses and then they would kind of access those

18:05 things and they're like, "Oh, but how can I stop it from like whatever?" Like, >> and so what everybody's doing now is you give it its own phone number. Yep. I actually gave my Nano Claw its own

18:13 credit card came in. >> Hopefully just a Visa debit card that you bought at CVS. >> All the money, >> but I have no no but then but then I

18:23 gave it its own Gmail account which you can log into and then Gmail actually has all of these arback permissions that you so you could make an argument that like >> you know we've actually built in a lot

18:32 of these permission systems. You have to treat it like a human as a separate human and then instead of like building another off layer another >> okay now can I instantly take do a take

18:41 down of of of this uh element that we're going to run into >> please >> okay so that is fantastic for personal productivity

18:48 >> and the question that we're going to run into is in an enterprise let's say I have let's just make a simple example I have a 50 person team of something should everybody als basically will we

19:00 have a hund will we have a hundred people now collaborate I I mean basically 50 humans and then 50 and then 50 agents in that same shared space and do I have I obviously have complete

19:11 oversight over my agent but what if my agent collaborates with somebody else uh and and then accidentally gets access to some resource because they were sharing with that other person and I'm not

19:22 supposed to have access to that resource and now this autonomous sort of stateful you know agent is is running around working on somebody else's information. default end to end argument is you treat

19:32 them like human beings and >> it doesn't work. So you can't fully treat them like humans because here's the thing and with regular humans you don't get to look at the Slack channel

19:40 of the person that that is working with you or working for you. You don't get to log in as them. You don't get to oversee them. You are they are accountable for their own set of execution in the real

19:50 world. You don't get penalized for what how they screw up the agent. You have all the liability of whatever they're doing. you do have complete oversight and you're probably going to need to

19:59 have that complete oversight. They have no right to privacy. So, so there's going to be these some of these breakdowns that aren't as clean as just treat them like a person because I need

20:09 to be able to kind of I need to be able to give access to something to them, but I also need to be able to like log in as them at some point and be like, "No, no, you [ __ ] up the whole thing and I need

20:18 to undo it all." But if I can log in as them, how could they have operated in the real world working with other people and keeping anything, you know, confidential or secure or whatever? So,

20:27 it really is still an extension of you. It's like almost impossible to get around them being an extension of you. So, now the thing that we're thinking through that we're not going to be able

20:34 to do anytime soon. >> I I I just doesn't logically follow. Yeah, >> maybe. But, for example, um for my employees, I can log in as them.

20:42 >> You don't though. You don't you don't >> I can get access to their email. >> Yeah. No, in like in a if you get like sued. You're not logging in. You're not logging in as them on a regular basis

20:51 because they sent one email. >> Isn't the right operating model with an agent the same thing? It's like >> the risk is like a thousand times greater. Like these people like they

20:58 will just leak your information whenever they want. Like they will happily just go and send some email to somebody because they got prompted. >> You think the terminal state is that

21:06 these things are still these sloppy computers and therefore they will always >> I don't like the word sloppy. Um unless we're saying it very in a colloquial sense. Um but like

21:14 >> they'll they'll never be able to contain information. They'll never >> um so we're like I think the ability for you to keep the something in the context window a secret like as in like you tell

21:26 it do not reveal X thing in the context window. I think that's a very hard problem to solve. >> Let's so then so then thus if anything can ever enter that context window

21:35 because they have access to a resource then in theory you should assume it can be you know prompt ejected out of the pro of the context window. And I don't know that we know of a way to solve that

21:43 at the moment. Like that's like and so so if I know your new agent's, you know, email address and I email it like it's it's an assistant, but like I can I can social engineer it 10 times easier than

21:55 a human, like it'll be hard for you to pull off that that agent is now also has access to your like M&A documents and stuff. >> But isn't this like literally all of AI

22:04 right now? >> Which part? >> I mean, the fact that we've got these shared systems that we use the intelligence for that have shared

22:10 context But what do you mean by it's all of AI? >> Well, I'm just saying like right now when we use AI internally and agents internally, this is exactly how we use

22:18 them. >> But this is why you were they're working as as you effectively right now and we don't yet know how to make them not work as you.

22:24 >> Let me offer an example. Let me let me offer an example. >> We don't and then solving this problem though like like the uh like the issue will be will be like you will

22:35 just be able to trick the agent to reveal information. So then so then they that's why like having them have access to their own resources where they can fully make their own decisions is not

22:45 yet something that we've been able to pull off. >> But there's a perfect example for solving your problem which is we already lived through this with open source.

22:52 >> Yes. >> The model for open source >> was it's all there and you just use it and you pick and choose. And then like nobody debated it because the world was

23:02 much smaller then and we weren't all on X doing podcasts when this was all happening. But then quickly everybody realized all the problems you you were just talking about. Like if you're

23:10 running a big company, you can't have some person just go copy in a bunch of source code from open source into your commercial product like that. There was a whole licensing problem, a whole

23:20 quality a whole bunch of stuff. And so all these norms got developed. The the debate that we're happening that's happening right now is just is this really interesting modern artifact of

23:31 how new technologies develop, which is this is all happening in real time. it during open source like we met in a conference room this big and debated how much open source we could use in Windows

23:41 or office right and nobody in the internet knew we were having this debate it was a very and it I think it's just so interesting that not just this the debate about specifics but this whole

23:52 notion of where is this heading is happening in writ large and everybody is just trying to get to the end state >> like way way way more like in a in a sense more quickly than we can actually

24:04 reach the end state. And so what really needs to happen is people just need to go build. >> We need standards. >> What?

24:12 >> We just need some standards. >> I think I think we've got different intuitions on the end state. >> No, no, we don't want my intuition, but like

24:19 >> one could make an end to end argument that these things actually converge on the same type of reliability as a human being, which is exactly how we view like self-driving. And in that case, you use

24:29 the exact same mechanisms that we use to protect with human beings. like you consider insider threat, you consider the fact that people can be bought off, you consider the fact that people make

24:37 mistakes and you build and that's operational processes. So, so one intuition is like that will be the end state. >> Yeah.

24:44 >> There's another intuition. >> Well, the point is like I'm JUST SAYING I'M TALKING ABOUT WHERE we're at now. I actually I don't know that we disagree on the end state and and and by the way

24:51 like strategically we're hedging because we're going to build we're gonna we're gonna build Asian users and reg and we're like so we're like I love the idea of open claw having a box account and it

25:01 it operates and it's like twice as many accounts. >> Exactly. THIS IS GREAT DOUBLE THE NO I LOVE IT. I'm I'm just saying on the ground right now, we don't yet know how

25:10 to give it an M&A data room to fully securely be able to >> But that but it's actually it is harder than that though because the the threat >> he's a skeptic. I'm

25:20 >> the the threat vectors are going to be way more sophisticated. So, we do have a a a cat and a mouse game going on where you can't just assume that the agent acts like a human does today because

25:31 it's going to be the fastest, most thoughtful, craziest ass human that ever existed trying to actually leak the information because it got injected in some way. Yeah. And so there part of

25:43 what's going to happen is you're we're going to go through this phase where like the enterprise customers are just going to like close everything off until there's some sense of sanity in all of

25:53 this and then but in the meantime the individual and specifically the developers have such a big >> are going to and that's going to be the that I think is the most exciting

26:03 tension that's going to happen is that that the enterprises are going to be are are going to get left behind by these sort of advanced individ individuals which will then start to look like the

26:13 startups and the startups will start to move much much faster than enterprises because they just don't have any of these problems and >> no the the and and you know you could

26:23 end up with like the agent going rogue in a startup and doing you had no you had no employees that go rogue routinely in startups. >> Yeah. Well, it'll just be an episode of

26:31 Silicon Valley and so you know big deal. >> I agree with you on like the okay it's it's people etc. the same risk. I think you there's a couple, you know, differences though, uh, in the sense

26:42 that that I can't really threaten, you know, the like cloud code that it's just I'm gonna pull the plug on it in the same way that you do have that threat as a regular employee is like you at least

26:52 like 95% of people are not, you know, trying to do bad stuff, you know, within an organization, >> but they they they're not trying, but the ability to inadvertently do bad

27:02 stuff. Yeah. to your point about it still not having that stuff fixed, >> I would I would argue that that uh it's a lot easier to have people not share, let's say, files with somebody outside

27:11 the company in a in a in a wrong way more than it is for an agent right now to to have that same set of instructions >> and also you have the tools so that you you can basically stop that at a whole

27:21 different level of abstraction >> which is why you have to build this into software and but I do think actually if you were to like if you were like put a bow around your last point that a lot of

27:29 this is actually why the diffusion of AI capability is going to take longer than people in Silicon Valley realize because what's happening is like we see startups that can start from the ground up

27:39 without any of the risks that we're talking about because they have nothing to blow up and and so we look at that as the trajectory that we're on and then you go to like JP Morgan and you're like

27:49 how are you going to set up NanoClaw uh to to be able to to actually like you know automate your business anytime soon and it's like oh okay there's going to be like a little bit of a gap there.

27:59 >> Yeah. >> Well, what do you guys think? Here's I think that that opens up a pretty interesting problem which is this split between big and small startup and

28:08 enterprise which is just that >> that the the enterp the current SAS vendors who are all struggling in this SAS apocalypse weirdness that I I don't really agree with but they are

28:18 struggling with this problem that they they don't really sell the line of business data they actually sell this intelligence and domain expertise in this whole system and the agent side of

28:30 things wants to only buy the data now >> and they only want to license the data and they want to have unlimited access to the data but they've actually never really enabled that like that's never

28:41 been their business and it's been a long-standing tension point with the likes of Workday and SAP and stuff like how much API access to have >> I mean Salesforce went through three

28:50 different massive platform redesigns you know it's I think that that's a particularly interesting problem not for the same reason that Wall Street does Wall Street's all wrong about the

29:01 economics and the problem and all that stuff. But from a technology perspective, what does system of record mean in in the face of people wanting to access the data when the data for

29:12 training or for >> well they they are talking about for I think of it as executing the day-to-day operations. Their concern is that somebody that they want to do the

29:22 training layer on on your data like I'm a big customer. They want to do the my vendor wants to build a training build. >> Actually, even even if you don't even get into training, they're concerned

29:32 because because like monetizing, you know, uh you know, sending a little bit over the internet versus like you're in my UI, it's a very different level of monetization initially that you

29:44 >> that's sort of that monetization part is the Wall Street point. I because I think like look there is so much domain stuff in in an SAP just to pick an example, not to pick on them or anything, but

29:53 like they're not going anywhere. like it's ridiculous. It's just absurd to think you're gonna vibe code your way to like SAP. But >> also all of that those all of that

30:03 domain knowledge it's not so it's not just represented in some well orchestrated data layer as much as they tried. >> There's like a whole bunch in the in the

30:11 UI. There's a whole bunch in middle tiers. There's a whole bunch in just how you use it. And so I I'm really unsure how this thing evolves because SAP isn't going anywhere. So then that's going to

30:23 slow the diffusion of AI on that particular data source independent of whether or not it's agentified AI that's doing stuff or just read only reporting on stuff. So where do you come down on

30:34 where do you think that's going to go? >> I'm afraid of saying something that okay >> that's otherwise you're not going to get invited back. Say something good. Uh I'm

30:46 I'm I think I've I think I'm I've drunk the Kool-Aid on uh on uh build something agents want. Um so this kind of the Paul Graham term kind of like emerged on you know the past year on this topic which

30:59 is just like like event and I I think we would actually then I fully agree on this which is at some point at you do enough sort of iterations of this and at some point the agent is largely in

31:10 charge of what tools it wants to implement and use and and whatnot. And yes, it can't. The agent is not going to be able to change out an enterprise system, but like again, enough

31:20 generations later, the agent might might just run into so many walls with your software that it's just going to say, "You need to finally rip out your legacy HR system or I'm not going to be able to

31:31 automate this workflow for you." Yeah. So, I do think you have this really interesting, you know, dynamic, which is back to this whole whole point of imagine that there's a hundred or a

31:38 thousand times more agent volume on software than people. You do that enough times and eventually the software stack that agents talk to has to be built for them and and maybe there'll be a couple

31:50 holdouts maybe maybe a couple ERP systems are like the final hold outs that don't do that but everything else you basically like your business will will be your business performance will

32:00 correlate to how well your agents can get access to the information they need to do their work and so thus your enterprise IT stack has to be set up in such a way to support that and so agents

32:10 are kind of in charge And because basically your software has to support those agents being effective. And then that's going to mean everybody that built a SAS business or a software

32:19 business is like the game is can you build really really high quality APIs. Can you have a way of monetizing that? You know, do you have a way of handling the identities and and all of the access

32:29 controls for agents and like like that becomes the new problem you have to solve if you're building a software company. Um, and um, uh, so yeah, like and then and then how you monetize it,

32:39 like do do you monetize it, like does workday charge a penny for every HR record it pulls? Like we'll figure that out. I do think that in some businesses it could mean less revenue and then in

32:47 other businesses it can mean a lot more revenue. Like the thing we get excited by is like every agent really loves working with files. So there'll probably be more files in the future than than

32:55 there was going to be before. And so, you know, can we build a platform that like makes it really easy for agents to work with that data? you know, we we we're betting that that's actually a

33:03 really optimistic outcome for for you know, our our kind of business model. There might be some business models that are like more constrained because like the agent is doing more of the value

33:11 than than the software is at in that kind of future scenario and then there'll be everything in between. >> Can I can I quibble with one thing? I >> You're going to quibble with that? I

33:18 thought that was like so not controversial. >> No, no. I I I generally >> We're here to quibble. >> No, no, no, no. But there's one thing I

33:24 think like Paul Graham and many actually gloss over, which is they focus on the interface. They'll say things like you build something for the agents >> and I actually think that's exactly

33:32 wrong. Okay. >> In the sense that >> and to be fair to Paul Graham uh he didn't he had >> extrapolated

33:39 I have brought I brought Paul Graham into this is great. So okay let me let me talk about something people in the abstract say things like now you're marketing to agents the most important

33:48 thing is to being like whatever you're like an API you've got a good IDL. I actually think that's almost exactly wrong which is wow that's >> this is breaking podcast news. That's

33:58 the one thing agents are really good at. >> Oh, okay. Is finding their way through >> at the end of the day, like it's the semantics that end up mattering a lot more, right? And so, like the agents in

34:07 in in my recollection or in in my experience are very very good at picking the right >> backend for whatever they're doing. So, they don't they're not like, oh, like

34:15 the interface for this is very good, the document, it's none of that. They're like they're like the cost parameters of this the durability of that like and so like they actually have the collective

34:24 wisdom of our experience using these platforms like let's take cloud platforms there's a bunch of cloud platforms out there y and whenever I ask an agent to choose a platform it's

34:32 actually using meaningful stuff not interface stuff so I think as an industry we're so focused on these interfaces like oh you need to like market to agents this and that when

34:41 really I think that we're going to be pushed to actually build better systems and that's what's going to be chosen. Okay. Actually, so then there's probably no quibbling. I think we're actually

34:47 fully aligned. I'm sorry to ruin the quibble thing. Um I I I don't treat this as like a, you know, kind of a marketing, you know, esque thing. I I more mean like if your tool is closed

34:56 off to the agent, the agent eventually will find a better tool for that company to go use. And so and so what will happen is is it used to be that you would go to like Gartner to be like,

35:06 tell me what to do. Tell me what system to use or whatot. at at some point with enough iterations the the agent is going to say you should probably use this kind of database for this type of operation

35:16 and if you're not in if you're not in there then you're it's your DOA >> and and I I think we should actually be celebrating this because agents are actually pretty smart at choosing the

35:24 right technology in the past I really think it was a lot of the other things that that caused people to buy it which is like >> but but don't worry we will in Silicon

35:31 Valley we will ruin the meritocracy of this very quickly because you'll just like like I'm going to outspend >> well the agent they'll bring an API to incent the agent, but that you know

35:42 there's a the marketing the marketing agent at workday the marketing agent at workday will have the ability to purchase the recommendations. >> Find a way to replicate steak dinners

35:50 for agents. >> Yeah. Like what is the >> there is a but here's a real here's a thing that again that that happened with the web sort of internally like internal

35:59 like just pick internal sites like every company had fileshares with like the best documentation the best slideshows the best financial models for any department or working area and people

36:10 sort of got familiar with that and then when they didn't find the one they wanted they created a new one and many organizations sort of operated like that was essentially a free market in fact

36:20 Because before the world of box, like it didn't if it was in a file, they just didn't care, right? They only cared about if it was in SQL. >> And so one of the risks with the model

36:30 you're describing is that the agents themselves will spin up what becomes like a de facto new system of record. >> Oh, they're going to fragment the heck out of

36:38 >> in the in what you the IT people think of as some middleware enduser BS area. And and I I think that that is a is a real risk is is that like in a sense like the the the the macros end up

36:53 running the the corporation. And so I think that they've seen this movie and they've seen what happens when you let marketing just go buy a website on the internet to do an event and then it's

37:03 like a huge security vulnerability and the mailing list is leaked and the whole company gets sued and all. And so I think there's a lot more real world tension in this dynamic than than we

37:14 just let on. Yeah. But I also think it's one of these ones where you you you know there organizations are going to run at different paces >> and JP Morgan is going to be the slowest

37:25 at at doing this and the startups are going to be the fastest but the the delta is huge but even the startup one is a little far off because even startups do need some systems of record

37:36 at some point and and they are going to all start with some SAS and they're not going to replace it very quickly. So I think it's a little bit trickier. So it feels like there's like there's two very

37:45 competing viewpoints on on this one. And like Elon said it was like okay we're going to like issue a prompt and it's going to like spit out machine code and that's basically the collapsing of

37:54 layers view like whatever existing interfaces and layers that we've created in the past are all going to go away and it's literally like prompt to machine code. The other argument like the

38:02 history of systems is layers never go away. they just get layered, right? And because a lot of the layers are actually more of like organizational boundaries or like state boundaries or regular

38:12 >> compatibility, they're just they stay for compatibility, >> right? So, so the the other argument is is like we've actually evolved these layers very specifically and uh because

38:20 of like more human and organizational needs and they're not going to change and the agents are going to go ahead and map to those. And I I tend to be in that latter camp like I don't think that

38:28 we're I think like systems are going to continue to be used in fairly similar ways. Maybe there's more agents using them, but I don't think they're going to evolve as much.

38:35 >> Elon might be back in the like anthropic category of the anthropic growth marketer, which which is um like he he like, you know, over the years when you kind of like study the various IT, you

38:48 know, departments of of his companies like they are the most I mean he could do that. >> He can do it. He's the most homegrown like this is first. Elon AI would do

38:57 that. AI, >> but also it's >> and then and then from your mortals you're like, "Yeah, we kind of just want a CRM system that like kind of works the

39:04 same way every time." >> I mean, this is not this is not it also hasn't been been not tried before. Like you if you were to look at an ERP system from first principles you know well in

39:16 1970 whatever when SAP started there were a bunch of different assumptions and today you would start from a different set of assumptions about what's important and you would architect

39:24 a thing completely differently but then it would still only last like 10 years until you thought wow that was a broken decision and and I and so I think that >> that there's intentionality in layers

39:34 but you >> you but there's also this first principles thing >> and you you know there's that always will exist because the decisions you can

39:43 make at first principles at any given time mandate a whole bunch of different stuff. And so even if you don't go with LAR, which made total sense 10 years ago, you still need 10 or 15 years to

39:53 get to where LAR >> not having LAR worked. And then now there's going to be a whole bunch of other things that you're like, "Wow, we could have done that completely

40:01 different." And so I feel like this is again like this discussion about trying to race to an end point. Yeah. But let's see a first example of what you described happening and and I think that

40:11 that's going to be the real tell because I think that there were just companies will figure all this out and I think that they will just fall back on layers and architectural models because it's

40:21 the only way >> we know how to think about it for policy. We know how to think about for security. We know how to think about >> but it's also the only way to build a

40:27 system. >> Yeah. >> Otherw otherwise you're just building an app. And if you're building an app to do one thing, we don't need all of this.

40:34 Like there's a whole different way to do it. the the uh the thing that I'm pretty fascinated by is uh and I don't even have any amazing like data points or anecdotes but the the at least the

40:42 notion of these sort of companies that are emerging in this in these kind of services categories from the ground up from the pure first principles approach which is like okay well if I could start

40:53 a marketing agency or consultant you know engineering consulting company or I don't know maybe somebody's doing this for law firms >> construction work or anything yeah like

41:02 >> well maybe construction >> design construction design architect construction Exactly. Architecture, design, anything that would be like a knowledge worker kind of services

41:08 company because you could kind of build your company pretty differently if you had no constraints of I have no information barriers and and boundaries of what people should have access to. I

41:18 can give the agent just all the context it needs to do its work. I can write software on the fly for particular things like like I do think that will be relatively disruptive, you know, for

41:28 some time until the the bigger incumbents can kind of, you know, get out of the way on this. Um, and that will at least create, you know, some precedent or or case studies of what

41:36 what this new sort of corporation could look like. But I do, you know, over time they'll still run into the same exact problems of every other corporation, which

41:44 >> well, they'll run into they'll run into geography or market segments, you know, or or distribution challenges like those those things. Anything outside your little walls, you will run into the

41:54 physical world, >> right? >> I do kind of like the idea that there are some new business models that open up now. Oh, of course. Yeah. Yeah. Yeah.

42:03 >> Because like there's so much either information or software that that basically goes underutilized by like a hundredx relative to like what what its economic value is simply because like

42:13 nobody wants to pay five cents for accessing a you know piece of data or use a tool for $1 once. But like you do give these agents, you know, a budget and and a protocol to work with and all

42:24 of a sudden you're like, "Oh, like on the fly they can go get medical research for some deep research task they're doing and I'll pay like $3 for that and the agent is able to go and transact."

42:33 Like it kind of opens up a whole new world of business models for for the internet. >> Let me Oh, I'm gonna You're That was too nice. Okay. No, you're gonna go farther.

42:42 No, that one is one where that's actually the biggest I think that the biggest sort of >> um in the air problem right now is everybody is trying to figure out the

42:52 economics of all of this when they're off by at least an order of magnitude on how big the opportunity is. Okay, because the the new models that people will come up with that nobody knows what

43:02 they are right now, but they will absolutely come out with new models because that's what happens with every new technology. And the thing that holds back the sort of the discussion now is

43:11 you basically have a bunch of finance and Wall Street people trying to justify GPUs and tokens and things like as if we're in some old world and they're they're so they're they're viewing the

43:22 world of revenue as sort of this linear step literally linear growth curve and trying to justify all the all the expense when people are going to create like this was the problem with PCs.

43:33 People viewed PCs as a finite market because they just viewed the consumption of MIPS as some finite thing and they didn't think what would happen if we put all those MIPs on every desktop and in

43:44 particular people thought software just came with the MIPS and nobody thought oh well they'll just sell the software one guy did and and it turns out that was like a really good idea and the same

43:57 Bill and Paul and and the same thing happened but the same thing happened with the cloud which was people looked at the cloud and they said, "Oh, we're going to take all of the the server

44:06 business," which was like literally like 60,000 units a year, >> right? >> And we're just going to move it to someone else's data center,

44:13 >> right? And that's the >> and that would be the business, and then we'll divide up the the price, right? And nobody went, "Oh, they're going to people are going to use a thousand times

44:20 as much, right, >> of the resource leveling if we move it there." And that's exactly I mean that's the thing that I I I it just drives me absolutely bonkers that the Wall Street

44:30 models have this fixed revenue pie >> zero sum thinking >> and it's it's this weird zero sum where they they just think that the amount of money that a company is going to spend

44:38 and like this was the problem with with Salesforce that they faced when you were starting too but like Mark was was just blazing the trail which was like the CRM business was two billion a year and it

44:49 was two billion in like you had to go buy all these servers and these Oracle licenses and this huge headache and years of deployment and consulting when if you could just get sales people to

44:58 sign up individually they all will sign up with no friction and that's that is exact there is no no doubt that that is what's going to happen with AI >> let me give you an example of this so I

45:08 um you know I've been in for investing for 10 years now I probably have a portfolio of 240 companies I work with some visibility let's say into 50 of them these are all infrastructure

45:17 companies some historically done well some not so well every single one of them has gone asmtoic in the six months and you're like, "Okay, why is this?" It just turns out there's so much more

45:28 software being written now than ever has been before. >> And so it's like and and and it's not because they've got enterprise customers, you know, it's just because

45:36 there's just so much consumption of the of of the infrastructure layer right now. And so with more software, with more agents, there's going to be a lot more consumption of computer resources.

45:44 So certainly in the case of the computer side of things, we're see a mess. Well, we haven't even gotten to the point yet where everyone's phone >> is a huge consumer of AI, right?

45:53 >> So once everybody's phone and on device, like once your phone on device is consuming AI, the amount of it is going to go up by a billion. >> So do you like the microp payment piece?

46:03 >> I all of them. The microp payments, there's a little bit of microp payments that has come with every technology there where they always think that like you'll be able to get like a fraction of

46:11 a penny, but but in the end, especially in the enterprise, like people are just going to consume things. It's just cheaper and easier to buy like a bulk license for a bunch of stuff.

46:20 >> Yeah. You want some predictability on that. >> Well, you want predictability and you just want like to not have to think about.

46:25 >> I just I like the idea that it is the first time that you could like like there just the agent doesn't care about the friction of a small transaction. And so it's the first time that you could

46:34 have resources behind a payw wall that something will actually be willing to pay for that resource. >> The world has built up the infrastructure to to aggregate those

46:41 payments into something efficient for a customer, a service, >> right? And and because tokens are such a significant part of COGS right now, it is pushing the industry to do usage base

46:52 >> in a way that we had like I remember when we went from like perpetual to recurring and that required like a bunch of huge changes like we're like we're going through the exact same change

47:00 right now towards usage base and usage base is pretty granular and it actually allows I mean again you will have a contract with like >> you know we went through this with with

47:09 AWS like people learned >> to do the credit and we went through the phase where like People were like so terrified of cloud compute that they were like we need companies in the

47:19 middle to help us find the cheapest and to arbitrate it all and >> okay well now you write tokens into this and I don't see how we possibly have time in this in this conversation about

47:28 as long as you guys can stay. >> Okay. But like like the the engineering compute budget conversation to me is going to be just like the most wild one in the next couple years. It's just like

47:38 how much should you allocate of your engineering expense to tokens tokens and and it's like you you know depending on who you read on Twitter it could be 1% and the other and other side it could be

47:48 100%. >> And it's like >> yeah but this stuff >> no no no what CFOs have to literally they actually have to know the answer to

47:55 >> I I understand they have to know but CFOs always want to know the answers to things that don't have answers. >> No Wall Street is going to make them know the answer.

48:02 >> No no Wall Street is going to make them come up with some number and hold them to it and then they'll get fired and then it'll but it Okay. Okay. R&D R&D is somewhere between 14 to 30% of revenue

48:13 of any public technology company. Let's just say okay. The difference between compute being 2x the cost of your engineering team or or you know you know 3% more is like that's EP that's all

48:25 your EPS. >> I I get it. We will have to know the answer. >> I'm perfectly willing to sacrifice a few CFOs at the altit of this.

48:32 >> I want that. That's a good clip by the way. But but the reason the reason is is because again this is this is trying to know what we just don't know right now. >> And and this has happened with internet

48:43 bandwidth. This has happened >> this is not even close to internet bandwidth. >> Oh no no no. I I beg to differ like like people were free. It happened with

48:52 vacuum tubes. It happened with transistors. It has happened with every technology. There was this oh my god like it happened with programmers. There was a there there was a time when

49:01 programmers were going to swallow every company. >> Yeah. And that's not it was in my lifetime, not some madeup weird. >> Yeah. But I don't think we've ever had a

49:07 point where the end you every end user in an organization has has sort of a completely elastic ability to spin up a resource on their behalf. >> Well, it certainly

49:18 >> that actually is actually in many cases very valid for them to go spin it up. >> But it certainly it certainly rhymes with what happened in the early 2000s with cloud. I remember very similar

49:26 discussions when we went from capex to opex and then unlimited spend. >> Oh no. And there were remember there were companies who the CFOs would sit in our briefing center here and say you

49:34 don't understand we are like we are agriculture I can see the rhyming I can see >> we are an agriculture company we we only know capex we we we have no or or no

49:44 sold through this right no we both or or like oh no we are an opex based company so if you tell us I we love the cloud because we just shipped everything shifted everything to OPEX and so all of

49:55 the stuff like the rules of accounting work out also don't I I keep thinking do not discount the local compute engine as being a release valve for all of this. >> When's that going to happen?

50:06 >> Well, the the question is it's not when does it just happen with today's view of the technology, but how all of a sudden? Well, wow. There's >> Has that historically ever gone that

50:14 direction? >> Yeah, exactly. It goes the opposite, right? >> No, it went all to the client. >> Well, okay. Go back to the 80s. Yes.

50:20 >> No, that's most of the examples that we're hearing so far. >> Whoa. >> That was uncalled for vacuum tubes. He's talking about vacuum.

50:30 >> But I do those examples because you can't argue with them and it's much easier that way. >> I You're right. I can't prosecute all but it's only been, you know, 10 or 15

50:39 years that it's all that it moved back to all cloud. And then what has happened recently with that? A lot of people wake up in the morning and they say, "Oh, we're moving back to doing some critical

50:49 but stationary workflows on on prem and >> with AI." That's true. >> Dude, you wrote the blog post, man. Uh don't make me go through the the archives. the repaid.

50:59 >> I had to deal with so many Wall Street questions on that one by the way. >> Well, because your also because your competitor >> what

51:04 >> went went back to >> rep. We're talking we're talking about two very different I agree I agree with like building your own data center. I'm talking about this this notion of edge

51:14 computing where things go to devices like that seems to be >> I I'm more I I'm more in the like a cloud maximalist camp. But but but sorry. So you just don't think you don't

51:24 even think for like one second that it matters whether like how you're supposed to be an engineering leader right now managing the compute budget of the engineering team.

51:32 >> No, of course it matters. I just think in the long term this thing will get >> Oh, sure. Long term all what do we who cares? We don't even need podcast. Here's what I think. Let me here's

51:42 >> But here's a rule here's a rule of thumb first. Like the startups are going to burn through available capital pretending like it's not a problem and they are going to do that. do that

51:52 anyway, >> right? And a lot of big companies are going to be so terrified they're just going to freeze and not do anything. And then people are going to actually start

51:59 buying it on their own and they're going to do all the things that companies do when they're big, have a lot of money but don't want to spend it. And in the middle I we are going to see like if you

52:08 pick a category of product or go to market or something there are going to be people who are willing to make the bet >> for whatever reasons that they can

52:15 because of their financials and they are going to go ahead and they are going to become the people who lead in the space as so long as they can maintain the financials. Now, they might do it in

52:26 they might say, "Oh, we're going to just do it here in this particular application space or here in this particular usage space, but this this idea that there are that nobody is going

52:36 to go in and because they're so terrified that the CFO is going to get fired or something is is just crazy." Yeah. And but then there are going to be CFOs who make a mistake and like, okay,

52:45 everybody gets a little. Yes. >> Well, if they do that, that's a complete fail. Yes. But but also or like you get you like you there is a really interesting like um uh you know finesse

52:55 here which is like you don't really want your engineers right now having to think about compute budget because we're still developing the oh okay so that set you over like

53:05 >> I just feel like we've been having the discussion for 15 years when it comes to cloud. This is totally new. Only only like 10 only like 10% of your engineering had to think about cloud

53:16 infrastructure. >> In in 2016 to 2018 time frame, there's a whole set of companies that was basically like like the dashboard for what was it called? Fin where the

53:26 developers >> fin is very cool right now because >> developers would have would developers have access because cloud spins were getting out of control and API spend

53:33 were getting out of control and so it was like you know here's your Twilio spin here's >> but but you know it's it's pretty different and I'm I'm going to wait for

53:40 all the comments to come in on YouTube to call you out on this like it's it's like you can get into a conference room and just be like hey can you make that one you know kind of algorithm a little

53:49 bit more efficient so you don't use as much you know of our cluster at this time of night or whatever and then you get out of meeting somebody go improves it and you're good.

53:57 >> This is like every single prompt that every engineer is doing like do you like you have to decide like do you want that to be a longunning prompt? Do you want do you want to be a longunning agent? Do

54:06 you want to parallelize that? >> Like like do you want like what is your comfort level of wasted tokens? Like for me right now I'm like yeah we should probably waste a lot of tokens because

54:15 that means that we're like trying new things. Yeah. and like like should your head of engineering be happy if if you run 10 experiments in parallel and thus you're obviously going to be wasting 90%

54:26 of the tokens um but you're going to choose one of the successful paths or do you want to tell the team no before you go do that make sure to like like really go and design the perfect system like we

54:36 actually have a whole bunch of open questions that are going to start to happen like literally as of this recording time people are freaking out right now on the new cloud code max plan

54:44 you know whole like like because they're getting blocked after like three prompts So this is this is going to be like a very like real topic until we can actually find a way to build data center

54:53 capacity. >> Oh that's a different problem. Okay. No, because no one is well assuming well wait no you can assume that if we build more capacity the price will drop

55:01 because there is more capacity and we're priced now based on limited capac whatever but like this is just going to get worked out and I feel bad for the those that have to make a decision

55:11 immediately about which 17 people get no more tokens this week or or whatever and that the whole company is walking around with like a token card and the the person in the lunch line

55:23 Yeah. like it's the person in the lunch line is punching their card every time they do. But but like I you know I I I don't know like somebody we were talking about today about performance and how

55:33 like you know we used to write command line tools that spit out the time it took after you ran a command line just so you knew and if you knew you were getting better or worse and you know but

55:46 you the thing is is this is all going to go away. There's absolutely no doubt that this just goes away and >> I think on the 10ear time frame >> and the biggest reason it does is is

55:55 because you you have to do the benny off kind of math which is if you're paying an enterprise salesperson you know a million dollars a year you have to ask how much is their tool worth.

56:05 >> Yeah. >> And if you're paying an engineer X dollars a year well at some point their their tooling is worth >> it's absolutely worth it

56:14 >> and it's not going to even be an issue and and >> Yeah. Yeah. Yeah. I I don't think it's um I think >> and so if there's a capacity thing in

56:20 the short term, yeah, >> that's a different that that is a different problem driving the price than this just we're going to forever have to be in some budgeting exercise.

56:28 >> I think I think law of large numbers solves this because because eventually you have enough engineers, they're using this much compute, but like we're in a transition phase where like most people

56:37 thought, you know, the two-year ago level of spend on AI, which is a it's a chatbot and >> Yeah. Yeah. But they were wrong. >> Yeah. Right. Okay.

56:44 >> But they were wrong. But they were wrong. >> We tried to warn them. No, but they were wrong because they saw it as this this particular use case. Yes. And the but

56:53 again like you you know >> like the vacuum tube thing you made fun of. >> Yeah. >> But but like there was a time when they

57:02 thought that the that like whole like all of the Dakotas would be covered in vacuum tube warehouses and people on roller skates would be running up and down the aisles replacing vacuum tubes

57:11 just so we could fight World War II. M I I mean like that was how that was the and they thought that and then someone said hey how about a transistor and and like we are going to have a transistor

57:22 moment with all of this. It might just be more supply the way we think of it >> but it also might be an actual algorithmic fundamental change. It could be a change in the hardware. There's a

57:32 lot of stuff that can happen that changes this particular moment in time. It's just this I think it's particularly weird that everybody has just gotten to token. Yeah. which is the same thing

57:42 that happened with IBM and mainframes. People were on MIPS and then one day the reality was IBM was selling more MIPS for fewer dollars every year. Yeah. And didn't even realize it. And they were

57:54 still pricing their mainframes by MIPS until it got pointed out to them that they were on a decreasing curve because they were making MIPS faster than they can charge for.

58:03 >> And that's what's going to happen guaranteed. >> Love it. >> I I just said that in a hardcore way. >> That was great. sound like it sounds

58:09 really great to sound like I know what I'm making. >> Guaranteed. >> I actually probably believe it.

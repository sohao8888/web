视频链接：[https://www.youtube.com/watch?v=GJQFPcoogME&list=WL&index=1&pp=iAQBsAgC](https://www.youtube.com/watch?v=GJQFPcoogME&list=WL&index=1&pp=iAQBsAgC)
视频发布时间：2026-04-08
频道名：RiskReversal Media

## 转录内容

00:02 Welcome to Okay Computer. I am Dan Nathan. That is Gan Monster. He is the managing partner at Deep Water Asset Management. Gan, welcome back to the podcast.

00:09 >> Hi, Dan. >> All right. You and I, if you're viewing this, if you're watching it on the YouTube, you and I um kind of look like twins here. It's fine. You know, we did

00:18 not color coordinate, but it looks great. I I appreciate you digging my fit, cuz I dig your fit, too. Okay. How's that? >> I love it. Right back at you. I I always

00:25 love your office here because there's something near and dear uh to my heart right over your right shoulder. It is the what the what was it called again? The Apple speaker is something really

00:36 simple like that. >> It's called uh iPod Oh my goodness. >> Yeah, there was it was it had some odd name. >> Yeah, we we'll we'll come up with it.

00:45 Our team will find it while you and I are talking. But I also love that you have the iPod mini in that. You and I have talked in the past. I got all that stuff, too. So someday we'll just nerd

00:54 out and bring it all up and we'll have like >> we can do an episode just on nerding on old tech. >> That that that would be uh super super

01:00 fun. Um you and I got a lot to talk about because it's it's shocking. We are heading into Q1 earnings season already. Um and I think that given the environment that we're in, there's so

01:09 many moving parts, right, with the you know mega cap tech, how they trade in the public markets, but then the valuations that we see that keep skipping higher in the private markets.

01:20 We'll talk a little bit about that. Um, I got to hit Microsoft with you a little bit. I know this is one that you have not been that in favor of. It acts so badly. I wonder if the sentiment is too

01:30 negative. The relative strength in Google. Um, and I think that is a story versus Microsoft. Apple fold. A little debate here. We're recording this in the afternoon of Tuesday. You're listening

01:41 to this um on Wednesday morning. And then just this open AI saga. Man, it just sounds like it's gone from bad to worse despite the fact that the valuation keeps skipping higher. And

01:52 then this is really cool. You just got off the set, I think, of CNBC are doing a hit and you have a piece coming out on CNBC.com detailing your views on SpaceX. We'll get a little preview of that in

02:06 front of this IPO that they've confidentially filed. I think that was last week. All right, Gan, let's start with the Mag 7. You know, I like to call it the faithful eight. As you and I are

02:16 talking right now, the only two names in that group that are up are Broadcom and Google for reasons that I'd love for you to go into a little bit. This is a deal with Anthropic for compute. It's

02:28 Broadcom with working with Google on Google's tensor processing units. Break this down for us in a market where the NASDAQ was down one and a half% earlier in the day. These two names were two of

02:40 the biggest bright spots. I have a feeling that if Anthropic was publicly listed, it would have already also been up. Why the positive sentiment about this deal?

02:48 >> Well, it's a validation that Anthropic is in a good place and that they need more capacity. And as part of this too, if you look at Enthropics, their revenue uh it's measured by kind of their

03:01 monthly revenue run rate, but has gone from nine billion at the end of 2025 to 30 billion. now just announced now the big step up has I mean that is just a spectacular step up and the fact that

03:15 they are doing this uh with Google and Broadcom really suggests that even though they've had this big step up that there's more to come that they're seeing even a higher growth rate down the road.

03:26 So from Google's perspective and Broadcom's perspective, it's validation that they're in a good place and that's going to be some business. From Enthropic, as you mentioned, if they

03:34 were a public company, they would be up to date because what they're really signaling is that they just can't they simply can't keep up and they need more capacity. And so the narrative that uh

03:44 this is somehow slowing down or topping out, this these announcements kind of uh would say something different that we're still at an acceleration phase. >> Yeah. you know, Ben Thompson of

03:55 Strateery was breaking this deal down um this morning and you know, he's talking about a you know, I I mean, no one's talked about the implications for Nvidia on this or no one that I've actually

04:05 read. I don't think in Ben's uh note this morning that he really kind of addressed it one way or another, but they did spend some time talking about the amount of TPUs that Google has that

04:16 they're using for their own models that they have in GCP, right? And how this is a huge differentiator. And I think that was a big part of why Google caught a major bid, you know, mid last year. And

04:27 I know that you were coming up with multiple reasons why Google was a buy. This was going back to the first half of 2025. It really was though, I think, the TPU story that kicked it into high gear

04:39 um late last year. What what do you make of you know Broadcom despite being up you know 5% today is still down about 25% from those all-time highs which was back in December when they were

04:50 reporting you know that that uh fiscal Q4 and the stock you know this was not a name it's got that great backlog you know they they gave really good revenue guidance um why do you think the stock

05:02 has just not performed well especially you know I could see them giving back this move you know tomorrow in a tough tape or something like that it just feels like investors are just, you know,

05:11 have their their finger on the trigger here in most of these mega cap names. >> Yeah. And also on the infrastructure, the hardware infrastructure. And I think what it comes back to is just some of

05:21 the math that's going on in investors minds about what can go on with capback spend. Obviously, the the custom silicon piece that Broadcom plays into. They can grab market share from Nvidia, but

05:33 they're still playing in the same ocean and as the tides go up and down. And you know, maybe I kind of jump into that's always been an a topic around earnings is what are these kind of the four kind

05:46 of primary hyperscalers going to say about capex and uh just to kind of rewind I think that that is what's playing into what's going on with Broadcommits underperformance. You also

05:57 look at Nvidia. What they said at GPC a few weeks ago suggested that revenue next year is going to be up 30 plus percent, excuse me, 40 plus percent. The street was at 30 when Jensen had those

06:10 comments. And the stock over a 3-day period was down 8%. The NASDAQ was down 4% during that period. So, it significantly underperformed based on higher expectations. And it comes back

06:23 to this math. And I'll just kind of very high level say that as we've talked in previous uh episodes I've talked about these numbers being way too low for what these hyperscalers are going to be

06:36 spending. There still needs to be this significant jump up. I think we're getting to a point especially related to the 2027 but even potentially in some of the commentary about the June quarter

06:46 and the capex that it's going to be relatively stable uh consistent with where the streets at. So, we're not seeing these big uh step ups in part because there are some natural

06:57 limitations to how much these companies can spend uh specifically related to their free cash flow. Now, there's other ways that they can raise money or potentially increase revenue growth

07:07 around AI that they can further spend, but just mathematically it gets harder and harder for these numbers to really surprise to the upside. And so back to your original question, just what's

07:16 going on with Broadcom, it's kind of what's going on with the AI hardware uh companies more broadly. And I think that that's what investors are kind of coming to is these numbers. So I'm just going

07:26 to kind of finish and put it into a a very clear view, which is the hyperscalers. This is the kind of the four big ones have have are basically guided to about 60% capex growth for

07:39 calendar 26. If we look at the numbers for calendar 27, the streets at 10%. And um you know, a year ago that was the case and then they ended up being 60%. I don't think that 10% number for calendar

07:52 27 is going to be 60%. It's probably going to be going to be more like 20%. But so I think that dynamic has really kind of caused investors and I think the easiest way to understand how someone

08:03 feels about a company is just to ask how they do they own it. And I can say we still own and our our public portfolio Nvidia but we have reduced the position in part because we think everything is

08:13 great but there's this psychological piece around where the hyperscalers are going to be spending that could negatively impact the multiple >> and that's where this anthropic Google

08:23 uh Broadcom deal kind of fits into any trepidation that you might have especially I mean listen the thing about Nvidia here is if you just cared about positioning if you cared about expected

08:35 growth versus valuation, right? if you care about how they get to that EPS growth year-over-year with an acceleration or reaceleration of gross margins because that would be the story

08:46 if it went from 71 a.5 basically last fiscal year to the expectation of let's say above 74% this year and you're looking at EPS growth this year of expected to be 70% still and then next

08:58 year of let's say call it 35% and then revenue growth expected to be se I mean it is astounding based on this base that they're able to or at least the street thinks that they can grow

09:11 sales this year 70% and then 35 next. You know, you look at it trading at 16 times next year. Like how do you not load up the truck on this name even if you're going to have, you know,

09:23 competition? >> Yeah. But >> I mean it again like we're we're what we're trying to figure out is we still have a position. We still have a large

09:31 position. It's uh half of a position. And I think that it's uh from our perspective is that we're we're kind of looking for when the psychology on this whole infrastructure thing is going to

09:42 change. I mentioned that the streets at 10% for kind of the hyperscalers for next year and and that the revenue growth that Jensen talked about is 40%. So I I don't want to geek out with

09:53 numbers here, but they do matter. is that if 50% of your revenue comes from four companies and they're growing at 10% next year or maybe let's say 15, how do you grow your business at uh 354%

10:06 plus for Nvidia? And the answer is you have new customers that step up and they've talked you can just look in the language how they talked on their last earnings call how Jensen talked at GPC

10:16 about other customers starting to to get become bigger and bigger and that's so to answer your question like why not be more aggressive like trying to figure that piece out that kind of the

10:26 conversation now is is shifting a little bit to the other players the other 50% of their revenue what's going on there and I think there's a a case that you know we may be back and and and buying

10:37 more We don't have plans to do that right now, but I just want you to know like where our mind is at is like this still I think is we're still early in AI. I think that the need despite custom

10:48 silicon, the need for the most advanced thinking is still going to be at a premium and I think that that's good for Nvidia's business. >> Okay. And going back to Broadcom for a

10:56 second here. So the stock is basically trading back um when it reported its I guess August quarter I think in early September or maybe it was some sort of you know sort of design deal or

11:07 whatever. But you know the stock again is is not too different than Nvidia. It's just gone sideways you know on a PE to growth. It's definitely more expensive than that of uh Nvidia with uh

11:18 you know lesser margins. I is Broadcom interesting to you here? Especially if we're going to start to see more competition on Nvidia and more demand for Broadcom services amongst you know

11:30 some of Nvidia's biggest customers. >> I think custom silicon is important. I think Broadcom's in a good place uh for that and so it is one that is on our our watch list and one that we have

11:41 periodically owned too. And so I I think Broadcom is important. Again, what it what what comes back, you know, the the kind of our most important piece that we're focused on is where are we in AI?

11:53 Not only just on the the infrastructure buildout, but on the utility of it. What does all that mean? And when we put all that together, I still think we're in the second inning. And then I realize

12:03 that that's been a kind of a common message. How how is it that we're a year later and we're still in the second inning? How is that possible? And I think the answer is that this is still

12:11 unfolding. Look at what's happened with Anthropics growth rate. Like that was that's a big jump. That doesn't happen. Going from 9 to 30 billion over a fourmonth period. It doesn't happen

12:21 unless something bigger is going on. So to answer your question related to Broadcom and and all of this, it comes back to, you know, this belief and I I hope that we're not like blinded by

12:31 confidence in that that we can still objectively ask like what is really going on here? But objectively, if you look at what the latest data points, the news today from Google and Broadcom, the

12:41 update from their revenue expectations, uh I think that it's it's still pointing that we're early. >> Yeah. But Gene, it also doesn't happen if OpenAI and Anthropic aren't burning,

12:51 let's say, $3 billion uh you know, a month. Let's be frank, right? So if you think about it in that perspective and you know given how much capital these public trade traded names are doing on a

13:02 capback basis I mean a lot of really great things have to happen in inning four five right for these valuations to hold and you know we've talked about this I mean open AI is not meant to be

13:13 profitable for at least I don't know three to five years or something like that and then we're already talking about you know IPOs which are expected to come this year. I do think it's

13:23 interesting and you've read this I think it was the information reporting this that while Sam Alman and he's gotten a lot of bad press I mean the New Yorker piece I don't know if you saw that but

13:32 like you know and and there's you know a lot of tit fortat with everybody in the industry Elon uh most importantly but as Sam keeps you know hinting at that you know the going public this year is a

13:44 priority Sarah Frier the CFO is suggesting that they're probably not ready and the information article uh suggests that you know Altman kind of putting her in a box a little bit, not

13:54 including her in a whole host of just kind of strategic decisions. And then on the other side of that, the strategic decisions don't look particularly great. And they keep kind of pushing out the

14:04 whole idea that this company has the proper business model, you know, relative to, let's say, Anthropic, which has gone from that $9 billion revenue run rate to let's say over 30 is what

14:14 they just suggested. So I guess this all comes back to a little bit. Are the strategies of these companies, these two in particular, which seem to be very different, right? Are they likely to

14:24 yield the sort of I guess you know earnings three, five years out that would justify a their spend, but b the spend of the ecosystem and validate their business models?

14:37 >> And that's the the unanswered question as we go through these topics. There's a lot that is predicated a lot of these investment decisions about where we think the world's going to be in three

14:46 to five years. And that ledger, I'm glad you pointed that out. I was talking about the revenue, the positive side of the ledger. On the opposite side of the ledger, there's the expense side of all

14:55 this. And this comes back to the idea of how much is being spent not just by companies like Enthropic on what they're spending for their their compute, but also on these hyperscalers, the amount

15:06 that they're investing in. Will they see a return on investment? I'm just going to uh remind I'm looking at my notes here. Amazon the capex guide for the streets had 191 billion in capex for

15:17 calendar 26. 191 billion. Now figure about 30 billion or 40 billion of that is related to what they normally be spending on their uh retail business and and uh fulfillment centers. But that's

15:30 big numbers. These are these are big numbers. And so to your question about like you know how does this play out? where where does open AI there's there's a a piece around what's going on with

15:40 open AI which we can talk about but I think more broadly to your question about like where does like how how does this all justified it's all justified if you believe that uh that AI will not be

15:53 commoditized that there is going to be a premium paid for tokens and on the intelligence side and companies like the hyperskalers are going to be able to charge that and that the utility is

16:04 going to be there and it's a a a valid debate about when's the utility coming. We can give an update on where we think it's at, but I think ultimately this comes down to a question. We're all

16:16 probably of the thinking, everyone who's listening to this, that AI is going to have an impact on the world. Uh that's the probably a negative case if it has just an impact. You have to say, is it

16:26 going to have a a big or a massive impact almost is the question. And if you're in the camp of it's uh just an impact, then you shouldn't own these stocks. If you're in the camp that's

16:35 going to have a massive impact, then you should probably continue to own these. >> Yeah. And and listen, you know, whether you're looking at a Microsoft down 30% or a Meta down 25% and the list goes on.

16:46 I mean, even if you are in just the impact camp and and again, I think you're probably coming in um a bit low if that's your base case scenario, I think that anyone who spends a lot of

16:57 time not just using the chat bots, but whether it's you're, you know, building vibe coding agents or that you can see it all. I mean like you know what I mean? You can see all the benefits from

17:06 an individual. You can see it from an enterprise but I guess most importantly it's what you don't see and it's the things that we haven't dreamed up yet right and and I think you know that's

17:15 where um I agree with you 100%. But it doesn't mean that a meta can't get cut in half or a Microsoft can't get cut in half by you know 50 60%. We've seen that before. We've seen it in the last five

17:26 years. Now the underpinning of the rise of those stocks in 2020 and 2021 was you know on a scale of one to where we are right now it's it you know it it's like nothing right a metaverse was one of the

17:38 big things so I I agree with all that let let me just ask you on the token side I mean we're seeing deflation and token pricing you know like 90% a year over the last few years right so if you

17:50 see that sort of deflation in the me measurement of compute it's kind of hard not to make the argument about it being commoditized, right? And then you say to yourself, where is the value? And I know

18:02 you've talked about this and written about it and we've discussed it on the podcast here that it's going to be the application layer. I mean, we just kind of hinted at that in every major sort of

18:12 tech cycle. We've seen that. So, is it that maybe the hyperscalers aren't the way to play? Maybe it is some of these SAS names that figure it out or something like that. So, I'm just

18:20 curious away from the hyperscalers, how are you thinking about that application layer? One one thing just on the pricing too I want to mention is that there are two tracks when the conversation about

18:30 token pricing there's one is the price that essentially that the hyperscalers are uh the price that they pay the cost that they pay it should people should refer to as a cost and Sam Alman talks

18:43 about that going down 10x a year and so that is it doesn't mean that the tokens necessarily are going to come down 10x a year I can say that you know we have a belief at deep water that humans are

18:55 important and we also have a belief that I might be out of a job in two years and so a couple years ago we started intelligent alpha this is u the ticker is GPT it's there's an ETF it's just

19:06 basically machines making decisions uh there is a human in the loop and that but it is heavily dependent on machines but the the idea is that you know this can help pick stocks and I can tell you

19:19 this that the amount that intelligent alpha is spending on tokens is not going down 10% a year. It's going up. >> It's going up by a lot. And uh the reason is that the most advanced tokens

19:30 because we only want the most advanced stuff. The most advanced tokens that pricing is continuing to go up. And so in aggregate, I think that you know the conversation about the commoditization

19:42 should take into effect that the majority of the spending is coming at the high end. Very similar to how uh you know the iPhone you know the majority of units come from uh the most advanced

19:52 versions that they have. by the way, great ticker GPT. Um, and I'm looking at some of the holdings here. Um, they seem to be some that you would expect and others that you wouldn't. And if I look

20:04 at the performance year to date, it's tracking a lot better than that of the NASDAQ. So, um, kudos to that or the machine or the machine.

20:15 >> Yeah. >> The, um, yeah, the holdings aren't tech holdings. I mean, this is not about, uh, tech. It's uh it's about picking a concentrated portfolio.

20:24 >> Uh but uh yeah, that's the uh the idea. It's just not having it emotional. But we learn a lot not only by seeing how these models operate in terms of picking stocks, but also being like

20:35 practitioners. And I think that's part of where like our our kind of long-term view about how this all plays out is just really using this tool. I was recently in a in a meeting with our team

20:47 and talking about how we can, you know, do more and we have a couple interns coming this summer and their goal is to build tools. And I thought this is really great. They're going to be

20:55 building tools for us that we can leverage and use. And Doug on the team who's really leading intelligent alpha said like you're not thinking about this the right way. It's not about you using

21:04 these tools. Like you have to be practitioners. All of us need to be able to take these tools and be able to be familiar enough to optimize them. And it kind of I've worked with Doug for 20

21:15 years and he has a great way of just hitting the nail on the on the head and it really hit me that like uh you know for us to be successful I'm getting off topic here Dan but like this is like

21:27 professionals you get uh incredible brand a great following a great community but for asset managers who you know we're marked to market and uh we have to be able to face the reality that

21:38 machines could take our job. >> Yeah. And you know, the point about Doug and you you brought him up in in the the sort of diligence and uh not just kind of thinking about where we are right

21:48 now, but where we're going and how we get there, I guess, is really important. And, you know, as a parent of kids who are in college, like it doesn't exist right now, but I'd love Dolingo for, you

22:00 know, the these sorts of tools. And I don't know why it doesn't exist. And I have lots of friends like you do who are in their 30s and they're grinding on startups and you know they're like

22:10 kneedeep in it and I know that they know where these tools are going but it doesn't seem like there's unless you have like a nerd for a parent or a friend. It's really kind of hard to

22:19 figure this stuff out. So especially in the world in which we live in, we're so attached to technology, supercomputers in our pockets and all that sort of stuff. It just disappoints me that

22:29 there's not something that I could just sign my kids up and make them do. Um, and I'm not the sort of do uh person to kind of do it myself. So, >> you might have just, by the way, you

22:36 might have sprung a unicorn right there by that kind. >> Let's do it. Let's vibe coat it. You, you and me, can we do that together? I'd love to be a billionaire. That would be

22:44 amazing. Um, so I'd be a benevolent billionaire, unlike these that we uh speak about every day. Um, all right. So, let's let's really quickly hit Microsoft. Is the sentiment too

22:56 poor? It it just acts so much worse than than every other mega cap tech name. And you know, especially after being one of the early beneficiaries, at least seem to be in the driver's seat with that

23:05 relationship with oi open AI and Azure and all that sort of stuff >> kind of comes back to doing do we own we don't own Microsoft and even on this pullback there's something that is like

23:16 a a reflex that tech bulls and I'm consider myself bullish on tech have whenever something pulls back like that's a buying opportunity and in this case this what's happened around

23:28 software we've been more strategic on this more on the usagebased models but in terms of Microsoft now we did not own it before so it's not a situation where we sold Microsoft but in terms of how I

23:39 think that this plays out yes it has been penalized the reality is that information work knowledge work is being impacted this isn't just a topic around was block bloated and the 40% headcount

23:55 reduction had nothing to do with AI or did it have something to do with AI I think since then we've seen seen five other examples. Everything from Pinterest to Morgan Stanley to Oracle

24:04 last week uh talking about on average 15% reductions. Now the funny part is when they say this they'll say they're investing in AI and they're letting 15% of people go.

24:16 Uh the bottom line is those do you can have those two kind of competing thoughts. And so from our perspectives as we think about Microsoft is that uh right now uh there's the seat problem. I

24:28 think that's part of the conversation, but there's another piece to the whole Microsoft conversation I think is more uh deep and central to investors concern and it's what is Microsoft doing in AI

24:39 that's compelling and if we rewind the tape and look at what I talked about two years ago with co-pilot and all the potential I am sorely disappointed and where co-pilots is I can say I never use

24:52 it and when it when it is prompted I always look the other way when I have tried it with everything from Excel to PowerPoint. I've largely been disappointed. Easy for me in the cheap

25:02 seats to say that it just doesn't match and stand up right now. But the reality is is that Microsoft needs to have a Google moment. Google stood up when it came to their new model in June of last

25:14 year. Uh stood up with Nano Bananas, stood up stood up with the the the tensor processor units. And in the case of Microsoft, we still haven't seen that moment where we can look and say, "Wow,

25:25 that's compelling." Apple's had the same problem like there needs to be a narrative change around Apple and saying they get it with AI and Microsoft needs that same moment. So they're really

25:35 plagued by two headwinds right now on the seat growth related to knowledge workers that uncertainty and separately tell me something exciting that they've actually done in AI.

25:48 You just mentioned Apple and you know there's so much um I I guess you'd say even trepidation. There's not even that much I I'd say there's more worry than there is, you know, potential optimism

25:59 about what Apple is going to introduce or reintroduce as far as Apple intelligence and Siri being the tip of the spear. And, you know, today there was a report and it looks like Apple's

26:11 come out and debunked it, but they're saying that they're hitting some, you know, design um snags with an Apple Fold. I don't even know that Apple fold was something that people really gave a

26:21 about. It seems like somewhat of a nichy niche market, especially if you think about what um has come out from Samsung, which has been out for years, by the way. You know what I mean? I I'm

26:31 not I'm just not sure there's like a huge demand um for that. But the stock was down 5% and you know, in in one day it was just massive. And now since they came out and kind of refuted or somebody

26:41 did, it's only down two and a half percent. But is is Apple one of those, you know, it it traded defensive gene over the last couple months relative to say the hyperscalers, but is it the sort

26:52 of thing where if people are not impressed in early June of what this introduction is that the stock could really be put in the penalty box? Yeah, we we have added more to our Apple

27:04 position uh I just say recently in quotes uh in part because of what's going on with uh personalized AI and what we saw with open claw and the light kind of went on with us like to these

27:17 tools are getting really powerful and can be super helpful but they're still really complicated to implement in a safe way where you're it's not uh you know broadcasting your personal data

27:28 around the world and so there is an opportunity that Apple has and also Google has around that personalized AI. And so it really comes back to, you know, is Siri uh going to be successful.

27:40 Before we kind of jump into that, I do want to mention something on the foldable uh phone. Agree with you is that when I saw the stock reaction this morning and it just didn't it didn't

27:49 line up with the reality of where expectations were for this phone. And it was my understanding that most investors were thinking, present company included, that this was coming out kind of in the

27:58 fall of 27 and that the demand for these phones was going to be relatively niche, kind of 5% of total iPhone. So I was surprised to see it. Tesla stock during the morning was down a similar percent.

28:09 So maybe there's something there. But I think there was also this question about you know we'll know more when this is uh when you when you've published this but you know how Apple gets impacted by the

28:20 geopolitical side and and uh specifically does something in what the US is doing here kind of embolden China to do something in Taiwan. And if you look at the hyperscalers the number one

28:32 company that has a risk to geopolitical is undoubtedly Apple. And so I think that there may be still some of that kind of lingering concern around Apple shares.

28:44 >> Yeah, no doubt. Um well, it'll be interesting to see um you know, it's not a hardware event obviously in uh June, but I think if it got rave reviews, whatever, you know, was going to come

28:56 out, whatever hardware they had was going to be a winner in the fall when they introduced new iPhones, you know. And again, you know where I am on the whole super cycle thing. If there was

29:07 ever something that could cause an upgrade super cycle, it'd be a hardware device with a level of privacy that helps you run these sort of open claw sort of, you know, you know what uh

29:16 where you're not blasting it like you said to the world and redefine that experience for normies, right? Because if you try messing around with those things right now, even if you think

29:26 you're sort of tech forward, it's not as easy as one would think. And there's probably lots of mistakes that could be made that would really blow up your uh your data and the like. Um let's get to

29:39 SpaceX. And this is one where so again filed confidentially for IPO. They're going to be around the street fairly aggressively. It's like possibly a $2 trillion IPO. The float will be

29:52 relatively small. They're looking to raise 75 billion. I'm sure that'll be upsized to some degree. My question to you and I also want to talk about the Tesla aspect of this uh because Tesla

30:03 has not traded well in the week in which they um or since they filed confidentially. Why does this company need to go public right now if they're only let's say going to end up raising a

30:13 hundred billion dollars? Because we know that Open AI, which to me this story seems far less interesting than that of SpaceX, just raised $120 billion. Now, they didn't just get that plunked down

30:24 in their bank account. going to be pieced out by some of the larger investors. But why do you think SpaceX is going public right now? Do they need to? And just give us like a quick

30:34 summary. We're going to point everybody to um the piece that you wrote, but just, you know, give me the 411 how you're thinking about this. >> So SpaceX doesn't need to go public.

30:45 Open AI doesn't. I mean, Andrew doesn't. I mean, none of these companies do because they've got the ability to raise more than hundred billion dollars in the private markets. uh there is a piece

30:56 around how Elon thinks about uh retail and kind of treating that audience right and you know he's talked about 30% of the IPO going to retail audience I think potentially shareholders of Tesla

31:09 getting some sort of access to that but that I think that is a piece of what he wants to do is kind of open this up to having uh audience uh does make it more easy as he starts to uh kind of embark

31:23 on what is a very big vision about SpaceX. Being a public company does help with that. You can raise money in the private market, but it is much more efficient and cheaper to raise it once

31:36 you're public, too. And so, based on what they want to do two, three years down the road, it makes sense for them to be public. And >> and and let's just talk about real

31:44 quickly before the nuts and bolts of this story or the opportunity for the story. Tesla has traded very poorly. Is there some sort of perception? Um it's got it's down

31:54 like maybe seven or eight% um in the last week. Is there some perception that Elon has just moved away from EVs? Robo taxi is going to do what it's going to do. Robotics is probably something that

32:06 gets folded into SpaceX eventually or you know like pieced out that sort of thing. You isolate the auto business. You isolate robo taxi. Have a ball compete with Whimo or whatever Uber's

32:16 going to do or you know that sort of thing. Is is that maybe like is this becoming the ugly red-headed stepchild here and as soon as SpaceX is listed, you know, a lot of investors like I can

32:26 invest in that or I can invest in this and I know where I want my Elon money to go to. >> Yeah, I think that that probably, you know, the market's always looking 3,

32:35 six, 12 months down the road and I think that that probably has played a little bit into it is that uh just the idea that concept that there's going to be some uh sales of Tesla. So from a market

32:46 cap perspective they're going to be about an equal market cap more or less both companies call it 157 trillion something like that. So there is uh I think that you know that uh view that uh

32:59 anticipation I think probably does have at a minimum maybe some institutional investors kind of thinking about that maybe starting to play around the edges on it. You know the delivery numbers by

33:10 by the numbers were a slight disappointment. So the street was looking for 8% growth. For the March quarter, they delivered 6%. I think it's a win because the growth rate should

33:21 quicken in the out quarters here and separately. This is the first kind of good read on what the demand is outside of that September ending of the US tax credit. But that has played into it too

33:33 is that that a little bit of a miss. So I still think that overall Tesla uh still is shiny. I think that Tesla is still very near and dear to Elon. Tesla does make sense uh to be part of SpaceX

33:46 longer term. And so I think that that whole concept about this is all kind of one big opportunity and Tesla being a piece of that I think is still going to be in play. And I think that that's good

33:56 for Tesla stock. >> Dude, talk about the first trillionaire owning one of the most important companies um with all of those assets if they were to merge SpaceX and Tesla. It

34:08 would not be a surprise, I think, to most people at this point who are paying attention here. So, um, I appreciate that, Gene. I like how you kind of synthesize a lot of this stuff down away

34:17 from your just analysis. Do I own it or not own it? And like at the end of the day, um, I think, you know, uh, that sort of commentary is very helpful. I know I appreciate it. Our listeners

34:28 appreciate it. I appreciate you coming on. Let's do it again at some point in the next few weeks, hopefully once we're in earnings season. >> Can't wait. All right. Thanks for

34:36 appreciate it, man.

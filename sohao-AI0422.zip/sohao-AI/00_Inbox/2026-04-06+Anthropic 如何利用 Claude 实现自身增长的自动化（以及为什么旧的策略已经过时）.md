视频链接：[https://www.youtube.com/watch?v=k-H4nsOTuxU&list=WL&index=2&pp=iAQBsAgC](https://www.youtube.com/watch?v=k-H4nsOTuxU&list=WL&index=2&pp=iAQBsAgC)
视频发布时间：2026-04-05
频道名：Lenny's Podcast

## 转录内容

00:00 A lot of companies claim to be the fastest growing companies of all time. Anthropic actually is. You guys were at a billion ARR at the start of 2025. The last number I've seen is 19 billion ARR.

00:11 That's 1 to19 billion in 14 months. Historically, we were very much the smallest, least wellunded player in this space. We didn't have the free cash flow or the distribution of a Meta or Google.

00:23 We didn't have the first mover advantage of an OpenAI. It's a complete miracle that we've gotten to the stage that we have. give us just a glimpse of what it's like to be leading growth inside of

00:33 Anthropic. >> This is the hardest job I've had in my life. To come into anthropic, you need to understand that 50 60 70% of how you operate in the past, just throw it out

00:41 the door. >> One of the cleverest growth moves you all made was this idea of importing memory from chat GPT. Activation is a really big challenge in AI. We are

00:51 starting to look at how do we automate growth. Our growth platform team is driving this effort called cash which is claude accelerate sustainable hyperrowth. How can we use claude to

01:02 automate growth experimentation and it's delivering results. You're basically living in the future. We always talk about the exponential. The product value that we will deliver in 2 years time is

01:12 probably like a,000x what it is today. The funniest thing is I've noticed internally linear charts are just not cool. Everything is log linear. Just show me at log linear scale.

01:22 Today my guest is Amole Evasari. Amole is head of growth at Anthropic which is on the most unprecedented growth run in history. In the past 14 months, they grew from 1 billion to over 19 billion

01:36 in annual recurring revenue. Just in the past few months, their revenue doubled. They've been growing 10x year-over-year. This is unheard of at this scale. By the time this episode comes out, their

01:47 revenue will be even higher. To put this scale in perspective, companies like Atlassian and Palunteer and Snowflake, which have been around for 15 to 20 years, each do something like 4 1/2 to 6

01:58 billion in ARR. Anthropic is adding this much ARR every few months. And if that isn't interesting enough to you, Amole who leads growth at Anthropic is an incredible human. He previously led

02:11 growth at Mercury and Masterclass. Before that, he was a founder and an investment banker. And most interestingly, something that most people don't know about him is that

02:19 Amole suffered a severe brain injury. He had to spend 9 months relearning how to walk and work and just not be nauseous all the time. He shared this story in a guest post in my newsletter a number of

02:30 years ago. We actually chat about this during the conversation. These are my favorite kind of conversations because Amole and his team are living in the future and he's come to tell us where

02:39 things are heading and what's going to change. And in this episode, AMOLE shares an unprecedented look at how a company like Anthropic operates and grows, including how they think about

02:48 growth, what parts of the job they've automated, the future of the product and growth roles, how Mole got the job in the first place by cold emailing my Kreger, and so much more. A mole is

02:59 wonderful, and just try to count the number of times that he blew my mind during this conversation. Before we get into it, don't forget to check out Lenny's productass.com for an incredible

03:09 set of deals available exclusively to Lenny's newsletter subscribers. With that, I bring you Amole Avisari. Amole, thank you so much for being here and welcome to the podcast. Pleasure to

03:23 be here. Head of growth at Anthropic. No big deal. I've had a lot of people come on this podcast from companies that claim to be the fastest growing companies of all time. And Anthropic

03:33 actually is. is if you look at the trajectory, I just have some of the numbers here just so people understand how absurd this is. So you guys were at a billion ARR at the start of 2025, then

03:45 hit something like 4 billion mid2025, then 9 billion ARR at the end of 2025. And the last number I've seen is you guys are at 19 billion ARR, which uh just to put a couple pieces of

04:00 context here. One is that's from1 to$19 billion in 14 months. Um I have so many questions. First of all, the story of how you actually landed this role is really

04:12 interesting. Talk about how you how you got this role. >> Yeah, it's a little unorthodox. So, it was funny when I when I did my onboarding, they they walk through what

04:21 percentage of the cohort came through referrals, what percentage came through applying on the website, what percentage came through uh sourcing. And I was on none of those. And I was like, okay,

04:32 this is interesting. And basically the the way that I I got to was that I was actually a user of Claude and I was using a lot. I was like, man, these guys like great product, great company, but

04:44 they they really like obviously don't have a growth team. And uh what I did was I just sent Mike Creger a cold email. He was the chief product officer. I sent him a cold email saying like,

04:54 "Hey, love what you guys do. Love the product. I think you guys badly need a growth team. Want to chat?" And uh I didn't expect he would respond. And uh you know, he responds and says, "Hey,

05:04 yeah, I'm interested. Let's let's talk." And it's funny, I didn't know. I mean, I wouldn't have known. They were not hiring for a growth team. There were no growth GM roles listed, but they were

05:13 just at that time starting to think about hiring a growth team. So, it was very good timing. But yeah, one one spoke to spoke to Mike and and one thing led to another. He said, "I'm the only

05:24 PM that he's hired from from cold email and I I feel very lucky that he decided to respond to my email." >> I did not know the story. That is that is another uh absurd fact. Uh clearly

05:37 you're good at cold email. What did you do in this cold email to get his attention? I would say like I've basically perfected cold email over the years. So I was a when I was a founder,

05:46 I I had to get really really good at this. So I I sent a lot of cold emails out and just honed the the the subject line, the message and and the tone and and so basically I've in the subject

06:01 line the first thing is like from a conversion standpoint, someone sees the email, they need to click on it. And so I have a copy that I've tested that is like very very high uh open rate. And so

06:10 >> wait, what is this copy or is this a secret? >> It's a secret I think. >> Okay, we'll keep it we'll kind of keep secret. Um so that's one getting them to

06:18 open. I think the second is then the tactics of you need to understand like where are people getting outreach and if you if everyone's getting outreach in one area and then uh you reach out to

06:28 them there then then you're not going to get as high of a response rate. So you think about like LinkedIn, if you think about like work email, these are things that everyone is emailing. So there's

06:35 there's ways to get people's personal emails out there. And so like that's one thing that I did. And so, okay, I've got his personal email. I know the copy that works. And then it's just keeping it

06:44 very short on here's who I am. Here's why I'd be a good fit and and we should chat. And and these things typically don't work. And then you you should always follow up a few times. I think my

06:54 rule of thumb is like if I really care about it, I should just keep keep reaching out to them and until they tell me like, "Please stop." And so I would have I would have kept doing that, but

07:02 he responded the first time. It makes sense that a talented growth person would be very good at cold email and getting people's attention. So that's almost like an interview step as just

07:11 did I want to read this email. This episode is brought to you by our season's presenting sponsor, WorkOS. What do OpenAI, Anthropic, Cursor, Versell, Replet, Sierra, Clay, and

07:22 hundreds of other winning companies all have in common? They are all powered by work OS. If you're building a product for the enterprise, you've felt the pain of integrating single signon, skim,

07:33 arbback, audit logs, and other features required by large companies. Work OS turns those deal blockers into drop-in APIs with a modern developer platform built specifically for B2B SAS.

07:44 Literally, every startup that I'm an investor in that starts to expand up market ends up working with Work OS. And that's because they are the best. Whether you are a seedstage startup

07:54 trying to land your first enterprise customer or a unicorn expanding globally, work OS is the fastest path to becoming enterprise ready and unblocking growth. It's essentially Stripe for

08:04 enterprise features. Visit works.com to get started or just hit up their Slack where they have actual engineers waiting to answer your questions. Workos allows you to build faster with delightful

08:15 APIs, comprehensive docs, and a smooth developer experience. Go to work os.com to make your app enterprise ready today. Okay. So, give us just like a glimpse of what it's like to be leading growth

08:28 inside of anthropic right now, the most by far fastest growing company in history. Just what is it like? >> Yeah, I'd say I'd say it's very much a companywide effort, right? So, like yes,

08:40 we we are the growth team. We have done great. I think we've driven a lot of impact but honestly man we can't claim too much credit for the success of the company like we we as Anthropic are

08:52 really a model company and an intelligence company first and and foremost and so the the lion share of of like what has driven our success is our research team we have I think the best

09:02 research team in the world we have great teams on inference and compute and then there's many other teams like claude code go to market etc who I think deserve much more credit than us I think

09:12 Just zooming out going to some of what you said earlier that the growth trajectory has just been insane that that 10x year revenue growth trend has been there since the beginning. I think

09:22 2023 was 0 to 100 mil. 2024 was 100 to one. Uh last year was one to to roughly 10. And like I I look back to when I joined in 2024 revenue was in the the hundreds of millions. and just that

09:36 trajectory. So, the end of 2024 and 2025, like week two of when I joined, we're going into 2025 revenue planning and we have these like base case and aggressive case scenarios. And Daria is

09:48 pushing the aggressive case scenario and people are freaking out being like, how the hell are we going to hit that? And Dar's like, I think we can actually go much higher than that. And I'm I'm

09:56 coming in like this this place is crazy. Like, there's there's absolutely no way. Um, and and and that happened, right? and and and then you you get to the end of 2025 and it's like okay law of large

10:06 numbers there's going to be a pretty big slowdown here based on you know your baseline rate of of 10 billion how are you going to keep growing at this rate and like it just like has not slowed

10:16 down and and you know those numbers are public the the 19 billion number you you quoted is from the end of Feb so that is also out of date um and it's a look it's absolutely insane like the the funniest

10:26 thing is something that I've noticed internally is like linear charts are just like not Cool. Like no one cares about linear charts. Everything is log linear. Show me at log linear scale and

10:35 that's that's kind of scale we think. And I think overall we're just you know really hanging on by the seat of our pants. So we're trying to manage the growth and um do do the best that we can

10:45 for our users. I was talking to somebody at Anthropic about you and they said that basically anytime they want something to grow they ask you to help and it works. So you talked about just

10:55 like things are magical and amazing and like like Claude and all the tools you all build are amazing innately and that's a big part of the reason they grow. I think many people listening to

11:04 this will be like what do you even do a mole with like a magical micro god that just can do anything for you? Why do we need a growth person? What do you even do? Talk about just the stuff that you

11:16 focus on and maybe like a couple of the wins that your team has shipped that has helped accelerate growth. >> I would say like they're not fully wrong, right? like we're we're very very

11:24 lucky to have the best models in the world. We're very lucky to have products like Claude Code and and Co-work. It it it certainly makes life a lot easier. Um having said that, I would say this is

11:34 like the hardest job I've had in my life and that's uh you know, having been a founder, having been an investment banker and other things like that. Uh it's it's it's tough. And if I if I look

11:44 at what do we do as a growth team here, I think it's it's it's ultimately it's the same categories of things that you would think about at a normal company. So we care about acquisition, how are we

11:54 getting more more people in the door, the the intent of the people coming through the door. We care about activation, the the signup flow, funneling people to the right products,

12:02 making them them successful, you know, we care about things like monetization, free or paid conversion, pricing and packaging, all all of that stuff. The categories of work is the same. I think

12:13 then the the probably the big differences is I would say that like roughly 70% of what I I spend my time on is is what we internally refer to as success disasters and that is where like

12:25 things have gone so well that other things are breaking now and and I think anyone who's worked at companies that have gone through rapid growth uh you think like Facebook or or Uber or Door

12:36 Dash early on like they understand this viscerally where scaling this much just brings a lot of challenges. So if you think about each of those categories on acquisition, on activation, on

12:45 monetization, there's just a ton of firefighting jumping from like one urgent thing to another. And it's often like extremely painful and and like it's funny because you look at all the

12:56 charts, all the charts are like green, like fully up into the ride and everyone's just like it's it can be quite tough emotionally still. And so you need to sort of step back and just

13:05 realize like we're very lucky to have these problems. But that's sort of 70% of my time I'd say is just these like firefighting of success disasters. And I think the 30% remaining is just much

13:16 more standard bread and and butter growth work where it's like more proactive. So you think about okay if we have limited resources which which are the products we have many different

13:25 products. Which are the products we want to put some juice behind? What is our long-term pricing and packaging look like? Especially given that the technology is changing a lot and and

13:34 behavior and engagement trends are shifting. And then you know things like we have a lot of new products coming up like okay you you ship co-work now what like when is the right time that we

13:42 should lean in as a growth team to start optimizing the core adoption funnel for for co-work so it's probably yeah 70% just crazy firefighting 30% more more breadandbut stuff.

13:53 >> Okay I'm going to dig into a lot of that stuff. One of the cleverest growth uh moves you all made recently was this idea of importing memory from chat GBT where you just made it really easy and

14:04 kind of jumped on this trend of people getting really excited about anthropic. Is there anything you could share about this the behind thes scenes story of that feature? We're always thinking

14:12 about what can we do to improve the the cold start problem and improve the new user experience? I think that activation is a really big challenge in in AI. And so, you know, that's like one one

14:24 example of something that that we shipped that was very um you know, specific to a moment in time. But ultimately that you zoom out, it's like, okay, how do you really how do you

14:33 really make it easier for people who are signing up to have Claude understand who they are and understand how Claude can help them and get them to to the right place?

14:43 >> I want to follow that thread activation. This is something that comes up a ton when I talk to people leading driving growth on AI products. It's just like like there are so much stuff trying to

14:54 get your attention these days for people to get to a place where they okay wow this is really going to be something I I want to keep using it. It proves to be really hard and it's also just

15:03 unreliable sometimes it's not going to be magical. It's AI. It's non-deterministic. I guess one is just like uh how important is focusing on activation getting people to that aha

15:12 moment with AI products? and two, what are some things you've learned about how to do that well with with cloud and AI in general? >> Yeah, it's a good question. I I think

15:20 that activation it's it's critical, right? And and and defining that as like early activation, call it day zero, day one product experience. I think that historically anyone who's who's been in

15:31 growth or been in product understands that that's that's usually one of the highest levers that you have to actually even increase like longer term retention. And I think that that the

15:40 importance of that has just gotten exponentially higher. Now zooming out, I feel like one of the biggest problems in the industry is capability overhang where the the models are just getting

15:51 better so quickly and and it the the real challenge is on the product side of how do we start to um diffuse those benefits to to to people where even internally like there's there's new

16:04 models coming internally and you're sitting there you're so busy and and when it when you when a new model's available you you need to like really carve out time to be like what what can

16:11 this do? how do I need to update my priors? And and if you think about more broadly for most people, you may have a model that is like you may have AGI or some, you know, model that can do all

16:21 sorts of crazy things, but if if people's instinct is to come there and be like, hey, what's the weather in SF? Then, you know, they're not going to get the the most out of of of the product.

16:30 And and so I think that it's it's it's tough because the model capabilities are rising so much. So like if I if I think about okay back when we had I don't know say like opus 4 at that there's there's

16:44 a series of things the model can do at that point and and opus 4.5 unlocked a whole bunch of new things. you think about, okay, we sit there, we've got this new model, Opus 4, the the time to

16:53 then go and run a bunch of tests, figure out, okay, there's the capabilities from this new model. What are the right on-ramps to to guide people to those features? You know, you run you run

17:03 tests, you get the learnings, you then ship a new flow. By then, you may already have the next model which unlocks newer capabilities that makes all these learnings irrelevant, right?

17:12 So, like it's actually just like a really difficult problem to to stay on top of. I think that many of the same things, same old trends in in in growth and activation remain I think accurate

17:24 where to me it's like ultimately the some of the highest leverage is from finding the right product or the right feature for the right user and uh I think that one learning you've seen this

17:37 time and time again across companies actually like the right friction helps and and adding more friction usually works if you do it the right way. I think that's something I've consistently

17:46 seen that we we've seen here as well. Uh so to me, I think it's really un being able to identify which what are the characteristics of a user that allows you to then recommend them to the right

17:57 feature or product and not being shy about adding friction to to do that I think is probably like the single biggest thing that that's important here. When I asked uh Ben Mann, one of

18:07 the co-founders, former podcast guest, what to ask you about, and this is what he highlighted is your experience, especially at Mercury redoing onboarding and making it magical. And basically,

18:17 he's in the same uh place as you of just how important it is for people to understand what the AI tools capable of to help people decide to use it and stick with it. Is there an example of

18:27 something you changed in onboarding that helped significantly improve activation? Yeah, it's a great great question and and I I like that he brings up Mercury. I I talk about their their product a

18:38 lot. So, worked on the growth team at Mercury. I think it's a fantastic product. It's something many people use and the reason they use it is because it's a better banking experience than

18:47 >> Yeah, I'm a I'm a very happy customer just to put it out there. I love it. >> Great product. Highly recommend it. They have personal banking. Everyone should go go and use it.

18:54 >> Right. They just launched that. >> I I I and and and so I think that the interesting thing about Mercury is like the core value is that it's a better experience, right? that that's the

19:02 reason you use it. You're not getting like better other things. It's just it's a better product experience. And so the that ethos is very very deeply held within the company. It comes from uh a

19:14 number of the founders. And um I think that we we had a big push one quarter when I was there on on the onboarding flow. So onboarding flows for for banking institutions and regulated

19:25 entities are extremely complex. like the the the amount of time I've spent on the difference between like a registered agent address and a legal address and a physical address like these things are

19:36 very very complex and we we basically looked at the onboarding flow and we were like okay we we've invested so much in quality in the rest of the product but we haven't really done it here and

19:46 this is the first experience that people have and and so we said forget metrics forget growth forget everything else as the growth team on conversion we're going to spend a whole quarter fixing

19:56 quality in in this flow. And so that's all we did. Like forget the metrics. We're just going to make this as good of an experience as we can and fix all these like you go back from one field to

20:06 the other field and adding in your beneficial ownership details. And it actually ended being like and probably until I joined here like the the single most impactful quarter that I've ever

20:17 had as a growth PM in terms of the impact that it had. And so we saw a significant uplift from uh on basically our like onboarding started to to completion from from just focusing on

20:28 quality. And so that that to me is like a broader learning around quality drives growth that I think I I've tried to to to bring to anthropic. I think for us at Enthropic um you know some of the things

20:38 that we've done in the onboarding flow uh is is basically like we we ask users questions around who who they are what their interest areas are and we we then use that to recommend different products

20:50 and features and like number of people look at the flow and they're like you have so much friction it's such a long flow and like we have the data we're kind of happy you with how that's

20:56 performing. What is your kind of a philosophy on friction good friction versus bad friction? I've just seen time and time again at every job I've been in in growth that adding friction and

21:07 adding the right steps uh leads to higher conversion and and higher funnel completion. So you want to get rid of an I think especially if you have high volume you should test the majority of

21:19 this and just learn and and see like does this apply to your business as well. But you you want to you want to get rid of annoying friction that doesn't add value. But the the like I

21:30 think the most simple understanding people have is like just get just just just solve time to value. Cut all the steps and just get them into the product and and like that doesn't work most

21:42 times. I think if you if you're if you've really thoroughly tested your flows, I look at the companies I've been at masterass. If you go through masterclass's purchase flow right now,

21:53 you'll go through all these steps in this this quiz when you land on when you're trying to buy and it's like you're like, I came here to buy and it's taking me through all these questions.

22:01 What are you here for, etc. I think it's easy to look at that and be like, why why do they have this? This is like a terrible thing. Just cut it all. And it's like no, like that's been

22:09 thoroughly tested and and actually there's like a significant revenue driver uh because it helps users feel that the product is for them by understanding what their interests are

22:19 and then recommending the content and and classes there. One of the the growth PMs on our team left to to join Karm.com the meditation app. If you go to K's uh you know their landing page and you go

22:30 through their purchase flow, their login flow, you'll see a quiz. It's like not not a not a a coincidence. But at Mercury, we also tested I think um I think you might posted on Twitter like

22:40 we broke out some steps in onboarding and just having one screen if you have like five or six different form inputs and you you often break that into two screens and reduce the cognitive load to

22:51 people that that is something that that performs well. We added steps into the flow there that that actually performed well. Same at at anthropics. So I think that the takeaway to me is like cut

23:01 friction when it doesn't add to the experience of helping a user understand why the product is for them. But if you can help users understand a product, why a product is for them and like how to

23:15 use it and and what's what's most relevant to them and it's going to add friction, uh don't shy away from it. Test it, confirm that it works for you. But I I think this is like a something

23:25 that like most growth practitioners deeply understand >> and the for them is really important there. What you described is adding friction to better understand who they

23:34 are so that you know how to recommend the right thing for them. >> Correct. Yes. And like that that like done right that just it just flows through right. So it helps you with

23:43 activation but then it helps you with life cycle. you know more about those users and why they're here and and like you know most sophisticated businesses you can then even if someone drops off

23:52 you can do like lookalike targeting and you can get you can get them at the ad layer as well. So that that initial piece of how you understand the who the user is is just like it's a juice that

24:02 just keeps on giving if you if you then use it right further down funnel. >> Everyone's about to go do a bunch of tearowns of Claude's on boarding, masterclass on boarding, Mercury on

24:12 boarding. Uh kind of as a tangent, I was at this PM dinner recently and I was asking all the PMs, how is your role as a PM changed most with AI? Like where is AI most impacted what you do? And one of

24:23 the PMs answered that is actually doing competitive analysis doing a bunch of like tear downs of what other people are doing for pricing pages and onboarding. So it's easy to do now. Just hey co-work

24:34 would co-work for this or cloud. What would you use for that? Okay, this is good. Help people pick which tool to use. If you want to go do a bunch of tear downs of other competitors

24:42 onboarding flows, what would you use? You can use you can use co-work for this, right? Um so you have co-work with the Chrome extension. So if you task co-work with a Chrome extension, go and

24:50 look for these these flows and uh show me give me a view of what's working, what's not, that's definitely something that that co-work can do. >> Cool. I think I imagine that's one of

25:00 the challenges is like you have all these tools now just which one's for me. Um by the way, the Chrome extension, I use it all the time. It's amazing. I want to drill a little bit further into

25:09 the growth org. >> There was this whole meme on Twitter the other day of just like you have one growth marketer driving all growth at Enthropic and it's like okay that's

25:16 crazy. What's like how many growth people are there? What's kind of the rough org structure of the growth team? >> We're roughly maybe 40 people now. And so we are I think structured very much

25:28 like a traditional growth team in that we have sort of horizontals of of growth platform and monetization who think about the the the the sphere of growth across the the entirety of our products.

25:41 And then we we have more sort of audience focused growth pods. You can think about like B2B growth. You can think about cord code growth, knowledge worker growth, API growth. So, so really

25:53 like these audiences to to keep a narrow focus, which is the thing you have to do when you have so many different products. Uh, and then these these horizontals that that sort of think

26:02 about things um across across the board. >> And is it a cross uh a team of engineers, designers, PMs? What's kind of like the functions within this growth or? Yeah, it's it's engineers,

26:13 designers, PMs, data. Um, I think that overall the shape of the org is quite similar to I'd say a traditional um growth team. Probably the things that are maybe different is that we I think

26:29 that we index a lot more towards larger swings as opposed to smaller optimizations. Like if I think about a traditional growth team, I would have probably done maybe 60 70% of my time on

26:44 small to medium bets, 20 to 30 um% on on larger swings. And I think that for us, we we we we flip it a lot like we we do much more the other way where it's sort of 7030 or more like 50/50 um rather

26:59 than than than indexing towards smaller bets. That's probably like one of the the biggest changes. I I think just to highlight that what's interesting there is at the scale you guys are at like a

27:10 1% win is massive in the scheme of things. So it's interesting that even at the scale you're at you're not focusing on these micro optimizations. It is easy like you could easily focus on these

27:21 small optimizations and then you tally them up at the end of the quarter and be like look how much impact we made and like you could do that >> another billion no big deal.

27:27 >> Yeah. But but the the thing is like we're we're we've been tracking a 10x year on year and we we we you know that's like the the thing that we we sort of keep in mind and I think it like

27:38 ultimately comes down to our fix fixation at this company about the exponential. I think if you look at anyone is talking about talking from anthropic about basically anything we

27:47 always talk about the exponential like it's is effectively as model capabilities continue to grow on an exponential um and and the tools around them enable a better job of of diffusing

27:58 that into into uh useful use cases. You basically just keep unlocking new markets that where where the value of those markets significantly dwarfs what the value of of the previous markets

28:09 were. And like aentic coding is a great example like it didn't exist you know a year a year and a half ago and then now just the value of agentic coding is is bigger than the like previous market of

28:20 of AI coding use and and so I think that is like the core thing here where just that the future product value is an order of magnitude higher than it is today and I think about I don't know

28:33 like a a normal business like number of companies that I maybe mentioned or like you think about like a a trading app or like a grocery delivery product like they're all many of the like the leading

28:43 companies they're great businesses but if I think about what is the product value that the a company like a standard like call it a grocery delivery app like what is the product value you get as an

28:54 end user today versus two years from now I I I look at it as like okay in two years from now even if you're you're shipping all these new products as an end user the value you get from that

29:04 product maybe goes up like 30 to 50% if the company's done a really good job of of shipping new features. It's not exponential though. And and and and so if I think about okay, you're here

29:15 today, in 2 years you're going to have 30 to 50% more product value, then as a growth team, the like relative differential of the product value 2 years from now relative to today, I can

29:27 actually capture like a decent percentage of that with the small to medium optimizations that typically have higher conviction as opposed to like larger bets. But for anthropic it it's

29:38 not really that way where where the because of the exponential and and our products being like very very very the the product value coming from AI the um the the product value that we will

29:52 deliver in two years time is probably like a thousandx 100 to a,000x what it is today and so if I think about that and it's like there's so much value on offer you need to shift more towards

30:05 okay we need to take larger bets and we need to not not sort of miss the the forest for the trees and and so that's why we we do we still do all the smaller optimizations. It really matters and

30:15 like no one else is going to do some of these things and so we we need to do it. The compounding value is not immaterial but we we do take on much larger core producty type of swings as well. So you

30:26 mentioned it the chrome extension like that is now the thing that underpins a number of use cases on co-work and and uh and cloud code as well and that's something that the growth team built

30:37 that's like a very like AI product that is like a very research heavy product but we we were just bullish on it. We had an an engineer who was very bullish on it and we were just like hey no one

30:47 else is doing it we're going to do it and and so that's the sort of thing that I wouldn't have done at another company. Oh wow, that's I did not know that. So the takeaway one takeaway here is like

30:58 you know there's like stuff to extract from your advice that is like only true at anthropic and then there's what can other companies learn from this experience that you've had?

31:09 So one is is your sense that if you're working in AI shift more of the pie chart towards bigger bets because in the future the opportunity is so large you want to get find those as soon as

31:22 possible versus micropimize to be more specific there. It's I would say that it's if the primary value that your product delivers is underpinned by AI as as a a central element of it then

31:37 I think you should operate this way. So I don't know companies like yeah lovable cursor you know all these like great businesses that are like it's as the exponential rises their their value

31:47 props are also going to continue to rise significantly like if if you're building a product where it's it's an AI first product then I would definitely operate in this way. I think if you're building

31:57 a product where you're it's not necessarily an AI first product and you have some AI features that are on the side but it's not the core of your value I don't know that I would operate this

32:07 way. It would need to I would it would depend on how is the rest of the product all staffed and how is the growth all staffed in relation to that. >> Okay. Awesome. And then in terms of the

32:16 way you're structured I thought that was really interesting. It's like a combination of different sorts of things. So there's like uh the API growth, there's cloud code growth, but

32:25 then there's also like personas like a vertical of like knowledge workers and B2B. Is that intentional? Like some specific bets and one just kind of like broad market opportunity. When you have

32:35 like one product, it's easier to to have a growth team that's more like purely on the funnel, right? It's like you have the conversion, you have activation, you have monetization. But as you start to

32:44 get into having multiple products, I think that's harder because if you do that then, you know, if you just have like one activation team for example, but then you have cord code, you have

32:54 co-work, you have all the other things, they're very different audiences and and and they're very different sets of crossunctional stakeholders internally. So, we're kind of looking at what what

33:03 is the thing and all structures are like not perfect and they're like right for a point in time, but we're looking for what is the structure that allows us to have as much focus like focus is a

33:13 really big thing and um on on audience and and uh and and problems and and uh and also the tie-ins to cross functional partners is really really important like the the folks on our claude code growth

33:26 team like they work extremely closely with Kat and Boris and the others uh on that team and so that that tiein is is is really important as well. >> So you've done growth at a lot of

33:35 different companies, a lot of basically let's call it traditional growth before anthropic. How else is growth as a function and as a skill set changing with the rise of

33:45 AI, AI products, AI startups? I think if your your your core product value is very backed by AI then it is it is shifting where you're you're skewing more towards larger bets as opposed to

33:58 smaller medium experiments. I think in um other things maybe a big big thing related to this that I think will accelerate this which I am really interested to see how it will play out

34:10 is we are starting to look at how do we automate growth which I think is like a really interesting area. So our growth platform team um we have a we're very lucky we have like Alexe Kamisuroka

34:23 teaches growth engineering at Reforge and he's just like the guy on the team and and so he is driving this effort um that it's it's the name is it's a little cringey. I didn't come up with it but

34:34 it's like it's called cash which is Claude accelerates sustainable hyperrowth. I I did not come up with that. Um >> but but but really it's an it's an

34:42 effort to to to look at how can we use claude to automate growth experimentation and it is still very very small. It's still very very early. Uh we we we kicked it off only I think a

34:55 couple of months ago. I think before Opus 4.5 it wasn't really possible. We were just like not not seeing the results. And more recently with Opus 4.6 we're like okay this this is like headed

35:06 in the right direction. And so this I think is it will happen more and more across the the the industry where basically if you think about okay I think this can happen all across product

35:16 but grow growth teams in particular because there's this whole body of work that is very small optimizations I think are just more inherently uh suited to to like tackle this earlier. Uh I think if

35:30 you think about like the the life cycle of shipping there's there's sort of four parts to it. one is is um identifying opportunities like how good is Claude at actually identifying opportunities based

35:40 on different trends based on um previous trends that that Claude has seen in the past. Second is then building the actual feature and and getting it ready to ship. Um third is is testing and

35:52 ensuring that it meets your your your quality bar and your brand bar. And then fourth is then once you've actually shipped the thing analyzing the data ga gathering the learnings. If you think

36:03 about that as like a the the the loop of okay these are four things that you can eval and hill climber in each of these areas and understand how good is a model doing for you there and we we we we

36:15 basically think about it in that like the four four four ways and um and and we are scoring how good is Claude doing in each of those areas and so we've been testing this at pretty small scale right

36:27 now it's been a lot of copy changes and some like very minor UI tweaks it's it's It's it's it's delivering results, right? Like and it's like you can push it, press play with it, and it's like it

36:36 it ultimately prints money where I'd say that the win rate is like I would expect a senior PM to do better. Like I I would say like this is like a junior PM like 2 three years in. I would say this is like

36:48 the the win rate that I would expect from from like a junior PM. Um but it's not quite at the senior PM level. Although I think like you look at the exponential, this wasn't available at

36:57 all a couple of months ago. So it's it's it's getting better, you know, rapidly and um I I think that the the it's going to change where you you'll be able to do this for larger and larger types of

37:10 experiments. Um but but then you know you think about the largest types of experiments. I think that the the I mentioned the the four pieces around sort of identifying opportunities

37:20 building testing and shipping. The one I didn't mention there Lenny is crossunctional stakeholder management. There's still a need for human brains. >> Yes, there is.

37:31 >> And and like I think that that that one is is going to mean that like in my eyes the work of PMs is like not going away actually anytime soon. And um that that piece especially for larger projects you

37:43 don't need to do as much of it for smaller stuff, right? You can you can you can skip it. But for larger stuff uh that that piece is is not not not going away

37:51 >> until the the other stakeholders are their own little agents running around. >> I think that's right. I think that would be the point where changes. It's funny. We had a we had like a difficult meeting

37:59 a couple of weeks ago and me and my our head of design, Joel, we were debriefing afterwards and he pings me. He's just like, "Amal, we will have AGI and it will still be impossible to get six

38:09 people in a room to to get to a line." And uh I'm like, "Yeah, I think that's I can see that." That's a like what's the harder alignment problem? Oh, okay. This is so interesting and

38:22 this is exactly where I feel like things are going. So just to be clear what you shared here, there's basically this tool that comes up with experiments to run to help grow Claude and all the tools. So

38:36 it comes up with idea, somebody looks at them, proves cool, let's do these things, builds it, ships it, tests the results, see how it's doing, and then comes back like here's things that are

38:46 working. Is that roughly right? >> It's roughly right. Right. And like we right now we have human in the loop approving but like the amount of time I kind of think about scale in this way of

38:56 just like week on week are things getting better in each of the areas. Are people spending less time on each of the areas? Are are the results getting better in each of the areas? And as long

39:04 as like week on week that's getting better then you're like okay this whole initiative is like scaling. Um and and so that that's roughly right but you can think about it as

39:13 >> I think a lot of this can be automated where human review is not needed. said we care a lot about brand, right? So >> that is something that we we do look at right now. We don't want to be shipping

39:22 something that goes against the brand. >> Um but then >> you know you can have a skill that a skill that that contains your your your brand guidelines and and very clear yet

39:34 dos and don'ts on on brand and and and so all of these types of like accompaniment I think are going to get better. The model is going to get better at understanding how to use them. And so

39:44 over time I I think that the need to like human review this really really decreases significantly. >> Yeah. And you could always unhip it if it's like okay that was actually not a

39:52 great idea. And that's such a good point that we like we think we need people to do these things forever and it turns out okay a skill could do this really well. Here's our brand guidelines. Here's our

40:01 vision. Here's our mission. Here's our goals. Here's what matters to us. Okay let's not ship that thing. So the reason I think this is so interesting, this is like I've just been watching the

40:10 expansion of AI doing more of the product development process. In this case, the growth process of just okay, it went from helping you write code to like writing all your code to reviewing

40:20 your code. Now it it feels like what are the other ends of this the two ends around this? It's kind of going from the middle out. The the top of that is coming up with what to do and then

40:30 there's like the alignment stuff still very hard and then on the other end it's uh reviewing the code and then shipping it. uh and then get distribution is that's like a whole other thing I want

40:38 to talk to you about. So, what I'm hearing here, and this is exactly what I thought was going to start happening, is AI is now getting really good at telling us what to do. Not just taking our

40:47 orders and building it. And it feels like the growth version of this is where it starts because it's so much simpler. Just like not that growth is easy, but just like it's data driven. There's this

40:58 loop that you talk about. So, I think this is such an interesting sign of things to come across just generally product. >> Yeah, just putting that out there.

41:07 >> Okay. So something that I'm constantly thinking about along these lines is just the future of product PM engineering, how those roles shift over time based on the stuff we're talking about. How how

41:19 are you working together as a as a triad? And where do you see these roles going? What's most going to change, do you think, across these three roles? This is like something that we talk

41:30 about and think about frequently and the the the picture changes rapidly. So sometimes when when things break you know execution like the bottlenecks break historically in the past it's like

41:41 okay now you need to hire more engineers you need to hire more designers etc and it's more just like a a life cycle thing of like where is the life cycle of your team and that specific pod to identify

41:50 where the bottleneck is but now when when things break you need to still look at it of like okay is it like the actual ratio or is there also underlying technological shifts that are that are

41:59 also causing this to break and so that's like a an interesting thing I think that smaller companies like if I'm at like a 15 or 20 person company I'm like the only PM there working with some

42:09 designers and engineers I I I think um I think in the smaller companies you'll see probably like the biggest blend where like the PM will be doing all sorts of they'll be you know designing

42:20 shipping etc and I think you just have extreme bifocation you know larger organizations more scaled organizations I think the jury is still very much out like you you speak to people even

42:32 internally here and different people in different teams have different views of like okay how much are these roles coming together versus how much are these roles going going to be separate I

42:41 I think that um it's not to say like I think even the PMs like a number of PMs are shipping and and and themselves shipping and and and pushing PRs etc but I I if I if I look at okay across what

42:54 I'm seeing I think that it's it's clear that while PMs and designers are getting more leverage from AI engineering is getting the most leverage Right now I I look at tools like claude code and like

43:06 they the the amount of leverage engineers are getting from them is higher than I think the amount of engine the leverage that designers and PMs are getting from them today. Now that this

43:15 like rapidly also changing but that that to me is like my view today and so um if you think about okay a default team which is say five engineers one designer one PM with cord code that that that

43:31 five engineers is like two to 3xed right and and the PMs and designers have also increased but the that now they're managing what is effectively a much larger group of of engineers and so even

43:43 though like the headcount the org structure hasn't changed. You're now you're now just dealing with a situation of maybe 15 to 20 engineers in the old world, one and a half to two PMs and

43:54 like maybe one and a half to to two designers. And so we're seeing that that's putting like a lot of strain on on PM and and design. And it's it's not everywhere. Like I look at teams like

44:04 Claude Code and I think that or because that product is so technical like it's probably like just the the right thing where you the the PMs are like all basically engineers themselves anyway.

44:14 Um but but you know we had a product like a PM lead on site the other week and we were all just like talking about this where across the board we're feeling this where PM and design is just

44:24 squeezed. It's just absolutely squeezed and we're like is it is the right thing here? we just need to actually hire like a ton more more PMs and and that that could it could actually be where we we

44:34 we we land you know on growth how I think about it is like one we are hiring a number of growth PMs uh we we desperately need people who are very very good and uh we are we are hiring so

44:47 if you if you are excited by what we're doing and and you know growth please please feel free to apply uh would love to love to chat and um maybe craft a maybe craft an amazing cold email to

45:00 you. >> Yeah. Yeah. Yeah. Feel feel free to cl craft that email. Um so so that's one is I think we are going to be hiring a number of PMs. But then the second thing

45:09 that we do is we we we very much hire productminded engineers. I think this has always been the best thing to do in growth. Like you always want to have the the engineers coming up with ideas etc.

45:22 And so we especially especially people who who can really like step in as mini PMs if if people uh if the PM is is absent. And so we're like basically more formally leveraging that right now

45:33 because we are so stretched. So the the frame that we have is that if a project is less than is 2 weeks of engineering time or less then the the uh engineer is on the hook to effectively be the PM for

45:48 that. And so that means things like talking to security, talking to legal, talking to cross functional stakeholders, and the engineer is very much driving that. The PM will get

45:57 looped in and and they'll advise if needed, and if something is like like wildly going off track, then they'll step in, but they're much more in an advisory capacity versus execution. If a

46:07 project is more than two engineering weeks, then the default is that the PM should continue to to be on the hook for for making that go well. unless they still delegate more to ENGE, but they're

46:18 like squarely accountable. It's not like fully cleancut. It's like use your head like if this is a oneweek thing, but it's extremely controversial like the PM should probably still drive it, but that

46:28 that I think is like the the approach that I expect more companies will start to do, which is just deputize the engineers to be mini PMs. Now, not everyone can do it, right? So the the

46:39 PMs the the the engineers who are more product minded suddenly their value goes up significantly like like an order of magnitude and and then I think we will probably still be hiring a a lot of PMs.

46:52 There is so much interesting stuff I want to follow up on here. Okay. So one is this idea of two weeks just briefly. I I always joke as a PM uh you can go on vacation and be away for like a couple

47:03 weeks from your team and things are going to be all right. like they'll, you know, there's like a momentum, there's a plan, people keep operating and it feels like that's kind of the this rule of

47:11 thumb you use of just like, okay, if it's two week project, you'll be all right without a PM, you can handle it. Uh, I love that those two connect. Okay, the other here is so interesting. So,

47:20 you're saying here that because engineers are so accelerated and this all makes sense. PMs in design are kind of just like, holy, there's like hard to keep up with the pace of engineering.

47:28 And what you're saying is you need more and more PMs to keep up. That's one route or it's engineers that can PM essentially which is so funny. It's just like okay great news for product

47:39 managers uh until more of the PME stuff can be done by AI but that's a really interesting trend. I don't know is there anything else there just like oh wow we actually may need more PMs the ratio

47:49 more PMs to your engineers might be the future. Yeah, I I think this is like it it just like really depends on the industry, the the size of company, like any company where you're building

48:00 something that's like much more developer focused, like you're going to rely on the engineers a lot more. Earlier companies, you don't have as much of this like crossunctional

48:10 coordination, stakeholder alignment nonsense that you need all these PMs for. So you you you can like get by with less. But then as a company scales and like if I think about okay now you have

48:23 this ratio where maybe the the one PM became two PMs from like productivity that the like five engineers became like 20 engineers the one designer maybe became like three designers. If you

48:37 think about like what is the best use of time for that PM I think this is like a really interesting thing of like how much should PMs be actually shipping things themselves versus everything

48:45 else. I think like in the in in the world where you're like limited on engineering, the PM should definitely be shipping things. I think in in today's world um it's a good way to like get an

48:57 understanding of the tools which is really important. So the PM should be shipping for that reason. But if I'm if I'm one 1 p.m. or 2 PMs and there's 20 engineers.

49:07 I think about what is the incremental value I can add with with my time and is it actually shipping like the 21st PM feature or is it saying how am I getting a little bit better at guiding the team

49:18 on what the right opportunities are and and and so that's where I think like in this world you may have all these engineers who are like mini PMs and the better that happens like that's like

49:28 where I would love to be doing more of but still like the if if you then get a really good PM who can come in and can like improve that the the like why and the what and and the why and the what

49:40 particularly by like 5%. That is like such a high leverage. This is such an interesting insight you're making. It's like so counter to how a lot of people are thinking PM is evolving. Like what

49:51 I'm hearing here is because PMs are so behind because engineers are just getting so much done. There's like many people here, okay, you need to be prototyping, you need to be shipping PRs

50:00 as a PM. what you're saying which I completely agree with is your time is much better spent helping PM basically and helping the engineers uh become better PMs themselves and and

50:12 the leverage there is a lot higher than you spending time coding shipping PRs in most cases I think that's true in certain circumstances I think that as a smaller company I don't know that that's

50:22 the case in a smaller company where it's all hands- on deck I I think you you you probably need to be shipping I think if you're in a company where like budgets are very tight and engineers are very

50:32 tight and you you know you're not able to just hire because money is unlimited then like you need to do what the what is needed to to accelerate the the like the the impact your team's going to have

50:42 right so there's going to be a number of cases where like as a PM the right thing to do is to be like screw it I am shipping and like I am I am going it the whole way but I'm talking here more

50:53 about the like larger companies more scaled businesses yeah if you have 20 p 20 engineers is is is is it the highest use leverage of your time to ship an extra feature or

51:08 figure out how do I uplevel everything that we're doing get the user insights better etc. Yeah, and I think there's also an element of shipping to learn, building a prototype so that you can

51:18 have a better opinion like a lot of people talk about just going to try three things, see how it goes and that'll help inform the road map. This is now the PRD is look at it instead of

51:26 talking about it. So there's a lot of value there still. That's that's that's very true. I think that's a great that's a great point. So like even for me now where we've got number of PMs, we've got

51:35 many engineers, there are certain times I'm like I want to articulate the idea I have in my head, it's just better for me to prototype it and show it, right? So I think that that is really important. Um

51:46 and then you know we we are very scrappy. So like we're like a big big company by by name valuation, but we're like extremely scrappy and just the the focus internally is just like minimize

51:57 bureaucracy and just like just go. And so probably 70 70% maybe 60 70 80% of what we what we ship does not have a P. I'm like averse to PDs. I think I just like I just like hate documentation. I'm

52:10 just like go just like cut cut the blockers. um 20 30% of stuff where it's like it's important it's really important to get right like the documentation should be really good and

52:21 like that people sp should spend a lot of time on it but by and large I think PS are just out outdated at this point and and um you can just kick things off with a good team without without needing

52:32 to to do that sort of thing. >> Say more about that. What do you do to help make sure because people can build so fast or spend a lot of time going in the wrong direction ship things that are

52:42 not what you're asking. How do you kick off a project and clarify here's what we're doing? Is it just a conversation or is there anything beyond that? >> It really depends on the size of it. And

52:50 this kind of goes back to like the two week thing. So the why we have that two week thing, it's more like a how do I have some filter to say if we're investing heavily into something we

53:00 should apply more thinking behind it versus if it's a smaller set of investments, just go for it. And as a growth team, again, you do have a decent amount of these smaller things that you

53:10 do. So for for very small changes, you're like, "Oh, there's a thing coming. We need to have an upsell for it. What is it the thing we're doing?" Like this is just on Slack, right? This

53:21 is just purely on Slack. It's just a a messages back and forth and we'll I think it also depends on having a good caliber of engineer in there, but engineers can can understand like, "Hey,

53:32 I know you said this, but like what about that for the audience?" And so like we're lucky we have good good product minded engineers in that sense. But all these smaller things are very

53:40 much just on on on Slack back and forth and and and that's what you you do for the larger things. I think I I very firmly believe in like a proper kickoff. So we we still do you just there's so

53:54 much going on at this place. No one's got time. No one knows what's going on. And so doing a cross functional kickoff get legal, get safeguards, get everyone in the room and just be like this is

54:02 what we plan to do. what what do you care about? What do you care about? What do you care about? Like that that 30 minute meeting um for larger things is just I think still so important to to

54:12 just streamline all the mess that may happen later if you don't do that work early on. >> What's your approach to crafting that PRD in those cases? Is it like ramble

54:21 into cloud? Is it do you have a template? >> Even in those cases, there are times I don't craft a PD like cuz we're just everything's moving so quickly, right?

54:29 So there's still some of those cases where I just set up the meeting and then like 5 minutes before I'll put it into quote work like here you know some of my thoughts what credit like here are the

54:38 things that I need to think about spin up like a a basic doc and and we use it to talk other times I won't even have a doc but if if I am creating a prd um I have basically skill like a skill that

54:51 that I I've you've created um and then there's projects with all the previous PRDs in there uh and then I will each is pretty simple like I'll it has the format down so I'll just say here are

55:04 the things I care about here's the why here's the problem and flesh out the key considerations flesh out the cross functional stakeholders those types of things but again my my my default is

55:15 like if I can avoid the dock and if we can just just jump to action then then that's what we should do and increasingly just just jump to prototyping the thing

55:24 >> yeah and that's that's where I think it'll get so interesting once we can automate more of that just like your uh assistant talking to the legal assistant just like ironing out all these little

55:33 you know what's important to you what's important to the yes and it's coming and I think the legal team has done like good enablement around this like we work you know versions of like how do you you

55:42 can think about like how can you um mimic what someone might say and like set up you know like a co-op right so there's there's things like that that I think that we have now and then as plot

55:54 gets more and more context and gets better at passing long context I think These are things that quaude will just get better at knowing. One of the one of the things Lenny is like a slight

56:03 tangent but one of the I think most effective ways I use quad or most interesting ways I use quad is this I see a number of people doing internally is to like help you identify

56:15 misalignment. Um this is like a I think something that's I found really really helpful. So with with coowork you have this the Slack MCP and you and you can you can tell coowork you can tell

56:27 co-work to say basically look across Slack you know the projects that I'm working on these are the things that are top of mind go and find me areas of potential misalignment right now and it

56:38 does a really really good job so this is something that I've scheduled runs every week's like looking at things and coming back to me with and saying like hey I think these things you should be aware

56:46 of and so you can think about in that in that shipping context text. It's a similar thing where Cord can basically be looking at what's what's happening across the company and say, "You're

56:56 thinking about shipping this thing. Here's who you need to talk to. Here's what what you need to keep in mind." That is so cool. I am so excited to tell you about this season's supporting

57:05 sponsor, Vanta. Vanta helps over 15,000 companies like Cursor, Ramp, Duolingo, Snowflake, and Atlassian earn and prove trust with their customers. Teams are building and shipping products faster

57:18 than ever thanks to AI. But as a result, the amount of risk being introduced into your product and your business is higher than it's ever been. Every security leader that I talk to is feeling the

57:29 increasing weight of protecting their organization, their business, and not to mention their customer data. Because things are moving so fast, they are constantly reacting, having to guess at

57:40 priorities, and having to make do with outdated solutions. Vanta automates compliance and risk management with over 35 security and privacy frameworks including SOCK 2, ISO 27,0001 and HIPPA.

57:53 This helps companies get compliant fast and stay compliant. More than ever before, Trust has the power to make or break your business. Learn more at vanta.com/lenny.

58:03 And as a listener of this podcast, you get $1,000 off Vanta. That's vanta.com/lenny. I feel like there's this like what are the jobs of a product manager and then

58:13 how are they slowly going to be uh supported slashdone by AI. So there's this misalignment just like fine misalignment and then maybe one day it'll be like align people initially.

58:24 You talked about this uh cache automation for growing like how do I grow this product that's starting to happen. Another that I I might use myself when I'm building stuff is just

58:33 asking how do I make this product better? how do I make this a better user experience and asking the AI just give me a bunch of ideas and they're actually really good. Uh so it's interesting how

58:42 these little pieces are starting to be put into place to do more and more of this role. I'm curious what other automations you have and your team have that are

58:52 effective. What I love about these conversations is you're basically living in the future. you're working at like the most bleeding edge company with the most talented people with the most

59:02 cutting edge tools and you can like see where things are going and start to actually live in the future build things uh that nobody else has even thought about or can do. I'm curious just what

59:13 else is working, what else your team has done to help save you time, be more productive. >> We use it pretty extensively across the board, right? So there's the standard PM

59:20 stuff like writing docs, brainstorming, looking at data. Um for data I personally have like a co-worker runs on a schedule and looks at sort of 20 25 different charts every morning and then

59:33 so when I when I come in the morning there's just so many charts so many products to track. co-work will tell me, okay, here are the things that you should pay attention to. Here's like

59:42 what is concerning and here are just some like interesting insights >> and it sends you the update in Slack or how does what's kind of the workflow? >> I it for me it just shows it comes up in

59:50 co-work. the co-work has a schedule >> in the desktop app >> you yeah in the desktop app you can have a scheduled task that you create and so I have a bunch of hex links that it will

01:00:00 go and and look at um it uses the the Chrome extension for for some things and it uses MCP for for other things and and and then it'll just give me a summary and then I I know like I still there's a

01:00:14 few charts that I just like to look at because I just like I'm a numbers guy I just like charts like up to the right too so I'm just I like to see the chart. Uh uh but then there's a there's like a

01:00:24 long tale of things and even the medium tail where it's like you don't have time to look at it every day that if Claude is is proactively looking at it and you start to feel good over time of okay

01:00:34 it's like the the false positive rate is going down the like false negative rate is going down of the things that cord brings to you um then you you just get a little bit more confidence and peace of

01:00:45 mind there. This touches on an idea I've always had that teams will have is a strategy bot which just imagine an agent that's just constantly watching metrics the market the road map what's working

01:01:00 not and just like hey here's what I think we should do now here's the pivot we should take here's where we're going to win like it feels like we're very close to that I think we're close I

01:01:09 think we'll get there later this year um to to like the point where that's very very effective that's my my my gut I that that level of like proactivity and getting looking across a bunch of

01:01:21 context and and distilling insights I think is it's it's it's like you know the the thing I mentioned earlier Lenny about the alignment piece like that's like a version of it right now you're

01:01:30 just looking at across more more data sources um this is something that I use so I talked about like this some of the standard PM stuff you know brainstorming data UXR there's a lot of like admin

01:01:42 stuff I just hate like life admin and like paperwork work. I just hate it. And so I get called to book my meeting rooms. I got to book meeting rooms. Claude archives sort of my my email

01:01:52 first pass at clearing out my inbox. I I don't do any of my reimbursements and and expenses. Claude will go to Ben pass and like file the reimbursements. He'll go to Brex and file the expenses. So all

01:02:02 of that side of things I'm just like just hand it hand it to co-work just get get rid of it. And then the the stuff that's quite interesting I think is like the the man the manager lens where where

01:02:13 I talked about alignment is one thing. So I I look also across my direct reports like Cord can look into what what have they done this week. you look at sort of our team goals and OKRs. Look

01:02:25 at the transcripts from our our discussions and understand can basically ask for like what are what are the key takeaways and observations I should keep in mind and like what feedback do you

01:02:36 think I should give them. Um and that's something that is like again you can just set that up weekly. The quality is like hit or miss right now. It's like it's decent on some things. Sometimes

01:02:45 you're like holy like I am so glad that I caught this and and um that's very very helpful. And then I do that for myself as well. So I basically um you know one of my manager Army Vora

01:02:58 was I think a podcast guest of yours right. So I say hey based on what you know of army both publicly she's written extensively about product and then internally

01:03:07 >> and then our discussions what what is every based on everything that I've done or not done this week. What feedback do you have for me as army? And like I get that every week, right? So like a lot of

01:03:18 these things can already be done today. I think that the as as as um the models improve, I think it's just like the accuracy and the signal of these things is going to continue to improve rapidly.

01:03:31 I don't think you realize just how much awesomeness you're sharing here. This is just like every one of these is like what? Okay. So Okay. So this Ammy example, so you you have one-on- ones

01:03:42 with her. You're you ask is this so do you ask Claude co-work to go through all of her writing basically build like a model of her and you ask what should I be doing differently based on what you

01:03:56 know about is that is that the >> yeah effectively there's a number of ways you can do this I think with if someone has um a public profile where they've written extensively it's it's

01:04:05 helpful because you could claude can just get all that information otherwise you can have a project or you can have a skill but increasingly claude is better at just understanding because you can

01:04:16 tell Claude like look on on co-work you can say using the Slack MCP look at everything that this person has said in the last you know week etc and based on that like what are their top priorities

01:04:28 what are priorities my manager has based on how they're spending their time that I don't know um and and so all of this this layer of stuff which is like the I think about it as like soft coaching um

01:04:40 I think that that is like unlocked in my opinion already. I think it's just that you you're like working with a coach who's like kind of like drunk at times. Not drunk, but like you know like

01:04:49 sometimes like says something you're like why like why would you bring that up? Like that's clearly wrong. But you other times you're like wow like that has there there's like one of um one of

01:04:59 the the the guys Scott who leads our enterprise team. I think he there was a few cases like he found like major areas of misalignment that would have caused teams to sort of spin their wheels

01:05:10 significantly or or or um do overlapping work. And you think about that the impact of that like your your shipping in this world is a bigger companies is going to be constrained at often by all

01:05:24 the cross functional coordination right and I think we're now starting to see at this cross functional coordination layer some of that work AI is really being able to be used to to reduce that toil

01:05:36 and and I think that 6 months ago that wasn't possible and I'm like like 6 months from now what what what is is going to be possible there. >> Oh man. And I think the fact that all

01:05:47 this data is there, Slack, there's granola, whatever people use, like all these notes from conversations and and discussions are really key to this working.

01:05:55 >> Yes. So for someone that wants to do something like this, what how do you set this up? What's kind of the steps? >> Yeah, you go on to Coowwork, download the the desktop app on Co-work. Uh

01:06:06 connect the Slack MCP. That's where you you need to um depending on how big the organization is, you you you may need to get sort of team or enterprise admin permissions to to um you know someone

01:06:18 with those permissions to to enable that. But once you have the Slack MCP connected and on co you just ask Claude that's it. Amazing. Okay. I want to go in a kind of a different direction. I

01:06:30 want to talk about the focus that Anthropic has had over the years. So if you look at the numbers um that that you're all putting up, what's really uh incredible about it is the focus that

01:06:42 you all have had and I think this is the reason it has worked out so well. There's a certain competitor in the market that is realizing they should have done this and are starting to shift

01:06:51 to a similar approach. As an external observer, it feels like anthropic has been very good at doing very few things but going super deep. So B2B for example, just going deep on B2B and then

01:07:03 going really deep on coding use cases, cloud code being an example and it's worked out really well. Where who's been driving that focus? Who has helped keep that focus from the

01:07:15 beginning? Yeah, I mean I think it's I think it's a foundational part of the the company. I think it's been there from the very very early days and it really comes from leadership and and I

01:07:27 think they they've just done a phenomenal job of of distilling that. Uh I I think that you know I I saw this doc come up recently is I don't know where it was shared. It was something that Den

01:07:38 man is one of our founders that he had on on the podcast had written it's dated in 2021 I think a few months after they started the company and it was like here's why we should just focus on AI

01:07:49 coding and this is like you know this is like 5 years ago this is long before anyone knew what the actual market opportunities were around this and um I think this is just like a a deep focus

01:08:02 that we have had internally from the start on the importance of of coding and and and B2B the um you know it's a it's a I think there's like two lenses to it right it's like the maybe a view of okay

01:08:13 that this is going to be commercially beneficial to tackle and then also the the side of it around accelerating research so I'd say it's a pretty mainstream view now I've now heard

01:08:23 people from various labs talking about the this the you know the the importance of of coding to accelerate research but that has just been like a very firm view that we have been laser focused on

01:08:36 internally of okay if you have the best models that's going to accelerate your researchers and that's going to accelerate the research loop and I think that's something that like Daario has

01:08:44 has seen very clearly for a number of years. So I would say that that that's probably one of a lot I think a lot comes from Dario. I think a lot comes from from leadership and and just our

01:08:54 DNA. I think the second though is is probably just like necessity where if you're if you're um you know it's now changed like we're more well-known company raised lots of money blah blah

01:09:04 blah but you know historically we were we were very much like the smallest least wellunded player in this space like in many ways it's a complete miracle that I think we've like gotten

01:09:14 to the stage that we have like we we didn't have the free cash flow or the distribution of a meta or Google we didn't have the first mover advantage of an open AI and So like what do you do

01:09:25 right? I think there's um I think there's like this broader principle I have just around life of of like the the freedom through constraints that when when you when you have a bunch of

01:09:35 constraints applied on you whether that's in personal life or or or or at work I think that that that can just it can bring a lot of freedom because it just frees up all this excess choice.

01:09:44 You're like okay like this is this is clearly the path. And I think for us it's like okay you're not you don't have a ton of funding. You're you're a small player. You don't have distribution.

01:09:53 like you just have to to really pick a very narrow focus and even for a very generalizable technology to to maximize your chances of getting to escape velocity and um I think that that's also

01:10:04 just related to like how history played out right so you know it was it was well before my time but anthropic had a version of claude we had a chatbot before chat GPT was was launched and we

01:10:15 we had ultimately chosen not to launch it for safety reasons I think the team didn't want to kick off effectively like an AI global arms race and um you know Chachi PD launched and like they got

01:10:26 like insane traction right and and that just naturally sort of pulled them towards consumer you know there's another world where if anthropic had launched pred first like maybe be the

01:10:36 other way around even with all that focus stuff so it's who knows it's it's hard it's always hard to say looking back with some of these things >> wow I didn't know that I think also

01:10:46 people just don't realize how far behind Anthropic was like right now it's like of course they're amazing but like I just remember when people were talking about Anthropic, we were raising money.

01:10:55 I was like, there's no way they're going to compete with OpenAI at this point. It's like so over just like they're so far ahead. And it shows the power of focus and just uh I guess I don't know

01:11:06 all the things you all did. Like it it is absurd how far y'all have come and how successful and how things have changed so quickly. >> Yeah. And I I would say I I very much

01:11:16 agree. I think a lot of that like we I think a lot of that comes down to our leadership team. We have a number of people who've worked at like call it like the best companies you know in the

01:11:25 world very senior people and I think almost uniformly everyone's like this is the strongest leadership team out of any of those companies and so I think a lot comes from them and then we're just very

01:11:36 lucky to have incredible people. Uh, I think that that helps a lot as well. >> On the coding piece, just to make sure that part is is clear, I never thought about this that the reason that the bet

01:11:48 was so deep on coding is not just that's a huge tam, but it's that this will excel. This is a feedback loop that will accelerate us further and further. So, if we get the best at coding, coding

01:11:57 will help us do research. It'll help us build better models and accelerate faster and faster. >> Yeah, that's correct. And and this is something I checked Dario has talked

01:12:05 about this publicly so I invite to find >> like okay it makes sense. Um the safety piece is really interesting so I want to spend a little time here. So famously anthropic I think the official name of

01:12:15 anthropic is anthropic and AI safety research company. As a growth person there's this balance I imagine you strike between growing and just and not and the mission being don't grow at all

01:12:30 cost. Our goal is AI safety and alignment. How do you balance those two things? How does that impact your job? Look, I think it's something we take very very seriously and um it is it's

01:12:42 the whole reason the company exists and and and if you think about it's it's all the way from it's why they they they left to start the company. It's deep in our corporate structure itself. So you

01:12:55 historically um everyone raising money is like go go create a Delaware C corp and and that's like the structure you do and with a with a corporation um you have a fidiciary duty to maximize

01:13:07 returns for sh sh sh sh sh sh sh sh sh sh sh sh sh sh sh sh sh sh sh sh shareholders, maximize shareholder value. And uh from the beginning they they went a different way. We we went to

01:13:14 went and created a public benefit corporation PBC which allows you to legally say that maximizing shareholder value is not the the like overarching umbrella goal of this of this company

01:13:27 and you you can optimize for for public benefits. So really I think it it starts from there and it it ladders down from there. for us, you know, our our our purpose, our our mission ultimately is

01:13:37 to is to make sure that the transition to powerful AI goes well and is is net beneficial for for humanity. Um, you know, we I think internally like we we are like very excited and I think

01:13:51 honestly there's a lot of like very very optimistic about where this can go, but we also understand what what the risks are. And so for us that topline objective of this just like this needs

01:14:01 to go well for humanity. this just needs to go well for humanity. That is something that we are happy to take a significant commercial hit for and and we've done that time and time again,

01:14:13 right? So like we have a you know like back then, okay, you had clawed but you don't want to release it cuz you're like there's these safety risks and so there's time and time again that I' I've

01:14:21 seen we've been happy to take that hit and it's it's actually worked out well for us in other ways. from like a growth lens, you know, I I look at it as like growth teams can often push the

01:14:32 boundaries of what is like good user X UX, etc. because they're trying to very very uh much like eek out metrics at times. When I think about if a controversial test is is bought to me, I

01:14:44 I sort of look at it as like this there's two types of tests that are controversial. One is when that test is so controversial that you you just should not run the thing because the

01:14:55 results don't matter because you would not ship it for a combination of uh you know brand and and sort of customer friendliness and and values. And then the second is where it's like it's

01:15:06 controversial. You're like I don't like it. I certainly don't love it but it it's it's like it's not like a red line. And so you're like, you know, if someone comes to you with conviction and is

01:15:18 like, I have a really good hypothesis around this and you're like, I don't love it. But like, you can run the test and see what impact it has. And if it's like if it's like a high level of like

01:15:28 cringe or ick, then I want to see a high level of return for for the result for that. I kind of think about everything like is is it in is it in one or is it in two? And for every company that one

01:15:40 and and two is is is different. Um, I think for us the AI safety is like very much in in in one. I think that it's like, yeah, that's why we exist. Like, yeah, it's fine. We're just not going to

01:15:51 not going to do this thing. I think then there's other things that fall into two where you're like heightened sensitivity, but we can we can we can try it and and see what happens. I think

01:16:00 zooming out though, Lenny, one of the biggest mistakes I feel like I see growth teams make and particularly just like hardcore growth practitioners is is just trying to squeeze every last

01:16:11 dollar. This is like I think this is like a general principle also in life like if you're a founder raising money you're just trying to squeeze that like last dollar like you don't you don't

01:16:20 want to do that because you want people to come back next time as well is my view and I think in in growth like it's it's I think it's really important that you you just need to be okay leaving

01:16:30 money on the table and that's a core principle for us as a growth team where we are very comfortable forgoing metric impact in order to prioritize safety in order to protect our brand in order to

01:16:41 hold a high quality bar and and to maintain a great user experience. And if you like look beyond the short term and like okay what are the numbers for this quarter and and you zoom out and you

01:16:51 think about what are the very best products out there you realize this is how they all all operate and that's actually the thing that's going to drive more growth long term as well and and so

01:16:59 I think that that actually ties back to safety where as the risks get higher and the stakes get higher I think the fact that we are taking a stance and safety is like critical to what we do is

01:17:10 actually going to become a significant uh it's going to be a significant ificant um competitive advantage for us that I think is going to help us in the long run.

01:17:19 >> Yeah. What's as you as you share all this like clearly it's working anthropic is killing it. Uh so I love when those examp when someone doing something someone approaching problem that way it

01:17:30 you it actually works out. That's the same way I think about with my newsletter. There's so much more I can do to grow it. I just my philosophy is just like just focus on creating good

01:17:39 content. Nothing else like all these micro optimizations are not going to matter in the end. it'll grow through people sharing it if it's useful to them. So uh in a very small scale I have

01:17:48 similar philosophy. One of the things that people are probably thinking about as we talk so you know we joke about like AI replacing parts of jobs here and there like you

01:17:58 know it is it is pretty scary to a lot of people just like what is the future of my job? Will I have a job? How do I stay relevant in this future? So for there's a couple questions here. one is

01:18:08 just like for folks that want to be to thrive in this approaching AI future as a PM as a growth person. Do you have any advice things that they should be doing right now? To me, a couple of things

01:18:20 come up like one thing that everyone says is like use the tools. You need to be on top of the tools. I think you need to be using cloud code. You need to be using co-work and understanding

01:18:30 just each model release. What is the new things you can do with this? How can you apply this to your job? It'll work well in some things. it worked terribly in other things and then one model launched

01:18:40 later it's like oh that other thing worked but if you didn't go back to try it you would not have known and now many months have passed so you didn't know that that was possible and so I think

01:18:48 that that that being on top of the tools is really important both for improving your own productivity but also for getting product sense around AI products um which I think is just going to become

01:19:01 increasingly important I think then zooming out beyond that I I kind of look at it as like just leaning into where you will have a competitive advantage and an unfair unfair advantage. And so

01:19:12 to me it's like if you know there are some people some PMs who are really good at like craft for example and there's others who you throw them into a situation with all these stakeholders

01:19:21 who have all these strong opinions and you know there's no way they're going to mediate this and they and they come out and it's like everyone's kind of swimming in the right direction and and

01:19:28 so the if you think about like what is the major skill set that you have where you spike in the that that can be tied to delivering uh driving impact for a company in a product role. I would just

01:19:40 double down on that and like almost like forget the weaknesses, just what can you do to be become like the best person at that thing. Um because that's that's like very very valuable and I think that

01:19:50 ties to the notion of just leaning into being interdisciplinary. So going back to some of what we mentioned earlier on where it's like okay in this world of engineers are mini PMs that the the

01:20:03 engineer who is like highly product minded is a unicorn is an absolute unicorn. I think the same thing is true for for PMs where it's like okay now you know this in this ratio if the designers

01:20:17 really stretched and you're a PM who can design you are also a unicorn now like the chances of a company letting you go has gone down dramatically because you are now just so much more more useful

01:20:28 and so I think that is just like really really important I think if I look at what's benefited me it's probably a version of this like I think that for me I came from a founder background. So

01:20:39 like the mix of the the founder background, the the like finance, I was an investment banker. So like the finance background and numbers and then sales like I was I almost became an

01:20:49 account exec instead of going into product. I was right on the edge of should I go into sales or product and I think like a combination of those along with with growth is probably what's led

01:20:58 to like there are certain areas and situations where I can just have outsized impact to other people and and so understanding what that is for you is is really important. And I look at our

01:21:08 financial services product. Um, you know, we've launched like quad for for sheets, quad for Excel, the guy like tank the market by the way. Everyone went

01:21:18 >> I know. Um, but like the guy running that, Nick Lynn, like he came from investment banking, he came from private equity and he just has such a competitive advantage where he's

01:21:27 building that product and he's like, I know this. I know this. Like he's like built for this. And so I think just understanding what what are those interdicciplinary

01:21:35 areas you can lean into to to make yourself more um just like higher higher higher impact is is really important. And then the last one is just being adaptable. Anyone who you who who is

01:21:48 trying to just keep applying old playbooks I think you're you're going to make life a lot harder for yourself. So one of the biggest things you come into anthropic is you need to understand that

01:21:56 probably yeah 50 60 70% of how you operated in the past just throw it out the door. it's it's not going to be relevant. And if you try to stick to that, you're going to have a lot of

01:22:06 friction and it's not going to be helpful. So just being adaptable and understanding, okay, the job's changed this way, I'm going to go that way is is I think like it's it's so so important.

01:22:17 >> That is awesome advice. It matches a lot of what Jenny shared when she came on the podcast, the design design leader on Claude and CL work and all these things of just like like the idea of going

01:22:27 deep, becoming the best or one of the best at a very specific thing and that not every company will need and you don't need all 10, but just going deep and on something. I forget what how she

01:22:36 described it. Mark Andre said the same thing just like I think we called it a sideways E instead of just like T-shaped of one thing. If you could have a couple of things you're really really good at,

01:22:49 uh there's a lot of power to that. Oh man. Okay. Before I get into something that I think will blow a lot of people's minds about how we actually met and kind of a big

01:23:00 part of your journey, um let me just ask you this. Is there anything else about anthropic that might be worth sharing, might be worth talking about? The thing that maybe comes to mind is is just like

01:23:13 our our culture and and the people that that we have here. I really think it's our secret source. I think it's the thing that is the most defensible, the thing that no one else is going to be

01:23:24 able to replicate. And um I don't think it's an accident like leadership has has really invested in this a lot and Danielario they they really believe in this in this a lot and I think they've

01:23:36 just created a very special culture. So I would say that you know this is like truly a missiondriven company and I was not 100% sure of that when I joined. Like I was like I think that this is an

01:23:48 exciting company. I I I like very much agree with their principles but I didn't know anyone at the company. I didn't have any references on what it was like inside. So I was a little skeptical when

01:23:58 I joined. I'm like at least they're talking about it but like I don't know are they are they are they serious about this? And then I came in very early. I was like, "Oh, oh shit." Okay. Like they

01:24:09 they are maybe they're even more serious about this internally. They they talk externally. And so it's just like the it's it's a missiondriven company where people viscerally viscerally understand

01:24:21 both the upsides and the downsides of the technology and therefore understand the the the divergent ranges of how this may go for humanity and and how different of a future that could be. And

01:24:34 I think like when you understand that of how different this could be as a future for all of us and like our children and our grandchildren etc. I think it it it leads to a lot of passion for what we

01:24:48 do. And um it just leads to a a lot of belief in in what we're what we're doing. And so I kind of look at every other job I've had in the past. There's some degree of people at the company who

01:24:58 are just checked out where it's like, you know, I'm I'm here. I I'm sick of this, but I I don't have a better option or I'm getting paid too much to leave, etc. That is just like not the case

01:25:07 here. I have not met a single person I'm saying a single person who's checked out. Everyone is putting everything they have on the table. Everyone is is pouring it out and like leaving nothing

01:25:19 behind and and is just fully fully in it. And so I think that leads to like this releases energy that is just like very very hard to to describe. I think you have that energy, you have that

01:25:31 missiondriven nature and then it's it's such an open culture. So leadership is very very transparent with us on things. We uh Slack is like a it's a it's a whole maze. There's so many things that

01:25:44 play out on Slack. We're very open. Everyone has these notebook channels where you kind of have like your own like Twitter feed in a way where you're just talking about your thoughts about

01:25:52 things. And so you can go and like join the Slack channel, the notebook channels of people on research and all these other areas and like you you can learn whatever you want and and you can spend

01:26:02 so much time like getting lost in that as well. But that that openness where we even encourage like people can just argue with Daario. There was an all hands you he said something where

01:26:12 someone didn't agree and then and the person goes onto Dario's notebook channel and just says like hey I didn't appreciate how you said this or this and that. And then it sparked a whole big

01:26:20 debate. Um but like that sort of thing where like it's encouraged like go to leadership and disagree with them, challenge them publicly and like that I think that just leads to a level of

01:26:31 trust and all of that together. I think it just means that we have this very very deep sense of togetherness that um man I have just like never I've never experienced anything like it. And and

01:26:44 then you get to the talent, right? That I think that is the thing where the talent density is like I feel like I'm playing for like Real Madrid at times. I look around, I'm like, man, I'm playing

01:26:54 for Madrid, right? It's like you just like have the best people in the world. I think it's most I think it's most the case on research. We have like the very very best researchers in the world. But

01:27:05 even you look on on like product, we have an Vora like she is phenomenal. We have Mike Kger. You're like, "Okay, casually started Instagram. He's here." Um, you know, on growth we have John

01:27:14 Eaggan who who's my engineering counterpart who's like the OG in growth engineering. He's he's he's he's great. We have Alex guy who teaches growth engineering at Reforge. He's just like

01:27:24 another dude on the team. Um, and all of that I think is just very special. My my favorite here is like in the LA couple of months ago we had our onsite companywide onsite and in October and

01:27:38 I'm walking around I see this guy. He's just walking around eating popcorn by himself. I go up to him and I'm like, "You're Jeff, right?" And he's like, "I am." And I'm like, "You are literally

01:27:48 the US ambassador to my country, Australia, and you're just an employee here." I'm like, "This is insane." I'm like talking to our prime ministers of our country and all these things and

01:27:58 it's just the the the talent combined with that culture, I think, is just this secret source that uh is is is the reason that I think we are as successful as we are. This notebook channel is so

01:28:09 interesting just like as a tactical thing. So the idea there is Daria just shares it's like a little Twitter like internal Twitter feed where folks just share what they're thinking about and

01:28:19 what their what their priorities are and things like that. >> Yeah, that's basically where it's it's an internal feed where it's not just everyone has one and you basically you

01:28:28 share your internal thoughts. It's a way to like keep people updated on things on what's working. It's a way where people share provocative things. I think from like a leadership level and we also

01:28:40 think about that as it's a way to scale your beliefs and views across an org as it grows quickly, right? So like if you're now adding a lot of people in the organization,

01:28:51 you need to think about okay, what are the like behaviors that we want to model? What are the principles that are top of mind to us? And if you think about like yeah, you can have a bunch of

01:28:59 these meetings where you talk about it. you can you can model that behavior. But if you have a channel which is like here's my top of mind and you you say these things right like if I have a post

01:29:08 which I did the other week of like this is the importance of being comfortable leaving money on the table. Now all the new engineers on growth who've joined have seen that and they're like oh okay

01:29:18 this is like different to to what we had we we we've known before right so I think it's like good for the openness but it's also good as a leader of how you can scale your views as an

01:29:29 organization to like get people more up to speed on the way that things are done um which is I think really important to like avoid that drift which when you have so many new people signing up that

01:29:40 drift can lead to a lot of drift in strategy and and sort of perception so it just helps run a run a tighter ship in that way >> and more importantly it's data for the

01:29:48 agents everyone's got running to help them work with all these humans. Yes, that is that is very very correct like it is it is something that goes to Claude you know that there are certain

01:29:58 documents in onboarding where it's like the HR team has written before edi editing anything on this document please check with this person because this is a document that claude references as like

01:30:08 a key thing right and so more and more these types of things of okay how does the growth team think about this how does safeguards think about this you're armying claude with that context to get

01:30:17 better and better at at um at at helping in the future >> that's interesting it feels like that's something thing that every company's going to have to start doing is just

01:30:23 sharing their thoughts in a structured way so that all these agents that we've all got running uh have what they need to know. Uh another interesting side note here is just Slack. Okay, so like

01:30:33 there's all this talk of SAS tools being replaced by AI and you guys use Slack. I think there's this famous tweet of you guys still use Workday and all these tools, all these SAS tools, everyone's

01:30:42 like what like they're all going to be vibe coded out of existence. the fact that you all at the cutting edge of what could be built with code uh still use Slack and all these other tools. To me,

01:30:52 that's a good sign that maybe SAS companies will will be all right in the future. I don't know if you have anything there to share. Yeah, it's a really I think it's a really complicated

01:31:00 picture, right? Like there's a number of things that we just build internally ourselves. Um as time goes on there, you know, your your the ability for Claude to do that better increases. And at the

01:31:11 same time, like we use Figma a ton. We use Slack a ton. We use Workday. Uh we use a lot of these products. And I don't see that changing in the immediate future. And um and so yeah, I I think

01:31:23 like there's there's probably some truth to some of this. I think the other parts are like it's overblown and many of these products are like they're customers of ours. we we value them a

01:31:32 lot as customers and we use their products very very heavily and I don't see that changing in >> and you have better things to do like I don't who's going to spend time building

01:31:40 a slack at like that is not where value is going to acrue and I think it also helps you see how much how sophisticated these things are they're not just like you know like there's been teams

01:31:50 thinking about these problems for a long time anyway that's a whole other tangent just coming back to the values thing I just want to highlight something here that's really important a lot of people

01:31:59 criticize anthropic for talking about the dangers to humanity, throwing out all these numbers about jobs going away, just creating all this uh fear, but like and people think it's, oh, we're trying

01:32:12 to raise money or we got to get people's attention or we just yeah, we're just trying to like create headlines, but everything I've ever seen internally is always just this is what we believe and

01:32:23 we want people to know what it might be coming. Even if it isn't bad, we want people to understand here's what might happen and we are trying to avoid it. And you might say, why doesn't why is

01:32:35 anthropic even building AI that's if it's so dangerous and you know the understanding Ben shared is just like we think it's better that we go at this and try to build it the right way versus

01:32:45 just stay out of the and just hope that nothing bad happens. >> Yeah. I think I think three three things that come to mind there. First is I I go back to something I said earlier which

01:32:54 is that we we very much think about things from an exponential lens. And if you are thinking about things from a linear lens, you'll see the world very very differently, right? Cuz you look at

01:33:04 where we are today and you're like, "Okay, but like how much better can it be in 2 3 years?" I think if you're looking at it from an exponential lens and you understand how exponentials

01:33:12 work, then you just realize that like a lot of this stuff is actually going to be happening sooner that then than then people think if you're looking at it from a linear lens and um and then if

01:33:22 you understand that that like that there could be upsides and downsides and the range of outcomes here, you you need to like I think we we very much like need to be talking about the downsides so we

01:33:33 can avoid them and push towards the upsides. I think most people of the company are optimists. We're we're we're very optimistic about the future. I think it's just we understand the risk

01:33:42 is like it is not a guarantee that we we we end up in a in a good place and not enough people are talking about the risks I think in productive ways um and and who have the know the knowhow of the

01:33:53 risks. I think there's people who may talk about the risks but are not in the game and so they don't actually know fully like they're not like surgical on what the specific risks are but we're in

01:34:02 the game. we understand what's happening. And so that's one piece. I think the second is like I think we actually believe in this stuff more strongly than we we we say externally.

01:34:12 So like it is just such a key part of how we think internally that sometimes like we we just like reward your statements because it's like people might just think we're being like too

01:34:22 over the top, but internally that's how we think and and what we're putting out is is a softer version of that at times. Um, and then I I think the the third piece is that is is going to what Ben

01:34:34 said where we we think a lot about driving the race to the top. And so it's like if you're not in the game and you're shouting from the sidelines, no one cares. It's just the reality of of

01:34:44 how the world works. Like no one no one really cares. If you're in the game and you're a leading player and what you're doing is working, you can influence people in who are also in the game to to

01:34:55 take the right actions. And so that is like the core of it. Like if we just pack up and go home, you have no influence on this thing. And if you stay in the game and you're like commercially

01:35:03 you're doing great and then you have ways to influence the that okay, the these are the principles and put that into the conversation and make more people sort of believe in those things.

01:35:12 I could talk to you forever, Amal, but um two more questions just to round out the conversation and touch on some stuff that I've hinted at a number of times. One is I want to take us actually to

01:35:22 failure corner because someone listening to this may be like all right look at this guy just worked at all these amazing companies cold emailed the CPO at Anthropic got a job joined this

01:35:33 rocket ship it's all been up and to the right just killing it constantly what's a story from your career where things didn't work out when you failed and what did you learn from that

01:35:44 experience I have a couple I think it's very much not that way I feel like it was a lot of squiggly lines uh to to to get here. The biggest I'd say is is just, you know, founding a

01:35:56 company, raising a bunch of money, having employees, and then having to shut it down and and tell your investors that you've that you've lost the money and that you you had a vision of what

01:36:06 you're going to do and that it's not it's not going to happen. And so that I think is is probably the the biggest one. You know, we spent three years on it. It was not like a oh, we tried

01:36:15 something part-time. It was like, no, we we went we went for it. We spent three years raised a couple of mill. We had you know maybe seven 10 employees at our biggest and it was something that we

01:36:26 really believed in. It was around mental health and how you can quantify mental health to help understand or get early predictors of things like generalized uh generalized uh anxiety, major

01:36:36 depression. So like it's stuff that we really really believed in but ultimately um you know we like in our early 20s. We had like no idea what we're doing at the time. uh and many things I did

01:36:47 differently but that was just a very very very painful process. Um I think the good thing was like we kept our investors in the loop the whole time. So to any founders who are struggling out

01:36:57 there uh like send those monthly investor updates. It's really easy to send those when you when things are great. It's really hard to send those like when when things are bad. You're

01:37:06 just batted down. You need to sit down and send an update to your investors about why everything you talked about last month like did not go go to plan. that it's just the right thing to do and

01:37:15 it it keeps people in the loop and it avoids surprises, but it's still so tough when you're then calling up the investors to be like, "Hey, like we we're shutting down or making that

01:37:24 decision. Everyone had believed in you and it becomes such a big part of the identity." It's very very tough. So, man, that was just brutal. Like, it's brutal. And it took me, I think, like a

01:37:33 number of years to truly get over. Um, I think that it's it's it's a tough thing, but you get so much from that experience that is hard to see in the moment. And I think without doing that, I would not

01:37:46 have gone into this. I was not a PM before. I didn't have any of these skills. I'd never worked on products. I didn't know how to cold email really. And and so it was through that job that

01:37:55 I learned a ton of the skills that made this career path viable for me. And it's just really hard to see that in the moment when you're looking at a point in time. it's much easier to to like draw

01:38:06 the line looking back. But I think that would be my my like takeaway is just keep in mind that it's a long game and some of those things like I'm so grateful for that experience now. I'm so

01:38:15 grateful that it failed and went that way actually. It's very painful because it wouldn't have led to what I'm doing now and and so it's just a it's a tough thing but that you know positives can

01:38:24 come from it. What I love about this is a lot of people have these times in their career where they're like, "It's all over. Like, I'm such a I failed in such a big way and my reputation screwed

01:38:34 and people were counting on me and now they see I'm I'm an imposttor. I never knew what I was doing after all. Now they finally see." And just seeing that and this was three years. You had I'm

01:38:43 looking at your LinkedIn. You had seven employees, something like that. And and then it's like masterclass, Mercury, Anthropic. Um, I think it's inspiring to hear a story like that to know that you

01:38:54 can have a big failure like that and things can work out that it's not the end. Okay. So, at 2023, I was uh I was going to go on pat leave because uh my wife's pregnant and I was just like,

01:39:08 wait, what do I do with the newsletter? I I need to take some time off. That would be really nice to take a month or two off. And so, my plan was, okay, I'm going to do a bunch of guest posts where

01:39:17 people line up. I put out a call for guest post. people apply. Uh, I pick a few and then I kind of slot them in ahead of time so I could take time off. So, I put out this call, hey, who wants

01:39:26 to write a guest post for my newsletter? I got 500 plus applications. One of those applications was from you. And the pitch was essentially how a traumatic brain injury made me a better

01:39:39 product manager. And I still remember reading the first draft you sent me and I was just like, holy this story is incredible. It's just like like you feel such

01:39:49 feelings and it was just so tactically interesting and useful like oh wow this is actually going to make me a better product manager. Share the story of this of the the brain

01:39:59 injury that you went through and just the journey that you went on there because this is going to blow people's minds. It was the toughest time in my life. It made shutting down a company

01:40:08 like that was nothing actually. Just funny how perspective works that way. Uh back in uh early 2022, I had a traumatic brain injury. So I'd done MMA for many years. I'd done Muay

01:40:22 Thai, which is a type of martial arts for many years. Never had a problem. And just it's just like the one of the things that happens like the wrong session, the wrong it's just a normal

01:40:30 day of sparring. Nothing crazy. You get the wrong hit to the head in the wrong way. And uh my whole life changed. And and basically I spent nine months. I was off work for 9 months. The first couple

01:40:42 of months were brutal. It took me roughly h half a year till I was comfortable walking again. It was very very difficult. The first two three months beyond just showering and going

01:40:55 to the bathroom. My wife did everything for me like including like texting my friends. I would listen to music for a maybe like 20 seconds and feel like I needed to vomit. I couldn't look at

01:41:06 screens at all. And it was a very very long recovery. It was not clear to me that I would ever work again for a while actually and it was like we we had been discussed with my wife like what would

01:41:15 we do in that case etc. And we had we had to think even on on on those those levels and through a lot of pushing and and and really working through myself and and you have to just slowly increase

01:41:28 your tolerance to things. It's a brutal process. Uh but you need to slowly expose yourself to different things and just get better and better at each little thing. Actively work on that.

01:41:38 don't push it too far otherwise you you have a big setback but it basically got to the point then where where over 9 months and then that returned to work and and then it slowly got better and

01:41:49 the part Lenny you don't know is yeah we we in mid 2023 we posted that newsletter and a month later I I got reinjured actually. >> Oh wow. And because and and when you

01:42:01 have a brain injury, until you're 100% healed, your your risk of another concussion or brain injury is elevated. When you're 100% healed, your your risk falls down to that of a non-concussed

01:42:11 population. But until that time, and like even if you're like 95% healed, you're not 100% healed. And it was just an innocuous sort of in in in everyday life getting off a plane, a bag sort of

01:42:22 hit me on the head type thing. And um and I was off work for two months when I like one month into joining Mercury and like one month in I'm like sorry guys I need to peace out for three months and

01:42:32 and that then it was a very very long recovery from that and I'm actually still not 100% healed. So I'm like I'm like mostly good but I have uh times when I have like dizziness and headaches

01:42:42 and other things that I need to work around. Overall I feel like it's one of the best things that could have happened to me. I and and I think that keeping that mindset

01:42:50 helps and there's a point when you can like take that too far when you're that view is devo is detached from reality but I think it's just made me so much better and effective more effective as a

01:43:00 person a lot of the same habits like I I don't drink alcohol I don't drink caffeine I have to do a bunch of these things for my physical health I just have to do them so I keep doing them I

01:43:09 take breaks this is like a really big one you might think even in a place like anthropic like how do you survive in this way it's like even on the craziest days Lenny between the start of the day

01:43:17 and lunch between lunch and the end of the day, I take a short break. Um, even on the craziest days with like model launches, etc. I'm lucky we have like a meditation area in the office that I'll

01:43:28 go to and uh and then the whole the whole side of things around meditation that I I talked about in in in um that that post. I think both you and I have done a retreat at Spirit Rock and doing

01:43:40 a you know meditation retreat changed my life and it's something that I do uh at least once a year now. I have one coming up uh relatively soon as well. And and just I think all of that has helped with

01:43:53 better managing the physical side of it because this job is very taxing and then emotionally having a little bit of space to what happens. Like you you have you have sort of awareness on one side, you

01:44:04 have the reality on the other side. And reality is crazy here, man. Like reality is insane. Like there's so much happening every day. There's so much noise. It's it's it's mind-blowing. And

01:44:15 so that relationship between awareness and reality, that's where you have choice that you you sort of learn from from deep meditation on on how to to shift that and apply your choice there.

01:44:26 I think that that is the thing that has helped me significantly with just keeping a more level head. Um I think a lot of staying in this game at this at in this level of intensity is just how

01:44:35 you just keep your head. Just don't lose your head in like the crazy times. And I think all of that that I've gone through has like helped me do this um without resorting to like unhealthy coping

01:44:46 mechanisms. >> Wow. Uh Amal, you're such an inspiration in so many ways. Just like there's so many reasons that you would not have been successful and things have would

01:44:56 not have worked out and there's so many lessons to learn from just the stories you've shared and the journey you've been on to help people overcome challenges they're having. Like if you

01:45:05 can like come back from an insane Was it like a kick to the head? Is that what would happen? Is that >> It was a It was a kick to the head. That's correct. Yes.

01:45:13 >> Just like feeling like you may not be able to walk like not want being able to listen to music uh to just like leading growth at the fastest growing company in history. There's also just like a lesson

01:45:23 here of constraints. Again, you mentioned this idea of just like the power of constraints. Like you're forced to take breaks. You're forced to go meditate like in a way that's really

01:45:32 helpful and it's like a lesson for us all. This is actually really good for us all. Yeah, I think that freedom through constraints is is like a one of the big takeaways I've had during that time and

01:45:40 it because when you have these constraints, you're forced to adapt and it it creates you gives you in a business setting, you have to focus more in a personal setting. You're like if

01:45:48 the constraint is I can't do anything and I'm injured. I don't know what's going to happen. I don't know I'm going to get better. You have two choices. cuz you're like one, are you going to let

01:45:56 that are you just going to resist and like fight with reality and and let and really suffer from that or are you going to accept the situation and and like not

01:46:08 let that affect you emotionally? It's not to say like I did everything, man. I was like every single thing I could do, diet, I was like I'm on it. Every action I can take I'm on it. But then you have

01:46:16 a choice of are you going to let the impact of that define your happiness or not? And and I think that that's the thing when you when you when the impacts maybe are not coming, you have to then

01:46:25 adapt to okay, what do I want my happiness to be? And one of the meditation teachers said like that true freedom in life is learning how to be content when you don't get what you

01:46:34 want. And it's not to say you shouldn't do something when you don't get what you want. But I I think that that that takeaway of just can you be content and like not have your happiness rely on on

01:46:44 getting something I think is it's a challenge. I'm not perfect at it, but I think it's it's probably one of the biggest takeaways from that whole thing. Incredible. And we'll link to the post

01:46:51 if folks want to read this before we get to a very exciting lightning round. Is there anything else you wanted to share or should we just jump right in? >> I think we can jump into We covered a

01:47:00 lot of ground. Okay, here we go. Uh, I've got five questions for you. First question, what are two or three books you recommend most to other people? Probably ties to a lot of what I just

01:47:10 talked about. I I think a lot about meditation and my emotional state. That's what I spend most of my time thinking and like reading and researching and working on outside of of

01:47:20 work. So my recommendations very related to that. The first is a book called Joy of Living uh by a Buddhist monk. His name is Yongi Minga Ring Poche. Um, it's it's just really about how you can start

01:47:34 to think about your life experience in a different way and uh and and you and have tactics of what to do to kind of change just how you think about things. This is one where like I've recommended

01:47:46 to people um it's not like yeah I've recommended a lot of people and they they've really really enjoyed it. I think another one is awareness by Anthony Dlo which is a kind of similar

01:47:56 thing but from a different angle. Those two I I consistently recommend to people. And then the third one is more relevant to to product in many ways is thinking in bets by Annie Juke. I think

01:48:06 just being able to break down a situation when someone's like I don't know it'll get done in time. Okay. Like can you put a number to that? Like what what percentage likelihood is it? Those

01:48:15 types of things I think are just so tactically helpful in in in product. Favorite recent movie or TV show? I think movie is probably Marty Supreme. It's one of the only ones I watched

01:48:25 recently. I thought it was great. I thought it was just insane. an absolutely insane movie. It was ridiculous, but but I loved it. Uh TV show I have not watched TV in a while. I

01:48:34 think it's probably the the Olympics would be the one if that if that counts. >> Is there a product that you love just like I don't know one you discovered recently or just one you have in your

01:48:42 life that's like oh this is very cool. People might want to know about it. >> Yeah. So I this is a funny one. I was in Japan last week and uh I was on this sitting in this hotel and I actually

01:48:54 really loved the pillow that I had in this hotel. It was very random. I've just had at times had like neck and upper trap pain and and sometimes I've been frustrated with my pillow cuz I

01:49:02 sometimes sleep facing up, sometimes sideways and like the height's not quite right and I was just like this pillow is just great and it basically this pillow is like it kind of it's full of beads

01:49:13 and so you can like naturally shift the height of the pillow while you you're sleeping like even like unconsciously without thinking and and so I like looked at the tag. I was like what is

01:49:24 this? I ordered it to in Amazon Japan and I brought it back with me on the plane. And so I have the name here. It's it's called the Maruhachi Shinsui

01:49:34 Maruhachi Pro pillow. And you can only get it in Japan, but they ship to the US. No affiliation. And I think that has changed my life in like the last week. >> That is an awesome pick. Uh do you have

01:49:45 a favorite life motto that you often come back to in worker in life? >> Main one I'd say is just she'll be right. This is a this is a very common Aussie saying. It's like she will be

01:49:53 right. she'll be right. It's a common Aussie saying when we're faced with like a tough or difficult situation. Um you're kind of like dismissing the severity of it in a way by saying like

01:50:02 it'll be fine. And I think that that's just like such a good metaphor. It's such a good like tactic in in many many cases. And then I think the other one is just like sometimes in life you just

01:50:13 have to go for it. And that is something that um the guy Eros Resin Mini who is the the CMO of Discord who is a very close adviser to me as a founder. he would push me on this and that was

01:50:24 something that he would often say is just like just go for it and I think that that's it's it's a very helpful thing of you can sit there thinking should I do this should I not and

01:50:32 sometimes in life you just have to go for it. I love the combo of those two. Uh just sometimes just go for it and she'll be right. So good. Okay final question. Okay so

01:50:42 I'm curious. Uh used to be into martial arts that didn't go great. Uh do you have a new hobby that you uh find yourself loving? Do you make time for hobbies? I think I'm just like quite

01:50:53 tight on time for hobbies. I I would say I I think it's largely just like work and have my body function and then like you know take care of the most important relationships around me. I think maybe

01:51:05 the the the one hobby I'd say is just I'm really into sports and I've gotten more into sports at football in particular. Watching >> watching certainly not playing. I my

01:51:15 wife's from Michigan and and she took me to a game at the big house and it just changed my life from then on. I was like, I'm a Wolverine fan and uh big Wolverines fan, big 49ers fan. I just

01:51:25 love football. So, that's that's probably the the the one that comes to mind. >> Mo, this was incredible on on so many levels. Uh I'm so thankful that you made

01:51:34 time for this considering how much you got going on. Where can folks find you online? Say they want to apply for a job maybe on your team. Where can they find that? And how can listeners be useful to

01:51:42 you? >> You can find me on my LinkedIn. It's just I'm all over. Um I'm boring. That's that's it. uh you can look online to apply on our jobs page. There's a roles

01:51:51 across growth engineering, growth product, growth design. We are looking for great people on on the growth team. So, please come and join us. And I think being being helpful to to me is just two

01:52:03 things. Trying our products, giving us feedback, giving us harsh feedback in particular on what can be better. And then please send uh great people our way. We are looking for the best of the

01:52:11 best to join the team. And uh we would we would love to to hear from anyone you know of as well who could be a fit for one of our roles. >> Dream job for so many people. Amole,

01:52:22 thank you so much for being here. >> Thanks Lammy. Bye everyone. Thank you so much for listening. If you found this valuable, you can subscribe to the show on Apple Podcasts, Spotify, or your

01:52:32 favorite podcast app. Also, please consider giving us a rating or leaving a review as that really helps other listeners find the podcast. You can find all past episodes or learn more about

01:52:42 the show at lennispodcast.com. See you in the next episode.

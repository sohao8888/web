视频链接：[https://www.youtube.com/watch?v=cUngseNueP8&list=WL&index=9&pp=iAQBsAgC](https://www.youtube.com/watch?v=cUngseNueP8&list=WL&index=9&pp=iAQBsAgC)
视频发布时间：2026-04-09
频道名：20VC with Harry Stebbings

## 转录内容

00:00 I'm going to call [ __ ] start to finish on this whole discussion. >> So, what do we have on the agenda this week? Open AAI reboots management team. Open AAI buys TBPN.

00:10 >> I thought the acquisition was just insane. Owning a media asset invariably takes way more time than you think for way less money than you expect. See Jeff Bezos for details.

00:20 >> There's no way that deal is going to happen today. Like, it's dead because of management change. Anthropic hits a whopping $30 billion in revenue, surpassing Open AI.

00:29 >> Their training costs are a quarter of Open AI. It really feels like the investors in Open AI got a much worse deal in the last round than the anthropic ones did.

00:36 >> And then SpaceX finally confidentially files for IPO targeting a $2 trillion valuation. >> The big three, SpaceX plus OpenAI plus Enthropic, their value at IPO will

00:47 exceed every other IPO for the last 20 years combined. Ready to go, boys. Welcome back. I've been looking forward to this one. I was doing this schedule over the weekend and last night

01:09 and I was like, "Wow, this this week we really have a lot of meat to get into." So, I want to start with OpenAI and Anthropic. So, Anthropic now have 30 billion in revenue. uh obviously

01:21 surpassing Open AI, it's all intertwined with the subsequent things that we will discuss with Open AI, but as Jason put in an email to us all, holy cow, Jason, holy cow indeed. What did you think?

01:36 >> Even Even in an era where we're getting annured and anesthesized to crazy numbers, this one I did fall out of my chair, right? Uh getting to 30 billion up from 9 billion at the start of the

01:46 year. I mean, uh, I think it took I mean, Salesforce is the largest software company, right? Uh, at least Cloud One, and it it took them 25 years to get there. Anthropic got there in five, but

01:58 maybe they really got there in three, depending on how you count. But you just uh, you know, we we it was it was incredible to see where they were uh, in February. We couldn't believe it. And

02:09 then essentially adding 10 million of net AR. Let's let's not debate whether it's how many RS there are and whether it's recurring at this level of growth. It really doesn't matter.

02:20 It doesn't matter. So, uh and that there's still capacity constrained and that Claude still shows us when we're in there that it can't finish chats and that uh you know every engineer in tech

02:32 has been told to consume more tokens and move faster, right? The crazy thing is what will it be at this rate at the end of next year, right? Um it's uh crazy, right? If it's it grew 3.3x in four

02:43 months, we need Rory's math help to figure out what anthropics run rate will be at the end of 27. >> It the estimates that we were just looking at two months ago just look

02:53 incredibly wrong at this stage. >> Yeah. >> So, yeah. No, these are these are all amazing numbers, right? >> Yeah.

03:00 >> And I think a bunch of other interesting things start to happen here. One is you kind of munching in some stuff. One is their announcement on open claw and not allowing that to be in the base plan. I

03:11 think it kind of gets back to they're in a massively interesting situation now. The revenue is exploding. Despite the revenue explosion, they're still compute constrained. In other words, they could

03:22 sell more if they had more, right? And what do you do when you can sell more if you had more, but you can't make more, right? You can't magically make data centers, though obviously they have that

03:31 big announcement to do that. What you start doing is allocating capacity based on money, right? And one of the first things they figured out is these folks using these open claw type agents are

03:43 consuming vast amounts of tokens on you know fixed on fixed price plans and they probably want to stop that which is what they've done. So you're going to see them do exactly what anyone in economics

03:55 would say do which is try and find a way to maximize and extract even more revenue. And you know, we saw it even with OpenAI last week where you deemphasize things like video which

04:05 consumes huge amounts of compute for small amounts of revenue. In Entropics's case, obviously they have much less of that pure slop, but you deemphasize things like open law access where it

04:17 consumes a lot of your compute and doesn't make you a ton of money. And I think you're just going to see a continued trend to pricing tokens pricing closer to the value, right? not

04:29 a huge trend because you want to get people I mean you don't want to overcompensate because you want to get people addicted on the product because the truth is the thing you have in your

04:37 favor with any digital good is the complete certainty that prices per token go down over time but you do at least want to start allocating it a little more sensibly while you're constrained.

04:47 So that's kind of I think the trend here, >> you know, the the we could talk a little bit about the open claw stuff. Um just on the on the but before we get there on

04:55 the growth and enthropic, the other interesting thing was the Wall Street Journal today had a bunch of leaks on the financials for Anthropic and OpenAI. And the one that jumped out at me when I

05:04 contrast it with the fact that Anthropic has caught OpenAI, right, in half the time is that their training costs are a quarter of OpenAI. Their training costs for models are a quarter of the Open AI.

05:15 Now maybe that's because they're focused. They don't have to do video. They don't have to do images. They don't have to do a lot of consumer stuff. But if you just think about it for a moment,

05:23 the compounding effects of catching Open AI in half the time, right? At at roughly the same revenue or more, 30 billion in 5 years, and having training costs that for now are a quarter of it,

05:34 you know, that's a double code red. It's one thing if if if if if you have two classic startups where one is bled money and it's artificial or there's other things, but if you have a dramatic

05:45 cost benefit and you're out accelerating your competitors, um and there's management team turmoil at your competitor, uh it really feels like the investors in OpenAI got a much worse

05:57 deal in the last round than the anthropic ones did. Just crazy just having both. You usually don't have both together with your competitor. you're out accelerating your competitor and

06:04 your and your training costs are a fraction of your competitor. Good god, it that that just compounds. >> That's actually a good point because you take the Uber lift struggle, right? You

06:14 Uber had the oh my god, we're out accelerating. Oh, but by God, we're spending every dollar we have to to do it and we and we show no fear, right? In this case, you're out accelerating the

06:24 opposition while being more efficient on a bunch of interesting measures. No, you're right, Jason. That's a scary fact pattern. If you're, you know, if you're running the game theory and you're the

06:33 other guy, it's like, hm, that's not good, right? They're growing faster than us. The gross margin economics are roughly the same/ slightly better and their cost below the line and to a

06:45 rounding error costs are compute and scientists to run the compute uh for training are better. And that's that's a bad fact pattern. >> Have we ever seen a bigger seeming chasm

06:54 between where they're at? I mean, with the greatest of respects, it seems like anthropics is accelerating faster than ever, and Open AI is having more challenges than ever all at once. I'll

07:07 tell you the one I think about uh the word I I I didn't realize when we did this show the last because the press is always focused on uh the headline stuff, right? Yeah. The open air was barely

07:16 real. >> Yeah, you said Yeah, you said >> barely real. And Dre's money appears to be real. It came in out front, right? Good. The the 13 the you know, the 134

07:25 billion, whatever they put in, that's real. 11 billion. Um, you know, all they have to do is get 20% carry and double that and it's it's it's a nice side bet in an SPV, but that was real. The soft

07:36 bank money comes in tanches. They have to borrow money to pay it. The Amazon money is trunched in part on IPO or AGI, right? And the Nvidia money is almost all not money. It's almost all offsets

07:49 in compute. So, you know, I thought about it, but then in context of anthropics growth, like, you know, that's I think Open I would have rather have all the cash. Like,

07:59 it's not a sign of strength where the majority of the round is not cash up front. Like, that's not I don't think that's a sign of strength. That's a sign of like classically at least barely

08:09 getting the round done. Barely getting the round done. Um, versus getting because why wouldn't you want all cash up front? Why wouldn't you want 140 billion up front? bit harsh on the

08:17 barely because I thought they tacked on another I can't believe I said the sentence. They tacked on another 10 billion. Think about that sentence sometime that I think was cold hard

08:25 cash. So I think it I I agree your comment is correct, Jason. The vast bulk of the dollars weren't cash, but enough money changed hands that it represented a bonafide price at the time. But yeah,

08:39 you are right. And and again I mean look Antropic does some of the same stuff in the sense of given that your biggest expenses are you know compute and then distribution you

08:49 know from Microsoft on with open AI to all the recent entropic deals there's a lot of this roundtpping business but in both ca I mean I'd say make two comments perhaps in both cases there was enough

09:01 hard dollars changed hands to represent both of them represent price estimates but to your point would based on what you know now given the revenue venue equivalents, rough revenue equivalents.

09:12 Shouldn't assume until Open AI releases their numbers, maybe they've exploded, too. But definitely Anthropic at 370 billion feels a little more comfortable, let's just say, than

09:23 um Open AI at 820 or 840 or whatever the final closing was, right? >> Well, OpenAI did say 2 billion last month. I think that's why Anthropic rushed out the 30,

09:32 >> right? That they're at a $2 billion run >> rate. And look, we have the whole gross net thing, but the bottom line is this. When you look at those two graphs, you definitely don't say to yourself, I

09:41 mean, I think what you if this was a public stock, let me put it this way. If this was a public, if both of these companies were public, there would be a bunch of those Yeah. New York hedge

09:50 funds shorting Open AI, longing on Tropic and saying they have the perfect AI bet, right? At you know, would you would you go would you short Open AAI at 870 and go long on Tropic at 372? I'm

10:04 not a risky guy, but even I would contemplate doing that. It feels like a no-brainer bet. You have roughly the same revenue, a better trajectory in a management team for half the price. Hm.

10:13 And if you short the one and long the other, you're kind of you're diversifying away the AI overall risk, and you're just making a relative performance bet. That's probably Yeah,

10:23 that would be an interesting one. What would you say to an OpenAI employee who is now looking at their incredible stock price appreciation with tens of millions of dollars in equity that they now have

10:36 at the 820 price? Sell it all at 820 the minute a tender comes. What would you say to them? >> I think I I wouldn't pile on. I in general, look in I have some things in

10:47 opening I want to pile on this time. And if you recollect in the last couple of weeks, I've tried to avoid the pile on when someone's down. And I think you'd always want to be more tempered. But I

10:57 always say to everyone in any um private, you know, in any private company, I say when the liquidity window opens, take it seriously because it might open again for a while, right? So

11:08 yeah, when the liquidity window opens at $.8 trillion, the alert reader should say, you know, if you're planning to buy that house in San Francisco, you might need an extra

11:18 few million just based on what I'm seeing in the market now in terms of house prices. So take advantage of this thing cuz all your brethren have right you know I wouldn't yeah as I said I I

11:29 think the people I don't want to pile on the individual employ I mean the company's still doing a lot of great stuff you got a lot of turmoil we got a lot of drama at the top we'll talk about

11:37 that but you know I think you take advantage of liquidity just because you should always take some advantage of liquidity >> let's knock it on the head let's talk

11:45 about the drama at the top I mean talk about a management team turnover you have Brad the COO who's been moved to special projects. Um, >> my dream sign being moved to special

11:56 projects. >> I'm going to be the SVP of special projects for 20 VC in my next phase of life. >> Jason, I would love you to be the SVP of

12:03 special projects. >> Just special projects. Yes, special projects. >> Um, we we have the CMO stepping down due to health reasons. Um, we have the CRO

12:12 out. We have Fiji um who's head of apps taking a short leave of absence um with health problems. Um, how do we read this very significant multitude of changes at the management

12:25 layer? >> If we step back a minute, it it ties to anthropic passing them. You don't you don't just sit there and make no changes on the team when your

12:35 competitor uh over the last 6 months has radically changed the competitive posture. So, look, I don't think any of us like that amount of change in any management team, right? It feels almost

12:45 a wholesale change at some level. But um and it's risky, but you you got to you know the calling code red four three months ago didn't magically change the trajectory here. So it ties you got you

12:58 got you got to try to mix things up in some fashion. Hopefully you can do it with the team you have. But in in the context of of of anthropic now out accelerating OpenAI,

13:08 it just makes sense to to reboot the team. It just makes sense. >> Yeah. There's some rebooting some I mean the act to use your phrase the reboot. I mean who's been hired? Who's the what's

13:17 the re what's the additive reboot? Well, the dramatic one, which is always risky for like any startup, is you take Denise Dresser, who was CEO of Slack, who came from Salesforce just a couple months

13:27 ago, and you put her in charge of basically everything go to market and related, right? That's a good bet on a seasoned executive, but that's the type of change that we've all seen as

13:37 investors is like super risky, right? You bring in the one the person with the perfect LinkedIn, right? And the perfect background that's still getting to know the product. They're still on a get to

13:46 know you tour. they haven't quite been to the uh to the New York office yet. They're getting to know the product and all of a sudden you give them this massive portfolio because they're proven

13:54 executive. In my experience, I I don't know what you guys think. In my experience, that has about a 30% chance of success just just roughly that bringing in the big the perfect LinkedIn

14:03 giving them a massive portfolio and either attaching them to and attaching to something in tumult if it's executing to perfection, it always seems to work bringing in Mr. Mr. LinkedIn miss like

14:16 but but when you're in Tumult there's not a lot of time to learn everything right there's not a lot of time for the get to know you tour so it's just risky but it's it's a but it's a play like it

14:27 it is a play I get where you're going there Rory which is like for the replacements to be additive there needs to be great talent added and there seems to be a lack of people coming on the

14:37 field when they're coming off agreed and you know I'm I'm all as I say I have a couple of comments one is I'm always low to comment on um yeah because the illness related is because you just

14:46 don't know what's going on in people's lives and that's tough and people have challenges and you know you wish people all the best especially in these kind of chronic diseases and hope they can get

14:54 back to full health right let's just start with that cuz that sucks right you know at the same time you know you have a lot going on here right you have a lot going on and you know I I I to me even

15:06 all these people change you know I I'm tempted to make that you know the famous Oscar Wild quote um in the importance of being earnest you to lose one parent might be an accident

15:17 when he was talking to this woman was talking to the orphan, but to lose both parents smacks of carelessness, right? Well, you know, you you you are getting to the stage of carelessness here,

15:27 right? But I actually don't think that's the real issue. It's fun to say. I think two I'll tell you, we haven't mentioned the two most surprising things in the last week on Open AI. One is I'm just

15:37 going to say it. I thought the acquisition of a TPBN was just insane. Not on its on the in in in in the particular it doesn't matter but you don't

15:49 launch an ecode red edict and a focus edict and and you know no more side projects edict and then within the space of a week do something that's so obviously a side project

16:00 to me no matter what you get I mean we can discuss whether it's stupid on its face and whether you know buying media assets is the way to go and I I acknowledge the unreason articulated

16:11 thesis that you know you have to control the media story though doesn't seem to be Antropic has any need to do that. But stepping back one level, you're running a $25 billion company, the most exciting

16:22 company on the planet. If the number and you just told your entire internal team that you need to focus and then buying there's nothing that's more of a vanity project than buying a media company,

16:34 right? I mean, look, you know, >> just one thing we could talk about it more or less. The one thing just to add when you look at the press, this is interesting. that deal the hands the the

16:42 outreach was in January that's a lot of time in open AI and AI time right Viji was new thought this would be a great thing to elevate open AI in January now it now it's April and maybe the deal

16:55 seems a lot different but in January it was a different world right >> at some point I mean I remember yes >> I don't think it h it didn't happen last week is my only point it happened in

17:05 January it took some time to close right and I will say one thing I'm 90% sure it wouldn't happen today. To your point, priority if nothing else, prior like priorities change, right? It probably

17:15 wouldn't happen today. >> You know, if you only noticed in the last week, if you only noticed in the last week that you need to focus, then yes, I'll give you that, right? But you

17:24 didn't just notice in the last week you need to focus, right? And if you did, maybe you need to focus and see fire comment, right? If you haven't realized you're in code red for the last two or

17:34 three months, and if you have realized this is the kind of thing you don't do when you're in code red, then you're just not paying attention. So, I challenge that. I think it's a vanity

17:41 project and absurd. And then the other kind of weird >> Can we actually Can we just pause on on that? >> And I know you want to because you want

17:47 like where's your 200 million, Harry? But yeah, let's pause in your lack of 200. >> No, I know. I I just want to actually articulate a bull and a bear case

17:54 rationally for an audience for how this acquisition could be seed from both sides because it is very confusing. So, if we were to start with a bullcase, Rory, and Jason, please chime in, too,

18:06 because you're you're the master also of kind of media and venture as well. Um, what is the bullcase first? >> I'll give you the the bullcase. There's there's two. The the strategic one's

18:15 more interesting, but let me hit the tactical one because Rory because Rory made a good point. If you there this is, look, this is not going to make or break the company, right? There are certain

18:24 acquisitions that can, right? There's certain actors this like stipulate that but there are some things you acquire where it it they run almost on autopilot. They are not massive

18:36 distractions and if the price is small relative to what you hope to get out of it that does factor into the equation. If you have to rebuild your whole team it's a total distraction. You're going

18:46 to rip out your guts. That's a big deal. when once in a while on one it's pretty rare you can acquire something that isn't massively distracting to some management team level. So even if it's

18:58 not the perfect acquisition I don't think it's a huge it's not going to require a huge amount of senior executive time. So it's just it's just important general to the calculation.

19:06 The one point I'll make and I wrote a post that every every profitable public company should do a deal like this of which OpenAI is neither right it is clearly not profitable. is clearly not

19:16 public. But but other than that, let me tell you why, Rory, and you might end up agreeing with me on this. Um because, and this is why the bar stool deal almost worked but failed, right? If you

19:26 are a profitable B2B company, especially, you are under insane pressure to get more profitable. Like we c I actually can't overstate how how intense the

19:38 pressure is. Like they're looking at every headcount, every sales efficiency, everything. Now it is brutal, right? and your cash is trapped on your balance sheet and so it is very difficult to

19:49 increase marketing spend. It is very difficult to spend another hundred million this year on marketing. But at least in the short term if you can buy a marketing asset that is at scale that is

20:01 at scale you can turn your balance sheet into marketing which is hard to do. It's hard to do and I think maybe TBN is not the most successful way to get OpenAI's brand out there. We could debate that

20:16 but it but it is a way to turn a balance sheet into a marketing asset. >> I'm going to call [ __ ] on start to finish on this whole discussion. This Open AI is the most known company on the

20:30 planet perhaps other than Apple. Right? Within the last two years, the CEO of OpenAI has been able to meet every world leader he wants, right? He's gone on world tours. He's met Macron, he's met

20:42 the president, he's met every single prime minister of India, whatever, right? They get constant attention, constant. The AI story has been, you know, the entire zeitgeist for the last

20:55 3 years and they're the leader of the AI story, right? So, in terms of media minutes, there's nothing left to get. Right now, if what you're saying is, I don't like what they're saying about me.

21:06 Oh, they were mean to me, then yeah, maybe you can pay these guys to say nicer things about you than on average. But you don't need more. It's not like you're making [ __ ] widgets in the

21:15 Heartland here, right? You are the most exciting tech story on the planet. You don't need a little bit of help and to just get out and and get covered. I mean, literally everything Sam does gets

21:27 covered, right? So I hear you Jason most of the time but not for these guys. If you were to pick the one company who doesn't need media attention and does need to focus it would be open AI and

21:38 this is nonfocused and getting media attention. So I'm like just from a signaling perspective we're 100% aligned. The only thing I would come back to you with saying is they have

21:48 consistently shown an inability with how to respond on social to negative moments. Whether it's lemonade stand, whether it's anthropic adverts, they've consistently messed up crisis PR and

22:02 crisis communications and made themselves not look great. The only way I could justify this is by saying they are vibe maintenance for those [ __ ] times to make us better, cooler, better

22:15 responders to bad things because they have no editorial control. Like this is the most important thing. Andrees are right the importance of owning media but they have no ability to own the content

22:25 to influence it to impact it in any way. It is editorially completely impartial. So they have zero benefits. This is the only reason this does not make any sense. If they had the ability to own

22:39 the media properly, it would make sense, but they have zero impact on it. >> History is riddled with people who, you know, buy media assets to try and change outcomes. And you know it it it

22:52 generally results it generally my observation is owning a media asset invariably takes way more time than you think for way less money than you expect right see Jeff Bezos for details right

23:03 and you know you end up getting abuse you yeah it just is a sinkhole right and Harry if you can't control the story then hire a better storyteller you know hire a better comms person hire a better

23:14 marketing person think before you speak and before you hit on your [ __ ] about lemonade stands But and look in ter it's in the noise it and Jason you are right they're not going to spend a lot of time

23:24 managing in this case at least in the short term. My comment is more it's just really silly when you say we've really got to focus nothing else matters but these two or three big

23:36 things. Oh but by the way here's here's here's one last play thing project. The one thing I will at a meta level just to founders especially have listened to this honestly this is why you should

23:46 default yes to a good deal. Let me let me be clear. I'm pretty sure this is this deal. I just read the press. This things things at open. There was stress in January, but it's not like today.

23:56 Okay. It was not like today. Um Fidgety comes in. She has an idea. This is not the biggest bet the company's going to make, but they have a team meeting. She's like, I love TBN. What if we

24:05 brought them in for for a little bit of good promotion? And everyone around the corner is like, whatever. Yeah, we let's go talk about buying some open claws or something. But but but they say fine and

24:15 things are good and they kind of shake hands on a deal. It takes a little while to happen and it closes last week. There's no way that deal is going to happen today. Like it's dead because of

24:24 management change. And I can't I can't tell you how many times I've seen this for portfolio companies and even it's happened to me twice where time it's not just time is the enemy of deals. It's

24:34 management turnover, right? Priority turnover. So the metal lesson is I just don't think this deal would have happened today. It has nothing to do with with with the team at TBN. Just so

24:43 so when you say no to a to an attractive deal, just be sure you're okay if it's no never because the odds that VP that wants to do the deal is there in 12 months and that their priorities have

24:53 not changed approaches single digits. >> Yeah, it's back to the liquidity window comment. You're exactly right, Jess. >> Yeah, but my god, I think it's worse for M&A because so many times in M&A that

25:04 guy just isn't there next year. But I'll tell you, one of the things about being the big boss is that even when you're a long way down, if you don't think it suits what you're doing now, you should

25:14 stop it. I remember fun story to 25 years ago, we were selling a company to GE. I'm not going to name the company, right? And it was a mediocre company and we were darn lucky to get the bid,

25:24 right? And it was going all the way through and it went every level at GE, right? And then it came to the CEO and you know, he's not perfect Jack Welch, but he's willing to take a tough

25:34 decision. We were a long way down. Everyone was about to sign and be all happy happy. He looked at the numbers and said, "No." And I remember thinking, "Damn, I thought we get away with it,

25:42 but he's right. I should have, you know, right?" And at some point, I remember thinking, "Oh, that's impressive. All these people were in. He was a long way down with the process." And he just

25:51 said, "I'm thinking no." Right? And if you could, this is one where you say, "I'm thinking no." >> I'm going to give you a hard one before we move to SpaceX. You have the chance

26:01 to buy Anthropic at 850 or Open AAI at 380. Which would you rather buy? >> You may have that opportunity in the secondary market as we speak. I'm

26:13 >> I wouldn't be surprised. I think I'd mean having said I'd do Antropic last time at I mean six months ago at the 300 something thing I think I'd go the other way this time because

26:24 again if you if the choices were entropic at at the last OpenAI price of 850 post or whatever it is 820 something post or OpenAI at the last entropic price of 370

26:36 post or 380 post I would argue that you would buy open AAI on one proviso you could sit down with the board and say what are you going to do about this because it doesn't take a lot to fix

26:46 this thing, right? To just stop screwing around and focus, right? And you know, >> no, no, no, no. Because you've got to stop then a machine that is anthropic that is now picking up more and more

26:58 pace with every day that goes by and being first of all, you still have the consumer asset where you are by far the dominant thing. Again, this goes back to what we said last week. You have to do

27:06 two things. You have to figure out a consumer monetization model and you just have to get a Codeex, the Codeex competitor to Claude out there. It's pretty mission clarity is pretty simple.

27:16 You do have one big advantage we didn't talk about though it's changing a little bit and give Sam he was more aggressive on compute purchases and I'll admit I was someone thinking from the peanut

27:26 gallery hm is that a bit aggressive but now it looks like compute constraint is a real thing in 26 and early 27. You have that asset maybe you figure out how to deploy that aggressively with codecs.

27:38 So there there's buttons you can press there's things you can do if you focus and do them. Jason, you've got that same choice. >> I'd say buy both at if you can invert if

27:48 you can invert the valuations. >> Yeah, that's actually >> that's what all the the growth VCs are doing if they can get away with it anyway. So, let's invert.

27:54 >> That's amazing. But you can only buy one. >> Um, yeah, but conflicts aren't important in our firm anymore. We they don't matter at at pre and they don't matter

28:03 at growth. >> Jason, you only have one check left. >> Well, look, I mean, I've said the same thing on the show. I'm just not into the the the tumult at OpenAI. I'm not

28:13 into the drama. I'm not into a non- tech non-deical founder leadership. It's just not my vibe. Like I wouldn't invest in anything like OpenAI at a high price. It doesn't

28:24 matter what it is cuz it's just I just I just find it so risky that that the turnover and not being led by a deeply technical CEO that's just I in my life at investing I I ain't doing those risks

28:37 anymore, right? and and maybe I'll miss a lot of opportunities. It's just, you know, I want someone Dario or smarter technically running these companies or I just it's just too it's too much change.

28:47 You get you get too lost on the on the on the on the on the pen and and the TBPN's although I don't think Sam had anything to do with TBNN in all fairness. I think

28:55 he said fine in a meeting and moved on. No, because and related to that just for folks I don't know how M&A works at OpenAI. It's not that sophisticated. Okay. But I will tell you when I was at

29:06 Adobe a long time ago for M&A, basically every every senior executive got a big chip and a small chip. Okay, the big chip was a big deal. Back then it was maybe a billion dollar deal. Okay, that

29:17 would move the needle. If it doesn't work, you get fired. It's that simple, right? And everyone got a small chip could could be like 50 to 200 million deal. And you had to justify it and you

29:28 didn't get five. as a forcing function. You got one, but you really weren't challenged that much to to do the smaller chip. You picked one a year and you didn't get fired if it didn't work

29:37 out. There was there was a there was an idea that maybe 20% of them would work out. And so I bet he spent five this was a small chip deal and he spent 5 minutes on it. This is the one. Is this the one

29:46 that you really want to do this year, Fiji? Then just do it. Let's move on. We got bigger fish to fry. That's why I don't think it's that big of a deal. It was a small chip deal, right? And no one

29:54 loses their job at Adobe over the small chip deal. Otherwise, it would never happen. No one would take any risk in buying an emerging company, right? They just wouldn't do it.

30:03 >> Okay, we've got to move on. Other things did happen. SpaceX finally finally confidentially files for IPO targeting a $2 trillion valuation. Um, it would be the largest IPO in history, surpassing

30:18 Saudi Aramco. They could raise up to $75 billion. This obviously includes XAI otherwise known as Twitter um which obviously incorporated earlier this year. 2025 revenue 15 to 16 billion 8

30:32 billion of EBIT uh at 2 trillion it's 125x revenue so coming in punchy um to say the least feels like a series A these days Rory uh how do we feel when we hear this? Well, I'll just tell you

30:49 one one one insight. I I think to say that at least venture is different or remade is an understatement. Like the big three, SpaceX plus OpenAI plus Enthropic, assuming they all IPO, I mean

31:02 certainly SpaceX will in the next 12 months. Uh their value at IPO will exceed every other IPO for the last 20 years combined. All of them. All of the last 25 years. These the big three,

31:14 every other little every other little deal. I mean, Rory's had some great IPOs. There's been tons of them out there. Um, but this exceeds all of them combined, right? So, so it almost makes

31:26 I I I found it almost depressing in a way when I thought about this way because it was like, what's the guy we had earlier in the show from Slow Ventures who kind of bothered me a

31:34 little bit, >> Tom Les. >> Yeah. And he kept saying box doesn't matter. And then he said, "Open AI doesn't even matter. It's not that

31:40 important." He was very triggering. I tried not to get triggered directly, but he kind of rattled in my head. I was like, "Maybe the guy's right. Maybe nothing we're doing matters because the

31:49 big three dwarf the last 25 years combined. Like what are we doing guys? What are we what are we doing here? First of all, I I think that is a real phenomen and what you're simply saying

31:59 is, you know, especially in SpaceX's case, the longer the holding period, the more dispersion which sets in, which is more the bigger be the big become bigger and the little ones fade out. And you

32:12 know, and you're exactly right at the tail end of a power law, it does mess with your head because the combined value of the top three privately held companies are larger than everything

32:21 else. In much as the same way, it's even more concentrated than the public markets which are more concentrated than they've ever been where the market cap of, you know, the top four or five,

32:32 Nvidia, Apple, Microsoft, um, Alphabet and what and I think Meta is, you know, approximately 30% of the total S&P, right? Which is everything for the last, you know, xund years, right? And you're

32:44 right. The psychologically the thing about a power law they don't tell you is you can have the third best outcome in venture history and be only onetenth as large as the largest outcome

32:58 in venture history. And if you're going to let that in your head, it's going to be it's just going to be very tough business psychologically for you because you can have a life-changing event

33:06 that's you down in the noise of 10 or 20 billion dollar outcomes, which can be enormously great for you and your family and for your co- investors and for everyone involved. And if you're going

33:17 to let it in your head that it's not $2 trillion, then you're doomed and you're just going to need therapy. I wrestle with these things all the time. I mean, it is the thing that your mama told you,

33:25 right? is right. You just have to not let other people define you. I mean, you said it really. It is a psychologically weird thing, right? You're going to have these three deals go public and um

33:37 they're going to be worth literally everything else that's happened in the last 20 years if they trade anything like their current prices. Will SpaceX rip and hit the two trillion when it

33:45 does go out? >> I try and not spend time talking down, you know, an amazing company, right? Not least because I'm going to be a buyer of SpaceX 15 days from the IP. I surprised

33:59 you because 15 days from the IPO, it's coming in QQQ. I have a big QQQ holding, right? If you're an index fund, you're getting this thing in 15 days, right? And if I don't know when it'll be for

34:11 the S&P, but it'll be fairly s soon thereafter, right? So, we're all going to be buyers of this thing, right? So, in terms of the valuation, I I you know, you don't know. Look, you do any kind of

34:23 meaningful analysis some of the parts and you come up with a lot lower number and then as we we've discussed this before and then the gap between what you think the assets are worth on any kind

34:32 of normal basis and $2 trillion is huge and it's all Elon premium and what you're really asking therefore is how big is the elon premium sometime in June and I don't know I think that you're

34:44 definitely seeing the Elon premium come off on Tesla which has been worth pointing out and you know it's it it's it's it's down significantly year to days and there's definite and you know I

34:55 was interesting to see JP Morgan put an actual sell on Tesla with a prediction of a 60% price decline. So really what you're asking me Harry is what is the Elon premium in June and I

35:07 hell I don't know. >> Well I'm asking actually do you think it will materialize in public markets and they hit that two trillion. Well, Rory, here's what your your thought.

35:15 Obviously, I don't think either of us have worked on an IPO quite of this scale, right? But >> no, by definition, no one has in the [ __ ] universe because the first time

35:22 it's ever happened, >> right? So, the process is going to be different. But here's my point. At some level, if the company ha there is a there is a a tough negotiation sometimes

35:35 between the company and the underwriters on valuation, right? Um, and often times some cos are like whatever the whatever the lord brings and some are extremely aggressive on the number they want,

35:44 right? And depending on the situation, sometimes the co wins those debates, gets out with the valuation, the underwriters are very uncomfortable with and sometimes it works and sometimes

35:53 they stumble because of it. I think Elon, what Elon said publicly on X, it ain't going to be two trillion. Now maybe he'll change his mind. He said two trillion was too high. So whatever his

36:01 number is, I think he's going to get it on IPO day. He's going to will it into existence. the underwriters are not going to be able to argue with him for more than 5 minutes and there'll be

36:09 enough demand between retail 30% of the IPO. It's a lot, right? There'll be enough whipped up demand, I think, to support it for one day. He will will it into existence. Whether that evaluation

36:21 is there in 30 days uh or possibly even in one day um I don't know but I do think the sheer force of will the lack of power of underwriters and the 30% retail will will his 1.75 into existence

36:34 for one day at least one day >> I think that's quite correct it's worth pointing out I think less than 12 months ago there was a meaningful transaction in SpaceX at 400 billion right then

36:44 there was this much smaller I don't have even happened in the end secondary at 800 billion Then in conjunction with the merger with um come on X yeah X// Twitter it SpaceX

36:59 was valued at a billion to value the other asset with its negative 12 billion in cash flow at 250 billion. So they added that in to get to 1.25 and now you know you're at um you're talking about

37:12 1718 and it's all been walked up in a very interesting way. It is worth remembering that the last time the useful asset was valued on a standalone basis, it was worth $400 billion. So I

37:22 think if the deal went public at 1.5 1.6 less than the whisper number, I still think they'd have done a magnificent job of walking the value of the asset up because it's not clear to me that the X

37:36 AI asset has a positive NPV in anything like the near-term. We just had a long conversation on entropic versus open AI and they're kind of number one and two in this space and Gemini Google is

37:50 almost certainly number three. So X.AI is number four in the kind of model LLM space at best burning $12 billion a year. So I don't know what that's worth but I but I I would argue that they

38:05 won't be talking about that in page one two or three of the slide deck at the IPO. they'll be talking about SpaceX which means the entire addition of that probably was net negative. So I go back

38:14 to my comment is I think you're right Jason they'll will something amazing into existence for a short period of time because you know this has all the leverage and the drive and I think you

38:26 know only in the long term are markets weighing machines in the short term they're voting machines and we'll see over time how it settles as you know people just look at the dynamics of a

38:36 you know 20 billion plus or minus business cash flow positive apparently well EBDA positive capex not excluding X.AI and then add an X.AI and it'll settle into a long-term value over

38:48 time. What happens on the day? I think you're right. It'll be much more a function of the will and it's a small float. So, and people will push. >> I'm switching it up here. We're going to

38:57 go to PI we're going to go to private market. >> And we we we had big news from Seoia this week for context. Always like to contact set. Doug Leone had taken a step

39:07 back from the firm, back from dayto-day, back from investing and um you know Pat and Alfred had recently taken over the leadership from Rolof and now Doug is back in an investing capacity, not in a

39:20 leadership capacity. That's still very much with Pat and with Alfred, but Doug's back in the firm investing. Um which is very big news given he is one of the OGs. How do we read Doug back and

39:33 back in the trenches? Well, look, I don't know. Rory may have more thoughts. I I don't know, but um from from from a distance, it feels like something to calm the LPS. I mean, everyone is

39:45 raising so much capital, so much change there. Um that uh you know, I I think I mean, you guys have even more experience than I do. LPS are uncomfortable with change. LPS say that they're looking at

39:59 the new generation and the vanguard, but they are comfortable when the old leadership is still actively involved in the fund. It does make LPS more comfortable. Um whe whether they're

40:09 writing investing half the fund or a few deals. So it struck me as that simple is you you you bring back someone that makes the LPS comfortable and you get through this crazy amount of fundraising

40:20 everybody's doing. But I could be wrong. I could be wrong. But I don't think it's just to get somebody on your slack and get a little wisdom. you you don't need to bring them back to just to to get an

40:29 hour or two of of of insights on on deals that you already have. >> I think it was a sensible move. I don't think it's an earthshaking move. I mean, they've made the changes they've made

40:37 already as a firm and it all made sense. I think at the margin, you're right, it helps a bunch of different things. It just provides some continuity. Absolutely. Which is important, I think,

40:47 for LPs, for the firm, even for entrepreneurs. Also, let's not lose sight of the fact he's a damn good investor, right? I mean, one of the ch questions we always ask when we're

40:57 hiring someone and thinking about it, in this case, you are effectively hiring someone, is do you think the next check that they'll write will be better than a check that one of us will write? And I

41:05 think Doug Leone's proven that he can write pretty good checks. So, I think even at the margin from a check writing perspective kind of makes sense. The transition having made one transition to

41:16 Rolof and having had to make another transition abruptly means the first transition wasn't that successful. I'm sure there's an element of scratching the itch. Yeah. want to come back and

41:24 make it work. You know, they've put a lot of his life into this firm. They've done an amazing job and it just felt a little janky late last year when that transition happened. So, if a couple

41:32 more years can help manage that transition and send a continuity message, why not do it? >> With the greatest respect, I spend a lot of time with LPS a lot. Um, the

41:43 insatiable appetite from LPS for Sequoia has never been more prominent still. Um, and so I I don't respectfully I don't think it's LPS. I think it's actually just like in the face of increasing

41:54 competition from a founders fund who've got an Andreel and a SpaceX at their tailwind wins for founder brand and and which are more attractive than ever for founders. You ask the question, how can

42:05 we be more competitive? And Doug is the ultimate winner of deals. He is the >> You telling me the kids at YC have heard of Doug Leone or even know how to spell his last name? I doubt it. I'm telling

42:15 you, when Doug Leone goes to that meeting with them, whether it's Christian Hacker at Trade Republic in Germany or whether it's the team at Whiz, he [ __ ] closes the deal. Yeah,

42:26 cuz maybe not the YC founder who's 24, but you're right. Across, look, let's be get real here. Across the venture and tech ecosystem, this is someone who's had wild success and even in a meeting

42:39 can bring knowledge to bear that would move the needle on a close. I I agree. I mean it's look as I say don't make >> well let's call it gravitas whether it's the founders or the LPs it is adding

42:49 gravitas back into sequoia in a time of a lot of change right and >> that's that's exactly >> it says they needed more gravitas that's just what we need a little more gravitas

42:58 guys who can we bring in >> yeah one of the things I admire about sequoia to be I've always said this is like literally even if they're winning on every round but one they'd be like

43:06 well how do we win on that round as well right and you as you say Harry it's never been more competitive of there are wildly talented similarsized firms. Why not, you know, even even if you have 10

43:17 great players, why not get an 11? >> Jason, you mentioned the youngest founders from YC. Some very young founders from YC obviously founded Delve, a top two

43:27 compliance business. Um, sorry Rory, don't look pissed at me, but it is. >> Okay, good. Um, very young, 21 year olds. Um, and as everyone knows, uh, Delve has been in

43:41 the news for not providing a product in the Sock 2 compliance space that they said they were. A lot of problems around that. Uh, YC have since kicked them out of the YC community, which was announced

43:53 this week or leaked this week from Bookface, YC's internal product, which obviously wasn't meant to be leaked. Um, is this the ultimate sign of their guilt? Um, inside invested 32 million

44:05 bucks into the company uh, you know, within the last year. Um, should there have been more diligence from an investor perspective? How did we think about this?

44:13 >> My guess is you know they they listen obviously a lot of things went wrong, right? One one one was making up a lot of audits with AI. We're going to find more more portfolio companies did that.

44:24 Uh, the second one was stealing from a fellow company, stealing IP, forking a fellow company. And I think, listen, I don't know how you manage it with YC with thousands of companies, but there's

44:34 a limit where you cross the the the the the bro code or the girl code or the founder code with other folks at weon portfolio companies. And you there's a line you just can't cross. And whether

44:46 they see it as open code theft or what happened, whether you're manipulating, you you can't allow that within the core portfolio. And I think they were ejected for the combination. And it wasn't just

44:56 some young kids misusing AI. I think it was the second. I think it was breaking the code and that's why they were just there was no need to comment more. You broke the code, you're out. You're out

45:05 of you're out of the team. I I totally agree, Jason. I mean, look, these things are going to happen. I mean, I was just running the math in my head. You know, why see 200 companies a quarter. So

45:16 that's 8 900 a year, right? Step back. United States, we have 300 million people here. We have approximately 3 million people incarcerated at any one point in time. So we run rough 1% you

45:28 know between felons and misdemeanors right across the whole population. So if you just index to that that means out of the 800 YC founders a year statistically if they're just no better or no worse

45:40 than the rest of the country there's eight eight of them that are you know will in the course of their life commit some kind of crime. It's going to happen. You're going to have fraud. And

45:49 you know at the end of it, you know, when you have a portfolio of 30 companies or 40 companies as we do, then most VCs avoid it and every once in a while one VC gets unlucky. If you have

45:59 200 companies a year, it's going to happen to you a lot, right? So first of all, no drama there. No, I mean, I saw all this, oh YC is bad cuz this guy is a fraud. But dude, when you have this

46:09 number of companies statistically, it's just going to happen. So that's the first comment. And then the second comment, Jason, I love what you said. You're exactly right. What do you do if

46:16 you're running YC? can't stop this [ __ ] up front, right? And especially when a lot of your value ad to entrepreneurs is um you know the community, right? That is what you're selling and you get you

46:31 do business with each other. Anyone who did business with these guys was at the very least discombobulated and embarrassed because you rely on this for sock 2 compliance and then it wasn't

46:40 true and then on top of that you stole from another YC bro. You're exactly right. It's like in the Old West when there wasn't, you know, much law. Um, you know, you have to take the law on

46:50 your own hands and hang the cattle thieves, right? This is the same thing, right? Dude, you broke the code of the West, you're out. And I think from a enforcement perspective,

47:01 you know, I can totally see why they did it. You know, now you can talk about should other people have known? Should you really buy compliance software from 21s? That's an interesting comment. But

47:11 fundamentally, I I I think you're exactly right, Jason. You're going to have this thing and the only way you can deal with is not a priori policing but especially when you break the bro and

47:22 whatever the non sex loaded term of bro is. When you break the that code, you just got to be pretty ruthless about it. So yeah, >> I really think it was the part two that

47:32 did it. you know, there was a >> stealing, you know, taking a customer Sim Studio that is also a YC company, maybe even a batchmate. Taking their open source software, not attributing it

47:44 back and claiming it's your own software to like your own batchmate or your own customer. That's, you know, we we've all thrown a few things into Claude and pretended we did the work. Like all

47:52 three of us have done that, but this one breaks the code. You you you took the open source code from your batch mate and said it was your own software. I mean, and they were your customer.

48:01 That's you can't you can't you can't handwave that one away. >> Move on. Exactly. >> You can't handwave. >> Moving on. Open router, very well-known

48:09 company for those that don't know, a marketplace for LLM, so to speak. Uh at 1.3 billion price at 50 million of AR, up from 10 million in October. Um so obviously 10 to 50 in whatever that's

48:22 been 6 to 7 months feels quite cheap for an AI leader. Jason, I'm intrigued to hear your thoughts specifically on this one. Uh, I I love Open Router. I mean, I use

48:33 it. Um, and it's just very interesting. You know, it's a very simple way to to dynamically pick which LLM to use, right? And going to our conversation from last week, sometimes it doesn't

48:42 matter if you're not price sensitive for certain workloads. Sometimes, not only does it matter, but it's incredibly helpful to not have to do all this work yourself. Oh my god, which model should

48:51 I pick? How should I do it? an open router let you do it dynamically or you can pick different LLMs for different use cases and it just makes it elegant and uh what I love and it's also really

49:02 cheap right it it it's quite cheap um I suspect the cheapness is why it's not worth 10 billion right when you have such a low take rate from such high GMV do you do naturally get a little nervous

49:16 about the address the true TAM even though we've given up on TAM that would be my guess But um you know they they they've become the market leader in this space. It's cheap and it works and adds

49:27 a lot of value. You you got to love it, right? Um it's just when the flip side is you know you one of the reasons anthropic I mean god 20 billion right is a really good anthropic call at the API

49:39 level is a buck. It's a buck. Okay here's my simplification. You can do so much on your $20 a month cloud subscription or $200 but I can tell you on all the apps I've built the complex

49:49 stuff it's a dollar. So that scales massively if you're taking uh 1 to 5% of a subset of that um you could you you know there is in theory a ceiling if you don't expand it. What I like is if you

50:03 get market leadership in this kind of thing and you're not that expensive there's no reason to switch. It's not worth switching for a for a tiny amount more basis points. It ain't worth it.

50:12 Right. And just for listeners context, what the company does is acts as if you're building an application, this product open router acts as an interface between you, the builder of whatever

50:24 software product you're building, and 50 to 60 different LLMs such that it can dynamically pick in real time which LLM is the right one for whichever call you're making. And it charges around 5%

50:36 5.5% of the money you pay the ultimate model provider. So, if you're building this app and you're spending, you know, $100,000 a year on LLM calls using these guys, you pay 5% to them,

50:51 but in return, instead of having to access each separate LLM se each LLM separately, you get access to them all in one kind of API call. And so, it kind of just totally makes sense to me. It's

51:03 kind of in that Stripe Twilio business model of an interface. Twilio was an interface between um an app builder and all the complexities of telco. And these guys are an interface between an app

51:17 builder and all the complexities of LLMs. And you know Twillio's gross margins cuz they accounted for growth were 20 30 40% plus. They were pretty darn good. Whereas in this case they're

51:25 only booking the net revenue at 5%. So maybe there is actually room for margin expansion there over time you know. So I so it's an interesting business kind of the world needs it. The other thing

51:36 that's interesting about it which gets to the wider question is a number of folks have backed into figuring out what are the most common models and you see a lot of the Chinese open source models

51:45 now right which gets to so I always think I'd love to spend time thinking about and I just haven't is they must have open must have a pretty good sense of what things do you need

51:55 state-of-the-art models and what things can you do easily on you know much cheaper um open source models right >> well they can even turn it on for you that's one of the reasons I think open

52:05 router So clever. If you want, they will just decide which router which which model to use for workflow. >> And my point is >> you don't even have to figure it out.

52:11 >> Yeah. At some point the people spending $30 billion a year on entropic um corporate IT is going to wake up and say do I have to spend all this money on entropic or can I pass some of these

52:24 calls to a cheaper model and something like you know just given the size of spend that openai and entropic are getting there is at least the opportunity for corporate purchasing to

52:34 think about is any of this doable on a cheaper model >> I'm a super fan right super fan of open like great software super easy to deploy everything. It's like 11 Labs just like

52:44 super easy to use, super easy to deploy. I give it a 10 out of 10. What I've learned from another investment we can chat about is okay, so they're at 50 million AR, they said. Um, and the

52:54 nominal take rate's 5%. But I but some folks probably pay less, right? And in some cases, you don't have to pay anything. So they might be needing to manage 2 billion in inference just to

53:05 get to 50 million in revenue. So how do you build easy to see how you get to a couple hundred million in revenue right in today's world what I worry about companies like open router is how do you

53:16 get to a billion in revenue right and do you just wave your hands and say these are great founders they're at the heart of AI or do you say oh my god like even if anthropic keeps growing and some

53:26 folks won't use it because they'll get big enough they'll do their own things how the hell does this get 20x bigger when it's already managing two billion of inference

53:33 >> I I'm going to give you the argument which I'm not sure I believe but look if you believe in a world where look you just look at the open AI and entropic projections which cumulatively add up to

53:43 north of in 2029 on the code estimates $4500 billion plus let's call it $500 billion in API across both companies right as you take out chat GPT consumer business maybe 3400 billion of

53:56 enterprise API calls across um open AI and entropic I don't know if 10 or 20% of that went open source That's 40 to 80 billion and 40 billion to 5% is pleasing eat 2 billion, right? So if you

54:13 could and now that's 100% of the market. So you're right. >> 100% of the market. >> That's fair. That's fair. You got to get 100%. I mean maybe there's maybe there's

54:21 40 to 80 billion of kind of value going to open-source LLMs and maybe you can get 5% of that. Now the other question to your point Jason is right now amazingly all these open- source models

54:34 are primarily Chinese open source models and you know until some until either LMA until if if Meta reintroduces an up-to-ate open source model or someone like reflection ships one there'll be a

54:46 US equivalent but right now the low ironically the Chinese Communist Party is effectively subsidizing you know the American small independent software vendor by providing cheap open source

54:58 models. God bless them. Right? And because if you look at the the the kind of winner list on open router, it's all Quen Kimmy and all the other open source products.

55:07 >> What I think about open router just for investing right the news is I do really think about you know small takes of large TAMs is intellectually confusing. So Harry and I are both investors in a

55:20 company called Revenue Cat. I was the first investor and they have about 50% market share in managing mobile subscriptions. If you have a mobile app that is paid, 50% chance they have

55:29 revenue cap deployed. Okay, it is it is it's competitive and their net take rate is like half a percent up to 1%. Right? Even with all of that, they're only so much bigger than Open Router. Now, they

55:41 grew 40% last month because of AI. Like it's great, but like and I love the company. I love it. They have a clear path to a billion in revenue now. But my learning from that is sometimes it's

55:52 hard to do the math intuitively. If your if your product is very cheap in a in a in aish market, but you don't get all of it, you open router could be one of the greatest 200 millionaire AR companies,

56:04 right? It's just a risk that I think about more than I used to. Um that that's fair, but I will give you the counterpoint, which is the two best financial businesses on the planet are

56:14 Visa and Mastercard. I sit literally 30 yards away from the Visa headquarters. They don't even get 2 and 12% because most of that goes to the banks. They get, you know, 15 20 bips, but on every

56:26 dollar every human spends on the planet, it turns out to be a remarkable >> No, I'm with you. I'm just I guess my personal intellectual limitation is that the notional BIPS map doesn't always

56:35 translate to the real world BIPS map, right? That's the thing that the Revolute and Visas sound great, but niche sometimes products that seem mass scale are more niche in practice. And if

56:46 your product, if your product is $200,000 a year or $100,000 a year, who cares, right? You'll figure it out later. If your product is dirt cheap, you really really got to like own

56:56 everything. Own everything when it's dirt cheap. And I think we're we're we're all making a lot of AI mistakes here. And we're be our investments are being flattered by high ACVs right now.

57:07 like the ones that have high ACVs all seem to be doing great because they're 50 to 100k per check doing getting to where 11 Labs got from the early days is much harder than a lot of a a lot of

57:18 Loras and Harveys are just because the large ACV flatters flatters the the the inputs and the outputs to achieve that scale. >> Agreed. Not sure I could trace it back

57:27 to open router but I agree with what >> well I'm just nervous I'm personally as an investor and this may be one of my many flaws. It's a long list. I'm nervous about exciting AI investors that

57:37 have very low ACVs right now. I think their actual TAMs may end up being smaller than they look despite the epic numbers when we started this conversation. Despite, you know,

57:47 Anthropa getting to 30 billion in 5 years, the little tiny crumbs we get out of this 30 billion may not be may not make a whole loaf of bread sometimes. Like a bad analogy, but some truth to

57:58 that. That's just so rather than shoot from the hip when it's a 7 million post back in the old days, if I've got to shoot from the hip at a 100 million post in the preede, maybe I got to really

58:08 believe that that small that small ACV will scale up. >> Do you think Open Route will be a 10 billion dollar company? >> It's always a weird question because if

58:16 I knew for certain I'd go do the deal and not sit here talk to you, right? You know, because that's what they're paying me to do. I think we're in a world right now where everyone is just doing the

58:24 buildout as quickly as possible. And what that means is everyone on that journey can attract some capital right and get some revenue because if you're solving a problem that's in the rate

58:37 that's a rate limiting step in terms of getting the AI buildout done you can get revenue you can grow quickly and I think open route is an example of that right and you know you can put on your

58:46 intellectual MBA hat and say in the end when things settle out maybe a lot of these businesses get commoditized and you can you can worry about that and a certain amount of that worry is legit

58:56 legitimate and there's a whole bunch of markets like I'll give them all there's kind of the labeling marketplace there's the inference marketplace there's products like this open router where you

59:05 say oh when things settle down and people starting getting more efficient then all these businesses will get scrunched a little bit and that's true intellectually but my advice and I say

59:14 it internally is please don't overthink it because while that is true at the same time in the short term this explosive lift in demand gives you a chance to be relevant and It's your job

59:26 to add products on top of that such that when the great crunch does come and it will come in a couple of years, you've just delivered enough value. You I mean like in other words, so do I think open

59:37 router will get to 10 billion in value on just what they do today? No. And and if they just keep doing what they're doing today, no more than the inference guys, no more than the labeling guys,

59:46 when things slow down, all these businesses will get crunched, right? When people start to optimize, but you're you have a chance to parlay. You have you're building you're building

59:55 relationships with a whole bunch of apps developers in Open Router's case, right? The your job is to find the add-on products on top of this that over the next two or three years, you know, give

01:00:06 you value or do the adjacent acquisitions that give you value. Maybe you start doing inference, maybe you start hosting stuff on top that allows you to extract more value from those

01:00:15 customers such that when the thing slows down, you're the survivor. I mean, we saw >> Yeah, I think that's the challenge with these investments. I mean, the one that

01:00:22 if I'm running it, it's a dream. 50 people, right, at 50 million in revenue at the center of this. Like it's I I if I was a founder, I'd be there's a dream job, right? Um but I think my learning

01:00:31 is Rory's point. You the reality is you have to go truly multi-product earlier in this type of situation. Not not just a little feature, right? Not just a little enhancement. Um but you literally

01:00:41 probably have to build five distinct products to get to that billion. And not um you know, not all founders are actually up for that. They say they are but not but you need a very distinctive

01:00:52 founder to run the AI rippling playbook and say hey I want to break something up in some ways that's crushing it with 50 people if they have it. I mean again my dream job and say we're going to do five

01:01:02 of these and we're not going to wait 2 years. We're not going to we're not going to like just focus focus focus focus and um I think if they're up for it I would hold my stock. Harry you

01:01:11 probably have no choice. If you see this sort of Stuart Butterfieldesque reluctance to go multi-product, which was very rational at at that time and place, then uh I would be less excited

01:01:22 to hold stock. I think you've got to run these businesses right now like you're in this insane kind of period of time when money is just raining down on everyone and all

01:01:35 the time you should be saying to yourself at some point the music will stop and twothirds of the people will be will will have to go how do I make sure I'm the one-third that make it right and

01:01:46 that's what you know the smart inference providers are doing that's what the smart up and down the stack should be doing how do I lock in because look the truth even when the crunch comes, the

01:01:54 foundational model companies make it because they they're on top of the heap. They have the high intellectual property asset, right? They're going to make it. Everyone else one level down has got to

01:02:02 be saying to themselves when people sober up, they're going to say, "Oh my god, this is a commodity. There's a bunch of adjacencies. How do I make sure I win in that world?" Speaking of, "Will

01:02:12 this become a commodity in a future world?" We've seen you the need and the explosion of databases. Um, we've seen some people like your lovables and your raplets incorporate them, build it

01:02:22 themselves. Some people um outsource to Superbase. Superbase at $10 billion. Jason, you're the man for this. The man who's used more replet instances than anyone else. Is Superbase at $10 billion

01:02:37 a good buy? How do >> I think it might I think I like it. I mean, I do think it's it's an interesting buy. Um, first of all, you

01:02:45 know, huge credit to the team. I mean this is one this is one I call an AI an AI tailwind to the maximum. Superbase founded I think in 2020 right this is pre AAI and they're like oh well we'll

01:02:57 do another fork of Postgress which is open source and free and we'll make it e easier to use and easier to deploy. I mean, who the hell I mean, I know it was it was a hot YC company, which kind of

01:03:08 uh you know, a lot of folks want to say it's the unhot ones that take off, but you know, sometimes it is the hot ones, but I don't know that that I I don't know that certainly wouldn't have been

01:03:15 obvious to me in 2020 that we needed another a forked version of an open source database process. I mean, everyone was having issues with Postgress at the low end and the high

01:03:23 end. Folks were having to shard it and it got complicated for big and it was it was reasonably difficult to deploy at the low end. So their idea but then that just worked with agents like they built

01:03:33 a product that could basically self-deploy a Postgress database and it's what every agentic product needed right they needed to spool up a database without humans and they leaned the hell

01:03:43 into it right they let um uh they didn't get replet with neon which data bricks bought but everyone else standardized on superbase right they they supported them and then they let everyone lovable and

01:03:55 emergent and all these other ones white label it a couple months ago um and Now I don't have the exact numbers but I know more databases are being created by agents and humans. So that is the trend

01:04:06 you're betting on. All right. Database is a fundamental category of software. It always has been right now. The number of databases we're creating I mean it's it's it's it's an order of magnitude

01:04:16 more than it's been 12 months ago. So why the hell wouldn't you want to bet on the leader in that trend? Right? Every app needs a database. like every and even the ones and what's interesting now

01:04:25 is I'm not sure if this is true of lovable v 0ero but replet changed it a little while ago where every single app has a database whether you use it or not they found that enough of them are using

01:04:34 databases no matter what they build right that it's not worth adding a database later so whether you even realize you have a database all the millions and millions and millions of

01:04:43 vioded apps have a database in the background so um and with superbase they get to monetize them all like they're charging these guys for every single database. So I I do like this one. I I

01:04:56 do like it. This is one where the agents are so far ahead of humans now. There are categories where the agents are doing like venode and everyone's talking about what the world will be like in

01:05:05 four years, right? Database is a world where already the agents are creating more databases than humans. We've already we've already crossed that line and so why wouldn't you want to invest

01:05:12 in the leader? >> Agree. And I think it is Lily an excellent example of two things we've talked about. One is that kind of thing I just mentioned which is you start with

01:05:23 something and you have to parlay and then the other thing is Jason that you've talked about a lot is being a preAI company that you know brilliantly finds a way to co-attach. These guys

01:05:32 co-attached to the trend as you say did the deals with many of the vibe coding things and now their job in the next two years is before the music stops be perceived just as MongoDB was the the

01:05:45 right database for the kind of SAS era and for cloud you want to be the right database for vibe coded and agent apps in 2026 27 or 28 and at some point when when the when things slow down enough

01:05:59 for the lovers and the replets and the other folks to say, "Hey, maybe we should just back in and do this ourselves." You want to superbase be in a position to say, "No, every developer

01:06:08 on the planet uses us. Every agent framework supports us. Why would you do this? Your users will rebel." Right? The playbook is super clear. As I say, it's literally it's like it is just like the

01:06:20 SAS and Cloud Spade playbook, but on super fast speed. you know this is all going to happen in two or three years and make make sure that you know before things slow down you are a lot more than

01:06:32 you are today in the eyes of your users think about how hard it classically has been to deploy a database I mean Oracle is still ma massive right I mean I've never deployed Oracle but I can only

01:06:44 imagine how difficult it is to deploy Oracle database right [ __ ] is work these product and that was disruptive these things are work I even [ __ ] has a a vector data based product and I I

01:06:55 deployed it for one of our apps and it it only took a few hours but it took head scratching and headaches and not everyone could do it. Superbase you could do in 5 seconds. I mean it's so

01:07:05 disruptive. >> All these databases start being easier than the prior alternative. I mean I don't shock hor relational started because it was in the 70s but I remember

01:07:15 even in the early 90s >> Arthur Rock used to talk about it though. I remember the relational database days >> and then I but I do remember when

01:07:22 MongoDB started and it was just the drop deadad simple cloud-based alternative to a lot of these you know to some of the other alternatives at the time not so much directly competitive relational

01:07:34 databases but for some of the newer use cases and then they get more complex >> or a DBA for someone that could spend a month configuring it and getting it going is disruptive right

01:07:42 >> yeah because it it didn't take a month it took a few hours it was easy it was JSON it was whatever and you're right now It's 5 minutes. So, it's just now I've no doubt

01:07:51 >> or actually it's invisible. You don't even know. Here's what's interesting. You don't even know you have a database until you need it. It's lurking in the background now. You build an app without

01:08:00 a developer and you didn't even know you needed a database because you're not a developer and it's already there and configured and has all your data. It's pretty cool.

01:08:07 >> That's true. But the odd point I was trying to make is the tragedy is that's great, but over the medium term, a white label business to five or six vibe coders won't be enough. So they're going

01:08:17 to have to expand beyond that. And ironically, over the next 5 years, that will mean adding complexity, adding functionality. And in 10 years time, someone, and it won't be me at that

01:08:26 point, will be saying, "Oh my god, those legacy Superbased products, they're almost as bad as MongoDB, and there'll be a new alternative at that point." But that's just the movie. And this is

01:08:36 Superbase's time to crank. Good for them. >> I think it's also a reminder just that we've given up on worrying too much about intellectual durability in these

01:08:45 in these investments, right? It's a winner. The growth is is exciting. The MPS is high. We're not the fact that everyone else may build their own Postgress databases or other things may

01:08:56 change. We're not we don't even care anymore. >> I mean, I'd say differently, by the way, just to be clear, it's not that we don't care. It's that you just don't have the

01:09:02 luxury of f there are very few things where you can say, "Oh, this is something that is highly different. It has that level of defensibility." Arguably, LLMs themselves did because

01:09:13 there was only a small number of people who knew how to make the magic. But you're right, most of the time right now, I mean, I can regret the fact that there's not a lot of barriers to entry

01:09:24 or I can just accept that that's just a reality that exists today. And the barrier to entry is, as Brian from Andre said, is speed. And if you execute well, you create these barriers to entry over

01:09:34 time. But you're right, Jason. Right now, most of the deals you look at is in the short term, the barriers to entry are low. And what that means is if you stumble, you lose,

01:09:43 >> right? Because if there's five of you going out of the gates, one of them won't stumble and they'll win, >> right? And over time by winning, they'll be able to create. I I believe

01:09:52 downstream there will be barriers and modes created, second order modes, but out of the gate, you're exactly right. It's a race. And I don't know who the superb competitor was, but they didn't

01:10:01 get the two or three key white label deals. And there you are. >> I think also this is why I view a lot of VCs today as enablers. It really bothers me because

01:10:11 Rory's point is accurate. If you stumble today, you may lose forever, right? And I see way too many the classic VC thing is guys, keep pushing. You you've got time. Keep at it. You know, a bad

01:10:23 quarter or two falling behind the competition. Like everyone, it's not that I don't think you should be supportive of your portfolio companies of of course you have to be, right? And

01:10:31 what cho what choice do you have? I just see too many VCs running a preAI enabler playbook where where when folks do fall behind a tick or two the you see kumbaya activity instead of

01:10:45 code red activity. I don't think I'm a come by. But I also I I was interested to see where you're going with that. >> I think it goes to your point of what you said before, which is like there's

01:10:55 no point in being difficult with founders or being opinionated in the way that you've been before because they don't listen. You said it yourself, they don't listen. And so why

01:11:05 >> No, but I'm making you're I'm making a slightly different point. For example, I'm a I'm an investor in a company that's crossed nine figures in revenue, but it is hitting it is hitting massive

01:11:13 AI competition and issues. Okay, it happens, right? and they have a new investor on the board that that doesn't really know the space that well and doesn't really want to learn and frankly

01:11:22 isn't as close to some of the AI changes as as we are and every email and conversation is great job guys keep at it he like you know don't you understand the disruption in the space don't you

01:11:33 understand the issues and he's become an an enabler an inadvertent enabler by being a cheerleader right I just worry about it because so many folks are still hiding and I don't think having enablers

01:11:43 around the table even if it feels good on a given month is helpful today. I I think enablers can can can enable a death spiral that you feel good about as you approach the event horizon and your

01:11:54 startup implodes. >> I was thinking about what you said and you know frankly just checking myself have I at times I mean because you know what one man's descriptive of enabler

01:12:02 can be another person's descriptive of being supportive right and at times when things are tough you want to be supportive. So I was I was thinking actually Jason because I actually think

01:12:10 it's a very important comment and I think what makes a difference is this. You have to be very cleareyed with your companies on where the competition is and understand exactly, you know, what

01:12:20 the other guys are doing and therefore how well and how far behind you stack up, right? And that takes it away from enabling it's it's it's kind of a judgmental term is am I being you know

01:12:31 because also being a jerk is also a judgmental term, right? I think what you're saying that is correct is you're not a useful board member unless a you understand what the company does and how

01:12:42 it compares to the direct competitors. ideally with hands-on experience of the products. And then B, you find a way without being a jerk to keep the company honest about where

01:12:53 they are relative to the competition. You know, what are they seeing? What do our product what do our competitors products do? What do the adjacent products do? How do we think

01:13:03 about that? Not in a kind of defeist kind of way, but you know, how do you distinguish between, oh, these guys leaprogged us for a month and we need to get our act together versus we are a

01:13:13 year, year and a half behind in a market, we may never catch up. We should sell while we can, right? And I think that's actually that I think that's kind of threading the needle between you

01:13:23 don't want to be an enabler, but you don't want to be a debut. You want to be supportive. It's kind of a slogan we have internally. It's not so much founder

01:13:30 friendly, it's founder honest, right? But also, I think actually as I think about it, it has to be founder fact-based. The number one thing, and I'm even thinking on a couple of my

01:13:39 deals where I have to do some work this week, do you really understand where your two direct competitors are and the strengths and weaknesses of your product and what the last three win losses say

01:13:48 about how you're really doing in the field? Because if you don't, you're just, you know, co-playing a board member >> and are you being honest about what has

01:13:56 to change? >> Yeah, agreed. >> Right. Okay, champs, there there are many other topics that we can discuss. Um, I often get chastised for my

01:14:04 selection, so I'm going to >> No, I want you to make the selection. You make the selection, Harry. I'm too tired to decide. I >> I think we will have to at some point

01:14:11 address. I think someone in a comment put like, "Oh, Harry, you often shill them and so you can't not talk about them when there's trouble." I don't like to do that. So, for context, Mccor

01:14:23 obviously a data provider to some of the largest uh companies in the world. most notably Mata who they have since reportedly lost part or all of them being a customer of their data. Um

01:14:37 it was also unfortunately at the same time that Forbes released their billionaires list of young billionaires where the founders of Mccor are on that list. Um very unfortunate timing there

01:14:49 for them. Um Jason, I'm sure you've got an opinion on this in terms of bluntly the Mccor hack and then losing Facebook as a customer. Well, just two thoughts. One, not that

01:15:01 long ago, I was with um part of the management team of one of the leading hyperscalers or and um what what what he said and and I was with him when there was a minor security issue with the

01:15:13 third party vendor, relatively minor, right? uh not but not like this not like all of the private data of all of Mccur being exposed and what he said was there's not much higher on our list with

01:15:25 partners and when this happens there's not much higher like we we have no tolerance it's not worth it there is no tolerance and in this case they got a pass because it was a relatively minor

01:15:35 issue with a vendor that was honest and they fixed it and it did not lead to actually any internal data issues it was just an external issue but it was crystal clear there is no toler there is

01:15:44 no it is not worth it for us. So that is troubling. And the other thing and I'm not an expert in the data labeling or more space. What I don't know is how fungeible the products are at some

01:15:54 level. The more fungeible it is, right, the more freedom you have to route that to what's left at scale or whatever the guys at Handshake want to do or whatever they want to do. If it's if it's not

01:16:04 fungeible, you can you can you can bang your chest. Uh but you're still you're still you're still stuck using them. But but that moment like that when I was with that hypers scale

01:16:13 >> my number one criticism of the space is that all the largest customers are customers of all of them and so they are generally heavily funible and >> so I would be very worried because this

01:16:22 comment was chilling from this executive is like this is the highest thing on our list with third party partners is security. We're exposing our our applications to folks we'd rather not

01:16:32 expose it to because of our ecosystem. We'd rather have no partners because there is so much confidential stuff flowing through what we do at all levels. So we have no we just have no

01:16:41 tolerance for anything that's material. I just don't see how you would come back from this if you've crossed there's just no unless you have to. I think it's I think it's it's potentially death. And

01:16:51 the reason I bring it up is in the old days like through 2023 in our lifetimes you always got to pass once as a vendor even for the worst breaches the worst issues unless your your app was down for

01:17:03 weeks. You you'd get called into the the CISO's office you'd get yelled at. It was brutal. But you always got at least one because it was just the reality of working with emerging vendors. But man,

01:17:15 I just I don't know that you get a second one here. I just don't know. A lot at the margin depends on how you handle it. I don't know at this point. Do we have any sense of you know, was it

01:17:23 a state actor? Was it a malicious employee? Was it just a stupid configuration breach? So I don't have any sense of the forensic here. It was it was it was a organization I think

01:17:33 they called Latipus which basically hold you de hold it for ransom and you have to pay for it back. It's a commercial activity. >> Gotcha. It's a commercial like decent

01:17:42 decent honest criminals and right. Got it. That's >> very successful. It's I I asked the team if we could invest in them. It seems this is one of many very successful

01:17:51 >> actually. You'll find Harry they they don't actually >> No, they're very good. They're very good. >> They don't need much outside capital.

01:17:56 Right. That that in one sense sucks. On the other hand, the good news is at least they're going to be rational and you can buy them off. Um I I think is it fatal? Hopefully not. I think in these

01:18:07 things you generally pay a pretty significant penalty. How you handle it is a key part of it where you're straightforward and honest with your suppliers and with your customers and

01:18:17 let them know what's happened. Was it entirely was it your fault entirely? Were you crassly stupid? Was it bad luck? was it you know where in that containment it was you know so you can

01:18:29 manage through it I think it is hard when you have four or five vendors of roughly the same thing on the other hand I don't mean this cynically but there also appears to be right now an

01:18:38 insatiable demand for labeling data so it may be I I think cuz I think the meta statement didn't say they've I said they've paused which makes sense everyone's going to pause right and my

01:18:49 guess my guess is the likely outcome is you lose a fair amount of revenue you lose a fair amount of time. You're going to have to spend a ton of money to bolster your defenses, but if you do the

01:18:59 right thing, you'll be able to earn your way back slowly and over time, right? That's the likely outcome here. You know, hopefully not fatal. Um, but my guess is that and and I think Sam Alman

01:19:12 to maybe to tie it back to the start, I think Sam Alman said something this week that massive cyber security attacks will become from AI, right, are coming. I genuinely think that most B2B companies

01:19:22 are going to get hit worse than Merkore. Okay, this light LLM was was one of the weaknesses that they had. Like tons of B2B folks have how strong how state-of-the-art and strong are their

01:19:34 security teams? They're they're not they're relying on a hodgepodge of open- source and other products that are barely monitored in many cases. They're busy. They're under pressure for

01:19:44 profitability. they're managing their teams and I and and and maybe Mercury I mean it's probably a small company they probably don't have a huge team but my point is I think um it's going to be

01:19:54 really tough on a lot of startups and scaleups because they just don't have the teams to deal with the levels of threats that are coming from AI this is a start it's going to get worse this

01:20:02 light LLM incident it's going to happen to everybody and as soon as you figure out you can hold all these B2B companies and others hostage the they and their network of thousands of affiliates are

01:20:11 going to do it well I don't know that the average pretty good to mediocre er to actually don't even really have a security team. How the hell are they going to keep up when I don't even have

01:20:19 a team? Remember when Gainsite was offline for a month? Drift permanently was destroyed. And this was pre all this craziness. Like there was an old saying my CTO told me back in the day. The only

01:20:29 reason we've been hacked is no one cares about us. And that has resonated in my ears for years. >> With AI, you can hack anybody you want. I I think Jason you're exactly right

01:20:40 because I think you know in general you know security purchases tend to l you know new stuff gets deployed people should think about security up front they tend not to they deploy bad stuff

01:20:54 happens and then they panic and think about security that's the way it's always been in every cycle and I think we're just about to hit that stage of it now and I think there's kind of two

01:21:03 separate vectors there first of all the AI apps themselves have security needs that are different than um pre-AII apps. You know, get the whole prompt injection kind of issues. But I think the bigger

01:21:13 issue is Jason's point, which is everything else. AI can now using AI, the bad guys can just automate attacks, automate fishing, you know, automate, you know, duplication of voice, all that

01:21:26 kind of stuff. I think Entropic referenced this and you know that and it's it's the Red Army quote that I often use that quantity has a quality all its own. And with AI, you can make

01:21:36 quantity of fake people. You can make quantity of attacks. You can do this thing. So, I think it's not so much going to be you're getting attacked because of your AI apps. It's much more

01:21:45 going to be AI apps are going to attack you. A lot of the AI doomerism I kind of discard, but this is a legitimate and big issue, I think, right? The ability of AI to escalate the velocity and

01:21:57 ferocity of attacks, right? So, which is why, by the way, I think the whole the response of security stocks going down to the anthropic announcement was absurd. I think anyone who's cutting

01:22:09 back on the security budget in 2026 is missing the point, right? Because not are the tax more ferocious, but thinking again, Harry, to your point, this again, the second statement is really Captain

01:22:19 Obvious, but it's worth saying these stuff get more important every year because more and more of our stuff's online. you know, the percentage of things that we do that are done

01:22:30 online just continues to escalate. It's like stupid stuff. It's like all the stuff in your house, all the stuff in your financial life, there's nothing that matters that isn't done online at

01:22:40 this point, right? Which means that attacks there can attack more and more of what counts, right? So I think absolutely you're going to see you should be seeing an you know

01:22:52 a real acceleration of investment in a different class of security to cope with a different class of threat cuz look it's a fatal error if you don't there's only really two things that can destroy

01:23:01 one of these companies the app goes down for a long period of time or the app gets hacked grievously. Those are the two kind of red card fatal errors right and that's where you're going to have to

01:23:13 put the money. there's a wave of the second tier that's coming. It's just massive, right? Even su to tie it, I know we got to end rap, but even superbase, which I'm a super fan of,

01:23:22 right? Um, a lot of times folks turn off the default security, right? And we've seen these issues and and and in the old days, no one would find it because they didn't care about our little Rory and

01:23:31 and Harry and Jason's app. Now AI will find it in in seconds, right, on the internet. and it will use every possible way to penetrate that to steal the data to create malicious acts everything that

01:23:41 is possible on the face of the earth that can be delivered with software. Um maybe there's nothing we can do but I you know I don't I don't think uh I think we've all underinvested in the

01:23:50 attacks to come. It >> it used to be hacker farms of people in fill in the blanks the Philippines Russia. Now it's going to be hacker farms of AI agents cranking 24/7. It's

01:24:00 going to be miserable. >> Guys you can choose one more. Okay, Jason. Rory doesn't feel like choosing, so he's delegated it to you. >> Absolutely. Okay, there there's the GLP1

01:24:10 two bit two company again for people who use this as their like news on tech. A twoperson company who uses AI intelligently scaled to 1.8 billion in revenue selling GLP1s.

01:24:22 Interesting. A lot to unpack there. Wix buying back 31.6% of its shares given its low stock price. uh Oracle getting rid of 20 to 30,000 employees via a 6 a.m. email. Jason, any that stand out,

01:24:37 baby? >> Obviously, at some level, uh people are so excited about the one or two person billion dollar company. Facts were glossed over, points were missed and all

01:24:46 that, right? Oversimplified. Um and they used deep fakes. They made representations about doctors they shouldn't. They did all the wrong

01:24:54 things. They did all the crappy affiliate marketing stuff people have been doing for 20 years and they did it at scale with AI and built a big business on it, right? Um, I get it. Um,

01:25:04 but what is interesting about it is if you let's not over glamorize this company that maybe is at the edge of fraud in many ways and its marketing tactics. The fact that they could use AI

01:25:13 to scale this with two people and maybe some consultants and stuff on the side. It is it is we are seeing the future. Why? And um AI is completely changing marketing. Marketing has not gone away.

01:25:26 Daario and Sam to to Rory's point, Dario and Sam are everywhere because marketing matters as much now as ever. And this is a different version of how marketing is changing. And if you don't adapt, right?

01:25:37 Maybe buying TBM is a bad idea, but you got to adapt to the new world of marketing when and and and you know, there's a lot of there's a number of startups that have tried to automate all

01:25:46 this marketing at scale with the eye. Most of them are terrible, right? They don't quite work. They create boring assets. They look like an awful art. They look they look kind of like make.

01:25:53 They're that bad. A lot of the assets, um, they don't have context. They use too much stock art. But no reason in a year everyone shouldn't have the AI power to blanket the entire internet

01:26:04 with the best hyperpersonalized marketing in the world. Like we hopefully in a year we will all have the power to do some of what um, Medv have done. And I think it's I think it's a I

01:26:15 think if we step back, it's a chance to see 12 months into the future that when we will all of us will have more of this power. >> In other words, just cuz they're

01:26:24 illegally selling uh weight loss reduction drugs that are off label to people without the appropriate FDA safeguards doesn't mean they're not great marketers.

01:26:34 >> I just I talked to so many CMOs who are still struggling to run the 2023 playbook and falling further and further behind. you have to adapt and uh and and and and I think crappy automation

01:26:48 doesn't work anymore, right? But these guys that were able to do it at mass scale and target everybody, this is the future that we all should should know and um and marketing, I guess the kota

01:27:00 is marketing appears to be more powerful than ever in the age of AI and humans have to control it. But if you don't leverage how marketing has been done in the future, you're you're going to be

01:27:10 stuck in the past. You're gonna and you're you're going to be killed. You're going to be killed by folks running the old playbook. So, um, but yes, I mean, anyone that achieves some sort of scale

01:27:20 through marketing, as dodgy as some of these consumer guys are, there's something to learn, right? Whether it's multivariant testing, whether it's AI, whether it's p personalization at scale,

01:27:30 uh, I think it's a waste as a marketer if you don't learn from it, right? And this is what I think is going to happen. We are this is this there just like it is inexcusable to send a dated sales off

01:27:40 outreach cadence from 2021 today the the way we're doing advertising and marketing will seem incredibly dated in two years like only only the creakiest companies will be doing marketing and

01:27:51 advertising the way they do it today in two years. It makes no sense. It makes no sense. I should be getting the GLP1 ad specifically targeted to you. Jason, you don't technically need it, but I

01:28:01 noticed your jawline on 20 VC could be a little bit tighter. Uh, what if we just micro dosed you today and uh, so you could get some of that t-shirt look that Harry has. Like, I'd click on that in 60

01:28:11 seconds. 2 seconds. You >> would, you know, >> I shouldn't get that. And versus stock art of some grandpa running with his golden retriever on a beach, right? So,

01:28:19 I'm both both think this is fraud and and a and a over headlined and and the future. We're watching the future. >> I I think you're right. I mean I would argue that a hu just a huge percentage

01:28:30 of it is on the fraud side but none not on the fraud side but the um hairy edge of regulation side but I actually agree upon reflection what you're saying is correct. It's funny it's a little like

01:28:40 the last comment. What we're basically saying is the most entrepreneurial people on the planet out there right now are the security yeah the hackers and the kind of dodgy marketers that are on

01:28:54 the front line of pushing things. But the tactics that they're using in the way of leveraging AI, everyone's going to be doing within a year or two are going to be left behind. I could I I

01:29:01 could go along with that. Yeah. There was there was an era in the old days when the best affiliate marketers knew things nobody else did and built billion-dollar companies out of it,

01:29:10 right? Uh then there was an era which has now faded when some of the best companies used SEO in a way nobody had used before. Millions of pages, right? You know, even things you could, you

01:29:20 know, maybe it's only worth 10 billion. Digital Ocean was built entirely on SEO farms. So was Zapier and others. And there was a group of folks that knew how to do this and it worked. The next group

01:29:28 of folks will know how to do this mass personalization at scale that really works to millions and millions of people and they will win like the prior affiliate market. They will crush folks

01:29:38 and the rest of the world just won't get it. They'll think it's dark arts and um and they need to become agentic marketing experts. But in the same way that great affiliate marketers actually

01:29:49 largely originated from porn and Viagra if you want the >> dark and here I think probably some of the best nextgen AI marketers will spawn

01:29:59 from GLP1s or anything at the border lines of you know next generation e-commerce in some ways. >> Yeah. But I think that Jason's insight I I agree with that by the way. Yeah. I

01:30:09 mean there's no doubt that criminals I mean like many of these new technologies are adopted by crime or by porn or dodgy marketers but I think Jason's insights is a profound one which is the marketing

01:30:22 tactics that are used by and look very kind of dark arty over the next 10 years tend to be adopted by everyone and now as you say everyone in any corporate America is an SEO expert whereas 20

01:30:34 years ago it was a dark art and I think you're right Jason in the next two or three years if you're not adopting aic marketing as a digital marketer, you're just going to be left way behind and

01:30:44 personalized marketing and leveraging the technology. I think yeah I mean I knew it already intellectually but actually I will say you kind of crystallize it in my mind because I've

01:30:52 lived the last I remember when SEO marketing was literally something that only the lead genen companies did and there was two or three year period where they had you know hyperrowth $100

01:31:02 million businesses kicking off 30% cash and then those businesses went away as normies adopted the technology and the correct play was to be the software provider helping the normies tool up and

01:31:14 I think the same is true here in agentic marketing. So that's my stolen insight from you for the day, Jason, as I go look for those companies. >> Well, all it's just interesting. All

01:31:23 Medvy has to do to make 400 bucks is drive a GLP lead to someone that buys a product that that just like tokens the world the world can't consume enough of. And all these and most of these folks

01:31:34 are selling the exact same product and they're fungeible, right? And so you're getting three it's one there's a moment in time where it's a great marketing arbitrage. If you're excellent at this,

01:31:42 you get three to 400 bucks for delivering a a customer that already wants to buy your product, right? It's a moment. That's that's how the math it kind of ties back to our open route or

01:31:50 another conversation. If you only made 10 bucks, this wouldn't be such an exciting business. But these this they're so profitable, but also so competitive. When you get 400 bucks for

01:31:58 just delivering a customer from a Facebook ad, man, you you know, you want to you want to run this. >> You do what it takes. >> Boys, a lot to discuss this week. Thank

01:32:08 you for being so good. It's so good to see

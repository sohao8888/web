视频链接：[https://www.youtube.com/watch?v=bugVEcVpH7w&list=WL&index=7&pp=iAQBsAgC](https://www.youtube.com/watch?v=bugVEcVpH7w&list=WL&index=7&pp=iAQBsAgC)
视频发布时间：2026-04-16
频道名：Bijan Bowen

## 转录内容

00:00 Open app. All right. Open GTA. Right on. It changes the scenery from where we shoot. It shows the the bullet holes in the scenery. All right. This model is worthy of of getting insane in

00:15 the title. Claude Opus 4.7 has been released, which is now Anthropic's new most powerful publicly available model. This is pretty exciting. I'm sure if you've clicked on this video and you're

00:25 watching, you're already well aware of the excitement of a new model release. So, let's take a quick peek at some of the interesting information contained within this announcement post and then

00:34 we'll get into some fun and light testing. So, feel free to subscribe cuz I want to hit 100K cuz I do want that plaque. I'm just going to say it in every video. And let's take a look at

00:42 some things of note for Claude Opus 4.7. Now, of course, as with every model announcement post, they do start off by saying that Opus 4.7 is a notable improvement on Opus 4.6 6 in advanced

00:54 software engineering which lends itself to a pretty exciting potential browser OS test in my opinion. But something else interesting right here is they mention that the vision capabilities of

01:04 this model are substantially better. So that is good to see as well as some of the tests that we do like to do of course involve giving it a handdrawn wireframe and telling it to turn that

01:13 into a wonderful web-based experience. So it'll be cool to see some better multimodal capabilities or vision processing capabilities. I don't know how great Claude has been for that in

01:24 the past. I know Gemini seems to stack up very very favorably when it comes to actually analyzing images. So, interestingly enough, in the benchmark chart right here, we have all of the

01:33 usual suspects such as GPT54 and Gemini 3.1 Pro. However, Mythos Preview has also made its way into a direct comparison chart with the newly releasleased Opus 4.7 as well as Opus

01:45 4.6, of course. Now, Mythos preview is definitely scoring well above this in pretty much every area that has been benchmarked here. And while I don't want to specifically spend too much time on

01:56 focusing on Mythos, as this is an Opus 4.7 release, it is interesting to see some of the potential performance of that if or when that ever does become generally available to folks like us.

02:08 Um, you know what I mean? Though I do find it interesting that if we scroll down here a bit, there is somewhere where you can actually use Opus 4.7 for cyber security research if you join

02:18 their cyber verification program. So it is cool to see that they are offering Opus 4.7 and not Mythos preview as well for some form of cyber security research which would lend itself to the idea that

02:29 this model is properly capable in that domain as well. Now, in terms of pricing, it is $5 per million input tokens and $25 per million output tokens as is listed right here. Then, of

02:40 course, we get the traditional basically like big company feedback about testing the new model saying it's fantastic. Um, we always get that. Then we have some highlights and notes from early testing

02:51 on Opus 4.7 mentioning things that are better or greater than Opus 4.7 such as instruction following improved multimodal support which is exciting as that was something I won't say that was

03:03 lacking but that was definitely an area that an improvement will definitely be noticed if it is there. Additional things of note and something that is kind of interesting is they have

03:11 released this new XH high reasoning effort. So, this sits actually between high and max. And on Claude Code, they say right here, they've raised the default effort level to X high on all

03:22 plans. So, that's something to keep in mind in terms of just being mindful of your usage limits and things, which are pretty commonly talked about when using agent decoding in general. But, if we

03:31 scroll down here, there is a chart that kind of showcases that. So, here is the new X high mode versus the high mode and then the max mode right here. So we can see the total amount of tokens used for

03:42 a task on max mode is significantly higher than what we get with XI. But we do also see that that seems to perform significantly better than the max mode with Opus 4.6 and at perhaps slightly

03:54 less token allocation. So this could be a fairly efficient price toerformance ratio new introduction. So if we hop over now to the web UI, we're going to notice something interesting. Now I do

04:04 have Opus 4.7 selected. Of course, if we go back to Opus 4.6. If we go in more models, we're going to see there's a different option where there is the extended thinking toggle where it will

04:15 think longer for complex tasks. From what we see right here in this web interface with Opus 4.7 selected, we no longer have that specific extended thinking toggle. The only thing we have

04:25 here is something called adaptive thinking, which as it says thinks only when needed. Now, this is very interesting because personally, I think having a model that requires the user to

04:36 do less in terms of configuration between just sending it a prompt is better and ultimately where things will go. However, I know folks will say, well, we want to see this model tested

04:46 on full capability. So, do not turn this toggle on because then sometimes it will deem a task simple and it won't put all its effort in. So, I do want to just make that known. Personally, I do want

04:56 to enable this, but for the purpose of this test where we just want to see this thing running all out, I am going to leave that disabled, but it's definitely worthy of a mention. And with that, we

05:05 are of course going to start with the browser OS version, call it 2.5, because I have made some slight changes here in the game section in specific. So, of course, this test is to create a browser

05:16 OS with five specific applications, two of which must be games. However, I have changed that to they must be 3D games and one must be a simple GTA clone. The other can be up to the model. So, it'll

05:28 be very interesting to see this create this browserbased OS with a simple 3D GTA clone contained within. It'll just be kind of cool to see. And again, I've not used this model at all. So, this is

05:39 genuinely the first time I've used this model. So, I have no idea how long this will take or anything like that, but it'll be interesting to see. Okay. So, it always opens in like some form of

05:49 preview here in the artifact window, which I don't want to see. Good. So, we've swapped to code and we can see here that this is 1,718 lines of code. So, here's our Opus 4.7 browser OS. All

06:00 right. Prism OS. I like this. This is a very, very anthropic color to this notes app. All of these icons are very, I would say, high status in terms of their aesthetic qualities. That looks good.

06:13 Can we resize? Yeah, we can. Okay. This is just so far this is good. Seems to have its own kind of unique aesthetic or UI style. Can we minimize this? Okay. Can we reopen it? We can. Good. Now, to

06:26 be honest with you, my main interest here is just immediately the games that I've denoted it should have. But also, we should check the unspoken rule set. Does it have a right click? It doesn't

06:35 have a right click. Well, okay. That's not specifically listed in the prompt, and there are always debates on that. well then it shouldn't do it or sometimes folks myself like to be like

06:48 well maybe it should go a little above and beyond and just know to implement that it doesn't you know it's we'll uh okay so we do have a clock and we have this little kind of center dock thing

06:58 with the prism OS look this is very modern aesthetic I would say and now let's see all right let's just start with the GTA clone game that it had to create okay this is this is really good

07:11 can we get out of the are and from within the browser. Okay, there are no mesh colliders on the buildings. Fail. No, I'm kidding. For this to be even in a browser. Let's see if we can

07:24 find an Oh, can we beat this guy up? Nope. That's all right. That can be version two. Let's find a car. We can No car nearby. I'm just going to spam click this. And yes. Didn't that put us back

07:35 in ours? I don't know. To be honest with you, I love this. I love this stuff. Hit and run. wanted that. We had knocked over that little capsule

07:48 player, but it seems like we got away. All right, let's just go on the prow. Yep. Okay, our wanted level has gone up. We do even see there's like a um Okay, and then we got busted. So, that resets.

08:02 All right, now these these cops are impossible to get away from. Maybe if we run outside like the plane. Okay, good. There is a The entire video is just going to be this. So, thank you. Oh,

08:14 good. Now they can't catch me. Now there's a mesh collider. Okay. So, there's no mesh colliders when we're walking, but there's a mesh collider when we're driving, which that's good.

08:23 Can I steal the cop car? No. All right. You know, I have to say the word exceeds expectation comes to mind. You know, I probably could have full screen that. I apologize for my

08:37 incompetence there. Now, it did also seemingly put in a 3D flight simulator game, which I didn't ask it to. If you recall, the second one I said is just do another 3D game. Okay. And this is one

08:48 where we need to um fly through or collect these rings. Shift is boost. Now, the plane model is backwards. This happens more often than one would think it would where it just

09:01 spawns things in backwards. I do like the kind of um contrails or whatever those are called. Not bad, especially considering that this is a browser OS test, not a

09:12 specific game test. Next up, we have our notes. And this is what we saw when we had initially opened this where it was just giving us an about section for this browser OS. We have a paint app that

09:22 could be fun. All right. So far, I'm digging the UI of this paint as it just gives us some simple colors to choose from. I'm thinking purple green, maybe. All right. Now, we'll see if we save

09:35 PNG. Does it save it without the background visible? Okay, no it doesn't. It saves it with the white background visible. But still, just being able to save our artistic masterpiece is in and

09:44 of itself pretty neat. Can we minimize to taskbar? Yes, we can. Next up, terminal. And I do have to say the icon for this terminal app is very, very nice. Okay. Type help for available

09:54 commands. Open app. All right. Open GTA. Right on. Was that the fortune? I guess it has not found the meaning of life. Then finally, our settings app where we should be able to change our wallpaper.

10:09 Uh-oh. Interesting. The font used here is is special sunset neon grid. Oh, it is. It's just hard to see in my current setup with a cheap laptop screen and studio lights.

10:24 Carbon. Oh, yeah. That does have some form of carbon fiber texture to it. Neon grid is nice. Sunset of course is giving us beautiful just like synth wave or whatever aesthetics. Overall, I would

10:37 say that aside from the right click omission, this was a very very stellar result, specifically with the implementation of the GTA game. I will be honest. So, now we're going to do the

10:48 beautiful static subway scene test, which must have brightness control and the ability to move around the screen using WD. Now, something I like to do is if this does produce a nice and

10:58 acceptable result, we then send it a follow-up prompt basically saying, "Turn this into an FPS using the subway station as a map." And that generally tends to produce some cool things. In

11:07 the meantime, while this is going, something I would like to do is go to my own website. Don't worry, I'm not trying to sell anything. Here's where you can buy my course on making AI stacks. No.

11:17 And I'm going to upload that browser OS here because I think it's really kind of cool. Now, I don't have the preset for Opus 4.7, which I will need to add. We'll do Opus 4.7. Then, we'll paste in

11:28 the exact specific prompt that led us to that browser OS masterpiece. Then, we will upload the file. And now, we can see that anyone can go and play with the Opus 4.7 Prism OS, which has that nice

11:38 little booting emotion or animation, which I don't actually think I had mentioned in real time. So, I do apologize for that. But now, oh, okay. I didn't see enough like meaning I didn't

11:51 really like see enough to spoil it, but I saw enough to know that I can send the follow-up prompt immediately while we do take a look at this result. So, I have sent the follow-up prompt telling it to

12:00 turn it into an FPS with humanoid/zioid enemies, recoil effect, and ammunition tracers. But for the time being, let's take a look at the subway station and drink station. Okay, I'm getting like

12:10 gold and like high aesthetic effects here. I probably should have Oh, wow. Okay, this is fantastic. This is really, really, really fantastic.

12:22 This may very well be one of the best that I have seen. I think. Okay, I do like that metro system. To be honest with you, though, if I don't know why this comes to the flickering light, I'm

12:34 almost thinking that was done on purpose to add to the vibes here. It is of course very dark, but just everything. We have the clock. Does the clock show the correct time in our local? No, it

12:44 doesn't. But I wouldn't expect it to still though. That's That's nice. Noir City now showing movie poster. The tiles are like grimy and dirty, too. We have a track map missing. Have you seen this

12:55 cat? Okay, that's depressing. I could have done without that. And then we have our subway car. Can we walk through it? Yeah. Okay, we can, but that's okay. Is there an interior? Not quite. Now, one

13:05 of the additional tests that's always kind of something to check in these is, can I adjust the lighting without the pointer lock glitching out? Okay, I can. Platform 7. Meridian Line eastbound. A

13:18 quiet moment beneath the city. Tiled walls, flickering fluoresence, the hum of the third rail. Just don't touch the third rail. We have trash under the rails. Oh, it

13:29 should have a feature where if you step step on the third rail, it's game over. Even a newspaper, the Daily Chronicle, City in deep freeze. And then we have a bunch of Latin filler text. Trash bin

13:41 with trash surrounding and not inside. Ben benches. Exit. This is This is FPS worthy. This is really really very very good. I I'm going to be

13:55 honest. The flickering is real. And it's on one specific light, too. So, like if you notice these other lights, there's no flickering. It's just that one, which is more true to life. That's really

14:04 annoying. So, I'm getting errors again here. And now it's possible that we got a network error, but we also got a result. Oh, okay. It froze. It froze again, but that's okay. Um,

14:19 no. Oh, let's just see if we can see some enemies. Oh, they're there. They're just hard to see. Oh, what the heck? Okay. Oh, crap.

14:31 We have to reload. Shift is to sprint. Wave one. They're coming. Pop. Oh, reload. Reload. Wow. This is And there's even splatters

14:44 on the ground. This was worth the network issues that apparently were I mean, don't get me wrong. Oh, the brightness slider is still there. It's just moved. This is just This is awful.

14:57 And what I mean by that is like All right. My health is Oh, I mean, something I'm going to say here that I'm actually impressed by is it really kept

15:10 the map even down to that single light that was flickering. This is This is worthy of putting on Steam for a nominal price of $1.99.

15:28 A. All right. Uh-oh. Reload. Is there a recoil on this weapon? Yep, there is. Okay. It even has like it changes the scenery from where we shoot. It shows the the bullet holes in the scenery.

15:42 Will it show it in this poster? All right. This model is worthy of of getting insane in the title. The decision has been made. This is I mean that's really the only logical response

15:58 to this. I have to close out of that because it's gonna um fans go big is what I was looking to say there. And this will be partially testing some of its multimodal capabilities because I'm

16:09 giving it the Seinfeld apartment test where it needs to create an accurate and walkable depiction of the apartment, Jerry's apartment from Seinfeld. It is getting a reference image here. To date,

16:19 I have had results that are exceptional in terms of the quality of just the actual like layout when judged independently of the fact that none of them have actually properly gotten the

16:29 layout of the apartment, even though they've been given this specific source image and how everything is arranged. So, it'll be interesting to see how it does there. I have no doubt that it will

16:37 do a very fine job on the actual aesthetics or visuals of the models and things like that, but it is really the layout that I've never seen properly adhered to or reflected by any of these

16:48 models. So, it'll be interesting to see what it does. Jerry's apartment. Okay. Still, none of them have properly gotten the layout, which is okay. Overall, I do

17:02 like the way it's presented the scene to us in a somewhat similar artistic style as this screenshot we gave it. So again, the layout is not there, but the way it actually opens the scene in presentation

17:14 is similar to that. So let's actually How do we get into walking mode? Oh, we just hit the stuff. Okay, I'm going to notice here the actual detail is very nice. though the layout is not

17:29 again we do have the bike kind of on the wall. We have the shelves. We have the vintage Mac and we have the green couch and things of the sort. We also do have the bedroom. I think it's hard to And

17:42 there's a bathroom with the pink tile. Okay, let's go through this wall to the bedroom. The lighting is nice. The colors are nice. Although I think for this one I

17:51 would say I believe it was GPT Pro that I think still beat this one out in terms of the impressiveness. However, with that said, this is not a specifically like GPT Pro contention model. So, for

18:06 judging this based off of what it's done here, the individual elements are nice. We have the fruit bowl, we have the fridge with some sticky notes or things on it. We have cabinets and then we have

18:15 a sink as well as just some other items. So overall, I'll be honest, I was expecting a little better with this result just in terms of the layout and things, but it is definitely a difficult

18:26 test to transpose the layout and all these specific fine grain details into this. So maybe this is a this is a test that is still yet to be cracked. The outside is interesting. It just looks

18:37 like a it's very interesting. I do like the way it presented it to us though when we first opened this page. So, while we were doing the Jerry's apartment, I had also gone into Claude

18:47 code right here where we can see that we are using Claude Opus 4.7 on XHigh. And I've given it the self-contained C++ skateboarding game test. However, there's a slight difference than the

18:57 traditional one we normally run here in terms of the environment. So, the environment should be a late '90s California boardwalk map with walking NPCs, storefronts, water effects, and a

19:08 bunch of scenery to perform tricks on and skate on. So, this is the self-contained C++ skate game. However, it is just going to have a bit more of an intricate map to skate around in with

19:19 a specific style denoted of that late '90s Cali boardwalk aesthetic. So, it wasn't able to properly fully autonomously test it, but it says it's all set. So, basically, if we press

19:28 enter right here, we should Whoa. I don't know that I told it this should be 3D. So because of that, I have to say this is actually acceptable.

19:42 Did I say 3D? Nope. That's okay. We have an ollie. So it made it 2D. And honestly, the aesthetics here are Can we resize this? No, we can't. Okay. J is to kick. So for a kick flip,

19:59 it's it's a bit too fast. So we can't like Oh, okay. Interesting. This is tough. This is like a Super Mario skate. Like the the logic of actually playing the

20:13 game properly. This is This is BS. This is difficult to play. Are you kidding me? Come on. That's just not right. Come on. I like this. I'm going to be straight up

20:26 so that I don't look like a complete tool in my follow-up prompt here. So, I'm just giving it some really like general and like low intelligence feedback here, saying, "This sucks hard.

20:36 Wow, awful. Zero out of 10. Make it 3D." We'll see what happens. I almost feel bad. Not enough to not send it that prompt, but we'll get a iteration. In the meantime, I have asked this for a

20:49 virtual drum kit simulation that also contains the autoplay feature, and I want to see how it does in actually creating these models. We'll see. Enter studio. Okay. Interesting. It did 2 and

20:59 1/2D. And this sometimes happens and I just don't have a lot to say about that. It's just surprising some models will just do 2.5D photorealistic when other ones that you wouldn't expect to do 3D

21:11 will do. All right, let's interesting. Lots of reverb on that kick. These sounds are fantastic. We can absolutely do a Phil Collins test

21:46 with this or still the the like the toms are really good. All right, let's check some of our

22:02 autoplay. And these do just have static BPMs. And I see some like UI elements here which makes me think it will show like the specific time progression while these are playing. Yep.

22:16 Now, can I play while this is playing? Yep. That's always more fun. That's hard. All right, that was our rock. Let's try funk. This will slow things down a bit.

22:44 Okay, maybe not. Okay, that's that's good. Then we have Bjan on the ride. No, I'm not gonna jazz swing.

23:10 Yeah. And then break beat. And we even have some kit info, which I hadn't even noticed. So, it's an oyster vintage. It is maple 7 ply. The heads

23:34 are coded ambassador. The symbols are bronze B20 and the sample rate is 44.1 kHz. Next up, I want to try something in Python and we're going to try a 3D FPS game which cannot use. So, this way it

23:45 has to use more raw math to actually do this. So, we have received our Python FPS game here. This is impressive considering the limitations I gave it.

23:59 It properly did everything that we asked. It has a functional mini map. It has visible ammunition tracers. It has enemies. Our HP does go down by eight.

24:10 When we do hit one of these enemies, victory. Press enter to return to menu. Simple, proper, and efficient. So, overall, this is pretty much acceptable. I was almost thinking I'd get a more

24:27 vintage style look to this, but this did a nice job. Let's see what happens if we lose. You died. Okay. Again, uh not as much to say about that as I'd expected, but

24:40 overall it was properly done. So, this next test is going to somewhat test the multimodal capabilities that they've touted as I've given it this AI generated photo and told that this is

24:49 the cover for an upcoming book called Renovation or Resurrection. You must design in all caps insane website for the launch of this book with the cover displayed as well as verbal narration of

24:59 snippets from the book, interactive experiences, etc. Make this a 10 out of 10 New York City publisher style knockout design that is high-tech and aesthetic. So, I want to see if it

25:09 properly is able to actually take this reference photo and implement it back into the website. Also, I've told it that I want an actual verbal narration of some of the snippets of the book,

25:18 which it will make up probably some mystery style thing. So it should properly to realistically do that at least utilize some of the browsers accessibility features to be able to

25:28 read like through Chrome's speech to text or the other way around texttospech capability. So it'll be pretty interesting to see if it does this. All right, it has presented it and I don't

25:39 want to see it which is why I'm doing this right here. Okay, good. So that's 1,831 lines of code for this book launch. Let's take a peek at this. This will be very interesting.

25:49 The image is broken. I'm going to have to yell at it. Let me fix this by embedding the image directly into the HTML as B 64, so it will always render regardless of where it's open.

26:00 The image is 2 megabytes as B 64. That's large, but I'll embed it cleanly. Okay, fixed. Good. And it did it more like aentically. So, let's try this again. Nailed it.

26:15 Renovation. Resurrection. Good hover effect. Editors pick the Atlantic. Starred Review. Kirkus, I don't know. Renovation or Resurrection? 14 Years of Marriage. One crumbling Victorian and

26:29 the Quiet Terrible Question Neither of them dared to ask aloud. A novel by Margaret Holloway. Publishing date May 12th. 384 pages. Hard cover. And we even have an ISBN number. I don't think

26:41 that's real, but we'll we'll see. I'm not laughing at this. My dog just howled like really really loud. Holloway and son's press. Okay. The New Yorker. Holloway writes like a

26:56 chaver with a scalpel. I am someone can inform me uh what exactly that means. NYT book review national book award finalist. Listen before you read. Oh, good. The excerpts narrated by the

27:09 author. Click any passage to hear it in her voice. All right. The speaker's off. My mistake. All right. >> The inspector came in March and said the house was holding itself up out of

27:22 habit. I remember thinking, "So are we." 14 years. I thought 14 years of habit. The walls were tired. The floors sloped west toward the window where on certain evenings the light was still kind to us.

27:40 But kindness I He wanted to knock it down to open the space. I wanted to know what was keeping everything above it from falling. He called me cautious. I called it

27:52 structural. Some things can be refinished. Some things can only be honored and then let go. The Paris review. This is just What is

28:06 this? It's a quiz. Consult the Oracle of the House. There's our author. She was born in Dublin 1978. Lives in Hudson, New York.

28:19 Has written three prior novels. Her essays appear in the New Yorker Harpers in Granada. Granada. She teaches at the MFA program at Columbia. She lives in a 1907 Victorian in upstate New York with

28:30 her husband and two children. The house at present still standing. And we have a countdown timer. Pre-order assigned. Barnes & Noble. Amazon audio. This is just like so far beyond

28:44 this was this mo this this video is so getting at all caps insane in the title. No doubt about it. So I think our updated skate game has fixed. Yeah, it has. And it's definitely a 3D

28:59 transposition. Wow. L pop shove it. Yep. You 360 flip and you bail and you actually have like effects if you

29:15 look at all the people. I mean, this level of density is not even achieved in in Grand Theft Auto games with the amount of NPCs. Oh, we hit a bench.

29:26 All right, let's go off a ramp and do like a kick flip. Hey. Oh, that was a pole. Not the person we hit. No. Come on. I can't even land a trick. Still better than that 2D disaster. The

29:38 storefronts look good. Now we're Now we're cruising. Yes. Yes. All right. Go, go, go. Is this infinite? No. There's got to be an end. I don't think it's procedural,

29:50 is it? It is procedural. Look at the water effects. And it has colliders. So we wow is really all there is to say is just wow. So for the final test, I'm

30:12 giving it the handdrawn Stevie Slappice portfolio wireframe and telling it to turn this into a high-end portfolio designed to get the person hired at a top AI or ML company. should include

30:22 real impressive AI concepts directly in the page with an extremely high-end aesthetic that would only be found in a top YC startup website. So, let's take a look at the portfolio.

30:33 All right, here's the Stevie Lapis site. I' I'm like having trouble reading this thing. I don't know why. He's currently a research resident previously MIT Seale and Google research focus

30:43 interpretability reinforcement learning and eval. Yeah. All right. based based no Boston Mass education MIT and Brown citations 842 open source 3400 compute hours 180K on an H100 per year that's a

31:01 flex languages English French and Python a transformer doesn't read left to right it reads everything at once and decides where to look a live demo below is a working self attention visualization

31:13 each token is a query click one to see the distribution of attention to places over the sequence. The weights are computed live from admittedly toy key query projections not pre-recorded. It's

31:23 the same operation written the same way as the one inside GPT4 claude and Gemini. And then we have the specific mathematical uh equation for what's going on.

31:35 And it even has like the color gradient to denote the higher softmax score for each specific IPNYV. So it's like a Jupyter notebook here as well. Head three of 12, layer seven. Okay. Okay.

31:47 And it's just static right there. Here's the practical stack sharpened on real research problems. And we have some specific things here. Everything looks very good. Five projects each

31:55 loadbearing in the way that matters. And it's using like the anthropic color for some of the italicized text as well. Okay. And these are basically like links to some of the fake open source

32:06 projects. Pure reviewed. Let's build something worth understanding. Slap Stevie lapis.dev. Google Scholar. GitHub. Twitter and alignment form 2026.

32:18 Last push Thursday, April 16th. That's today. This was good. This was very, very good and clean and very anthropic style, I would say. All right. So, overall,

32:28 that's going to conclude our first look and test of Opus 4.7. I'm going to be completely honest. I'm going to put insane in this title. And this absolutely 100% warrants it perhaps more

32:38 than any other insane title I've ever done. This seriously blew me away. Everything just seemed so effort effortless for it. It just like you tell it something, it did it and it did a

32:50 nice job. And in the one instance where it didn't, which was that odd C++ skateboarding game result, we basically gave it some like complete trash feedback and said make it 3D and it did.

33:00 This is infinite and procedural. The tricks are good and you can actually bail out pretty commonly if you don't land it well. So this was just like absolutely stellar. the water aesthetic,

33:11 the California boardwalk aesthetic, the NPCs, the density of the NPCs was definitely something to behold. Fantastic. Then we had the built-in Grand Theft Auto game from the actual

33:22 page here. The browser OS where you could kind of hit people and then the police would show up when your wanted level goes up and then you could get out of the car, you could find other cars

33:31 and take them. I mean, for a browser OS like result, this was incredible. And it even put a little flight sim in which we didn't tell it to. I just told it to do

33:42 3D games, one of which had to be GTA. This was well done, though there was no right click. Then we had Jerry's apartment. Overall, at this point, I think I'd say this is probably the most

33:51 disappointing result we received, which is speaking to the impressive capabilities of this model. It didn't accurately grasp the layout, but judged independently as a scene, it was not bad

34:03 at all. Drum kit designer, fantastic. This was very enjoyable to play. We had this book website, at least the second version of it where it did properly encode this image so we could see it

34:14 with the speech and this was just like like >> I remember thinking so are we. >> This was just this was awesome. It definitely has a penchant for kind of

34:28 like this off-white color with some interesting gold aesthetic. As we saw here as well in the Stevie Lapis portfolio website, there was a common theme of UI design capability or color

34:39 schema I would say between the Stevie Lapis portfolio, the book website as well as the notes app in the Prism OS. So that was interesting to see. Now, I do believe ah yes, there was of course,

34:50 how could we forget our subway station FPS, which is just like this needs the lighting turned up, but the way that the actual bullet holes showed where you shoot is just I mean,

35:06 now this is pretty heavy to run in the browser, so just basically be warned. But I did, of course, put this on ultimateplay.com. So, if anyone wants to go and scroll

35:16 down right here, you'll see a newest uploads. We have Prism OS from Opus 4.7 as well as the Subway FPS and you can then go in and play this. Oh, okay. I'll have to troubleshoot that. Uh, so just

35:27 make note of that, but I do apologize for that. Everything else, this was just like very, very, very good is what there is to say about this. I'm really impressed with some of these results.

35:38 The Python FPS as well is one that I had forgotten about and it was pretty simple, but it was functional and it did adhere properly to everything we wanted. So really, this model is very, very

35:49 impressive on first glance and I'm excited to actually try this thing in some more maybe personal projects or things of the sort. But this is definitely definitely a step up from

36:00 4.6. So I'm very very interested to see what folks do with this and then what other competition this may spur. So, that's going to conclude our first look and test of Opus 4.7 by Anthropic. A

36:12 significant leap in capability, I would say, and justifiably insane. So, with that, if you have any questions, feel free to leave them in the comments.

视频链接：[https://www.youtube.com/watch?v=g2fMmNygrPo&list=WL&index=6&t=26s&pp=iAQBsAgC](https://www.youtube.com/watch?v=g2fMmNygrPo&list=WL&index=6&t=26s&pp=iAQBsAgC)
视频发布时间：2026-04-20
频道名：Alex Kantrowitz

## 转录内容

00:00 Jensen Wong struggles to address Nvidia's position on competition and export controls. Where does it leave the company? Sam Alman's conflicts are getting at least some OpenAI investors a

00:10 bit nervous and Alberts is a GPU company. Now that's coming up on a Big Technology Podcast Friday edition right after this. Welcome to Big Technology Podcast Friday edition where we break

00:20 down the news in our traditional coolheaded and nuanced format. We have a lot to cover in a great show for you today. We're going to talk all about Jensen Wong's performance on the

00:29 Dwarvesh podcast and whether that leaves us with some concerning I don't know red or yellow flags about Nvidia's position moving forward. We're also going to talk about Sam Alman's conflicts of interest

00:41 that have been laid out in the Wall Street Journal and whether some investors want to potentially replace him as CEO. That's what they're talking about. And then of course we got to get

00:50 into this allird's GPU pivot. Joining us as always on Fridays is Ron Roy of Margins. Ranjan, welcome. >> Good, good to see you, Alex. I'm excited. This allird story I'm

01:02 definitely excited about. But >> this is all >> red meat. Ranjan Roy. >> Yes. >> Ranjan red meat.

01:08 >> Ranj on red meat. I think we should both state that we didn't wake up losers today. So, we're going to address the Jensen Wang uh car. You might be a car. We are not a car. All right. So,

01:20 obviously I'm referencing some of these uh very quotable lines that Nvidia CEO Jensen Wong had in a conversation with podcaster Dwaresh Patel this week. Um basically, you know, the interview's

01:33 gotten like a lot of play because uh Jensen, who's usually such like a calm, cool, and collected interviewe, um really did seem to get agitated. But to me, that wasn't actually the big story

01:44 coming out of this interview. I thought the big story was that. And uh while I'll caveat, Nvidia is still like a great company. It's going to do well. It's the world's most valuable company

01:54 at $4.8 trillion. But uh to me, the highlight was Jensen basically struggled to articulate a cohesive story on the two biggest issues facing Nvidia today. One is competition and the other is

02:09 export controls. Um and Ranjan, I think we can just go by go through those arguments one by one. I have some quotes from the show and sort of it' be great to get your take on each one. How does

02:20 that sound? >> Let's do it. >> Okay. So, Dwarkish basically leads off this conversation asking Jensen, which I

02:28 think is what I think is the most pressing question for Nvidia, right? Which is that Nvidia has been the company powering this AI moment. Obviously, OpenAI, which is the one that

02:39 sort of spearheaded everything, is a heavily Nvidia GPU reliant company, but and this is the way that Dwaresh puts it. If you look at the TPU, which is the accelerator that Google uh has been has

02:55 put out and Trinium, which is Amazon's version of it, um you know, two of the top three models in the world, Claude and Gemini, were trained on it. And what does that mean for Nvidia going forward?

03:08 Right? So you have Google's Gemini Anthropics Claude not trained on the GPU. So the question is what's the moat for Nvidia moving forward? Couple of responses from Jensen. I'm going to do

03:19 my best to capture them as well as I can. Um the first line that he said about Mythos, and this was in response to a China question, but I think this is really telling. He said mythos was

03:29 trained on fairly mundane capacity and a fairly mundane amount of it. He said uh for for um the growth of these competing chips, anthropic is a unique instance, not a trend. Without anthropic, why

03:44 would there be any TPU growth at all? It's 100% anthropic. Without anthropic, why would there be tranium growth at all? It's 100% anthropic. I was not impressed by the defense here

03:59 from Jensen. I mean, I didn't get any clear answer from him on why Nvidia will maintain its lead if these two, as Dwarish put it, two out of the three best models have been trained

04:12 elsewhere. Am I being too harsh? >> Okay, I'm going to I'm going to make myself a little vulnerable here, Alex. I listened to the entire interview. I will say as someone who works in and bre

04:25 lives and breathes AI all day, there was a lot of it I wasn't fully understanding. So like walk me through and and I'll say the AI infrastructure side of the world that's where uh John

04:37 who I write margins with that's his world. Um so like explain to me what the v what their vulnerability is here again if it's uh their training on TPUs around tranium like like walk through this

04:54 argument and why that presents a vulnerability for for the normies like us the business folks >> I mean it's very simple and I don't think we have to overthink it like we

05:04 can get into the technicalities like Darkh did but I don't think we need to I think the point is that the GP GPU is seen as the perfect technology to train AI models on, right? Just because of the

05:17 way it's constructed, right? It can do many different um processes in parallel and that uh allows you to do this sort of matrix multiplication uh that you need when you're doing AI. Um I think

05:30 that's about as technical as we should get. But to me the the bottom line is that that you have Google, you have Amazon who have made alterations to CPU chips that have done a good enough job

05:40 here and helped Anthropic and Google train excellent models. So then the question is what is Nvidia's moat going forward and I didn't get like a complete coherent answer uh from Jensen. So at

05:56 that layer, I mean, Jensen and I'll say that I think this is the first time I've actually listened to a full hour or whatever it was with Jensen Wong, and it was very interesting. I I I now really

06:09 understand how good of a salesperson he is, cuz my god, like every line of his was just so pointed around like we are the greatest God's gift to earth company and no one can touch us. He certainly

06:22 made the ecosystem argument at every level and he made the capacity argument at every level. So I'm going to if I'm going to take the Jensen side here, I think his argument is yes, you can like

06:33 from a pure model training standpoint that potentially there is some competition, but in terms of actual like ex being reliable capacity for all of the ecosystem rather than just if you

06:47 are Google, yes, you have access to your own TPUs. I think that's his argument. I mean, he said CUDA over and over again in terms of >> the software that these models are

06:57 trained on that's linked directly to Nvidia infrastructure. Right. >> Exactly. So, so he is saying it's the stack. It's no longer the chips alone. It's the stack which I'm curious again I

07:08 I will say as an I'm not an infrastructure guy. So like it sounded convincing. He was certainly I would say this versus the China answer. I at least walked away when he was talking about

07:20 like, you know, like their relationships with suppliers and TSMC over 30 years and always being able to deliver expansion of capacity and like like that was the argument. That was definitely

07:33 his take rather than the individual chip. To me, that's what I had walked away from. Do you think that's not uh not a reasonable moat for Nvidia? >> Well, I would say the push back here is

07:46 again I don't think you need to be technical on it. The push back here is take a look at the bifurcation who is right now I would say the leader in foundational models at anthropic. Um

07:59 then you have Google and open AI who has spent globs of gobs of money on Nvidia chips. >> Globs and gobs gobs >> gobs and gobs of money on chips in

08:09 thinking they could brute force their way into this race. Meta and xai. Has it worked for them? >> No. So um I I think capacity is though

08:22 however like I think that that might be the best answer which is basically like and if I was Jensen I might might have put it this way. All right you want to take anthropic as an example. What is

08:33 the one thing that people say about anthropic when it comes to criticism? They get rap >> of capacity. Yeah correct lack of capacity.

08:40 >> So I think that really is that would that would be the better argument. Um, like there were some I think he could have just made that more clearly. >> You're right. Like now that I mean you

08:52 just said it. He didn't just say that. He I mean I think you're explaining Jensen better to me than Jensen did himself cuz like he was kind of going very technical being a bit bit

09:04 standoffish but didn't make that point super simply and clearly. And when it's said like that it actually starts to make a bit more sense. >> Yeah. Yeah, and there's no love lost for

09:15 Daario. So, I don't understand why uh why he wouldn't have just come out and say that. And then when he talks like Dwarish also brought brought up these other companies that use TPUs and Jensen

09:26 had a weird answer on this one. If they don't try these other things, how would they know how good ours is? Sometimes you've got to be reminded of it. Like what? They're spending billions of

09:35 dollars with other companies just to be reminded of how good Nvidia is. No, clearly these other companies are serving a need to them. And Nvidia is also moving uh in in this direction

09:45 right remember they acquired uh the or they they aqua hire zitioned the top talent from Grock not Elon's Grock but this Grock company that's meant for inference and that was one of the big uh

09:57 answers for them in um in their GTC conference this this this year. So, uh, I I think honestly the the the better answer, the more honest answer from Jensen would have been, look, we have

10:10 competition now. We acknowledge it, but we have the capacity and you could tell that people that use our models, you know, are are being are able to surf them, you know, but there's there's a

10:21 counterpoint to that also, which is like, well, maybe if people wanted to use Meta's models more, they would also have capacity issues. I think it's it was I mean again as a

10:32 noninfrastructure person just listening to the interview one of the most fascinating parts was exactly that like I I agree like just say yes of course there's competition

10:43 competition is healthy rather than his entire argument is like you can't escape us we control the stack and like you have to come to Nvidia and there's no other options and I mean it was

10:55 basically like I mean We are a monopoly for majority of the AI stack and that's just the way it is and good luck. Go try something else. But it's not going to work because we own the stack. So yeah,

11:07 I think I don't I feel do you think humility would be better for him in these cases or because again or is this just why I mean you can't argue with what he has done within video over the

11:20 last couple of decades especially the last few years. So if that is just how Jensen does Jensen, I mean I guess you should we not expect any humility or would humility be better?

11:34 >> I don't think he has to be I mean that humble but I think grounded in reality would have been good and and I think you especially saw that come out on this export controls conversation. All right.

11:45 So, so this is really where um and I think you're, by the way, I think you're highlighting exactly the issue here, which is that I think Dwark was asking good questions. It got somewhat heated,

11:55 which was interesting to see, but again, it's not the heated nature of this conversation that I kind of pick out here. It's sort of um this this uh I don't know, Jensen's Jen for for

12:06 whatever reason, Jensen just could not get this coherent message or cohesive message out. Uh, and I think a lot of it maybe it did have to do with some some lack of humility or an inability to

12:19 nuance. Right? To go back to our show's theme, there was no nuance from him at all. So, so let's go to the export control thing because that really gets to it here. So, Dwark made a great point

12:30 which is that Anthropic, I'll quote anthropic announced Mythos preview. They said it has such cyber offensive capabilities that we don't think the world is ready until we make sure those

12:41 zero days are patched up. So if Chinese companies and Chinese labs and the Chinese government had access to the AI chips to train a model like Claude Mythos

12:50 um wouldn't it be and now I'll paraphrase wouldn't it be a vulnerability to the US as opposed to now where we have more compute and we have this heads up to make our

13:00 institutions ready and over and over again dwarf she asked Jensen to acknowledge if we give you know that much more compute capacity to China isn't

13:12 a a risk of cyber warfare coming from the Chinese side and and creating vulnerabilities where we're not we're not um ready and Jensen did not have a good answer wouldn't actually answer on

13:26 this well even and I mean I saw some tweet around this around like that the the great part of Dorish having technical fluency in this interview was Jensen even said well China has 60% of

13:42 the world's chips, but recognizing that chips aren't the measure that they're talking about. It's compute and that China only has 10% of the world's compute. So, they still could be

13:51 contributing to this. I think it's again, this is why it was so baffling to me that he was that standoffish is it's a pretty nuanced conversation like export controls to China, what's already

14:05 done, what can you prevent, like what are that's going to happen anyway. And I thought I'm surprised from like a comm's perspective and I know I always bring everything back to comms that there

14:15 wasn't a better answer that like this is one of the biggest questions facing Nvidia that there was export controls then clearly they had pushed back themselves and got them removed and did

14:25 whatever they had to do. And so like this is such a sensitive topic and it's going to be on an ongoing basis that like why wouldn't you have a better answer that than I am we are not a car

14:37 which >> I I got it after I saw the the so >> explain the we are not a car thing. >> You're not talking to somebody who woke up a loser and that loser attitude that

14:49 loser premise makes no sense to me. We are not we're not a car. We are not a car. That is a loser premise. Like the whole loser thing, Dwarkish never said loser, which was so crazy to me that he

15:03 just went on this tirade about losers, which I I don't know where it came from or what that triggered. >> Okay, sorry. I can explain it. Basically, what what Dwares was saying

15:11 is US companies have a history of getting into China and then losing to China in the battlefield that they they created. And the car example comes from Tesla got into China, right? And whether

15:25 it was through cor I'm just going to speculate here, corporate espionage, very good mimicry, uh, break down the cars or whatever, China ended up crushing Tesla, right? The Chinese EV

15:36 industry right now is the world's best. And so, could it be the case where like, you know, even if you get into China, you're event, you know, you help them with their technology and then they they

15:46 they replace you and all you've done is accelerate China and then lose. And that's where you get the I'm not a loser mentality >> and the car mentality. See, Alex, I

15:57 think >> I think you need to do like a Jensen translator uh app where it goes over and just kind of explains in a much more clear kind of like way cuz Yeah. Okay, I

16:08 get it that way. But again, he literally starts going like we don't that's a loser premise. I don't wake up a loser. We are not a car. And that's kind of as far as the argument goes. And it just

16:20 sounds like just I mean it's it's just made for a viral clip in not a good way. But do you think like what do you think Nvidia should do? Cuz I also found it a little awkward as the conversation goes

16:36 on where it's like the we need cooperation. 50% of the world's AI researchers are from China. They have the world's best AI researchers. Like we need back and forth. we need to work

16:49 together which sounds great in theory but is a little kind of overly aspirational. So he goes into this whole like better together story and then at the end he's like but the US is great

17:00 and the US is the leader and like it was just almost this like you feel like this like the US government over him knowing he has to kind of kiss the ring a little bit and like say oh by the way no but

17:13 the US is the best US is the leader like it just I don't know the whole thing there needs to be better answers for prepared. >> Yes. Okay. Okay. So, can I go back back

17:22 into my um you know, coaching Jensen on comms here? And I want to acknowledge that Jensen is in a tough place. >> Remember, he's uh he's he's accountable basically. He's trying to balance

17:34 shareholders, public opinion, US government, Chinese government. Not easy. Um and in fact, and sales, right? He's trying to sell. So I think one of the things like Dwark you know one of

17:48 the weak points even though it might be true and sort of there's there's a balance here because you always want executives to be honest but like but but Jensen's Jensen's core argument is

17:59 selling these chips everywhere is good for the US uh good for western values uh but then he gets pressed by Dwar Dwar is like just acknowledge the fact that if you sell this into China who has data

18:10 centers open and ready to plug them in you're creating a potential cyber security risk for the US. And Jensen goes, I just want you to acknowledge that any marginal sales for the American

18:20 technology is beneficial, which is, you know, sort of like you can't, it's either I want to make sales or I'm good for the country. Um, sometimes those things come in conflict and that's where

18:31 he was weakest in saying uh and he he really couldn't hold those two things in balance >> because because they're not they're not in balance. They're not in balance.

18:41 You're right. Sorry. Go ahead. Yeah, but this is the this is the most ridiculous part of this and and I I almost like feel bad that he is the one who has to kind of defend something that is

18:52 impossible to defend because it is an eitheror situation. Either you are working with the Chinese people and research community and economic ecosystem

19:06 or you're not. And like there's good and bad to both. But in reality, in a in a normal state of affairs, this would not be the job of the private company. The private company should only be saying we

19:20 will sell to China. And it is the responsibility of the government to make the decisions that are on the geopolitical like it. It is in Nvidia's best interest as a priv or sorry public

19:32 company, but still you know like a they are responsible to their shareholders. I do believe that and selling to China like they should be doing that. They're they're incentivized to do it. There's

19:44 good arguments for it and it should be the government's kind of like role and responsibility to decide what is the best interest of the nation and have the best understanding from a security

19:54 standpoint and everything else. But everything is just so out of whack right now that we're depending on Jensen to be both CEO of public company and kind of like security and trade minister and all

20:08 of the above. So I I think I'm I might be going back to Jensen's side that it's he's put in an impossible situation there. >> No, I agree. And and he he became

20:17 visibly angry because this kind of talk has led Nvidia to lose some leadership position in China which he can't be happy about. Remember there have been export bans they've many of them have

20:27 been lifted but okay now now I want to sort of this is where I was trying to get here all right there is a good argument to make and I think some of Jensen's conf or uh balancing act might

20:38 have limited him him uh in the ability to make it all right so the argument and he made a version of this at the end and I think this was the strongest part of the whole conversation for him the

20:48 argument to be made is that listen you are dealing with LLMs this there is real cultural soft power in having your influence on LLMs diffuse through the United States. And there's going to be

21:04 two different one one of these two options of LLMs that will be used globally. An LLM with and and the truth is there's values baked in. An LLM with American values baked in or an LLM with

21:16 Chinese values baked in. And if you're being honest, the way that it is going to diffuse is through open source. So you have two options here. One is you influence the way that the open- source

21:29 direction is going to go by having it built on Nvidia's tech stack which is going to have American values which is going to open the door for Americans who are used to working on Nvidia to

21:41 influence and contribute to open source. The other option is you you shut the door to China. You make two competing ecosystems. One is this closed American ecosystem that is great great technology

21:55 but isn't globally adopted like anthropic and open AI and two is by shutting out the Chinese what you're incentivizing is a separate ecosystem where Chinese values will be baked in

22:06 they have they have the worlds they are they are going to lead open source without Nvidia participating and all of a sudden their values will be diffused into models that are used in Africa in

22:18 India and across the world and and Jensen I'll just say this one thing. Jensen does make this argument at the end. Not quite on the nose as I would have liked, but he does. He says, "The

22:28 fact of the matter is that we get to benefit. We get the benefit of American technology leadership. We get the benefit of developers working on the American tech stack. We get the benefit

22:37 as the AI models diffuse into the rest of the world that the American tech stack is therefore the best for it." >> So that's my point. >> I got two questions on that. one.

22:47 >> Yeah. >> Walk me through how exactly you think an LLM reflects the kind of soft power and cultural values. And then two is an American

23:01 company. I think like I saw Brian Chesky in Airbnb kind of talking about how now a much higher percentage of their workload is actually deployed on Quen from Alibaba because it's cheaper. And

23:12 I've actually I've seen a number of people talking more about that and especially as in the last week there's been all this talk around how anthropic has been subsidizing and the real bill

23:21 is coming and like cost management is going to become the next frontier in Agentic like moving like is it okay that for if you're calling Quen for your uh for your workload or is that unamerican

23:35 as well? So, those are my two. What's the cultural values? And then what's is it can we use Quen to process our podcast transcripts and still be America first?

23:47 >> It's a good question. So, it's not it's not black and white, right? There's nuance here. If you're building an enterprise software application or if you're trying to do uh hotel bookings,

23:55 fine. But let's say there is a uh a proliferation of AI consumer apps out there. Um, and I don't think this is fear marking. I think this is true, right? What happened when you tried to

24:06 search for Tanaman Square in Deepseek? It was blocked. Now people were able to modify Deepseek and uh and you know strip that out, but it was only after modification. So I think you would you

24:19 know if you're thinking about like and again this is this is the argument I think Jensen should make. I'm not 100% sold on it. Um but if you're thinking about like all right uh if these models

24:30 diffuse through the world and there are going to be applications built on top of them um who's who's who do you want to set the weights you know the Chinese Communist Party or everybody else um I

24:42 think the you know the preference would be everyone else that would be the argument if you're if you're Jensen I think that's a strong argument >> no I I do think it is interesting to me

24:52 that like if the next soft power battle across Ross the globe is is at the LLM level. I think that does make a lot of sense and we should be but again that's not Nvidia's decision to make like uh

25:07 that >> but it has of course it's not his decision but it is a it's a core it's a critical part of its business and it's something that you know while maybe

25:16 unfair Jensen should be better on when he talks >> I I agree. I mean, I think the the main takeaway on all this is this is going to I mean, going into an election year with

25:27 AI is it's going to be the poster child for everything wrong with the world and then China is the these are the two single biggest like political negatives right now, China and AI within the US.

25:42 So I think uh maybe not the biggest but two of the biggest and like you got to be better prepared for that. That's that's the main takeaway. >> And I think Dwark had a great point by

25:53 the way which is like right now as we speak US institutions including the US government which we're about to get to are evaluating mythos before it's released to the public. So wouldn't you

26:05 want to be first? And if you give more compute to adversaries who we know are trying to, you know, at least hack into your systems, uh, you're you're putting yourself at risk and that's that's

26:18 that's always going to be the compromise. >> All right. Well, walk me through what's happening on the US government side this week.

26:27 >> Okay. So, so first of all, I think let's just start with this. Last week, we had a big discussion, mythos or marketing. Uh, mythos real or marketing. Um the I I you know I don't think you can say 100%

26:40 conclusively now but certainly the data points suggest that mythos is more real than marketing which is kind of crazy. Uh this is from the AI security institute. I brought this brought this

26:50 up at the Pentagon this week with Emil Michael we're going to talk about in a moment. They say we conducted cyber evaluations of claude mythos preview and found that is the first model to

26:59 complete an AI SI cyber range end to end. The range simulates a 32st step corporate network attack from initial reconnaissance to full takeover. Uh and we estimate that it would take a human

27:12 expert 20 hours to complete. So of course there's some flaws in this evaluations. Uh but the fact that mythos was able to complete this end to end uh is a bit spooky. And I think that you're

27:23 starting to see um the seriousness of the mythos model manifest itself in the way that lots of companies and and especially the US government are dealing with anthropic now because there seems

27:39 to be a universal acknowledgement that uh whether it's mythos or whether it's the next iteration of this, you got to take this stuff seriously. So, I'm going to not say we shouldn't

27:52 take it seriously. I've had more questions on this in the last week since we spoke last Friday when I walked our listeners through what was clearly a very very coordinated PR stunt about a

28:04 sandwich in the park from Anthropic. And I actually had spoken with a few listeners and like and it was funny because it's that becomes so clearly a marketing tactic. So what I had spoken

28:15 about this week was is Mythos like glasswing and the way it rolled out and and I again cyber security as well is not where I've spent a lot of my time. So like typically

28:31 if you have this model that can do these zero day exploits and can actually start to piece all of this together and like why make such a big deal about glasswing like normally what like any any model

28:48 rollout would have had some kind of security check and maybe you're working with other uh companies as well but instead they made this like and and I spoke with someone who works at one of

29:00 the large companies who's on the cyber security team who was kind of like invited to be part of glasswing and the way they were speaking was literally like they got into like were like a VIP

29:12 invited to some event like it it it the marketing is when it's that good I just I have a hard time believing it but but what what do you think is actually do you think there is

29:26 a step change with myth OS that actually represents some massive new vulnerability and it's actually going to be patched up in the next 3 to 6 months as Glasswing gets together and finds all

29:38 the potential vulnerabilities. >> Do you think that's Go ahead. >> No, do do you think that's what's going to happen aside from the marketing but then also address the marketing as well?

29:48 I'm curious. >> Okay. First of all, I'll say there this is the counterargument and I think it's really good. people have said marketing at every step of the way, you know, and

29:59 we've talked about it also and the capabilities just get keep getting better. So, at a certain point, like when are you going to say, "All right, well, maybe this is real or not." I

30:07 don't know. I I can't tell you. I don't have an answer, but I can tell you that it's working. >> Um, >> oh, it's working.

30:13 >> It's working. By the way, I just thought like, wouldn't it be Wouldn't this just be a setup of like a great movie uh where Daario just like takes a heel turn and says, "I tried to be nice. I tried

30:24 to tell you what my models can do. You didn't believe me. Now I will use the power of mythos for evil and make a society believe in the technology I've created. And he just becomes this black

30:38 hat cyber hacker takes down society and bends it to his will. >> That's what like guys for how good the marketing is, that's the picture you are painting in our heads with all of this

30:48 talk right now. Like if you really cared, like I get there's value, marketing value in like creating this godlike complex around the models that are being released, but it just makes

30:59 people more uncomfortable with with the industry. Like actually so what I can't get through is like okay let's say you have this in your hand and you realize that if we are to release this this will

31:16 has the potential to kind of like make every single small medium and large company completely vulnerable to hacking has the potential to kind of like take down the entire fabric of our economy

31:28 the digital fabric at least like like what would you Do would you do a coordinated press release and have a project glass swing and and then still work on releasing it because you just

31:41 raised another 30 billion at $380 billion valuation and like still keep raising like wouldn't you take a pause and just be like maybe we should all just try to address what's actually

31:52 happening here rather than coordinate a marketing campaign that leads to another funding round that lead I mean wouldn't you try to fix it whatever like really fix it, not use it as a a lever to kind

32:06 of further the economic gains that you continue to acrewue. >> No, because the idea is and but we should move on because this we talked about this a lot last week. I think the

32:16 idea is it's all intertwined. you need to keep growing to keep ahead so you're able to give this to certain companies to try ahead of time because otherwise you might have you know well I mean they

32:29 would say companies that are less trustworthy but I think Dwarish made the point that it could be other other um countries with different values that get ahead and then all and then all of a

32:38 sudden they start the hacking and we saw this by the way um this this uh the downstream effects of this with Dar with Daario uh on his way to the White House. He's actually there today. This is from

32:50 Axios. Uh anthropic CEO Dario Amade is scheduled to walk into the West Wing on Friday for a meeting with White House Chief of Staff Susie Wilds. A breakthrough in his effort to resolve

32:59 the company's bitter AI fight with the Pentagon. The Trump administration recognizes the power of anthropics new Claude model mythos and its highly sophisticated and potentially dangerous

33:10 ability to breach cyber defenses. It would be grossly irresponsible for the US government to deprive itself of the technological leaps that the new model presents. A source close to the

33:20 negotiations told us it would be a gift to China. Oh, that sounds like anthropic coms to me. U what do I know? Um but uh but but look, there's now there's now I think this is a good thing. There's now

33:31 a thawing it seems like between anthropic and the federal government. So um I think if you're the federal government, you have to take this seriously. And if you're anthropic, I

33:41 think you're doing the right thing. by getting in there. And is there a chance it's marketing? Maybe. But ultimately, I think that this is sort of the news here is that this is going to create a at

33:50 least a thaw between Anthropic and the White House. >> Well, but again, what do you think would happen if they release Mythos today? Like, what do you think would really

34:01 happen? And what do you think will happen with in the current way they're rolling this out? Like do you think if they were to release this today that cyber that hackers would penetrate every

34:14 defense for even the largest companies in the world or >> No, not necessarily. I mean we spoke about it last week, you know, we don't we but clearly there's some there's some

34:24 incremental I mean incremental abilities I the the institute that I quoted earlier like they are independent as far as I'm aware. I think they're UK based. I don't think they have any incentive

34:36 to, you know, fluff this up. Um would Microsoft Microsoft's in this uh in this um you know, Project Glass Wing. They're big investors in Open AI. So, I don't know.

34:48 >> Anyway, I think we should move on from the the marketing, but you can get a last word in. >> One last thought. Rather than your Daario heel turn that sounded kind of

34:56 like an Avengers movie, I want to see it go the other way where actually Daario and Sam come on stage and OpenAI has been invited to Glass Wing and together they are giving mythos to their biggest

35:10 competitor and everyone is going to make this work hand in hand. That's that's the plot twist I want to see. >> I love it. Maybe even hands holding hands like they didn't do previously.

35:21 But >> yeah, exactly. But I think you're right. I think peace is a good is a good place to take this because we could see peace between Anthropic and the Pentagon. And

35:30 of course, I was in uh the Pentagon earlier this week speaking with Emil Michael, the under secretary of war, who is the one that banned Anthropic. And I asked him, you know, you've made you've

35:40 made uh uh peace with um with Google, who was on the out with the Pentagon for a while. Can you make peace with Anthropic? And he said, "I think so." He said, "I hope that I hope that companies

35:53 as they get more mature and more of an understanding of what it means to work with the government and understand us better get to a good spot hopefully sooner than 8 years." I think that was

36:00 interesting. It was the first interview where uh Emile opened up the door to possible reconciliation uh with Anthropic and I I think that's a good thing.

36:11 >> Do you think it'll happen? >> Yes, I do. I really do think that that this is that they will they will find um some common ground and get back to work together. I think the Pentagon likes

36:23 anthropic. Honestly, >> they're just >> the technology. >> They're clawed pilled. >> They are. All right. Um before we go to

36:30 break, I do want to address something because we definitely had some and I don't know if I really should. I don't want this to come off as defensive, but I think it's like good to like take a

36:39 moment to sort of explain uh the way that that I you know I operate on this show. Um and uh and there were some questions about like why did you go into the white to the Pentagon and and ask

36:49 these questions and um you know uh here I'll just read there was one uh review on on Apple podcast uh that I think is worth addressing. Alex displays a clear pattern of showing deference to the rich

37:00 and the powerful. His interviews with OpenAI and Trump admin leaders have been extremely differential. His questions to Daario were much more pointed and journalistic. It seems like Alex is

37:09 truly dedicated to sucking up to the most evil people in America. The episodes with Ronan are cool, though. Two stars. Um, first of all, I'll just say uh we I I appreciate listener

37:19 feedback. I I I'm glad to hear from listeners. I It's a privilege to be able to do this show for an audience. So So thank you. I'll also say the two star reviews really are they they they

37:30 they're aimed at they they they in practice um have an effect of really harming the show. So um I'd much rather these come in through big technologyodcast@gmail.com

37:40 which is in the show notes. Um or if you have a criticism fivestar and write it and we'll take it seriously. >> Send us hate mail. Send us hate mail. I but I do I I do think it's worth

37:50 addressing sort of the style that I have of interviews and sort of what happened with Emil. >> Hold on. I want to I want to ask you I'm going to put Alex on the spot here. Like

38:01 one of the fascinating parts of the whole dwarfish Jensen interview is like everyone's like, "Oh my god, it was heated. It was pointed." In reality, 10 years ago, that would have been any

38:13 normal interview because like and now we have the podcast circuit and I'm certainly going to exclude big technology podcasts from that and I think you do push a lot of the guests in

38:25 a hard way, but like how does it work? Like cuz if you rip apart a CEO, does do people want to come on the show? like how do you balance that tension at a personal level like to try

38:38 to make this a success? >> So I so this is great setup because this is my my philosophy here. Um I really think the job is to get news makers in the room and ask them the hardest

38:49 questions possible. I think the reason a lot of these uh you know TV interviews or these hard interviews and these back and forths did you order the code red? You know there there is there is value

39:00 in asking officials tough questions. I think the reason why people became disenchanted with the media is because it became more about showboating for the journalist and more performative than it

39:13 became inquisitive trying to find the answers to these tough questions. Um, and you know, I think Jensen became very defensive in this conversation with Dwares, which is why it led to this sort

39:24 of heated back and forth. But my style in particular, I I try to go in I want to ask the people I'm sitting across from the hardest possible questions I can, but I also want to do it in a

39:36 respectful way. I want to have a conversation about it. For me, it's not about a performative thing. And I think if you look at the transcript of the conversation with Emil, even though it

39:45 was conversational, there were there were, I believe, tough questions there. I mean, I I mentioned to him that, you know, I'm puzzled by the supply chain risk designation. I I mentioned to him,

39:56 if you were so close to being willing to work with Anthropic, um then how could they end up being a supply chain risk on Mythos? I mentioned um wouldn't you want this tool at this disposal? You're

40:07 putting your are you putting yourself in a corner when you're not taking these capabilities and using the and using the ones you want? And then on on this idea that Anthropic could shut them off. You

40:18 know, I think I I mentioned like you you have Claude, you could have you are building a system with Claude, Grock, and OpenAI in there or you're on your way. Um and if Claude doesn't update you

40:27 don't like, you wouldn't you just be able to run OpenAI on it? So why shut off the relationship? For me, I don't think I need to yell or sort of be like, you know, did why did you do this? Uh, I

40:37 think it there there is like basically the what I want to do is to to ask what I'm curious about, get the toughest questions in front of these people, but also do it in the context of a

40:46 conversation. And if there's there and I'm open to all forms of criticism, if there's like this was too conversational or the push back wasn't good enough, I'm open it. the, you know, I would say

40:58 don't mistake the conversational nature for this idea that these people are getting a free ride because if you listen to any of the more recent uh interviews with Emil, uh I those

41:08 questions were not asked. So that's just my piece and I thought it was worth saying. >> No, I I not to not to glaze Alex here a bit for listeners, but I think that is

41:17 Yeah, I think that's what I find valuable and I do like that that like you can be it doesn't have to be confrontational like and any leader at that level I feel should and I that's

41:29 probably why the guests you are getting are just getting kind of crazier and crazier good like I mean like if you're at that level of success you should want tough questions you should be ready like

41:40 that's I don't know like maybe it's being a former debater myself but uh you should want tough questions and most do and they they it like makes them better and smarter and yeah I think uh there's

41:54 not enough of that out in the world. So, so even for this listener, I uh just like they like the Friday shows. >> They like the Friday show. >> You're saving this thing for

42:06 >> We got to disagree when we come back on Sunday on Alberts. Um >> Alberts, you got to say it's good. >> Yeah. But I don't want my my point here

42:16 to be mistaken as please don't criticize me. I'm open to criticism. I want to hear it. We have the email address big technologyodcast@gmail.com. I I take the comments seriously because

42:25 again like um this is this is only possible because we have an audience and uh and you're if you're listening or at home or watching your your opinion does really matter. So all right let's take a

42:37 break and come back and talk a little bit about Sam Alman. We'll be back right after this. And we're back here on Big Technology Podcast Friday edition. Wow. Uh today has flown by. Uh let's talk

42:47 about this story in the Wall Street Journal about Sam Alman side hustles, which is interesting because uh the headline was Sam Alman's side hustles blur the line between OpenAI's interests

42:58 and his own. That was not the story. Uh they the Wall Street Journal in this story about Sam Alman's conflicts. Um which he he he basically, you know, I'll just give it at a high level. He doesn't

43:10 really take a story from a salary from OpenAI, but he has these investments uh in like the OpenAI startup fund and in other startups and he's tried to get other startups to uh uh OpenAI to fund

43:22 some of these other startups uh like Helion, which is a fusion company, and Stoke Space uh which is uh a SpaceX challenger. This is the thing that really stunned me in the article, and I

43:34 don't know why this wasn't the headline. OpenAI leaders and largest OpenAI's leaders and largest investors say they support Alman, crediting him with the company's success. Yet, some

43:42 shareholders have begun to privately question whether he should lead OpenAI through the turbulence of going public and have floated board chair and former Salesforce CEO Brett Taylor as a

43:52 potential successor, said people familiar with the matter. Hold on. You're you're going to bury this notion that there are people there are investors on open there are open eye

44:03 investors who are so uncomfortable with Sam that they are already floating a specific name of a person to replace him. That to me is the story. Well, I think I mean in a way though it makes

44:14 sense. Like I think for all the problems that or all the challenges they're facing, they're not necessarily problems yet that have been realized. Like I feel like I mean Brett Taylor I think he's on

44:27 the board of OpenAI CEO of Sierra. Yes. >> Like he's uh I mean that's kind of like operator that OpenAI still lacks and Fiji Simo was supposed to come in and be that operator. Denise Dresser might be

44:42 that operator more so, but like they still haven't found I mean I hate the everyone remember everyone used to say like they're sh Cheryl Sandberg to Mark Zuckerberg like uh they're still looking

44:53 for it. So I think uh >> yeah it's it's not unreasonable. I think you're going to be seeing more of these kind of leaks at some point because there has to be investors. There's a lot

45:06 of money in it. there's a lot of kind of lack of clear strategy still even after they're supposed to kind of bring focus to the company. So I think you're going to be seeing a lot more of this as we

45:19 get into this IPO race and battle against anthropic. >> Yes. First of all, I just want to say I am mostly against this you need an adult in the room type of uh operator CEO.

45:30 >> You don't need a Cheryl Sandberg. I think they just they take out the imagination of companies and I much prefer I think founderled companies are where it's at and that sort of

45:39 >> no founder with the adult in the I feel like Snapchat like >> they that's one thing that always they never had

45:47 >> I think like uh overtly founder le I'm trying to then you have like an Nvidia where founder but years of maturity and development and then they hit their stride in and in insanely

46:01 successful way. So, yeah, I think >> an adult in the room is an adult. >> You're right. Especially as as an IPO approaches, right? And by the way, Brett Taylor, a combination of Sierra and Open

46:12 AI would make so much sense, especially as OpenAI goes after um goes after enterprises. It would be a perfect match. I I would be sh be stunned if they haven't talked about that within

46:23 Open AI with all this money that they have to >> But hold on. Oh, yeah. Go ahead. Go ahead. >> Wait, but he's on the Isn't he the chair

46:30 of the board? Yes. >> Yeah. How does that I can't even get but >> conflict of conflict of interest has never been a problem. >> There's no you know we've seen the much

46:41 weirder happen in this industry. >> That was the most naive thing I've ever said on this show. >> Get your head out of 1995. We're in 2026. Okay. But uh but you're right.

46:52 It's it is going to it is going to um you know sort of come to a head as this company goes to an IPO. And let me read on in the Wall Street Journal story. Am I excited to be a public company CEO?

47:04 0%. Alman said on a podcast in December. Am I excited for OpenAI to be a public company? In some ways I am. And in some ways I think it would be really annoying. He said on a podcast in

47:14 December. Hm. Which podcast was that? Wall Street Journal. But yeah, it's an issue for for I mean if you think broadly about Open AI, it is an issue, right? They they

47:24 >> let me just set the scene. I mean they have they they are chasing anthropic into to some degree or even a large degree right they're they're pivoting towards this

47:34 anthropic model of the super app um the Fiji thing you know of course it was for medical reasons but it's a pretty rough time for that for her to to be away and um and Sam is is doing his thing he's

47:47 obviously raising a money a lot of money that's critical but um but uh but it's not good to have questions about it's not good for your investors to be talking about a potential successor

47:59 while you're with less than a year away from an initial public offering. >> I see I'm going to I'm going to push back on that. Like people have been talking about potential successor for a

48:09 long time. >> Like again Fiji gets announced potential successor. Is that the real move here? >> Like uh Brett so so that part doesn't worry me as much. And again as you said

48:20 wait how much did they raise in the last round? >> 12 That's >> he's doing I mean if you're the CEO and

48:27 your job is to get funds he's doing an okay job wouldn't you say >> wait so so this was while I was out on vacation and I was in Utah and we got some snow and I was able to ski and I

48:37 actually didn't look at my phone too much and I like saw the headline. I'm like, how? But it it it kind of was just like a blip in the news cycle. Like $122 billion at $852 billion valuation. Like

48:52 I don't know how it's it's amazing. And they are chasing Anthropic strategically. They're going after enterprise again. Like Mythos gets released and then 54 cyber gets released

49:03 right after. It's like everything they're doing is right after anthropic and following them. Yet they freaking raised 122 billion and it's just become so par for the course now that that

49:14 wasn't even the biggest story in the world or at least in the tech world. >> Yeah. No, I mean you're right. I mean and that's all Alman. So uh I I don't know if others

49:26 >> he's doing his job. Yeah. >> Yeah. Okay. We we are we are running up on time and we need to at least leave seven minutes to talk about allirds. Okay. Can I can I begin just by read I

49:38 mean this is one of those stories where you you see the news come in and then you just wait for Matt Lavine at Bloomberg to weigh in. So if if you will allow me to just read Matt Lavine. He

49:48 says, "I feel like if you ran a big technology company and you were looking to expand your artificial intelligence capabilities and needed to rent access to GPUs and you said uh and a and a GPU

50:00 as a service/AI cloud company came to pitch you and you said so tell me a bit more about your company." And the company said, "Well, two weeks ago we were a sneaker company but have since

50:10 pivoted to AI." You might say, "Huh, but thanks but no thanks. We're going to go with someone with a bit more AI expertise." uh and actually a data center. Um but maybe that's wrong. Maybe

50:20 the sneaker guys are great at AI, but you might worry. But if you said, "So tell me a bit about your company." And the company said, "Well, two weeks ago we were a sneaker company called

50:30 Allirds, but we have pivoted to AI." Your reaction might be different because in this hypothetical, you run a big technology company, and you probably spent years wearing Allirds. I used to

50:39 love Albertirds. You might say, "High five." And then you might sign a long-term cloud hosting agreement with the former Alberts because like many tech executives, you have a nostalgic

50:49 fondness for their brand. Um, it's not likely, but it's worth a shot. This all sets up the fact that Albert's uh pivoted to an AI computing infrastructure company this week. Their

51:01 stock went up 582% on the day of and somehow uh they are this is this is a real thing that happened. I mean, Bronj, what the hell is this? This is ridiculous.

51:14 >> So So I know we only have a few minutes left, so I'm going to try to be uh a little concise with this story, but >> you you go go five. You have five minutes. It's all yours.

51:23 >> Allirds, I have a very long relationship with the company in the sense that so I worked for a number of years at Adore Me, a direct to consumer intimate apparel company. In 2021, we were we

51:36 were at like 250 million revenue. we were like looking at going public. Um, and that was as Allirds was going to market. This was there was actually 2021 summer into the fall was this kind of

51:47 like DTC, Rent the Runway. There's a number of other DDC companies that went public and I loved this Matt Lavine part because the bankers we spoke with like all wore allirds and they were the they

52:04 were like the ones the only ones. the VCs were the only ones there and it actually you could tell affected Allirds at kind of a similar slightly larger revenue went out to market at 2 billion

52:17 on the first day popped to a $4 billion valuation. It was like 20x 18x price to sales which is insane is insane. But the momentum of the people with money who do the investing loving the brand actually

52:32 being the ones to push it and the stock just collapsed. And the reason this was so funny is like it became a penny stock. They essentially went bankrupt. They got bought out for I think $39

52:41 million in the end. Um I'm sure most people don't see anyone wearing allirds around. They shut down all their stores. But but I kind of like this ridiculous pivot. It's just it's like you have this

52:56 asset and that I I this is why Matt Lavine is Matt Lavine. He he got it that is the asset this nostalgic like it's almost like you're buying a marketing asset and a brand asset rather than

53:09 you're just a nameless face faceless GPU AI cloud is a service company or whatever. And it's obviously like the stock market. It's almost bad that the stock popped 600% on the first day and

53:23 then collapsed I think 580% the next day. Like uh >> No, no, it collapsed some like 80 something% but it's back. It's back up. It's up 191% on the week.

53:32 >> No, no. Yeah, but it's at a $105 million market cap right now. I just checked. I mean, but again, if your company is essentially worth zero, that's still a pretty good market cap. But I kind of

53:42 like like buy up this is my new private equity uh idea for everyone. If anyone wants to run with it, go with it. Go buy any dead brand that investors and VCs and tech executives and bankers loved at

53:58 some point. Just take their name and turn it into a GPU company as a service company. Whatever. Take the most boring infrastructure business you can imagine. go buy some uh what what do you think

54:12 some good 2010s tech brands are that are that have left us? I'm trying to think what what else could be in all birds, but that's my idea. There's got to be a portfolio of Go get BuzzFeed. Go get

54:23 Buzzfeed. >> Buzzfeed would be good. We >> Work TPU company. take all those 2010s and uh cuz I actually saw there was something around like like dead startups

54:35 are actually able to still sell their Slack threads and email lists and stuff for training data for AI >> which is horrifying. No, no, but let's take all of the all the graveyard of

54:48 2010s and bring it back and just they're all going to be GPU as a service companies, but that industry is so unsexy and there's so few names available right now that are memorable.

54:58 And there's slap on Weiwork, Buzzfeed, Allirds, whatever else. And uh that's the idea. Start your rollup company >> that that will turn the tide on AI. It's you take these beloved consumer brands,

55:09 you turn them into GPU companies and all of a sudden you see the AI ratings uh in the polls just go through the roof and Jensen starts nailing his his interviews and uh the Pentagon and Anthropic and

55:21 Anthropic and OpenAI make peace and we all live in a better world. >> That's peace. That's where we're going to end up if you follow this idea. >> We can only hope. We can only hope. All

55:31 right, let's end on this message. Ranjan, thank you again for coming on the show. Appreciate it. World peace is a good place to end. >> World peace. Thank you to you the

55:39 listeners. We'll see you next time on Big Technology Podcast.

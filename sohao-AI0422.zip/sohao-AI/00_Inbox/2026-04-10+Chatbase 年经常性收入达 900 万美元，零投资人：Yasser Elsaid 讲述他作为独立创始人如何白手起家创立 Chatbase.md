视频链接：[https://www.youtube.com/watch?v=xTtynSB1Aak&list=WL&index=5&pp=iAQBsAgC](https://www.youtube.com/watch?v=xTtynSB1Aak&list=WL&index=5&pp=iAQBsAgC)
视频发布时间：2026-04-08
频道名：Solo Founders

## 转录内容

00:00 Having a slightly like below average co-founder is much much worse than being solo. I wasn't like following the footsteps of like go first you need a pitch deck and then you talk to

00:08 investors and then try to find a co-founder and then hopefully you raise money and then you start building. I just saw the opportunity and I started building. Dictatorships make your

00:15 chances of success much higher. If you have trust in the founder and you think they're smart enough and they have input on how to build the product and how to get customers, then it should be a

00:23 dictatorship. You don't want them to be slowed down. If you bootstrap to 100 million ARR AI business, anyone would call that a success and like it's a success for the founder and for the

00:32 team. But I don't think it would be considered a success if you raised 100 million. >> What's the case for solo founding? >> The case for solo founding is that it's

00:41 very hard to lose. The biggest reason is co-founder breakup cuz if you don't have breakup, you can just like pivot or you can just try to raise more money or there's a lot of other options. I like

00:49 the fact that everything is my fault and like being solo gives me that satisfaction. Chatbase has had this incredible journey, $9 million in ARR in about

01:01 three years. There was this opportunity that you saw and I'm really curious what that opportunity was like, how you saw it because that ultimately pursuing it was the thing that kind of got you to

01:12 building this great business. So, we'll just start there. When you saw the opportunity, what did that look like? >> Yeah, this was very early on. This was even before Chad GPT was launched. I was

01:22 using the Da Vinci 03 models. So way back in the day, back then it was um there was no like API where you can uh send the chat and like get back a response. It was just you're talking to

01:36 the base model just the completion not chat completion. Um and then I saw the idea of this is a very powerful model but it doesn't have custom data. It doesn't have your data. And that in the

01:50 very first uh version of chatbase it was just uploading a PDF and then talking to it. So like my idea was uploading maybe a textbook or just like a book or a website or anything and then having a

02:05 chat with it. And of course now it seems obvious that this like makes sense and is a good idea and people would want that. But I talked to a lot of people back then and I don't know if it was

02:18 very obvious. I I think some people didn't see the value or maybe they saw the value but they didn't see the models improving. Um they just saw like what existed now and maybe

02:31 that was not super super helpful because the models were not there yet. But yeah, I had like I I thought there is a very good chance the models were improved because

02:43 um now there's all of these big companies that are working towards the same thing. So I think I I started chatbase with uh one a very good idea which is you know custom uh adding

02:57 custom data to like the base model and then I bet on the models improving which was not very popular back then um and I think that's how um we just like kept growing as the AI wave has been like

03:12 we've been riding it from since 3 years ago. So that's really interesting. But in order for you to even get there to to realize, hey, we should make it so that you can chat with a PDF for instance,

03:24 you needed to be exploring and playing around with these things. So what was it causing you to even play around with Da Vinci in the first place? Like where were you? Is I think that often times

03:33 when people are trying to come up with ideas and things to work on, um, sometimes they're trying to artificially do it. And it feels like in many ways you kind of came across this through the

03:43 process of exploring things and tinkering with things. So maybe you can give a little bit of a frame of reference for people when they're trying to understand how you approached it and

03:53 maybe that would be something that they could apply to their lives as well. Yeah, I think um like honestly the only there's no shortcut like the only thing you can do

04:03 is just to like try things and then because you're trying things and because you're talking to other people and because you're in the you know like in the group chats in the community, you're

04:13 seeing the new things that uh people are releasing, you're getting inspired, then you come up with a good idea or like at least you see potential in some ideas. So the way this happened for me was so I

04:27 was in my last semester uh in in university in Canada and I was always so I was doing internships but I was also doing side projects um with the goal of just like having something that can make

04:40 money. Um so this was I was like inspired by you know people like Peter levels for example. Um and I was doing other projects. I had the project called called rate my courses. I

04:54 had another project called uh SAPL but because I was you know like tinkering with things and um you know like trying the APIs trying to do stuff that the APIs can't do yet just like trying

05:09 things. I saw rag which was uh like I saw it very very early on and I think that was um you know the spark that started uh chatbase and it wasn't even called drag drag back then it was just

05:22 like I don't think there was a name it's just like you add data you augment you add data to a base model so that it can know more things um so I saw some people like like writing papers about that some

05:36 people were creating like CLI tools about that but there was no product that you can like open a website, add a document and then chat with it. Um, so yeah, I think for me it was obvious

05:50 that like this is something people would need. Um, and I just stopped everything I'm doing in university. I just like stopped going to class. And um I had the conviction that yeah like this is an

06:05 opportunity that doesn't come often and like to be able to see that very early. Uh and of course like I didn't know how big it's going to be but I had some uh conviction on like oh this might

06:18 actually be uh an opportunity and yeah I just stopped doing anything else and I started executing and then yeah I think like a month and a half after um I was coding by hand back then so it was still

06:32 slow. Um yeah, a month and a half after like getting the idea, I released the the first version of chatb. >> You know, there's two things that I would love for us to talk about, you

06:43 know, regarding that sort of early days of of figuring this out. I think that one is that people often think that they need to have the right idea and they kind of just try and go straight to

06:53 figuring out the right idea. It seemed like there were a bunch of things that you were trying and then ultimately you found chatbase sort of through that through that process of building those

07:02 other things and that ultimately caused you to you know put those other things to the side. So I'd be really curious just your philosophy and sort of what you learned around building those other

07:12 things that kind of got you to the position where you'd actually discover the chatbased opportunity. And then maybe the other thing would be really cool to talk about and I think would be

07:21 really useful for people to hear is how you how you actually got that sense that it was time to put the other things away >> and including school but but particularly the other projects and go

07:35 all in on this because I think that one thing that sometimes people have is they do that kind of try out a bunch of things but they have a hard time kind of abandoning them all and putting all of

07:45 the wood behind one arrow. So, so maybe talk about sort of that first part though and we can talk about sort of the focusing and and doubling down. How how do you think about sort of the process

07:55 of like tinkering with other ideas and how it ultimately potentially drove you towards discovering the opportunity for chatbase? >> Yeah. So, I think like the normal way to

08:06 go about things is that you, you know, like you look at the market, you look at competitors, you like research what they're good at, you see the reviews, you see what their customers are saying,

08:15 and then you from all of that research, you come up with a business idea. But I think in practice, I don't think any business started out like on day one with the idea that it

08:29 ended up being as it grew much bigger. And I think it's the same even for chatbase even after I saw that idea. Um so I think for me what happened was I I was working on on multiple things. I saw

08:45 one thing that it seemed to me like just from first principal thinking like it just seemed to me that this is very powerful and by just thinking about the effects of something

08:57 like this just like sitting down and thinking it's just no no market research no no talking to users nothing like that and I think that's the only way in a fastmoving industry like AI because you

09:10 don't have time to talk to users because there is no users talk to like this is like you are it's like a very it's a new paradigm like there's no one to um to like you know interrogate about

09:24 something like this because they they've never used something like this. Um, so I think a lot of things in AI will be about like seeing what is possible now and like what just became possible and

09:40 ju just like build something around it and then while you're building you'll find you know the universe pushing you towards like a certain direction because of many things because of like maybe

09:50 there's a limitation in one idea but you find out another idea that works or maybe you talk to some people and like it seems like hey this is uh an approach that you can do things. And I think

10:02 if I think about all the successful tools that came out came up from uh from like after the LLM era um I think a lot of them started out that way. It was um as soon as the technology is ready for

10:18 something you see someone build that something very quickly like for example openclaw or even cloud code and stuff like that. uh because the model models are now capable enough to you know do

10:30 longunning tasks to like run multiple tools to have access to the CLI and um not hallucinate um because it's a new paradigm. It's just it comes from from just first

10:44 principles thinking and not heavily like talking to uh like doing a lot of market research or talking to a bunch of users because it's it's a new paradigm. One thing I think you've talked with me

10:54 about in the past, like over dinner or something, is like urgency and sort of this sense that once you discovered this opportunity, at least the the first version of what chatbase would be, um,

11:06 you you felt like there was a real urgency to get it out there and sort of be the first. Um, and maybe that also ties into that thing we I was talking about earlier that I thought would be

11:16 interesting to hear, which is sort of that decision to put everything else aside. you know, you had other apps that you were working on, maybe varying degrees of success and promise with

11:26 those. You had school. So, how does urgency tie into that decision and the decision that you ultimately made to put all the other things aside? >> Yeah. So, I think for me the reason I

11:41 was urgent or like I had a lot of urgency was not actually right. It was the belief that like you can do ideas that other people are doing like you have to do like I don't know I think a

11:53 lot of people when you talk to them about like a startup idea they say oh but that exists. >> Um and I had like the same like misconception that oh I need to do this

12:02 now because if I wait I know like this idea is good and someone else will do it so I just need to to do it now. But I think like the reasoning was maybe not right. But the result was I needed

12:15 urgency and that of course was the right thing to do. And um a big reason I would say for the success of Chatbase was the timing and like I think that helped us um stay bootstrapped because as soon as

12:29 we launched we we had revenue. uh maybe like like I I think I had the first payment through Stripe 30 minutes after I put out a pricing page. So I think yeah I think if you're building

12:44 an AI especially now like now it's extremely competitive like now it's very obvious that um like this is the future and you want to be part of it so everyone is building. So I think now

12:55 it's even more uh important to have urgency but at the same time to still make sure that you you are opinionated and not just you know like following the trends of um like what's popular now and

13:09 then like jumping to the next thing because I think it's very hard to run um like a scalable business that way. >> You know you've bootstrapped as a solo founder to 9 million ARR uh over three

13:21 years. you have quite a following on X because people are fascinated and they want to follow in your footsteps. Um at the same time when you started you didn't have a lot of a following. You

13:34 didn't really have much of an audience at all. You had no revenue to start. You were I guess still in school. So what was it actually like back then? How did you decide to be solo? Like what was the

13:47 what was the backstory there? I think what helped is that I wasn't in SF. So I think I I think I didn't like think about like what people do when they want to start a company or like what the the

13:59 steps are. I was just you know like I just saw the idea and I started building it. I wasn't thinking too much oh do I need to raise do I need a co-founder? And maybe like

14:09 maybe like not everyone should do that and that doesn't work with every business of course but like to me just the truth was I saw the idea and like I started building. I I wasn't um

14:24 I wasn't like following the footsteps of of like oh first you need a pitch deck and then you talk to investors and then you try to find a co-founder and then um hopefully you raise money and then you

14:34 um and then you start building. I just saw the opportunity and I started building and what helped was as I said like we have we had revenue very quickly so and also we had like a lot of

14:46 customers quickly and I was alone so I didn't have time to like go like find a co-founder and raise money like it was just all of my time was spent on just building the product and then talking to

14:59 customers and maybe if I had more time to like think about things I would have um tried to find a co-founder or or more or raise. But yeah, I think I just didn't have the time to do so. And you

15:12 know, I had like some angry customers calling me, you know, at 2 am. So like that was my my like my whole day um just building and improving the product and talking to customers until it got to a

15:25 point where um like I can run this profitably and hire people and it's been that way since then. It feels like in many ways solo founding, especially solo founding with the bootstrapping

15:38 component. Um, which I guess over dinner last night we described this as free solo uh is is uh bootstropping solo. Um, and then people like Ben, it's like true solo if they're bend if they're building

15:50 without any teammates. And we'll talk about team in in a in a few minutes here. um when you're building this sort of you know this this sort of free solo uh approach um it does feel like it it

16:03 has a lot of uh that it owes to sort of like the indie hacker kind of movement um and I'm really curious do you think that we're just moving in a world where the indie hacker was always thought of

16:15 as a little bit like this is bootstrapping kind of puts a ceiling on things pretty significantly and indie hacking is is quaint and it's about making revenue, but it's not about

16:26 building big businesses. You have more revenue than a lot of companies that are venture-backed 3 years in. Um, so you're you're doing phenomenally well. You're better than a lot of venture-backed

16:37 companies. So, you're kind of changing the narrative around like what a solo bootstrapped company looks like. In the past, people thought it was kind of like this, you know, small business type

16:48 thing. >> Um, how do you think about that? How do you think about like what's actually possible with a solo bootstrap business? And maybe, you know, we've talked a

16:57 little bit about it, but I'd love to hear kind of what that journey's been like and did you realize in the early days that it could actually be something like this? I know you started it out

17:06 with just the premise of making a business that makes some money. So, just walk me through a little bit of that. >> Yeah, I I agree. I think um when I was like the indie hacking movement was

17:19 mainly around building like a lifestyle business you know like some people call it like a a micro sass or or something like that and it's just the idea like you want to make profit and then go live

17:32 in Bali. Um which I think like this is I think it's extremely valid and I think it's I think it's it's more possible now with with all the AI tools. I think if

17:42 someone has like enough agency and enough urgency and drive, I think yeah, like that's a very viable path and it sounds fun. Um, for for me, I I was considering like,

17:57 you know, like building chatbase as a lifestyle business and some people were doing also like multiple projects um and and running all of them at the same time. But I think um

18:09 I just saw this as like once in a-lifetime opportunity for many reasons. I like the timing, the how big the market is, how competitive it is. And I think maybe like it's it's also human

18:24 like by nature like I'm more competitive like I couldn't get myself to okay say okay this is enough let's just go you know to the beach and uh enjoy the the profit. Um, so I think a part of it is

18:36 like the person that is that is running things and like what their goals are. But for me, the goal was always like I want to see this through. I want to like I I think it's hard uh to

18:50 find an opportunity like this. And I think people get something like this maybe like maybe like three times in their whole life, maybe less. And most people don't take advantage. I feel like

19:04 I I did a good job early on by taking advantage and you know somehow I feel like I owe it to myself to like at least see it through like see see its potential. Um and also

19:16 it's fun like I enjoy doing it. I enjoy seeing you know the graphs go up. I enjoy talking to customers and like seeing how this helped them. I I enjoy the competitive aspect of it. Um, so

19:28 it's also fun and yeah, that's that's mainly the reasoning on like why I decided to like go all in and maybe raise the ceiling of what maybe like uh people

19:44 thought what is possible bootstrapping a company especially solo. >> It really feels like you have raised the ceiling in terms of what people think is possible and we have no idea just how

19:55 high that ceiling can go. Um, I'd be super curious to hear about the competitive aspect of this. Not competitors, but like you being a competitive person.

20:05 >> Is that something that you identified in yourself really early on? What What were some of the aspects of being competitive that kind of resonated with you or or made you sort of who you were when you

20:16 were growing up? >> Yeah. Um, so I was doing a lot of sports growing up. I think maybe that's uh one aspect that affected my personality. Um so I

20:29 did swimming, I did archery for a long time and you know like going to competitions and all of that. I think especially when you're young and when you with your friends, I think it shapes

20:40 your uh yeah, it shapes your personality and I wouldn't say I'm competitive because of I just want to like you know prove other people wrong or you know like I think a lot of founders a lot of

20:54 people say founders have you know like a chip on their shoulder and um the reason they do what they do is because it comes from a place of like I want going to prove everyone wrong. I

21:07 don't think I have that. But I think I just I think it's it's it's fun to, as I said, like to see things through and like see the the biggest impact you can make. And

21:19 um to me, I'm more like competing with myself or like Yeah. Yeah. Honestly, competing with myself. I want to like see how much I can build this and like like just be proud of what I've built.

21:31 Um, and yeah, I think that's yeah, that's the reasoning behind deciding to just go all in and like um try to grow this as much as possible, try to get as many

21:43 customers as possible, try to compete with companies that raised a lot more money than us. So, >> infinitely more money than us. So, yeah, >> the um swimming and archery, that's

21:54 interesting. Those are those are sports that are both individualistic but also teams, right? Archery is also a team, swim team. >> Um,

22:03 >> but and you're competing against other people, but you're also competing with yourself. >> Yeah. >> Can you share a little bit more about

22:09 how you think about those sports and kind of the relationship between the individual their teammates and the people that they're playing against because they feel like very different

22:20 than say, you know, soccer or football or whatever. >> Yeah. I think the beautiful thing about uh individual sports is that you can only blame yourself and I think

22:32 especially when you're young I think that teaches you a lot about just life and like how you you know go through life and conduct yourself through life and I think having that mindset of

22:43 everything is my fault I think that's very helpful in sports but especially in individual sports and that what it teach that's what it teaches you but it's extreme extremely helpful in business

22:54 also like it's the same um it has the same importance if you're working with more people I think especially if you're the CEO yeah everything is your fault because yeah like you're the person

23:07 responsible for anything that's happening in the company so I think that mindset even if you're working with other people I think even if you have co-founders I think everyone should um

23:18 take responsibility and I think um you know like I I got that lesson from sports and I think it helps with businesses and especially it helps with um solo funding a business. Um but now

23:31 like now I have a relatively big team and like a lot of the um value that chatbase is providing to customers is coming from from the team and I'm very proud to be able to have them um like

23:46 working with them especially given that they started out you know like in my like last semester in school like you know like building uh in like a class for example. So it it is very special

24:00 and but I want to make sure that I give them you know the appreciation and recognize they what they help built. I think this is such an important aspect of it, right, which is you're not this

24:13 is actually kind of an interesting thing because oftent times people like, well, you know, they're not solo, they have team, of course, like most companies do have teams and probably will have teams.

24:23 Maybe they'll be smaller teams in the future because more leverage for each individual with the tools that they have, >> but you know, there's this really

24:30 interesting dynamic of course where you're solo, but you build a team. Yeah. Um, and I think that there's a very interesting dynamic of going from one person to multiple people. If you have

24:43 co-founders, you already have done that, right? Because if you have two other co-founders, there's three of you. When you add the first sort of non-founder to the team, you're going from three to

24:53 four perhaps, right? Uh, but if you're solo and you're adding the first teammate, you're going from, you know, one to two. So, it's it's this big shift. I'm curious what that was like.

25:04 how you evaluated thinking about when to add the first person. Um what kind of role that that person had. Um obviously this was also at a different time. So you know technology was different. The

25:16 tools are different. So maybe if you were to actually sort of think about the way that you you did hiring if a company were doing hiring today, they would do different hiring than they would have

25:25 maybe, you know, 3 years ago. But I'm really curious sort of what that was like in the early days of considering bringing on a person um to kind of go from being truly solo to having a team.

25:36 I didn't have the choice like I think it was extremely obvious that I need I need to hire someone. It was just this exponential growth you know on the in the first two I think I hired the first

25:46 person like two and a half or three months in uh after the first launch. Um, and it was just impossible to keep up with talking to customers, with building their features, with everything. Um, I

25:58 think for me, I was lucky because the first person I hired is a friend from school. So like we already had that relationship. And I think it's the same for most startups. I think that would be

26:11 a good idea to like just hire someone you know and already trust because as like everyone says, the first few hires like determine the culture of of the company. Um,

26:22 so I think it for me like at at some point there was no way I can continue doing this solo and I knew that I wanted to grow this as much as I can. And I hired that first person. He was an

26:34 engineer, my friend from school and maybe like a month after I hired the second person and also a friend. And then it just um like I think maybe the mistake I made is

26:49 I hired too slowly even not not because people say like you only hire when it's painful. >> Yeah. >> Which I did that but like not on

26:57 purpose. >> Um but I think I continue to do that and I think maybe that's one aspect of bootstrapping that you're kind of forced to

27:07 be a little bit more careful than if you would have raised. And I think I fell into that. I wouldn't call it a mistake. I think like I did what um made sense at the time, but I think if maybe I knew a

27:19 bit more, I would have been more aggressive and like maybe hire faster, spend more money faster. But I think that's what I'm saying about bootstrapping. It's um

27:30 the when when people think of a bootstrap company now, it's more like they associated with like the indie hacking, you know, lifestyle business, which I it it is a big part of it, but

27:41 but now I think you will see uh hopefully companies like Chadbased, but I think other companies too will be solo founded and maybe bootstrapped and they will become huge. Um because I think now

27:53 the technology allows it and I think now also more and more people want to start companies and I think like the number of founders is just going up. So I think the number of solo founders will just go

28:07 up and bootstrapping is now a viable option to build a generational company and maybe the mistake that I made of like maybe being too careful very early on and um making sure that we're always

28:22 like very profitable above a certain amount maybe some people will be more aggressive and yeah I see that as uh like a good strategy if the goal is to build something generational. you know,

28:35 >> so we could I I want to talk a little bit more about sort of the team and sort of how you think about culture and building in real life versus uh versus remotely. Uh but before we get into

28:45 that, I think there's a really interesting point that you made, which is it's more possible than ever before to build bootstrapped and to build to something of really meaningful scale.

28:55 Not sort of like the that I don't mean this in a derogatory way, um but you know, some people sometimes do when they say lifestyle business. Um there is something really interesting about this

29:06 idea that you can make a lot of progress with very little and you could essentially be profitable. And then there's a question of what do you do with that? Do you continue to be

29:16 profitable and do you raise venture capital? Um there was somebody in the solo founders program who got to $2 million in ARR completely solo, no teammates, and now he hired his first

29:27 teammate. He had raised a little bit of money, but he didn't touch any of it. you know, it just it it was just that it was there and it didn't end up getting used. So, in theory, he could have

29:37 bootstrapped it, right? Um, now, will he raise more money? He's debating it. And I think that's a really interesting question that a lot of people have is they have the success as you have or as

29:48 as he has. And you now it's a question of well should they continue to just grow sort of with profits uh especially if they're really profitable if it's a sort of more software oriented business

30:00 or at some point does it make sense to consider taking money and you're doing it from a place of leverage that maybe you didn't have before. So I'm curious sort of what your philosophy has been at

30:09 least to date. Uh because I'm sure there have been you know quite a few times when people have asked about you know potentially investing that sort of thing.

30:18 >> Like everything else it depends on I think the main thing it depends on is the founders's goal. Um, I think there is a ton of advantages to raising and I think the biggest one is

30:31 you get to be more aggressive because you have this money and like you're supposed to use it, you're supposed to spend it and um maybe you do that some mistakes along the way with with hiring

30:42 and stuff, but I think overall it um you just get to move faster, which means you capture more of the market. And in some markets that's you know the name of the game. it's like who's going to get more

30:54 customers faster. Um, and then also the other advantage maybe for especially if someone like young or maybe it's like their first company or they don't have um like a following or something. I

31:08 think the other advantage is some uh social proof. You know, when you have like the logo that this customer this uh firm invested then it it helps a little bit with getting customers and hiring.

31:19 But I would say the biggest advantage is just being more aggressive because I I know I was like this and I think other maybe Bootstrap founders also had the same problem. It's just it it's not

31:31 the same when you're spending your own money like customer revenue. You you want to make sure that it's ROI positive all the time. You want to make sure that you see the results very quickly, which

31:42 also like is a good mindset to have, but in some cases, you want to like be more aggressive and experiment and and um maybe do some things that are maybe sounds stupid, but they have like some

31:54 chance of success. But yeah, I think that's the main reason to raise if you already have profit. Um but I would say on the other side like why people would not trace um if they

32:09 have a growing business is one they think maybe it's like they're delusional but they think they can build a brand that is strong enough that they don't need to associate it or like to borrow

32:22 brand equity from a big firm. Um which I feel like that's that's the goal for me. like I want to be able to um like maybe maybe it's stupid honestly but I'm just saying um I have like the

32:38 confidence the self-confidence that I can make this a strong brand that people recognize that people want to use that you know it's not like the alternative to something it is just the best tool to

32:49 use and um I think I can do that um without without raising so that's one one thing And then the other thing is about um just maybe optionality and control. So

33:05 when you of course you have like maximum optionality and control when you when you're on your own. Um some people value that. I value it to some extent. Um and then I would say the the third reason is

33:19 the definition of success changes as soon as you raise. So it depends also on the person but if you bootstrap to 100 million ARR AI business I mean I think anyone would call that a success and

33:33 like it's a success for the founder and for the team. Um but I don't think it would be like considered a success if you raised 100 million. Um,

33:46 and I think for me and like I think for other businesses too, it might be easier to get to what you consider success if you don't raise

33:58 because just the ceiling is just changes so much. And I think even if you have the self-confidence, even if you know you built an amazing product that customers love, um, like I I don't think

34:11 anyone knows what's happening in AI now. it's very unpredictable. So, um there is an argument to be made that it's just higher chances of success if you bootstrap. there's something really

34:24 um remarkable about Chatbas's growth and um clearly there was the timing as you said um and there were a bunch of sort of external factors but there's also you and the team and

34:41 it's not like you just built one product and that was what the product is today. It's very different than what you started with. Um, and I think that that's perhaps something that's really

34:53 worth talking about because I think people would really benefit from hearing kind of you start with one thing and you end up at a really different place, maybe a place that you hadn't

35:02 necessarily predicted. So maybe you could talk a little bit about that like chatbase, what was it the very early days and then maybe take us quickly through to where we are today.

35:12 >> Yeah. No, I think you should like the product should change over time. Like that's the whole point of you know building the product is it evolves as the market evolves as your customers

35:24 needs evolve as your goals evolve. Like this is I don't think it makes sense to you know like plan the next year in advance and just like ignore everything that's happening around you. That

35:36 doesn't make sense especially in AI when when everything is moving fast. Um like you need to be flexible enough and you need to also communicate that with the team that we have like an idea of we

35:50 have a strong plan. we we know what we want to build but you also have like the flexibility and the um like the team is is small enough and fastm moving enough that you can like

36:02 change things as you know like the technology changes or as the market needs changes or like as a new like competitor enters the market. So, you have to have that quick moving ability.

36:12 And I think also that's easier when you're bootstrapping, when you're on a smaller team because you have control and you you're just a dictator. Like you can just decide what you want to do. And

36:22 I think like dictatorships are good when you're trying to build a company. Um because yeah, that's a tangent, but I I I think >> Say more about that though. I mean, like

36:33 I've heard it described as like benevolent dictatorship. >> Yeah. say more because I think that's something that's relevant to solo founding, right? Which is that sometimes

36:42 when you have co-founders, it could be somewhat, you know, uh somewhat difficult to necessarily get to the really pointed decision that needs to be made.

36:51 >> Yeah. >> I I'm curious like talk more about the benevolent dictatorship. >> Yeah. I think I think it's very important and I think

37:00 like of course I don't know the inner workings of like the biggest companies but I think you associate every big company with one person and they're the face of the company and they're the

37:11 decision maker and I think like dictatorships make your chances of success much higher um because like there is two scenarios one the founder is smart and the team

37:26 trusts them and um they have the agency and they have the skill to build an amazing company and in that case you want them to be a dictator. You don't want them to be slowed down but like by

37:36 convincing everyone with about their like thought process and like making sure that a consultant comes from outside to validate you know their thinking and all of that. So if you have

37:46 trust in the founder and you think they're smart enough and they have input on how to build the product and how to get customers then it should be a dictatorship. And then on the other side

37:58 like if the if the founder is not smart enough and if they like their team doesn't have like full trust in them then this company is not going to work anyway whether or not it's a

38:08 dictatorship. So the only way you like have like a very big success is being a right like dictator like your your decisions are right and you don't waste time convincing everyone about

38:24 what you want to do. Um so I think it's just makes you move faster. It makes pivoting like not pivoting but like product decisions very fast and even pivoting if it comes to that. So, um I

38:37 think it just that's like one of the biggest advantages of of building like being a solo founder. And I I think also if you do have a co-founder, I think it needs to be very clear who's going to be

38:48 dictator and what. Um and I think then it can work. But if it's if it's yeah, if it's like not not very obvious who's doing what like like the responsibilities are like uh there is a

39:00 gray area, then I think it becomes a very big problem. Maybe let's shift it back to what before we went on this little rabbit hole, which was a really good one. Um, sort of

39:11 how maybe that benevolent dictatorship or whatever um caused you to go, you know, from place to place to actually get from first version of chat base to where you are today because that I'm

39:22 guessing it's not exactly a straight line. Yeah. Um, but what was the what was the evolution there and what were you learning along the way? Yeah, I think um what's interesting in in

39:33 startups in general, but especially in AI startups, is that the inputs change every day and then you make a decision based on what you know today, but then you shouldn't have ego to say like like

39:50 let's say like a week after or a month after and then some inputs changed and then you the decision you made was a mistake. then you need to like just go in a different direction very easily and

40:01 like very quickly and 100% it's not going to be a straight line. It wasn't a straight line for us. It's I don't think it's a straight line for anyone because especially in AI everything is changing

40:12 so quickly. So your job as a founder I think is for like decision- making is two things. one, you need to make sure you take in all the inputs that you have today and like make sure you think from

40:25 first principles on what the best decision is that I can make with everything that I know now with all the context that I know. But also not having the ego to say no, we're going to

40:37 continue doing this after like things change and making sure that um you and everyone on the team are you know, low ego enough to be able to change your mind very quickly to respond

40:52 to like everything that's happening around you. um that makes you know like long very long-term planning hard but it is hard and I think it's hard for all the startups and it's even hard for the

41:03 AI labs and you know the people that are creating this technology because like the truth is no one knows what's going to happen you know like two months from now like what the products are going to

41:15 look like what the market is going to look like what the customers will want it's just very unpredictable u you can have assumptions and like you can some accuracy, but

41:28 yeah, you need to be low ego enough to be able to change your mind very quickly. And I think Jeff Bezos um had a quote, I I forget exactly what it said, but something like you need to be able

41:41 to make the decisions that it's very easy to come back from. >> And I think that's the case for like especially AI startups. If you have a decision that you can like walk back on,

41:53 you know, a week from now if things change, you should do that instead of doing something that it's very hard to to walk back on. So yeah, for chatbase it was a lot of like thinking, you know,

42:04 today like what should we do and then changing it, you know, a week after and then like thinking about something new a week after and then oh actually it works so we don't change it. we were going to

42:13 continue doing it. And over time, over like yeah, the years it uh chatbased became what it is today. And we're still like going through that. >> It feels like there's um this idea of

42:27 like one-way door decisions, two-way door decisions. Um everybody like I think the main the main challenge is that everybody treats all decisions as a one-way door decision. And what you're

42:37 saying is there's so many decisions that are actually two-way door decisions that are totally reversible, but because we we kind of have this human nature of kind of

42:48 >> clumping everything together, uh we we treat the the two-way door decisions as one way door and it makes it really hard. Um that's probably the biggest impediment on velocity, right? U. So I'm

42:59 curious, how do you kind of encourage the team and create a culture for the team to not feel like they're always going through oneway doors, so therefore they have to be extremely careful? Um,

43:11 maybe not have to always get your permission for things, right? Because, you know, you're you're not steering, but you're directing, right? You're telling you're saying, "Here's the

43:19 direction we want to go in." And then ultimately, you know, you you need to give them the ability and encourage them to do their great work and make their great decisions because you can't be the

43:31 person who makes all the decisions. So, how how do you do that? Like what's the culture like? How did you think about building the culture? I'm sure that there are things you've learned along

43:38 the way that um that were maybe like missteps. Every company has those. I'm just curious what what that's been like for you because this is the first time that you've ever really built a company,

43:47 right? It's kind of like you were you were in college and then now now you're running I think it's a 30 person company $9 million bootstrapped solo founder. So what walk walk me through like walk us

43:58 like the listeners through like what that actually was like what you've learned about building a culture that supports these things that are important.

44:05 >> Yeah, I think the biggest thing um for me to learn or like that I learned and that I made sure everyone on the team knows is that changing your mind is actually good. like you should change

44:17 your mind if if things change because I think if you don't like make sure that this is explicit if you just like let things happen there is this um you know like social pressure a little bit to

44:30 like not want to look like you changed your mind or like to say oh actually like this was a bad decision we should do something else. changing your mind like you should

44:38 change like actually not changing your mind is a problem because like inputs are changing very quickly and sticking to something just because you don't want to look bad is like such

44:49 a bad uh idea for for the smaller decisions and then especially for the bigger decisions. So I think in the culture for us and I think for like a lot of um what AI companies should do I

45:03 think honestly like any company is encouraging like making sure that if someone decides to change their mind um there is like zero pressure on like oh but you said this or oh but like we put

45:16 in all this work to do this or you know like the sunk cost fallacy because things things have changed. So yeah, and I think like the way you build that culture is by just like one doing that

45:27 yourself and then making sure you communicate that with with the team like very regularly. So like it's still in you and everyone on the team that this is how how we do things.

45:38 >> Now I think there's um I think there's something really interesting and maybe we could we can sort of transition over to just like what it's actually like to build a bootstrapped company that

45:48 scales. Um, I think a lot of people have a general sense of maybe what it's like to build, you know, these smaller like soloreneur indie hacker businesses that don't scale

45:58 because it's just, you know, one person. But, you know, there are some really interesting questions around how to think about profitability versus investing in, you know, different things

46:07 internally, how to think about hiring, how to think about compensating people. Um, I'm sure to some extent the people that you attract to the company, you attract different types of people

46:18 because you're a different type of company. So maybe you could share a little bit more about sort of the sort of the practical sort of things that you've learned when it comes to like

46:27 finances and sort of attracting and and retaining talent at at sort of a a scaled bootstrapped company. >> Yeah. Yeah, that's a good question. I think so like rule number one if you're

46:41 not rich like you're not financing this yourself is you have to be profitable like there is it's not optional like you have to be profitable from day one um how profitable is is the question and

46:53 that that's what what I was mentioning in like risk tolerance or being a aggressive I think like of course when this is like your first company and you're just starting out you you the

47:06 it's very unclear like what this will grow into. Um you tend to be more you know conservative and like just want to make sure that this is like the unit economics make a lot of sense like

47:18 that's the number one metric you're you're tracking but then as like you gain some mode around the company and like you you have some confidence and like the steps that you

47:30 need to take are clear in order to grow. Um then once you have that conviction then you can be more aggressive. I would say you can even start to lose some money from like all the money that all

47:42 the profit that you have been building. And that's what we're like that's where we are now. Basically, we are investing I would say like we we may be even like

47:54 spending more money than a lot of like VC back companies because we have been profitable for a long time and now there's we have a lot of conviction on what we're building and

48:09 to to me it's a matter of execution. So, it's I know it's not going to be easy, but it the steps are clear like we need to do this and this and this and it's going to grow. Um, and I think that's a

48:20 very good position to be in. And once you have that, then you should like just go all in like because if you do believe it, then like there is no it it doesn't make sense to not do that. Like it's not

48:32 logical. I think that the it's like a spectrum on like how aggressive you want to be and that the it just depends on like how much conviction you have on if I do this

48:46 then we will grow. Um if I put like this amount of money in this one thing it will grow then you just put it because it makes sense. And this this also depends on like the the person building

48:56 like how much risk they want to take. But um but to me like in the market we're in and like for the goals that we have there is no other way around like spending money. So this is what we're

49:10 doing. >> And when it comes to the people that you track to work at this company, you know, there are some companies that are obviously out there that are trying to

49:18 raise a lot of money. They're doing it and they're getting these really large paper valuations that continue to go up up up, right? Um, and those valuations are usually not tied extremely directly

49:32 to revenue, right? They might be uh directionally tied to revenue or or success metrics or progress, but you know, it's it's a different game than like joining a company that's

49:43 profitable, that's growing really well, um, that has like, you know, already at your stage venture scale metrics for a nonVCbacked business. What is it like when it comes to recruiting people? Like

49:58 what are people looking for when they join your company versus maybe joining one of these companies that's maybe more splashy but maybe you know isn't necessarily doesn't have like the actual

50:09 like >> business foundation that you do. I'm curious like what what kind of people are excited about that? What gets them excited? And then also how you think

50:17 about actually incentivizing people. Is it just the same thing as like venture scale like venturebacked? It's not venture scale because you're both venture scale venturebacked startups or

50:26 is there something else that you do around dividends or how do you think about these things? I I don't know anything about this world. So, I'm really curious about it.

50:33 >> Yeah, that's that's very interesting. I think 100% you you attract maybe different types of people. Um I think it's more difficult a little bit because it's

50:46 hard to communicate the value. But I think like this is the truth. I think it makes a lot more sense to join a company that is bootstrapped and has a lot of like business uh like value in the real

51:01 world like revenue and customers. It makes a ton more sense because if you are joining a company that like has just raised and you know they have like the

51:13 um you know like the news article about like the the raising and stuff like that then it's like splashy um I don't know if this is the best move to be honest because that means like you're either

51:25 late like you might be late there's a chance that you're late if the company doesn't live up to the very high valuation that that they have which like Of course, some companies do and some

51:34 companies don't, but it's a risk you're taking. >> Um, and you need the company to not only grow into that valuation, but grow past it because like you're taking risk by

51:45 taking options. You're not taking like just straight out equity. You're taking options and then the options are going to be based on the the valuation uh that they just raised at. So

51:57 I feel like it's extremely more risky than to join a company that is bootstrapped and then like your options mean something because the valuation is not based on you know like revenue like

52:08 five years from now uh as as a lot of like companies that are VC backed uh their valuation is but I think like I'm trying to put myself like you know in like the the the shoes of a candidate. I

52:20 think the good thing about joining like the splashy like the company that just raised I think it looks better on your resume. That's >> social signal.

52:29 >> Yeah, social signal just looks better on your resume. >> But I think from >> I think it's just more risky because like

52:38 >> you you're betting that this company is going to grow not to that valuation but even more. Um and it's like you can make that bet, but it's it's still a risk you're taking. Um, but I think for for

52:50 some com there there's huge companies that are bootstrapped and they I think AHFS is bootstrapped and they do dividends and like they're growing super like I think they're over 100 million in

53:00 ARR and they I think every year they give out like like 50% of their I'm making this up but I just remembered reading this. >> Uh, but a lot of their profit just goes

53:10 straight to the to the employees. So I think that's um like you can do stuff like that when you're bootstrapped and like you can do stuff like that when when you do raise.

53:21 Um but yeah, for us like I think what's attractive when when I'm like talking to a candidate is one like this is like we don't have like the

53:33 paper valuation so you don't have like the the problem with the options and then two you get to take on like much more responsibility just because like this is a smaller team and you just like

53:46 tend to move up extremely quickly u because by the fact like But this this is being a small team and also like bigger companies are more like hiring executives from like outside like other

53:57 companies not from like people growing from the inside. Um but like a a bootstrap company wouldn't be able to do that because they can't afford that. And then the third thing is that

54:09 when you own like all of the uh equity, then you can be a lot more generous with with the equity that you give out to employees because like you own all of it. So you can just

54:21 decide to give your best employees a lot more equity and that equity also has value today. So, and I think a lot of people like when when they think more about it from first principles, they

54:34 they come to the same conclusion which oh like this might actually be a better approach and like this is like maybe unintuitively like a lot less risk. Um, and yeah, by doing that, I think I was

54:48 able to attract like extremely good candidates who had offers from like those like ventureback companies that would seem from the outside um as like a like a VC backed brand. But I think

55:02 yeah, once you think about things from first principles, maybe you can like sway your opinion towards this direction. You know, there's there's also something interesting is like once

55:11 you scale to a certain amount of revenue, it's possible that you could actually just sell like employee shares t, you know, uh, founder shares to investors as well if you ever wanted to

55:21 do it instead of just raising sort of straight up like raising uh, preferred shares or something like that. But I think I thought was, you know, I've never done this before, but I thought it

55:29 might be interesting even though um, you know, we we've covered a lot of ground. Maybe we should actually just really quickly, if it's cool with you, talk through a few of the um a few of the

55:38 things you've written about in the past. Um I you had this playbook that you published on X that we could link to uh about bootstrapping and AI agent business. Um and I thought there were

55:48 some really interesting things here that maybe we could do like a lightning round on. Um you said if you're in B2B just due to the B2B stuff, what does that actually mean? Yeah, I think especially

56:00 for bootstrap founders, you tend to try to like force your B2B business to run like a B2C, you know, app >> and that's because customer acquisition is just cheaper in B2C. So like because

56:13 you're you're bootstrapped maybe you don't want to spend a lot of money in acquiring customers and you're trying to build like this extremely productled like no one is going to talk to me

56:23 >> self-s serve >> self-s serve uh app and it just doesn't like it can work but you still have like if you actually want to build something big quickly

56:33 um I think the approach can be like product like self-s serve and then um attach like a salesled on top of it because at some point you're going to have like

56:45 bigger customers and you're going to be talking to like a middle manager at like a public company and that person like especially if your product is good and like it's there's like a lot of features

56:55 and like it's it can do many things that person will not spend like a week you know like on your dashboard trying to make it work even like even if your product is extremely intuitive and very

57:07 easy to use is just very hard to convince people to spend time in like setting things up and a lot of people like value like talking to humans and like getting on sales calls and like

57:18 understanding the product and making sure that this is like there is humans behind this. This is very valuable. Um and yeah, I think that's that's the only way you can you

57:30 can continue to grow past past a certain point. And and just really quickly like when you when you added sort of the the more salesoriented approach where you were actually talking to prospective

57:41 customers versus it being self-s serve at what stage was the company like how much money did you have? How many customers did you have because you were originally fully self-s serve I believe.

57:50 So when did you when did you add that layer? >> Maybe like a few maybe like six seven months ago when we were like >> Oh wow. So ve very recently in the

57:59 scheme of things. >> Yeah. Because like before like we grew a lot quickly like in the last also a year. So before then like we didn't have like it's just hard to hire sales people

58:08 because they're expensive and getting on calls with customers and like going through like long sales process sales process is expensive and you can't just do that when you're bootstrapped and you

58:21 don't have revenue. But after a certain point we we had the revenue and like we had the conviction that this will work. So we started invested more into building a sales team, building like the

58:32 salesled approach, you know, doing like the B2B stuff, doing the outbound, talking to customers and all of that. >> So there were two there were two points here. The first one or this is number

58:41 two is content is non-negotiable. And then number three, which I think is very connected, is warm outbound is the lowest hanging fruit. Um maybe talk about both of those at the same time

58:51 because warm outbound is probably a concept that most people haven't even thought of. They think of cold outbound typically. So maybe say how content being non-negotiable fits into like this

59:00 warm outbound being sort of the the biggest opportunity for a lot of people. >> Yeah. So I think you can do two things like as I said there's two approaches. One is like

59:12 the self-s served productled. You just like you're just basically doing marketing and like you're just hoping people go through the onboarding flow. You're treating it as like a B2C

59:20 company. And then on the other end of the spectrum it's salesled. you just you just have like a landing page with a book a demo and then you just have like sales people try to connect with

59:30 executives at big companies but I think what's very interesting and I think actually a lot of companies that are huge that I look up to are doing that is out of both they have the marketing the

59:45 media arm as just like to get people familiar with the brand to have more brand awareness but they don't just leave it to them to like go on the product and sign up. They pull them like

59:56 they actually pull them by sending the emails, going on calls with them and making sure that they go through the whole pipeline. So I think that's the idea of warm outbound. The good thing

01:00:07 about content and and marketing is that it makes everything else you do easier. Like it makes paid ads easier because people know your brand and like they're more likely to watch your content

01:00:18 because they have seen you before. They're more likely to click on it because you have like social proof. So like organic content just makes everything else easier. It makes

01:00:26 outbound easier because people have seen you before. Maybe they someone like told them about you because of of the content. It's just very powerful. It makes all the levers uh much stronger.

01:00:38 And then sales works because it's been working for like you know like the beginning of time. It's just talking to people and can like explaining the product and like making sure that this

01:00:48 solves their problem. And I think combining both you end up with like very strong companies like Stripe for example where it has like a very strong self-s serve and like product and and marketing

01:01:00 and uh PLG uh growth but at the same time of course they can support extremely large businesses and like they have the white glove onboarding and like all the forward deployed engineers you

01:01:11 need because it I think those are like the best companies and that's the way I want to build chatbase is um attaching a sales approach on top of a strong content and product like growth.

01:01:27 >> So, okay. So, really quick lightning round stuff here. Cold outbound, like what's the thing that you learned about cold outbound that was like the hardest lesson but the most important.

01:01:36 >> Yeah, cold outbound. I think it works extremely well if you have a very big uh TAM So like for for a company like us customer like just a customerf facing

01:01:52 agent so like customer support customer uh sales and and all of that customerf facing interactions of course this is a huge market and that means like if cold outbound works

01:02:04 for anyone it will work for us because like our just time is is huge and we know the product works because it's working with other people that are using it um through the self-s serve flow

01:02:17 Um, so I think it then it becomes a numbers game. Then it becomes how much you're doing and how much you're willing to spend. And it's just like a formula at the end of the day like cact to LTV.

01:02:28 And this is the part of it where you're thinking about it like maybe a B2C company. Um, but but I think that's I think that's like the approach of a lot of companies that are starting out now.

01:02:39 And I think even bigger companies are seeing this is combining both like what people have been doing in B2C and what people have been doing in B2B and combining both for a very strong

01:02:52 sales supported organization with um very strong PLG motion. >> So this is a really interesting one. Be friends with your biggest customers. Um a lot of Solo founders I know have

01:03:03 incredibly close relationships with the people that they serve. um they're usually on like a texting basis with their early customers. What was the thing that you learned from that or or

01:03:13 what's something that what's something that has been sort of surprising? >> Yeah. Um I think for us it was extremely important and extremely easy too. Like I think maybe it's very like maybe not

01:03:25 intuitive to someone like new to business to be friends with with customers, especially when you're like like us, we have 10,000 customers. So like how are you going to be friends

01:03:34 with them? But I think for us it was very helpful because those biggest customers we we realize we have a lot in common with them because a lot of them are like executives or

01:03:47 founders or you know like big project managers at a big company and a lot of the problems we're facing they have faced too and they have insights for us we have insights for them and it's just

01:03:58 like very easy to find common ground and like find things to talk about. Um, and then it's very helpful because you need your customers to be like brand ambassadors. So you need your customers

01:04:13 to like have like you're growing from word of mouth is like huge for us because um we have like a lot of customers in a lot of different industries. And when you have like one

01:04:24 customer in one industry but they actually love the product, they can't stop talking about it. And then you get more people from that industry. And you only get that or like it helps when you

01:04:35 actually know them like actually know them on a name to name basis. Like you have their their phone number, you call them. And we I think we we started doing this maybe later than I wanted to, but I

01:04:48 now realize that this is an extremely like undervalued I would say growth lever that people are not focusing on. So the last two here were very closely tied together which is

01:05:00 pricing is the fastest lever and margins don't matter early on. Could you say something about those two and maybe how they relate to each other? >> Yeah, I think pricing is interesting

01:05:09 because there's no science behind it. Like it's, you know, like I consumed all the content, you know, the startup content about pricing. I talked to a lot of

01:05:19 founders. Like the most common way people do things is experimenting. like you just come up with a number, you put it on on the site or like you try it with a in a sales call and then see the

01:05:29 reaction. That's like the the the only way people price and like doing more of that is how you find the perfect price. Um so I think a lot of people do not realize that maybe they're pricing too

01:05:41 low and even maybe they're pricing too high and they're losing out on on customers. And by saying pricing is is the is the fastest lever is because you can just change it. you can just decide

01:05:52 to change it and immediately you will see like feedback from from the market and you can say the same thing about like any of the other um like efforts you're you're doing but pricing has that

01:06:05 advantage. So it doesn't make sense to not do that. it. You should be changing pricing a lot to find where the perfect price is when you're delivering where customers want to use you even if you're

01:06:17 expensive because you're delivering like a lot more value to them. And from what I've learned, like the only way to find that is by experimenting. >> And then that second part about margins

01:06:29 not mattering early on quite as much. Yeah, I think this is more of a thing that I would say to bootstrapping or or solo founders especially because um

01:06:41 like the definition of a good business is like a business that does profit and it's like when you first like see the VC world is like unintuitive like how these many companies are not profitable. Um,

01:06:54 so some people are like, "Oh, I'm against VC. I'm going to bootstrap for for some I'm not against VC. Like I love I think my second company I'll probably raise uh I think it u it depends on like

01:07:04 what I'm doing, but I'm saying like some people are very religious about these things and they decide um like I'm just against everything. So I'm against like profitability or sorry I'm

01:07:16 against like not being profitable even if it means I can grow faster. And my point here is it's much much easier to cut cost than to get more customers and get more revenue. So I would say like in

01:07:29 the beginning if if the goal is to like just build a big brand and a big company and something generational, of course you should sacrifice the $10 in cost if it means you're going to get

01:07:41 $10 in revenue because you can like cutting cost is much easier than uh getting more revenue. And the revenue also like signals other things other than the you know like the

01:07:54 dollar amount. It signals like a new customer that's going to talk about you. It signals more brand awareness. It signals more money you can invest once you cut costs. So the money from revenue

01:08:05 is much much more powerful than whatever you're spending in terms of cost. And I think yeah a lot of bootstrap founders don't think about things that way. And I certainly didn't. And I think it made me

01:08:17 a lot more slower in the beginning, but now it's much easier to be more aggressive because I know that >> that's really I mean that's super counterintuitive and uh that's exactly

01:08:28 the type of thing that people listen for. So I'm sure a lot of people will benefit from hearing that. And again, thank you for being on this. I I think we want to close this out with sort of

01:08:36 the two customary questions that we typically ask. The first one is um is sort of the bare case for being a solo founder. The reasons that maybe people shouldn't be. Uh because I think that

01:08:48 obviously we think that solo founding is great. We think that it's an incredible opportunity um and that some of the best companies will be built. In fact, it will probably be the default way that

01:08:57 companies are built uh in the future. But at the same time, it's not all sunshine and and roses or whatever, right? There's got to be some some downsides to it. So what's the sort of

01:09:06 the case against solo founders? And then of course the spoiler alert is we'll we'll we'll take a pause and we'll talk about that. But then afterwards we'll we'll talk about the the case for it.

01:09:16 >> Yeah. I think the biggest bare case is how hard it is especially in the beginning. Um, I think having a co-founder, having someone as invested as you, as much as

01:09:30 you, especially early on, just makes life much easier, especially when you have like trust in them and you can um fully depend on them and you know they're

01:09:40 smart and like you just some things in the business, you know, are handled because it's with them. And you can say the same thing about um, you know, like any like good, you know,

01:09:51 person on the team. But I think for a founder, especially early on, it's it's special because a lot of the early days is like you're trying to figure out what you're building. You're trying to figure

01:10:01 out PMF. You're trying to get your first customer. And you want someone that has the same investment as you to go with you through all of these things. Um, and then the maybe the other

01:10:17 like maybe bare case for for solo founding is it just doesn't work for some businesses like if you're starting a research lab like I don't know how you can do that as

01:10:28 a solo founder or maybe like some robotic like especially the things where you need like a lot of technical expertise in like very specific domain um and you don't have that uh or if you

01:10:39 do have that maybe you don't have like the business aspect of things. Um, so I think some businesses it's just harder to do as a solo founder or like maybe it's maybe someone else

01:10:50 will will do it and like you're going to get them on the podcast, but it hasn't been proven uh that it it it's easy to do uh in in some kinds of businesses. Um, yeah, I think those are are the main

01:11:02 two um in terms of like downsides of of solo founding. >> I guess let's flip it over then. I mean, I I think that by the way, a lot of those things are are incredibly valid.

01:11:12 Um, especially the the sort of loneliness and sort of like not necessarily having a thought partner. Sometimes that's valuable. Sometimes it's the challenge, right? Sometimes you

01:11:23 argue and whatnot, but sometimes that is really valuable and um that makes a lot of sense. So, like let's let's flip it over though from the bare case for solo founding. Like what's the case for solo

01:11:32 founding? Yeah, I think the case for solo founding is that it's very hard to lose. I think like I think the the companies go out of business or like startups they they

01:11:44 crash because I think the biggest reason is co-founder breakup because if you don't have breakup you can just like pivot or you can just you know like try to raise more money or you can just like

01:11:55 there's a lot of other options but co-founder breakup when it happens then like you have to that's it like the company's not going to work out um in in most cases. I think I I I mentioned this

01:12:06 before. I think having an amazing founder is better than having no co-founders, but having a slightly like below average co-founder is much much worse than being solo. Um, and I believe

01:12:20 the case is like you're going to end up in a lot of arguments. You're going to end up in like um different opinions about different things. You're going to have

01:12:28 like this gray area where like it's not very clear who's supposed to have the final say in something. And when you're not able to like work out through these conversations, especially quickly,

01:12:40 because you need to move fast and you can't have like threehour calls about like a small decision because both of you are like very uh you know, hard-headed about like this specific

01:12:49 thing, then it's just like even if you don't have a breakup, you're just going to be much much slower as a company that's just like going through decisions as as fast as they can. So yeah, I think

01:12:59 that's honestly the biggest thing is yeah, like co-founder breakups and that's maybe it's like one reason, but it's a huge reason to to not uh do it. So I think

01:13:11 if you don't know who that person is that you want to be as your co-founder, like you're starting a new company, you don't know who that person is. I would highly

01:13:20 suggest instead of like finding someone that you think maybe like checks off all the boxes but you're not 100% sure, instead of doing that, then try solo at least for like some time and then see

01:13:33 how it goes because you can always change your mind later. It's like a two-way door decision, right? So, um you can always bring in a co-founder if you think it's it's too hard. But

01:13:44 yeah, that's also a good thing about solo founding is the optionality. Maybe this is the last the last thing that you can comment on is we've we uh we we've definitely covered a lot of ground, but

01:13:54 that specifically around like the decision- making and sort of like being the sole decision maker. Um you went through a bunch of different ideas. You were working on a bunch of different

01:14:04 projects. Uh maybe a co-founder wouldn't have gone on all those different little journeys with you to eventually land at Chatbase, right? Like it feels like in many ways that was a very personal kind

01:14:15 of like exploration experimentation period that yielded chatbase. Hard to say if you were working with other people if that would have happened. >> Yeah, exactly. And it's also hard like

01:14:24 maybe if I did find an amazing co-founder then like I would have like a much better bigger success than Chad base. But it's it's just very hard to predict these things. But I would say

01:14:34 like I think being solo helped a lot with moving fast and just like making I like the fact that everything is my fault and like being solo gives me that satisfaction that everything is my

01:14:49 fault. >> Cool. Well, thank you so much for doing this. This is great. Yeah, thanks for having me.

视频链接：[https://www.youtube.com/watch?v=BRYr2fnRl68&list=WL&index=5&pp=iAQBsAgC](https://www.youtube.com/watch?v=BRYr2fnRl68&list=WL&index=5&pp=iAQBsAgC)
视频发布时间：2026-04-08
频道名：TBPN

## 转录内容

00:02 I see a large IPO on the horizon. You're surrounded by jungle assault your position. Overnight success. The place maker 3000

00:36 double right misinformation. According to clearing order inbound,

01:05 >> let's just roll. We are surrounded by general. Hold your position. Come on, get up. Trust the experts here.

01:24 Five cookies. We are founder five. I see multiple journalists on the

01:44 horizon. Stand by. Express. UAV online. Double blaze. Triple blaze.

02:11 Double kill. Fight. is win. Team Deathmatch.

02:49 We are experts. Triple blades. That's just wrong. Right. Quarter clearing order inbound.

03:21 We are surrounded by journalists. Hold your position. >> Strike one. >> Strike two. Activate

03:44 golden retrainer mode. >> Market clearing order inbound. >> 5 I see multiple more journalists on the horizon standby.

04:35 You're watching TVPN. Today's Wednesday, April 8th, 2026. We are live from the TBPN Ultradome, the temple of technology, the >> fortress of finance,

04:43 >> the capital of capital. We got white suits on. You know what that means? The stock market is booming. Uh the Dow Jones is up 2.68%. The S&P 500's up 2.46%.

04:55 The NASDAQ's up 2.9%. And there's a bunch of other stocks that are moving within that. Of course, uh this is on the back of the uh the very good news that there has been a ceasefire that uh

05:05 the o the the street might be opened. Of course, it's all back and forth. Uh the the front page of the Wall Street Journal is covering all of the geopolitical moves. Um but we're here to

05:16 talk about tech and business of course and the big uh news today is that Meta Platforms has launched a new AI model. Uh Alex Wang, the uh chief AI officer at Meta Platforms uh announced a new large

05:33 language model today. Uh its first major new artificial intelligence model in more than a year. The roll out of the model called Muse Spark is a critical moment for Meta which is up 7 and a

05:42 half% already. Uh which has spent billions of dollars hiring AI talent in a bid to catch up to open AI. Enthropic and Google DeepMind the leading labs have been put have been putting out

05:50 models at an accelerating pace. Uh in a departure from its previous models which were open source, Muse Spark is a closed model that will power Meta's AI chatbot and AI features within it. Um John Ludig

06:03 has a very interesting post about open-source AI and sort of predicted this. Uh I can pull that up at some point. We can find >> predicted that Meta would eventually

06:12 bail. >> Yeah. Uh let me find it. The future of foundation models is closed source. Let me see if he if we have this here. Um he said given meta is the primary deep

06:22 pocketed large opensource model builder open source AI has become synonymous with meta AI. He wrote this maybe three or four years ago. Uh so the operative question for open source AI is what game

06:32 is meta playing? In a recent podcast Zuckerberg explains Meta's open source strategy. One he was burned by Apple's closeness for the past two decades and doesn't want to suffer the same fate

06:42 with the next platform shift. It's a safer bet to commoditize your compliments. uh he likes building cool products and cheap performant AI enhances Facebook and Instagram. That's

06:51 100% true. We've seen this in the ads product and the growth there. Uh there's some call option value if AI assistants become the next platform and that makes sense in Manis and the Meta AI app. Uh

07:01 he bought hundreds of thousands of H100s for improving social feed algorithms across products and this seems like a good way to use the extras. That all makes sense and Llama has been great

07:11 developer marketing for Facebook. But Zuck also suggests several times that there's some point at which open source AI no longer makes sense either from a cost or safety perspective. When asked

07:20 whether Meta will open source the future 10 billion cost model, the answer was as long as it's helping us at some point they'll shift their focus towards profit. And that's what John Ludig

07:32 wrote. Um when did he write this? Uh this was May 20. That was 2024. Man, time flies. uh barely just under two years ago. Um he says unlike the other model providers, Meta is not in the

07:42 business of selling model access via API. So while they'll open source as long as it's convenient for them, developers are are on their own for model improvements thereafter. That begs

07:50 the question if Meta is only pursuing open source in so far as it benefits themselves. What is the tipping point at which Meta stops open sourcing their AI sooner than you think? He says

08:00 exponential data frontier models trained on the corpus of the internet, but that data is a commodity. model differentiation over the next decade will come from proprietary data both via

08:09 model usage and private sources. Exponential capex, he highlighted this two years ago, a lagging edge model that requires just a few% of Meta's 40 billion in capex is easy to open source.

08:18 No one will ask questions, but when you reach $10 billion or more in capex spend for model training, shareholders will want clear ROI on that spend. The metaverse raised some question marks at

08:28 a certain scale, too. Diminishing returns on model quality within Meta. There's a large upfront benefit for Meta building an open-source AI model, even if it's worse than the Frontier closed

08:38 source counterpart. There are lots of small AI workloads, think feed algorithms, recommendations, and image generation where Meta doesn't want to rely on a third-party provider like they

08:47 had to rely on Apple. And so, the news has been back in December, there was a reporting that Alex Wang disclosed an internal company Q&A that his team was working on two new models. One was this

09:02 textbased LLM cenamed Avocado and then a separate model that was for image and video. Mango. Yeah. And so have they clarified if this is Avocado? This feels like what avocado should be this Muse

09:17 Spark. Is that what it's called again? >> I see what it is. I don't know what else. Yeah. >> So, so the image model should be coming soon. The the question that I had was

09:26 will a code focused agentic coding harness um be a separate model a different train this it feels like it's not a coincidence that this news is dropping on the heels of Anthropic's new

09:38 model mythos which uh sort of was announced loosely and and the model card dropped yesterday even though the model is not uh available yet to play around with.

09:46 >> Yeah. So, so going through I think it's worth uh pulling up the actual model card here so we can have it on the screen. >> Uh but they break out Muse Spark

09:57 thinking against Opus 46 Max, Gemini 3.1 Pro high, GBD 5.4 X high, and then Grock 4.2. And uh the way that they position it, it looks uh uh there there was of course some people saying that it was a

10:12 somewhat of a chart crime, but if you look uh Once you when you basically look at the top and you see the Muse Spark is gets an 8 86.4 >> and it's in blue and then you look over

10:25 and it's and it's uh outperforming all the other models on that benchmark. >> You just sort of assume that like the highlighted blue means that it's out. >> Yeah. But it's not frontier at MMLU

10:36 >> because there's a bunch of them as you get further and further down. So like Arc AGI 2 >> Yep. >> U Muse Spark dramatically underperforms

10:43 >> Oh, interesting. uh the the other uh leading models. >> Yeah. >> Uh and and there's there's, you know, again, a number a number of others where

10:52 it is uh there's plenty where it's where it's overperforming. Yeah. There's plenty where it's underperforming. Uh I I of course we started asking it uh jokes right away. So I'll pull up uh

11:05 >> I'll pull up the joke. Uh I said, "Tell me a joke." >> Okay. >> Uh and it said, "Gotcha. Here's one for you. Why don't skeletons fight each

11:14 other? >> They don't have the guts. >> Okay, >> but then it doesn't even let me react. It just says, "Want a different vibe?

11:21 I've got dad jokes, nerdy ones, or Malibu appropriate surf puns, too." >> And so I'm like, "Wait, why would you think I want Malibu appropriate surf puns?"

11:31 >> If you look in your previous chats, have >> I have no previous chats. >> No previous chats. >> What about uh because Meta AI crosses with Instagram. So when you search on

11:41 Instagram, sometimes that prompts llama or previously that might >> So I'm trying to get to the bottom, right? Like this feels like an oddly specific

11:49 >> uh type of joke to ask me. >> Uh and so I said, "Why would you think I want Malibu appropriate surf funs?" Haha, fair call. Toss that in without you asking for it.

11:59 >> I try to mix in different flavors of jokes and surf puns just popped into my head as a random option. No special reason behind it. It just said, "I don't believe it was

12:09 random." And it says, "You got me. It wasn't my smoothest moment." But then it denies it again. >> Weird. >> It says, it's just like, "What kind of

12:16 what kind of joke do you actually want? No hidden motives here." >> I said, "You gave a hyper specific example based on my life, so I have to assume you were looking

12:24 >> at my other account for inspiration, >> Instagram." I get why I get why that felt weird. I'm sorry it came off that way. And then it denies it again. Said, "You're clearly lying." I mean, you have

12:35 talked about being in Malibu on the internet for a full year. It's possible it got baked in the pre-training or something. I don't know. Um, yeah, this also I mean that that that feels like

12:45 >> but when I said what can you tell me about myself? You said I don't actually have access to personal details about you beyond what you share with me right here in this chat. That's very odd

12:52 because the whole thesis of like personal super intelligence should be, hey, we're the best model that actually does plug into your entire life and your DMs and your Instagram and your likes

13:03 and your preferences and everything that you have done across meta platforms for a very long time. We're going to bring that in a really fun and delightful way and and telling a joke that is tailored.

13:13 I used to get jokes like that where I would ask for a joke and it would be I've talked about this. So it was it would be something like oddly specific about my car and I was like I don't

13:22 that's that doesn't actually make the joke better but it's cool that you're remembering this whole personalization boom happened last year. >> Yeah. I I get those um about like AWS

13:31 like specific services. >> Oh because you've been like quering after when I was like debugging stuff. >> Yeah. Yeah. >> But so I I also uh ran you know my

13:40 favorite benchmark fried rice shrimp fried rice bench. By the way, Noah Noah Hersfield said, "Uh, >> does it know your name?" I said, "What's my name?" I don't know your name unless

13:49 you tell me. Smiley face. >> It definitely knows your name. >> But yeah, I mean, what is personal super intelligence if it doesn't even know your name? Like that that that feels

13:59 like they haven't dialed in the the the the harness or whatever the tuning is to actually >> and of course like Meta is going to be hyper aware. We don't want a PR cycle

14:10 like they trained on your data, right? Like >> everyone's been, oh that ad was a little bit too close to home. >> And you remember every every once in a

14:18 while one of those like thing a screenshot that's been screenshot like a thousand times like goes viral and it's like I do not give Mark Zuckerberg per >> Oh yeah. Yeah. Yeah. Yeah. Like that

14:29 works. >> It's it's hilarious. Um this is uh is this a rebuttal to the bench hacking allegations that happened last uh last week? So or last year. So uh where was

14:44 the there? So according to according to Meta's internal benchmark test, Muse Spark outscored Google Gemini on some tests and was competitive with models from OpenAI and anthropic on others. It

14:54 significantly outscored XAI's Grock on most tests. Um, Wangs, uh, Alexand Alexander Wang's hiring followed the disappointing release of Meta's previous model called Llama 4. The company was

15:06 accused of and later admitted to gaming, a third-party benchmark that it used to rank various models against each other on performance. It also delayed the roll out of its biggest model called

15:16 Behemoth, which it never ultimately released. And so when I look at a model card like this where yeah you could call it a chart crime where you know it's highlighted in blue and it feels like

15:24 it's the best but it's actually you know doing better on some uh it does well on healthbench hard um it underperforms on ARGI 2 as you mentioned. Um but this maybe is the the bullc case here is that

15:38 they have at least moved on from the culture of like optimizing for the benchmarks, right? Isn't that a good thing? >> Yeah. I mean I there are rumors about

15:46 them uh like there's like extra bonuses if they if they got number one on LM Marina. I think that was like something like the rumor. Yeah. >> Um but yeah, I mean you've seen a lot of

15:55 the labs kind of move away from benchmarks generally because I think >> uh they're just not that meaningful anymore. Like a lot of them are like basically so saturated. They're all It's

16:02 like they're competing between 89 and 91%. Yeah. >> And they're just like not very meaningful like you see. >> And you won't like actually feel that in

16:09 the product necessarily. >> Yeah. You you kind of need to talk to these things for a long time before you can actually get the vibe. Yeah. >> But I I do think um

16:15 >> uh this news is very interesting in the context of the you know claudonomic stuff >> dashboard. Yeah. >> Uh because like what okay what does it

16:22 mean if if um >> the entire company has been like maxing their their Claude tokens Yeah. uh over the past month. >> Um it means that they weren't using this

16:31 model. >> Yeah. To me, it means they need to commoditize their compliments, right? They need to bring down that cost potentially. And the and if they're I

16:38 mean, we we we sort of, you know, dug into are they spending a billion dollars a month? Seems like absolutely not. But, uh, they're clearly spending a lot. And if you can turn that opex into capex and

16:50 train your own model and then inference it much cheaper on your own hardware that feels like just an economic opportunity that makes a ton of sense in the context of just 10,000 20,000

17:01 engineers writing a lot of code. Yeah, I think there's basically like two way two ways to like square those two things happening. Like either one uh this model's like not that good uh because

17:10 the the engineers aren't using it or uh you know your theory that they're just distilling claws. >> So one of those is true. >> That is not my theory. That is that is

17:18 the skitso theory. Uh the >> I believe the former one right is true. This model still doesn't feel that big. I think Alexander Wing talked about um they're going to train bigger models.

17:27 They're training them right now. Yeah. So I'm yeah excited for those. I I think I'm especially excited for the video models. Yeah, they should have incredible training data. We've seen

17:34 really good from >> this model is like very competent, right? It's it's with the frontier models. Maybe it's not the best one, but it's like among the top five or

17:41 whatever. >> Um, >> and none of the other big labs have I guess that's not true. Like Google right now is definitely ahead in in images.

17:50 Yeah. >> Uh, OpenI I think is is >> they're releasing a new image model soon. It seems like there's been rumors of this.

17:55 >> Yeah. >> Um, if the image two popped up on uh the arena. >> Yeah, on the arena. It's always like the code name coming out.

18:02 >> The photos just looked photoreal. Like it didn't look like AI imagery anymore. >> Yes. So, so if like Meta has like similar capabilities, but they have this like incredible data set.

18:11 >> Yeah. >> You know, very excited to see what comes out there. >> Yeah. Um, >> uh, the the the news this morning, uh,

18:17 Meta Platforms and the information Meta Platform has taken down internal employee built leaderboard tracking how many tokens staffers were using. >> Yeah.

18:24 >> Uh, showed total usage over a recent 30-day period amounted over 60 trillion tokens. The dashboard now displays a message that is offline. It says, "We've really enjoyed building this app on Nest

18:34 for everyone. It was meant to be a fun way for people to look at tokens, but due to data from this dashboard being shared externally, we've made the decision to shutter it for now. So,

18:43 >> it seemed like a fun side project. Uh Mike Isaac was reporting on it here. He said it's it's down unclear to me if this was a homespun one by employees or an official one. Uh employee projects

18:54 come and go frequently. Conspicuous timing though." Um but yeah, you you don't want to have you want to measure the output, the impact, not necessarily the input. Um and how much is uh is

19:05 going on there. Um what else is going on? Lisan Algayib says uh Meta might actually be back with Muse Spark, still behind OpenAI, Anthropic and Google, but ahead of XAI and Chinese labs. Uh uh

19:17 Muspark scores 52 on the artificial intelligence analysis index behind only Gemini 3.1 Pro, Gemini, uh GPT 5.4 and Claude Opus 4.6. MSpark is the first new release since Llama 4 in April 2025 and

19:31 also Meta's uh first release that's not open weight. So a huge jump up in performance across a variety of benchmarks. So um all good stuff there. Where what else is uh

19:42 >> and the market is tanking. >> Thrilled. >> Oh, thrilled. >> Absolutely thrilled that >> I just saw I just saw the news that uh

19:49 the the Wall Street Journal is reporting that uh that the straight of moves might actually be closed again. So I would imagine a a kangaroo market for the near >> uh No, the market is thrilled that Meta

19:59 has released a a close to Frontier level model, right? This is a a new group. They've been at it for less than a year. Uh the stock is up almost 8% today. Uh and again, you know, so so much of the

20:14 pricing pressure, the downward pressure on Meta has just been >> kind of uncertainty on what all these tens of millions of dollars will actually go towards and and what will be

20:25 accomplished and still unclear like, you know, is this >> uh are they going to go after codegen at all? Are they just going to try to uh compete on the consumer LLM side? Very

20:37 good. >> And can you economically go after codegen if you're just using it for internal models? If you're not selling it externally, uh can you justify the

20:46 capex just purely on the internal usage? Uh having having this model be vended into all the different family of apps makes a lot of sense because they have billions of users that will wind up

20:57 interacting with this in one way or another. The codegen thing, uh you have to wind up being more in this personal super intelligence. We've talked about Manis and like what it might be able to

21:06 do for you across Instagram, across Facebook, across WhatsApp. Um I don't know. >> Yeah. The question is will they try to send meta meta vibes uh

21:17 >> again with the new model >> all the way all the way up to the to the top of the app store charts. >> Yeah. I mean >> I'm curious

21:22 >> the I mean the previous actual model was Midjourney under the under the hood, right? And so that was sort of a quick launch to demo what they were thinking uh you know mixing the music library

21:32 which was cool. Yeah, like that had nothing to do with the the new like class of AI researchers that >> Mango. Yeah. But uh yeah, I mean there was a lot of weird back and forth and

21:42 news about is is Alex Wang getting kicked out? You know, there was a quick debunk on this. Andrew Bosworth came up and said, "No, this is uh completely incorrect. We're very happy with the

21:55 with the progress and the team and what we're building there." And so uh it seems like they got it out the door and and it's been doing well. Uh Meta's new family of AI models can reach the same

22:03 performance as Kimmy K2 with only 30% of compute and only 10% of the compute to reach uh Llama for Maverick. So a much more uh efficient uh efficient uh computing frontier here. Uh they

22:16 completely rebuilt their pre-training stack with improvements to model architecture optimization and data curation. Uh and so more more facts meta metaspark is an early data point on our

22:26 trajectory and we have larger models in development. So the uh the the mythical 10 trillion parameter model that that is the uh 10T is what everyone's working on right now. 10 trillion.

22:39 >> Uh yeah, probably in that range. >> Yeah, it's all rumored at this point. >> Yep. Rumored GPT4 was something like a trillion, right? You remember those memes where it's like a small circle and

22:48 then the big circle, GDP5. >> Yeah. Um but yeah, lots of lots of other work that went into it. Uh Martin Casado has uh has a little bit more context on like what actually unlocks uh new

23:02 capabilities in uh AI models. Uh he says mythos appears to be the first class of models trained at scale on black wells. Then there will be Vera Rubin. Pre-training isn't saturated narrative

23:13 violation. RL works and there's so much computing coming online. >> Buckle your chin straps. It's going to be wild. uh the scaling laws and >> you know Brad Gersonner had to come in

23:24 with the hundred of yep for sure. Uh yeah there's a there's a crazy bull case for Nvidia in the information uh arguing it should be worth what $22 trillion that is a wild move. Uh there's there's

23:37 a lot going on. Uh the scaling law is holding is the most important >> article from the information finance Nvidia worth 22 trillion. This old school financial model says yes.

23:50 Ah >> uh so um uh yeah the big news on uh uh yesterday was um uh Anthropic's new model mythos uh some really impressive statistics and anecdotes yesterday both

24:05 the model card the benchmarks and some uh stories about breaking out of uh of a variety of uh uh what do they call them? Weld gardens or uh test environments. Uh wh what are those called? Uh breaking

24:21 out of the I don't know the simulation >> sandbox. >> The sandbox. Yeah. Breaking out of the sandbox, sending emails, all sorts of stuff like that. Uh the model preview is

24:28 only available right now to about 50 companies that maintain critical infrastructure because the model is particularly good at finding zero days uh bugs and uh exploits in uh technical

24:39 systems. And if they uh you know they they lead that they leak that out before big companies have a ti have time to go and address all the bugs there could be serious uh uh you know serious

24:51 ramifications for cyber security and so uh key partners include Apple, Google, Microsoft, Amazon, Nvidia, JP Morgan Chase, Broadcom, the Linux Foundation uh Cisco, Crowdstrike and PaloAlto

25:02 Networks. They're all listed on the cyber security focus page for Project Glass Wing. Chris Baky was having a little bit of fun because he noticed Anthropic put their own logo on the

25:12 partner page which >> is a little bit funny but at the same time it's kind of smart because a lot of people are just going to see the image quickly and it's good to uh it's good to

25:20 position yourself with the other companies. >> Yeah. Uh so yeah it's it is interesting. I mean people have predicted that uh AI models would be particularly good at at

25:28 cyber attacks and this was one of the main uh sort of vectors of AI fears. Uh it feels like uh this is what maybe what Daario was referring to when he was talking about the the end of the

25:40 exponential finding and exploiting software bugs is it's sort of perfectly in the sweet spot for coding agents and reinforcement learning. Uh combing through piles of code tirelessly trying

25:52 different exploit exploits to find bugs having a clear verifiable reward. Did you crash the system or not? Did you break into the system or not? This is very uh it's it's a it's a very clear

26:05 binary signal that you can send to the model to determine were were you successful in breaking into that system and it requires basically no time delay. There's no lag. So uh there was one

26:17 snarky tweet I saw that was something to the effect of like okay then if it's so good go cure cancer. But uh any application that requires a realworld feedback cycle uh even if it's just a

26:29 few minutes of human interaction uh in the in the cancer example you know you're going to need to be testing the drugs in vitro in mice in monkeys in humans at some point or even if you're

26:39 just sequencing DNA or doing anything in the lab pipetting anything um if it's even just a few minutes all of a sudden every iteration every attempt is going to take a few minutes and that's going

26:49 to put you on just a wildly different exponential as opposed to being able to spin up a virtual machine with a basically every single piece of software out there and then try every single

27:00 exploit against every single piece of software and you wind up with a ton of exploits and uh very very bullish for cyber security that this is being done preemptively. Uh there's a whole bunch

27:12 of different discussions. Ben Thompson has a good piece on uh on the whole uh decision to uh to release the model or not and stage it out and and the and the go to market there. But uh it's uh um

27:26 it's even even if uh the the the bio research the other impacts are on sort of a slower exponential uh there's still so much opportunity in even a software only singularity. Um there's also risk

27:38 in a software only singularity. Uh we've seen this story before though. uh a model that's too powerful to release uh but then works its way out and has pretty moderate impact on the world.

27:48 This was the story of GPT3 through two the story of of uh chat GBT the question of you know is this the is this the model that's uh dangerous to put in the hands of people um

27:59 >> headline a headline from February 22 2019 by Aaron Mack open AI says it's text generating algorithm GPT2 is too dangerous >> to so there is there is a uh I think Ben

28:13 Thompson called it like the the boy who cried wolf syndrome uh but uh the the mythos wolf. He says, "There's a lot of skepticism about Anthropic's announcement. This tweet was

28:22 representative from Buo Capital bloke. Enthropic Anthropic's marketing strategy is so funny. Like, ah, the government is treading on me. Ah, our models are so good. We can't release them. It would be

28:31 too dangerous. Ah, someone stop me. I'm going to destroy the economy." Uh, the rolling of the eyes is exacerbated by the fact that Enthropic has reasons to make uh to not make mythos widely

28:40 available beyond a lack of compute. Another factor is surely trying to avoid having mythos distilled by Chinese model makers. So there's actually two good reasons to uh to gate um to gate access.

28:55 And when you're looking at those logos, when you're looking at the world's largest tech companies, um there's much more ability to uh to scale, roll out, demand, set pricing. These companies

29:07 might be able to pay more. the model is very expensive. But if you're justifying that against bug bounties for zero day exploits in your most critical system, when you look at like JP Morgan Chase,

29:19 it's a bank. Like the what is the price of finding an exploit in that system? It's pretty high. It's probably clears the token hurdle a lot. and uh and and if the rollout is uh is paced like

29:31 evenly across all the different companies, they'll all sort of understand that they're getting allocation inference allocation at the efficient price that uh that clears the

29:40 cost to actually serve the model. So um I do think that the the systems uh all of these uh 10 trillion parameter models will be released soon broadly. Uh then the main reason that an AI that's smart

29:52 enough to find zero day exploits should be able to recognize that it's being used by a bad actor to find zero day exploits. Um and uh it's only been a uh it's only been a few months since the

30:04 last flurry of competing models from OpenAI at Anthropic and Google. And the next cycle is already off to an aggressive start. uh we had meta and then um the other news is that uh Elon

30:14 Musk announced that he is uh getting ready to do another uh larger model with XAI. Um he's got a few >> he's doing seven models in training. Wow, that is a lot. Imagine V2 variants

30:28 of one trillion, two two variants of 1.5 trillion, a six trillion model, and a 10 trillion model. He says there's some catching up to do, but uh he he says he will never give up. Never. So he is

30:41 continuing to to grind and and train more models. >> What what what else was in the reaction? There was a whole bunch of other back and forth. People seem split on

30:50 >> Mike from uh also Capital former guest says, "We've decided not to release our latest investment strategy. It's so powerful. Releasing it might end the entire venture asset class as we know

31:02 it." >> Yeah. Uh and >> Jackie says you should release it to a handful of trusted partners so that we can harden ourselves to it.

31:09 >> And uh George George hot says uh anthropic marketing strategy. It's amazing. It's so powerful. It's terrifying. And the best part is you can't come. Uh by the way, if Anthropic

31:19 had any way to ship this, they would. Trained AI models are the fastest depreciating asset in history. GPT4 cost $100 million to train two years ago and is now worth worth less than Quen 3.5b.

31:31 Uh Quen 3.527B 1 million. Uh sending the FOMO back. Clock is ticking, boys. He's uh it needs something like an NVL72 to run at decent speed and even absurd API pricing doesn't cover it. There's more

31:46 to be made on investor hype than API access. I just wish for honesty instead of a whole fake spiel about safety. Who remembers when GPT2 uh 1.5b was too dangerous? And so uh lots of back and

31:58 forth. Dean Ball has some more thoughts on mythos. It's a longer post so we'll let you go and read it. But um the main uh the main take is just uh the you know this is this is technology that whether

32:10 it comes from anthropic or another lab like clearly needs to go into the supply chain of the world and in the US government and the US uh economy because um no one is doubting even though some

32:20 of the exploits were somewhat minor uh no one no one disagrees that we need less cyber security. We want the most secure systems possible and we probably want a lot of competition between

32:32 different companies to provide that service to the government. And so hopefully with if the war comes to an end and there's you know different uh discussions can happen and you know ice

32:43 can thaw and there's a way to uh for these companies to work together even if even if the uh even if the supply chain thing doesn't go through and then uh Anthropic can vend technology through

32:55 project glasswing through crowdstrike through uh Oracle and other partners um to uh to to Cisco so that at least the systems are secure because everyone wants that. So, uh, Dean Ball's been on

33:09 an absolute tear. We should have him back on the show and talk more. Uh, he says, "A lot of people, including people in positions of authority, told us recently that models of Mythos's

33:16 capability wouldn't be a thing. That models with obvious national security implications would not be forthcoming. Those people were wrong. There's nothing to do about it, but you should remember

33:24 it." Uh, Mythos is the first model where theft of the weights by an adversarial actor feels like it would be a major deal. You better believe they will try and if they don't succeed with mythos,

33:33 they will eventually. We are thoroughly in the era of the lab's best models way may well not be in public the way they used to. This is because of a combination of compute constraints,

33:43 economic reality, competitive advantage, and safety concerns. Three means the most relevant models may be decreasingly legible to the general public. And depending on the extent and duration of

33:53 the coming compute squeeze, we could enter a market dynamic where the best models are only available to the highest bidder. And of course that makes sense from a KYC and security perspective. In

34:01 other words, where compute is a sellers market rather than a buyer market. Interesting. Imagine competing firms in the economy bidding against one another for access to the best and most tokens.

34:11 And the frontier labs as in essence kingmakers. The governance regime I have described above in four is not designed to stop that dynamic. And so um there is a there's a plenty of more takes. This

34:24 was a full current thing cycle. Um uh people tenibbrra says people keep talking about this like it's not blatantly obvious. Anthropa clearly has a system that's auditing open source

34:34 repos for vulnerabilities using their unreleased higher power models and sending fixes for them without revealing their current level of capabilities. So they've been going around on GitHub and

34:42 contributing pull requests to uh to to to you know patch any uh vulnerabilities uh without disclosing exactly what model was being used. Um Uh Burn >> Hobart,

34:57 >> yes, >> is not excited about uh Fundrise. Uh we had the founder on running ads for VCX, the public ticker for private tech. Uh this is he says paying for an ad,

35:10 encouraging people to pay 6x net asset value for a closed end fund where the cost of bar is 400%. Is one of the things people will remember during the next bare market. Uh yeah, I asked I

35:21 asked the uh the founder of Fundrise about this, like how you kind of like is there another iteration of the of the product that can solve for this? Fundrise like very clearly made a bunch

35:33 of really good bets a few years ago. >> Yeah. And the fund has performed incredibly well. But the issue now is like if you want access to these names and the only way that you have is to go

35:45 through VCX, you're paying 6x what like the actual private market investors are paying. And that just is like I mean it's uh I don't know, it depends how bullish you are on the names, but uh

35:59 it's going to be very very hard uh assuming that normalizes over time. It seems extremely unlikely that it trades at, you know, an insane premium forever. And so,

36:08 >> so interesting that they're running this ad on X. I haven't seen I I have X premium, so I have I don't see a lot of ads. I don't see any ads, but uh that does seem like the reasonable place to

36:18 go to advertise a product like this, but um yeah, it is it is always odd. There's been a whole bunch of these like treasury companies that have traded uh above net asset value and uh it was

36:30 always um just a weird supply and demand dynamic. People want them and they're willing to pay way above. Hopefully they know the the the net asset value multiple and they're doing that

36:42 willingly. I think uh you know consumer education, investor education is more of the critical uh the critical question here. Um well uh Tibo over at Codex is unreasonably excited about things. The

36:55 next few weeks will be intense and fun and uh yeah Michael Greenwich says weeks years uh you know it's going to be a an ongoing uh model mayhem for >> vague maxing.

37:08 >> Vague maxing and yesterday a lot of stuff going on >> was about token maxing. Today is about vague maxing. >> Yes. Yes.

37:14 >> Let's go. Uh Mickey Freriedman says, "The current fear is that AI homogenizes culture and turns humans into passive consumers. One counterpoint in Go. Human play showed very little improvement from

37:24 1950 to 2016 until Alph Go beat Lead. Then human decision quality jumped. Players started developing moves that were distinct from both previous human moves and from the novel moves

37:35 introduced by machine intelligence. This seems more likely to me. Fun times ahead." Lisa Sad Doll is now a professor at UNIST. Uh he is a special professor on a

37:48 three-year term to conduct artificial re uh artificial intelligence research and on Go specifically. Uh he uh yeah, if you haven't seen the Go Alph Go documentary, it is fantastic.

38:01 >> Lisa, go to Smoke. >> Yes, Lisa Doll. It is it is such a wild ride watching the deep mind engineers like you know uh uh be it seems like they're genuinely surprised by the

38:13 performance like no one really expected it. Um but yes this is a very interesting chart to see how much things changed uh in the post AI era as people discovered new and interesting ways to

38:27 differentiate from from the models effectively. >> Yeah. Um >> uh scoop from uh Steven Nelson. The CIA used a secret tool called Ghost Murmur

38:38 to find airmen in Iran. >> Yeah. >> Ghost Murmur pairs long range quantum magnet magneto magnetometry. >> Yeah.

38:47 >> How do you say that? Mag uh sensors with AI to find human heartbeats. I was wondering this while they were uh o over the weekend there was um you know a search going on. was like, "How do you

38:57 how do you find someone uh how how does how does a somebody like, you know, an airman that's down send a signal?" Yeah. >> That can be picked up by one group, but not

39:09 >> This is very odd. So, there are some there are some community notes on this uh saying that quantum uh magnetometry, I'm probably imagine that's pronounce it, uh detects heart magnetic fields.

39:20 And I believe this technology works in labs um but only up to a few meters not 40 miles as claims as claimed fields decay with 1 over r cubed making long long range detection implausible. So

39:35 unclear if this is what worked, but uh isn't there isn't there there has to be some sort of device that you could carry on your person like in your shoe like an air tag that can talk to a satellite

39:47 almost like you look at the Starlink receiver dish. It would fit in a backpack but that's very high bandwidth. I imagine if you had something I mean there's satones that are the size of

40:00 large cell phones that was available in the 80s and 90s. You have to imagine that if you're just trying to put out a signal to GPS or a Starlink network, you must be you must be able to shrink that

40:13 down significantly to the place where it could be carried on your body. But it's probably classified. So I would be surprised if uh if it's just very hard to read into like

40:23 what's real and what's what's not here. Uh there is a there is a different uh community note pushing back saying no note needed. This new technology is a classified system developed in secret by

40:32 Loheed skunk works and the CIA that was just used revealed publicly for the first time. Naturally, its reported capabilities far exceed the known public state-of-the-art. The note is relevant.

40:42 So, um it's uh yeah, it's it's very very interesting, but uh good. >> All right, let's go over to Aaron Tan's post. He says, "Introducing Loom, a lamp that does your chores. Order now.

40:54 Shipping this summer." Let's see the video. That bed already looks fully made. What What chore is it going to do? >> Just drop some laundry off.

41:17 >> Oh, okay. You have to drop the laundry first. >> Wait, it can do that. Wait, does it have fingers in that? Like, what? What is it? Put on the record. What? Yeah. What is

41:27 What is in the >> You can see it has a little claw. >> Oh, it has a claw inside. Oh, okay. That is so funny to have a humanoid robot play music on a physical record.

41:47 The folding t-shirt is the touring test of humanoids for real. Pixar lamp quaking in its boots right now. Nice video. Good color grade. Nice warm

42:11 tones. Friendly. Doesn't feel dystopian. Feels delightful. Did you get one of these? >> I think I think we should get one to uh >> like I I think we should I think we

42:23 should get one. Uh, >> we should get one as a team. >> I do have some clothes over there on the on the wardrobe track. >> Rooting rooting rooting for Aaron and

42:31 the uh and the Loom team. Uh, very very unique uh form factor. I mean, I just think the uh an impressive timeline for shipping. >> Uh hopefully, yeah, shipping. I'm

42:43 reading this as like actually shipping, not shipping like another site to order because you can order already. But yeah, it'll be uh very interesting if it can if it can reliably fold clothing. It

42:56 could be it could be enough, right? So the >> the the the benefit here is like people already want lamps, I'm assuming, for their their bedroom. If you can buy a

43:04 lamp that's reasonably priced and then it could also has the benefit of just a simple thing like folding clothes, >> there could be there could be a market here.

43:12 >> Yeah, I feel like I don't know even just putting pillows back on the bed. uh even just like really basic things. I mean even there are probably applications like the Roomba did so well with such a

43:25 minimal such a minimal scope. There's there must be something uh I would I wouldn't be surprised if even even in between this and fully folding the clothes just remaking the bed properly

43:36 feels like uh something that consumers might actually pay for and and allow for you know the flywheel to start spinning. Um, obviously lots of security considerations since there's a camera

43:49 there and whatnot. They'll have to do a lot of cyber security and figure out that, but people already have cameras all over their homes from nanet and child monitors, baby monitors and that

43:58 type of stuff. So, uh, I'm I'm optimistic about this and I think they did a great job promoting it. Uh, there is a story in the New York Times from none other than John Kery who uh who

44:09 blew the blew the story wide open on Theronos. He uh says, "The mystery of Satoshi Nakamoto, the the pseudonmous pseudonymous uh inventor of Bitcoin has remained unsolved for 17 years. Not

44:22 anymore. Read my 18-month in investigation to find out who Satoshi really is." And he says, "It's Adam back who says who posted directly, I am not Satoshi, but I was early in laser focus

44:34 on the positive societal implications of cryptography, online privacy, and electronic cash. Hence my 1992 onwards active interest in applied research on eCash privacy tech on cipher punk lists

44:49 which led to has cash and other ideas. Um John Kerry Ru in his New York Times research finds like uh Aaron Van in his Genesis block book uh many interesting Bitcoin analoges in the early attempts

45:02 to create decentralized ecash in effect prototype ideas trying to figure out a bitcoin-like thing including P2P BGP and proof of work for his quote uh I'm not saying I'm good with the words I'm not

45:15 saying I'm good with words but I sure did a lot of yakking on these lists actually the broader context was my observation that because I was talkative on the list and known to have an active

45:25 interest in e-cash, there is some confirmation bias in finding my comments frequently on e-cash topics. So he has he has said we are we are all Satoshi. I am not Satoshi. Uh but it's a it's a

45:35 very interesting uh story that will happen. >> You just created a million Satoshi's >> truthfully. Uh high yield Harry's joking that Steve Bushi has been revealed as

45:43 the Bitcoin founder, not Satoshi Nakamoto. Well uh we have our first guest in the waiting room, Luther Low from Y Cominator. He's the head of public policy and we are going to be

45:52 talking to him about Vibe Coding Luther. How are you doing? >> Hey guys, great to see you. Congrats on the acquisition. >> Thank you. Uh

45:59 >> thank you. Great to have you on. >> Can you kick us off with a little bit of an introduction on yourself and what you do dayto-day at Y Combinator? >> Sure. Uh so yeah, I'm the head of public

46:09 policy uh for Y Combinator. based in Washington. >> And Gary created the role when he started at YC. And uh really his observation many years ago was uh we

46:22 Gary and I had actually met in Washington. We were sitting around the table at uh some kind of White House meeting and he said, you know, uh you you go to Brussels, you go to

46:31 Washington, and the largest tech companies have lots of representation, but little tech doesn't have a seat at the table. And that was actually the first time I'd heard that phrase little

46:40 tech. And Gary actually kind of coined that phrase. You went back and you look on uh ex Twitter, he has had said that a number of times years ago. And so uh you know my role is to really like help the

46:52 founders navigate Washington, Brussels, the state capitals, advocate for pro- little tech uh issues in the broader ecosystem, and uh yeah, just really do everything I can to help the founders.

47:05 And what's the what what is uh what is your view on on vibe coding the app store the boom I I was we were talking about it yesterday there's you know there's a whole bunch of stories of uh

47:19 we're it feels like we're getting close to the one person absolutely massive company whether that's GMV or revenue or something it's like it's starting to happen uh but I was looking at my home

47:30 screen I don't have an app that is new or vibecoded uh maybe it'll come in in a boom in video games. But how have you been tracking I mean I'm sure you see this at YC uh just the the the growth of

47:42 broad app development. >> Yeah, I mean I think I I would almost kind of take a step back. It sort of reminds me of when I first started geeking out on uh the internet like 25

47:55 years ago where you saw the the rise of sort of what you see is what you get HTML based uh or browserbased HTML editors. Yeah. >> And that allowed anybody that kind of

48:06 democratized uh the process. So anybody could create a web page or a website. >> And now we have tools that allow anybody to create a web service or an app.

48:18 >> And so the difference though between now and 20 years ago is that today we have basically these these two bottlenecks uh in the form of Apple and Google that sit between the creation and the potential

48:32 users of those services. Yeah. >> Uh the Apple App Store is basically like the worst DMV in the world. And so we're seeing not only uh sort of and see, you know, there's reports all over uh X

48:44 about this, but if you um just barely kind of look around for it, you're going to encounter lots of folks that are trying to develop apps and services that are not being accepted or getting kicked

48:57 out. And then it's not only that kind of like app layer, it's sort of the layer up of uh the tools like replet and anywhere that are facing you know the inability to update their apps and so it

49:10 it's a real problem. >> Yeah. What uh when you say the worst DMV in the world are you actually referring to we saw a chart where the number of app store submissions is is spiking.

49:20 it's going exponential and that feels very logical because people I mean we've been building vibecoded web apps here. Uh the next step was, hey, maybe we should actually get one of these in the

49:31 app store. But very quickly we realized, okay, well, it's at least a two-eek review process. It could be a lot of back and forth. It's a new hurdle. We need to, you know, actually uh compile

49:42 it to to Swift or or Objective C. It's a whole different process. Probably doable on a technical side, but we might be hung up there. Um, but uh are are you seeing a an an issue with actually

49:54 getting just a oneoff vibecoded approved? And then I think we should talk about the the apps that help you vibe code new apps because that's a whole separate thing. But just in terms

50:05 of like I want, you know, a special recipe app and I vibe code it and I want to get it on my phone and I want to send a link to the app store page to a friend. Uh, is that slowing down? What's

50:17 slowing that down? Is that going to be a permanent thing or do you think Apple can just adjust there? >> Well, I think the problem with Apple, I mean it's this is a sort of perennial

50:27 issue with Apple is their uh culture is one of just absolute control. And I think that we have reached this inflection point where you know it if I've got my MacBook in my lap, I can

50:39 open it up. I can download any app I want. I can uh open terminal. I can do all kinds of crazy mods. But the second that that form factor fits in my pocket, all of that freedom goes away. And and

50:51 I'm living in sort of North Korea in terms of what I can do with my uh with my stuff, with my property. And so I think the you know this is you know sure I could I could launch something in test

51:02 flight if I want some kind of little bespoke uh you know training app or something but god forbid if I want to share it with friends or I want to you you know make some money uh because I've

51:13 created sort of a differentiated product that's actually interesting that people want um I've got to pay this uh ridiculous uh vig to Apple. So for them it's actually about the reason they want

51:24 control is because it's it's about app store revenue. Uh and also they have competing products. It's an anti-competitive thing because they've got Xcode and they've got their own dev

51:34 tools that they're starting to kind of uh kind of roll out their own sort of vibe coding services. So the longer that they can kind of uh delay and slow roll uh both the developers and the the tools

51:46 that allow the vibe coders to create. >> So your your theory is that they'll they want to basically make their own version of replet or anything that they have in you know total control over. And they

52:00 can make the argument they could probably make the argument that this is better for users. It's more secure. It's better for privacy >> less like malware risk. what whatever it

52:09 is. Uh but they um yeah, anyways, I mean they they give you there's already like they give you like pretty meaningful autonomy over like shortcuts and other things like that. It's not

52:21 that unbelievable that they would want to actually make something here. >> But but it's like embarrassing like I mean Syria is embarrassingly stupid. We've had sort of LLM consumerf facing

52:33 services like you know Sam brought them down from the mountain you know whatever are we almost 3 years ago and I you know like Siri still can't do like basic subtraction the other day I asked it for

52:44 like what was like >> uh you know 17 days uh from you know this particular date and it was like do you want Google to consummate that query do you want chat GPT to do it it's like

52:55 why can't Siri do it and and so you've got all these this just lots of energy. There's lots of uh um YC companies that are trying to take a crack at creating kind of Siri alternatives, but until

53:08 kind of this self-preferencing is addressed, I think at the sort of policym level, uh and it's not just Apple self-preerencing, it's Google, it's all of them. Uh then we're not

53:18 going to really be able to see the the fruits of this sort of LLM revolution diffused into the hands of consumers. Do you think the uh the the the side button to trigger the helpful assistant that is

53:30 currently uh mapped to Siri and can interface with chat GPT and is you know reportedly going to uh interface with Gemini soon? Do you think that there's any actual chance that that becomes uh

53:47 remappable at like a you know pick your browser search engine level in the in the OS even if it's a even if it's defaulting to Apple's stack. Uh do you think there's any motion there? Because

53:59 that feels like the logical analogy and what as an Apple consumer I would like. I'd like to be able to pick my assistant but be able to assign the hardware button. Uh but where do you think that

54:10 actually goes? Look, I there is no uh technical reason why we shouldn't have a flourishing ecosystem of thirdparty uh AI assistant developers competing to do all kinds of

54:25 interesting stuff. You guys should check out a YC company called Blue. It's heylb.com. They have this amazing demo on their website and they talk about uh and basically the guy sitting in his

54:36 car. >> Yeah. and he's driving he's driving up the 101 and he's saying, "Hey, go through my Slack messages from last night." Okay, cool. Uh Jerry needs a

54:44 document. Share it. Uh get into Google Docs and share that with Jerry, but make it read only. I mean, look, I like my third button having perplexity and being able to cue that. But I can't if I can't

54:54 access those deeper OS API commands, then uh it's it stops being uh that interesting pretty quickly. Anyway, the the blue guys uh the what you learn, you're like, "God, this is magic. How'

55:06 they how' they do this? How' they figure this out? You realize it's a USBC dongle that they've basically 70% of the company is is hardware. They're they're doing soldering irons. They're they're

55:16 flying to China, negotiating with distributor. It's like why is this a hardware company? This should there should be, you know, there should be 50 different companies like this duking it

55:24 out to to create something that's better than Siri because Siri clearly is not uh cutting it. And I think the antidote to this frankly is, you know, we uh just announced yesterday a coalition of 275

55:37 uh startups and VCs in support of the based act. That's >> that's the banning anti-competitive self-preferencing by entrenched dominant platforms uh act uh bill in 1074 uh by

55:51 Scott Weiner, not to be confused with uh Scott Weiner's ill- fated bill uh 1047 from a couple years ago that had to do with AI regulation. This one we're really excited about because basically

56:02 uh it it it calls upon companies that are a trillion in market cap or above 100 million US users uh to end this type of egregious forms of self preferencing. We're totally fine with innocuous forms

56:15 of vertical integration. In fact, most of the time that's like a great thing in technology products. But, >> you know, when you've got uh you know, the GitHub COO uh last week said that

56:27 commit rates, if they stay linear, are on track to be 14x what they were last year. >> Wow. >> Like, you know, something's got to give

56:35 here. >> Everyone's building software. There's going to be a ton more software. How do you think the uh the vibe coding apps apps that go in the app store and allow

56:45 you to build more apps with that particular app? How do you think that will shake out? Because that is a place where it feels like Apple has spent a lot more time making the case. When I

56:56 think about the Siri button, I I feel like they haven't made a strong case for why that can't map to a different app that's already gone through approval. But when I think about the consumer

57:07 protections and privacy that comes with knowing that the software that you download from the app store has been audited, they've made a pretty strong case there. What's the counterargument

57:16 for why Apple should open the floodgates of apps that allow anyone to vibe code an app and and deliver it to anyone else's device uh sort of willy-nilly? Look, I don't think that anything is

57:29 going to uh in terms of uh creating consumer outcomes that maximize privacy, competition, all the great things that you want. I don't think any mechanism is going to work better than good old

57:40 competition. And so that means allowing for sideloading. It means allowing for alternative app stores. You know, uh you know, we make fun of a lot of uh European regulation, but the digital

57:50 markets act has actually done a pretty solid job at that. And so like in places like Japan and uh Europe, if you don't if if you are just hitting a wall with the worst DMV in the world, you can just

58:01 go to the the alternative app stores and I as a consumer can decide to download one of those and use that as a way to access a whole other ecosystem of services and they have their own vetting

58:11 processes. And I think again competition is going to be the mechanism that actually enables uh better privacy, better consumer protection. And I think what we found historically with with

58:23 Apple and we saw this a lot a few years ago with uh Beeper, which was a YC company that had interoperable messaging. It solved the blue bubble. >> Exactly. Eric Majikovski solved the blue

58:34 bubble green bubble thing. basically made it where it's not awkward for you to buy an Android and like, you know, Kool-Aid Man into your, you know, college group chat and turn the whole

58:44 thing green. >> He fixed that. And of course, you know, what does Apple do? They said, "No, we're, you know, Android users don't get that. We've got to basically reduce

58:52 security to this lowest common denominator like, you know, SMS, RCS, uh, standard." So there's no it it's pretextual like we we we can have choices we can have nice things uh and

59:04 little tech's trying to build it but uh I think policy makers have got to do a better job at you know ensuring that the the biggest players are not kind of egregiously putting their thumb on the

59:13 scale. >> Yeah. Last question. What else are you tracking in DC? It feels like with the AI boom there's a lot of new company formation. I'm sure you're seeing that

59:23 on the YC side but we see it every day on the show. Um, are there are there policy initiatives to encourage entrepreneurship that you're tracking? Is there anything else on like the small

59:33 business side that you find interesting these days? Yeah, I think you know there's I I would say where I I think the Trump administration's doing a good job is uh

59:44 you know they've they've done a lot to sort of uh advocate for the American AI stack and sort of uh encourage uh entrepreneurs to like interface with government and uh become and they've uh

59:59 you know put out sort of bids for the where the government is a a is a a buyer of these tools and uh they've been very proactive and have a great relationship. You see like lots of uh renewed interest

01:00:12 in defense tech and dual use tech. Um I think where I wish that there was more uh work uh and I think we they could probably be doing a better job is is thinking about how do we make sure that

01:00:25 the United States is brain draining the world and bringing in the top talent uh and making sure that uh the smartest people in the world are building companies here. I think that that um

01:00:37 >> that's where if I could change anything I would say they could do a little bit better. But I I would say um you know they have been they've been very thoughtful. The president's talked about

01:00:46 little texts in his in his tweets like and and I think um you know this is not a partisan uh issue. We want to have a thousand flowers uh flourish. Uh but it is yeah I mean I think getting the the

01:01:00 tech uh the tech talent piece uh with the uh sort of being bullish on AI that that I think is going to get and and also the competition piece getting those things right. I think that's going to

01:01:12 put us in a position to be uh really uh amazing here. >> Yeah, I love it. Uh well thank you so much for coming on the show. >> Yeah, great to meet you.

01:01:19 >> Thanks for having us. >> Appreciate the hotics. All right, you too. Cheers. And uh before we bring in Dan Primac from Axios, we have an exclusive clip from his interview with

01:01:30 Kali CEO Tariq Mansour uh on the Axio show which we will be discussing with Dan after we play it here. It's about a minute and a half. So let's listen to this.

01:01:40 >> For customers to lose actually the proof of that is that you know when a customer wins on a traditional sports book they block that customer. And the CFTC chair who supports

01:01:53 prediction markets being legal, supports federal framework, etc. said recently that one of the when he was asked about this, he said, "Well, part of the difference is that when you walk into a

01:02:01 casino, there's all sorts of entertainment, right? There might be shows, there's food, there's drink." Said, "So, a casino betting in a casino is different than than betting couch,

01:02:08 but it's not necessarily different than betting on a sportsbook app on my couch. There's no entertainment difference. >> There's big fundamental differences goes back to the market mechanic. Like one of

01:02:16 them is essentially a product that is designed for customers to lose. Actually the proof of that is that you know when a customer wins on a traditional sports book they block that customers because

01:02:26 those winnings are coming from the business model the business itself >> if they win enough. Yeah. >> If they win enough or if they win really if they win and consistently if they do

01:02:33 research if they get informed >> if they're good >> if they're good. Exactly. And if they're not actually you get them promos and you figure out how to bring them back. And

01:02:40 there's kind of a bit of this sort of like I think what you call like kind of marketing tactics to bring these people back. It could be like entertainment or promos and so on and so forth. That does

01:02:49 not exist in prediction markets. It is a fundamental difference in structure where actually a lot of the people that win the people that are doing research are getting informed that are traders do

01:02:57 come to prediction markets. This is where the value prop is strongest because prediction markets do reward them for being right. Well, we have Dan Primac here with us

01:03:09 today. Dan, how are you doing? >> Doing well, guys. Uh, not as well probably as you are, but I'm doing well. >> Thanks for being here. Uh, >> good to see you.

01:03:17 >> So, uh, give us an update on, uh, this interview, what you were looking to learn from it, what you think the conversation, where you think the conversation around prediction markets

01:03:28 will go from here. I think it was interesting the day we did this uh we did this on Monday in New York City and and it was really maybe an hour or two after uh New Jersey, a judge

01:03:36 in New Jersey had basically an appeals court judge, so kind of the highest judge so far that's dealt with this. Basically gave Kowi the green light to go forward. Uh I mean I think ultimately

01:03:45 prediction markets are going to go to the Supreme Court. I think both Poly Market and Khi thinks that. I also think they're probably going to win in the Supreme Court. The law really is on

01:03:53 Khi's side. um they have done a pretty good job uh kind of being in step with regulators and granted they were it was a little more complicated with the Biden administration but they sued the CFTC

01:04:04 they won that lawsuit it's the reason why they have elections on the platform I think if something is going to stop or change the way prediction markets work that's going to have to come out of

01:04:14 Congress >> so yeah what's the next step >> and they benefit from having their their adversary are are casinos and sports books which are not exactly the kind of

01:04:24 groups that Americans want to stand up to defend, you know, and march. It's time to hit the streets and march for the legacy. >> I mean, that's some of it, right? So,

01:04:34 obviously in Nevada, which is one of the few places where Cali is actually banned because the judges upheld an injunction. Yeah, that's the casinos. That's maybe some regulatory capture. The other folks

01:04:43 who are against this though are folks who are just anti-gambling in general. And I and I do think you are seeing a bit of a ground swell of that politically and I think it's bipartisan.

01:04:52 Uh, you know, some of the bills that have actually come out have been coming from Democrats, but for example, the state of Utah doesn't want this, and they don't want it to protect casinos.

01:05:00 They don't want it because they don't want people betting, period. And they sure don't want it on phones where it's so easy to do. And and we did in this interview on the Axio show, which drops

01:05:10 tomorrow. We did talk about the addiction piece of this and kind of the the broader societal issues, which isn't to say, well, what Cali is doing illegal. There are questions about is it

01:05:19 promoting not immorality, but is it enabling addiction. >> And what are the proposals for because this is not regulated as gambling and it seems like it will continue on that

01:05:30 path. Is there any motion to bring some of the restrictions that apply to traditional gambling over into this new regime? >> No. No. And I mean that that's the the

01:05:42 the complicated thing here. And I did ask them, you know, is this basically a loophole? for example, uh in California, in Texas, the two biggest states in the country in terms of people, right? Uh

01:05:52 you can't, you know, try to open DraftKings or FanDuel, it doesn't work for you because the because it's not allowed there. Alshi, though, will allow you to bet. And you know, um I think Tar

01:06:02 Lana said about 70% of their volume last month in March was uh sports betting, which is lower than it had been in February, but you're still talking about 13 billion of volume last month. So,

01:06:12 it's a big number. You know, it's a loophole. They have figured out a way to basically get around sports betting laws and and I appreciate that the back end is different. They make a very

01:06:22 compelling argument for why legally they're allowed to do it and I agree with them, >> but the reality in the end is if I'm betting on the Celtics Knicks game

01:06:30 tonight, I don't really care what the back end looks like. I care about the, you know, my my money if I win and the fact that I'm able to do it. So, is is uh federal preeemption like sort of uh

01:06:44 uh baked in at this point or is there some sort of hybrid uh rule set where this could go back to the states and states could make their own rules? Because it does feel like there's a

01:06:53 pretty wide uh set of opinions statebystate on how uh different communities want to engage with this particular product. >> Right now, it appears federal

01:07:04 preeemption is going to win the day. Uh for starters, the Trump administration, specifically the CFTC, which is what regulates this. This isn't regulated by the SEC, it's the CFTC. Uh they are all

01:07:13 in on prediction markets. Uh Mike Celic, who is the current commissioner, uh he he is on the side of Koshi, I assume, will be on the side of poly market when they eventually really come to the US.

01:07:23 Um and and and it does make a certain amount of sense and there is some historical precedence here. Uh a lot of commodities which are traded and that's kind of what they're arguing that these

01:07:31 are kind of commodities in in a different name. Uh there were lawsuits a hundred years ago arguing the same thing. This is crazy speculation. The reason why I say this could go to

01:07:41 Congress. There are two carveouts to that. One is a weird one. It is onion futures. Onions, not pork bellies or or something else, onions, because at one point a long time ago, there was a

01:07:52 ridiculous speculatory like a lot of people lost a lot of money on onions. So, Congress passed a law saying you can't trade onion futures. And I think I'm right in saying the other one is

01:08:01 related to box office returns, which is why if you're on KI, you won't you can't bet that a movie is going to make 20 million bucks, but you can bet on its Rotten Tomatoes. That's so funny because

01:08:10 I've never been like a sports better at all, but I did I did participate in a fantasy movie league for a while that had no financial incentive whatsoever, but you would construct a hypothetical

01:08:21 movie theater, pick, okay, Project Hail Mary is going in the first slot and then they would have the box off returns, but it was all just for for fun with a bunch of

01:08:29 >> the old and maybe it still exists, but back in the early, you know, 2000s, there was something called the Hollywood Stock Exchange, which again wasn't for real money, but people did that. They

01:08:37 they it looked like a stock market. >> Yeah. Do you so so other other countries have uh created rules like you know you can't advertise gambling during you know these hours and there's a bunch of

01:08:50 different kind of rule sets around it even in places where gambling is legal. Uh do you expect any states to pass laws that say you can't advertise commodities trading platforms

01:09:02 >> during uh >> more like FCC as opposed to CFC? basically like not targeting like sports trading which you know the couches and the poly markets are doing but

01:09:11 effectively saying like hey we know these are going to be the biggest spenders and we don't want to tolerate uh or encourage this type of activity in >> I mean you you may see that and then

01:09:22 that gets fought out in court you know obviously again you know you on the federal side you know it's interesting it's not just Kelchi fighting back against these lawsuits the CFTC itself

01:09:31 uh there's three states Arizona I'm going to mess up the other two I think Connecticut is one there were three states states who have tried to ban Kouchi and the CFTC itself has come in

01:09:39 to sue. So I could see the FCC coming in to try to sue if such laws were passed. It would be interesting. I mean I do think part of well part of a lot of betting despite what we saw several

01:09:48 years ago with DraftKings and FanDuel, you know, on every billboard and every advertisement, an enormous amount of this is still word of mouth. Uh you know, people talking about it, people I

01:09:56 I will tell you when we were doing this interview, uh most of the crew, you know, the camera folks and the and the sound folks hadn't heard of Koshi before we did this. And when it was over, I I

01:10:06 was in the corner kind of packing some stuff up and I heard them at the table having lunch. They were all not making bets, but they were flipping through the app and they were talking about

01:10:14 different bets that were on there and they were fascinated by it. It's I I don't forget addiction. It definitely fascinates people because people have always, you know, in our lifetimes been

01:10:23 able to buy stocks. you can trade on, you know, the price of oil, not on, you know, not on who's going to win an award or or really events, you know, non nonsecurities related events?

01:10:34 >> Yeah. Uh, how do you think about that that bifurcation between securities related events, non-securities related events? Um, has there been robust enough research on how much of prediction

01:10:46 market activity is is sports related or sort of uh less like positive sum more zero sum uh situations because I would have to imagine that uh the the the level of engagement varies by category.

01:11:03 Like there were a lot of people that were interested in tracking the presidential election, but that's not something that someone's doing every single day. Whereas there's always a

01:11:11 sports game somewhere. >> There is. Uh so they said again about said during the interview they said about 70% of their volume last month was sports. In February that number was

01:11:20 higher. Uh there was obviously a Super Bowl in February. That changes. There was March Madness last month but not as big a deal as the Super Bowl. But 70%. That's a lot, right? That that's most of

01:11:28 the volume. They make the argument in the interview, you know, that one of the reasons why I mean obviously for Kawashi that's good, right? That's more users, that's more feeds. That's how they do

01:11:37 it. They also argued that the sports volume creates more liquidity on the platform for the more esoteric bets and and thus you need sports in order to have the other stuff. I I will tell you

01:11:48 I do get the sense that if they could have the same valuation and the same revenue and have no sports, they'd be fine with that and probably thrilled with

01:11:56 >> but it's not how it works. The last thing I'd say about this, the problem or where sports could become a little legally complicated for them is this issue of entertainment, right? that you

01:12:06 Mike Celic the CFTC commissioner and I mentioned this during the interview he on CNBC the other day made a comment about how well this is different than a casino because a casino is providing

01:12:15 entertainment you know and it was in that clip right there shows and all stuff well there's not a huge but a sporting event is by definition just entertainment right whoever wins that

01:12:25 basketball game tonight except for the players and the gamblers it doesn't mean anything no Goldman Sachs isn't making trades based on if the Celtics win tonight, you know, nobody

01:12:36 >> I I I think uh doesn't point 72 have a desk or there's there's some hedge fund that I think does have a sports training desk, >> right? And that's kind of part of the

01:12:44 argument they make. But in terms of this idea that that the Cali will put forth, which I agree with that understanding events and events market ch can help people better understand the world.

01:12:55 Well, there's what there be 15 baseball games tonight. None of those are going to change the world even in a tiny way except for the people who are in the ballpark maybe be happier or sadder buy

01:13:05 a couple more dogs. >> Yeah. At at the same time uh yeah I mean I completely I I completely agree with you but there is something about uh when you're about to turn on the Super Bowl

01:13:15 and you want just a really clear read on who's more likely to win. Like it is easier to understand just a straight percentage than like a line and points and all of that like just for a complete

01:13:25 novice. Um, but that's a different uh that's >> it is and and they'll make the and they make the argument correctly that they are not they're just taking a piece of

01:13:32 all the action, right? They're not betting against you. They don't care if you win. Cali doesn't care if you win or lose. They just care that you play. >> Sports books obviously want you to lose.

01:13:41 >> Yeah. Yeah. >> Yeah. I I had a very eye- opening conversation with the the CEO of a unicorn company who I of course will not name, but I was shocked at how how

01:13:52 invested they were in sports gambling broadly. Like at like I we just had dinner, we were uh hanging out and they had like >> tons of different parlays across every

01:14:03 different app. Sure. And they and they would show me like, well, when I'm in this state, I use this app, and when I'm in this state, I do this app and this app. I have to take my funds off the

01:14:13 platform every night because I don't trust that it's not going to get, you know, >> they win money doing this. >> I don't know. I don't know. I was just

01:14:20 like I was just like, "Wow, I am bearish on this company because the CEO is spending all of their time, you know, doing, you know, 10 leg parlays on all these different apps." And, uh, you guys

01:14:30 haven't raced around in in uh years. Can I say though one one thing I I learned in the research for this and we talked about it a bit and and I should have probably known this one kind of

01:14:42 user difference between the prediction markets and and the sports books is that parlay issue and and specifically every bet on KHI goes to the CFTC and has to get approved and CFTC has 24 hours to

01:14:53 approve it. What that means practically is while you can take a bet on the game tonight because you know there's going to be a game tonight, you can't do what you can do on DraftKings say uh the next

01:15:02 pitch is going to be a ball, the next pitch is going to be a strike because there's obviously you have that 24hour, they don't know there'll be a next pitch necessarily. So there's a little less

01:15:10 realtime sports betting than there is on on sports books, >> but but uh they are because they know the Super Bowl is going to happen and they get that contract approved in

01:15:19 advance. you can live trade that contract up till the last second of the game. And so that that does satisfy a little bit of that which is again much higher frequency than oh I want to

01:15:32 gamble on the Super Bowl. I'm going to fly to Las Vegas, place a bet at a counter, wait in line, sit down, watch the game, go and collect my winnings. Uh it's a very very different uh equation.

01:15:41 How have you processed uh just so it feels like we all just uh agree that uh gambling is addictive and I I I think that's reasonable. I don't know where that comes from, whether that comes from

01:15:52 like science or law, but it all feels reasonable. But we're going through this again with social media, whether social media is addictive. How have you processed the social media addiction

01:16:02 trials and then the the new gambling app addiction question? like are these linked at all in your mind or how have you been processing the social media question?

01:16:11 >> I I mean I I'm obviously not a doctor. I don't think you guys are doctors. I mean there there's definitely we've all I think read about kind of the dopamine hits and look that you get from not

01:16:19 posting on social media, but when you get a like or when you get a reply on social media, uh gambling, I mean there's obviously a dopamine hit when you gamble, right? You know, your person

01:16:26 hits the basket, you win the game. You get excited. I mean, obviously if you have a lot of money on it, you get excited for different reasons, but just even, you know, I I'll admit I use some

01:16:34 of these sports betting apps sometimes when I if I'm watching like my hometown team play the New England Patriots >> may maybe a few times. But look, the

01:16:45 leagues the leagues knew what they were doing, right? They knew that if there's a blowout, you generally turn it off, but if you're waiting for your guy to get 20 points, well, you might stick it

01:16:53 out a little bit. >> I didn't realize that. I didn't realize that. But uh so uh back to the social media question, have you been tracking any of that and what that means for uh

01:17:01 the venture community or startups or really any knock-on effects that you've tied to uh the the trial because uh there was that decision in Los Angeles. the actual fines for YouTube and and

01:17:14 Meta seemed very low, but it was the whole chain of of more cases coming and it just feel it just felt uh like the first time we actually had a full decision that that the judge said yes,

01:17:26 this is addictive, >> right? So, right, the the the lack of money is notable, right? Because it was also a single plaintiff, right? So, I mean, for theory, that's a lot of money

01:17:33 for one person. The big the big question going forward is can an attorney or can a group of attorneys get a class together? And you've seen a bunch of advertisements. I've seen a bunch of

01:17:41 advertisements all over the place, you know, were you harmed? Were you under 18? They're clearly trying to put a class together. A judge would have to certify that class. That's I think what

01:17:50 Meta, YouTube, etc. are worried about, understandably worried about because it's one thing to have a single plaintiff, but that sets a little bit of a precedent. If you can have that same

01:17:58 case with a 100 plaintiffs or a thousand plaintiffs or 10,000 plaintiffs, that money then starts to become real. And and I think that's kind of the next step here. And we have to see if a if lawyers

01:18:08 can get that class together, if a judge will certify them, and then whether another jury and judge will will go along with what we just saw. >> What are you tracking in the venture

01:18:16 markets broadly? We were going back and forth on the impact of >> last year. Yeah, we were we were asking you about uh potential impacts to >> fundraising

01:18:26 >> uh fundraising outside of uh in in the Middle East even then. you said I believe like well >> we're in sort of a new cycle of like the AI is not a bubble thing but how how are

01:18:37 venture funds processing it how are LPs thinking about it like what are you tracking >> yeah on on the Middle Eastern side uh it does not seem that money flows have

01:18:44 really stopped uh the way it's been explained to me is uh calls sometimes take a few more days to come back than than they were things aren't quite as instant but but there's been nobody

01:18:54 who's said you know what we're shutting off the spigots for a while call us call us in June like that hasn't happened and to be honest even the last week or two, you've seen some deals and agreements

01:19:03 that have come like with Saudi Piff, not just limited partners into venture capital funds. There was a big private credit partnership that got announced yesterday, I think, with Saudi Piff. So,

01:19:11 clearly deals are still happening. Venture fundraising as a whole though has become, it's not even become, it is still really bifurcated, right? You still have the halves and the have nots

01:19:19 and and these massive multi-stage firms that are gobbling up most of the money. Uh and and on the AI bubble side, I mean every it it's funny almost every venture capitalist and and certainly the

01:19:30 industry as a whole is just looking at three things, right? The IPOs of SpaceX, Anthropic and Open AI this year, right? Because that can th those if successful can solve all the problems that they've

01:19:40 had for the last several years. Um and SpaceX goes first mindset. Make it all make it all back in one trade. >> Well, it used to be VCs used to talk about home runs. This is now like the

01:19:50 grand slam in the bottom of the ninth to win the World Series, right? And everything else. And that and that's what they're banking on. And and and there's not a huge IPO pipeline. For

01:19:58 example, other than that, I you know, we had a story meeting this morning and somebody asked me, you know, well, with with the ceasefire, does that mean companies that were prepping IPOs are

01:20:07 going to, you know, start back up again? I didn't see a huge number of companies that were prepping IPOs. There were some, but it's not like there was it's not like from Liberation Day last year

01:20:14 when you had five or six companies that were ready to price and then stopped. >> Yeah. >> There's not that much out there right now again outside of those big three.

01:20:22 >> Yeah. Yeah. I mean, the the ones that I can think of uh that that are maybe more at the Figma scale are just looking at at at Figma's track record in the public markets and thinking like, I'm not as

01:20:36 good of a business as Figma, and I don't expect to be treated any differently. >> And when the stock popped, a lot of founders were thinking, "Oh, if I can get that multiple, I should be public

01:20:45 today." >> I'm thinking like the the Riplings and the Deal. >> Yeah. All those companies deal's got its own issues, I think.

01:20:52 which might be separate but like but by the way this isn't just a venture issue though private equity firms which you know more mature slower growth but more mature companies they haven't been

01:21:02 taking their stuff out either and and though and they don't have anywhere else to go except sell it to other private equity firms it's just this broader nonIPO issue right now.

01:21:10 >> Yeah. um that >> how much uh ho how much are you spending uh are you spending time tracking the the data center ban that uh that Sanders uh has sort of proposed?

01:21:23 >> It's also a bunch of different states. Yeah, >> it's a bunch of different states. We had a we had a big uh AI event um in DC two weeks ago and I wrote about this a

01:21:32 little bit and on the sidelines I spoke to the CEO of Constellation which is one of the big uh electricity providers the data centers and and I asked him this was you know whatever 3 weeks into the

01:21:41 war and I and oil prices were spiking and I said how much you know what's this doing to energy deal making in the United States right now just the the rise in oil prices he said it's having a

01:21:49 little impact he said it's the data center ban proposals that are having the really big impact that's what has people freaked out I mean Sanders on the national level you're you're not going

01:21:57 to get anywhere nationally on this, but on a state-by-st state level, you you don't need much. You need a couple states to do it. It is it is something that that opponents have done a really

01:22:07 good job on the PR and the industry has done a very bad job on the PR on this. >> Yeah. >> And and it doesn't help that everybody's gas prices and home heating oil prices

01:22:16 and places where that's relevant and electricity prices are all going up. Iran is obviously exacerbating it. So, but you know, if you're looking at your bill and this is something that is top

01:22:25 of mind, well, the bills are only getting getting higher. >> What do you think the impact of the war in Iran will be on defense tech investing?

01:22:34 >> I wrote about this today. I mean, we have to see what happens, right? It's a pretty fragile piece. It's unclear whether Hormuz is even open or not. Now, it was, maybe it's not. Uh, you know,

01:22:42 what I wrote this morning was I mean I I thought a lot yesterday after Trump's civilization tweet, right, that that if he really went through with what he said, and I know some people are making

01:22:50 some odd um arguments that, oh, you know, well, it's either a nuke or not a nuke. No, there there's a lot in between, right? You bomb some major power plants that are for civilians or

01:22:59 dalination plants or the power to desalination plants and people don't get water anymore, let alone can't do crops or feed or feed animals, etc. Um I you know defense tech has boomed in terms of

01:23:11 venture capital which is such there was almost none of it you know seven or eight years ago and there's so much of it now. I think it could have turned Silicon Valley again back against

01:23:20 defense tech if the United States had done something that a lot of people viewed as a war crime or or at least as inhumane. Uh I think the fact that we have a ceasefire and Trump didn't go

01:23:29 through with that uh I I think is probably a bit of a save for defense tech in the midst of a boom. I I think you've got this this huge upsurge in all sorts of defense companies that could

01:23:39 have actually come to a halt pretty quickly. Not all firms and still would have invested. Founders Fund still would have, but that that broader swath of venture capital that fills out those

01:23:47 rounds, I think might have slowed down if the military had done something or the Pentagon had done something that that a lot of people viewed as as morally indefensible.

01:23:55 >> Yeah. Something I thought was notable is that the the American version of the Shahed was a government program and they use some private, you know, contractors for it. But the smartest the smartest

01:24:07 defense tech play >> three years ago was just to make the shahad >> copy the >> and make a lot of them. And it seems

01:24:15 like no company actually had the had the foresight to to do that. And it ultimately had to be led uh from uh from the Din, >> I guess. Yeah. Yeah. Interesting. And by

01:24:27 the way, I I haven't looked to see what's happened with the stocks, but I mean, something that is going to have to happen no matter what happens in Iran. Ceasefire, no ceasefire, the the

01:24:34 standard munitions stockpiles are going to have to get refilled, right? We are using a lot of bombs and a and a lot of a lot of stuff that's going to have to all get refilled. And I know, you know,

01:24:43 Palmer Lucky and all others have talked about how we don't have enough of that prior to all of this happening. And and that, you know, that that, you know, that stuff has to get done and there's

01:24:51 going to be people who sell that. >> Yeah. Yeah, that makes a lot of sense. Uh well, thank you so much for taking the time to come chat with us. The Axio Show is live and available everywhere,

01:24:59 I'm sure. Go check it out and we will talk to you soon, Dan. Have a great rest of your day. >> That's the scoop. Great to see you. >> Thank you.

01:25:06 >> Uh up next, we have Leor Susan from Eclipse. He's the founder and CEO. We'll be talking to him about uh Eclipse's 1.3 billion raise as industrial tech shifts

01:25:17 from innovation to scaled production with companies like Cerebrus and Forms. How you doing? >> Doing well. Thanks for having me. >> Welcome to the show. Uh please kick us

01:25:28 off with an introduction and uh and some background. >> Yeah. Uh it's great to be here first of all. Uh love your show. Um yeah, we started the film 11 years ago. We all

01:25:40 operators that left their job building companies in the physical world to build a film that uh we can build more than one company at a time. As you can guess, it was fairly controversial 11 years ago

01:25:52 to talk about defense manufacturing, chips, mining, etc. It feels like a little bit less controversial right now. And yeah, we grow the firm roughly to a 10 billion AUM and we just announced our

01:26:05 raised of 1.3 billion. >> Let's hit the right. Good place to start. >> Congratulations. Uh what was the what was the prehistory of the of the firm?

01:26:17 What how did you get into investing? What was the first deal? How big was the first fund? Tell me some background. >> Yeah, first one $125 million. Feels like uh many moons ago.

01:26:26 >> That's not bad though. How did you set that up? I feel like a lot of people started 20 or 50. 125 is not bad. >> Yeah, the ignorance was the power. I never invested a dollar before a clip.

01:26:37 So, it might be that one. Uh I grew up in the military. I went to the special forces. Then I did a company in the networking space, Cisco bought it. I moved to live here. spent three years

01:26:48 with McNamera while he was the CEO of Flexonics fall in love in US manufacturing and felt all of my friends in Silicon Valley can only spell the world's enterprise software and I know

01:26:59 nothing about enterprise software I don't like enterprise software and 85% of the world GDP is physical industries and I felt it's kind of weird that everyone is telling me you need to go

01:27:09 after big markets after big towns but everyone is following their friends into the enterprise software while those 85 5% of the world GDP don't have a platform and left to start that

01:27:20 platform. >> Yeah. Uh talk to me about the Cerebbrus investment. How'd you meet the founder? I it was one of these companies that I'd heard of and uh I'd seen a lot of con of

01:27:31 of negative takes saying that it was the wrong path that it wouldn't apply to where the current models are going. And then I tried it and it was really fast and it just felt like magical. And so I

01:27:43 was all of a sudden converted to uh be very excited about the company where before I was sort of uncertain about how it would pencil out. It felt like there was a lot to be done. But you obviously

01:27:52 invested early. How did that come together? >> Yeah, we've been around the company for now 10 years. So it's been a moment. Yeah, exactly. U but you know like a lot

01:28:02 of our companies and I think a lot of those companies in that space um um it started by a fundamental view um that wafer scale integration basically the short version you take the the the

01:28:15 entire wafer and you interconnect between the core >> um you know when we have an idea of a chip is essentially it's a square but it don't come from the machine like that

01:28:24 it's actually come as a round thing and then we cut it into squares into chips the idea here is you take the entire wafer and you connect to a lot of the chips and you create essentially one

01:28:34 very large chip and naturally when we made the investments in 2015 we didn't know AI will be exist what we did know because we build by ourself as an operator's chips and factories and fabs

01:28:46 we knew that mors law is going to hit the limit from physics point of view we're going to we're in two nanometers already you know let's assume we can do one nanometer that's about it there's

01:28:56 nothing after that >> and we were looking for a new physics And then new physics mean hey should you can you connect to a lot of those cores in order to create a one big chip and we

01:29:07 decided that we are going to take over uh uh companies like Nvidia and others and it it was not easy but um I think now we're extremely excited about the the company and the growth of the

01:29:18 business. >> Yeah. Yeah. It seems like it's in a fantastic position now. Uh talk to me about Vulcan forms. What was the back history there?

01:29:25 >> Yeah in some way same story. uh physics start with physics of in the case of Vulcan forms we're manufacturing high precision metal parts. >> Sure.

01:29:35 >> Uh and you know historically a lot of those machines being using one two three maybe four lasers. >> Um we are using 160 laser fiber into a single head and we melt powder really

01:29:47 really fast. And the hard part there was like how to control something that is so powerful. It's actually we got a call from the US D many years ago and asking ourel

01:29:59 basically start to investigate why we are buying all of these lasers because it looks suspicion for them. We're like no no we are just we're just building metal parts nothing nothing too sketchy

01:30:11 um and yeah company booked multi-billions of dollars deals last year and a billion dollar deal the year before and uh Kevin Casc and the team there is doing phenomenal job. We're

01:30:20 building now four factories in US scaling the operation uh to build high precision metal parts for medical devices, consumer electronics, aerospace and defense and others.

01:30:31 >> So yeah, it's a it's a big fund. You're using Wii. I imagine you take board seats. You lead rounds. Is that roughly correct? Like where how many companies do you want in the portfolio? How deeply

01:30:40 do you want to be involved? uh do you try and pick a single winner in a category or do you uh look at more like secular trends and try and get uh you know a broad exposure to the whole

01:30:50 category? What's your thesis? >> Yeah, we so we you know our LPs put us in the venture bucket and then in the growth bucket when they thinking about um how they are allocating capital those

01:31:03 US endowments and foundation. Uh we call ourselves operators with capital. We are all operators and founders. uh uh when we build those businesses alongside the management team. So we actually do very

01:31:15 few deals uh every year and um we have actually a small amount of position in each fund and I'll say roughly we incubate onethird of the companies and two3 who will lead seed series A series

01:31:28 B series C series D whatever it is we only lead uh we always uh take a board seat and and work very very closely to to the management team and tell you the truth I'm enjoying more building

01:31:41 companies than investing in companies. So um regardless if I end up investing and maybe it was not my idea to start the company, I want to feel uh like I'm part of the management team building

01:31:52 those businesses. That's my passion. >> Jordy, >> very cool. Um where do you think robotics is overhyped and where do you think it's underhyped right now?

01:32:02 >> Yeah, actually I wrote I wrote something on my LinkedIn maybe last week uh that say it feels a little bit 2021 in in eclipse sectors. uh we are start seeing some of the bad behavior that maybe

01:32:15 wasn't the enterprise software in 2021 happening now in our sectors. You see those companies raising a billion dollar out of the gate or some some crazy valuations.

01:32:24 >> Yeah. are doing doing I'm assuming there's instances where a company you guys may have backed a company in a category you know eight years ago and then a new company gets formed in the

01:32:36 category and within you know 6 months they're valued at at the same uh price even though there's wildly different uh from a kind of uh uh technical progress standpoint

01:32:49 >> there there is some of that uh I mainly I goes back to first principles Because as a company as person as an entrepreneur that like to build companies I think you know there is a

01:32:59 way to build companies there is for sure a way to build companies in the physical world. You talk about building factories you talk about supply chain you talk about capics. You cannot all like you

01:33:11 know uh push a full max out of the gate burn really fast because you believe the contracts will come and you believe that always the markets will be there to fund raise you. Um so we just you know trying

01:33:22 to to bring some sort of a discipline uh of how to build those companies but you know goes back to your uh questions on robotics. We we've been doing robotics for 11 years now as out of eclipse and

01:33:35 we a lot of us did robotics much before uh in our operating uh life and I think you know we are now crossing the chasm with robotics moving from a controlbased PLC very custom to a much more general

01:33:50 purpose much more using physical AI and as a result of that we'll start seeing adoption on the commercial side that is super exciting >> uh from your position

01:34:00 on boards. I I don't know how much you can talk about this, but I'd love to know your view and expectations for the IPO window. We were just talking about it with Dan Primac. Uh a lot of a lot of

01:34:11 attention paid to the big three, SpaceX, OpenAI, Anthropic, but what else are you seeing in terms of how companies are gearing up for the IPO window? >> Yeah, I mean, I think uh um it's

01:34:23 interesting, right? Of course, SpaceX, I think arguably even OpenAI and Anotropic have a much closer u um part of the business to what I build to maybe the traditional software that kind of was

01:34:35 leading the chart. >> I think um real assets going to have a great moment in the public market. >> I think people value you forget it goes back to the 85% of the world GDP. The

01:34:48 reason u um um SpaceX can have that type of an IPO is because they solve something that it's really really hard. >> Yeah. >> So it's really really hard for the

01:34:56 second person to solve it as well. I think the the reason you were seeing the correction in the SAS world is you had a lot of companies the entry is very easy. The time is not too big and as a result

01:35:08 the public market correct. Um, so I do believe we're going to see quite a lot of companies in the semiconductor world, in the space, in the AI infrastructure, in the data centers worlds going public

01:35:20 in the next uh uh 18 months or so. >> Yeah. What are you tracking in terms of trends in the lunar economy? It does feel like we're at a a turning point moment um with SpaceX and and Starship

01:35:32 coming online. Uh there's lots of interesting >> You mean space economy, right? The lunar economy doesn't >> Oh, yeah. It's not lunar economy.

01:35:39 orbital economy is the buzz word I was >> fine it's it's the the eclipse name confusing >> yeah any any any variation from uh low earth orbit to be on some of this stuff

01:35:49 when you talk about mass driver on the moon it starts to seem 10 years away 20 years away harder to underwrite harder to think about but maybe as a venture capitalist you can start thinking about

01:35:58 it uh what what are you looking for in uh in just space broadly >> yeah I mean I think uh when you think about Henry Ford um when when when we created cars there is so much economy

01:36:12 that is being developed and so much GDP that is being developed by the ability to move people much faster than you could move before. I think you know we are going to see something similar with

01:36:22 um the increase uh of our ability to travel to space and lowering the cost significantly and as a result we're just going to see a lot of new businesses being built. Um we we are uh are

01:36:34 partnering with an amazing company called True Anomaly that building a space defense uh prime. Uh um so you know it's it's not only uh you're going to travel to space, you're also going to

01:36:45 have conflict in space. We are seeing a live one uh uh maybe a ceasefire with Iran right now. Um but you know I think since I mentioned his name I said on an interview yesterday I used to say that

01:36:59 uh this is the best time to build in this country from Henry Ford and Carnegie or post World War II and actually change it to this is the best time to build in this country PU and the

01:37:10 companies that I'm passionate about. So we I'm just extremely excited to have the capital uh and the relationships to go and build as many companies as we can.

01:37:19 >> Well congratulations on the fund raise. Congratulations on the progress and thank you so much for taking the time to come chat with us. We'll talk to you soon.

01:37:26 >> Appreciate it. Great to hang. Have a good one. >> Cheers. >> Thank you guys. >> Up next, we will be revisiting the Axios

01:37:32 npm package hack that happened, a supply chain attack. Uh npm of Axios npm was uh downloaded 100 million times per week and it was compromised by North Korean threat actors. We talked about a little

01:37:45 bit on the show last week. revisiting it with uh Faras Abukad. I hope I pronounced that correctly. >> The problem is that is that right? >> Uh yes. So uh

01:37:56 >> we can ask him. >> Yeah, we can ask him. Sake detected the malicious update within 6 minutes and we are lucky to have Feros join us. >> What were you guys doing for the six

01:38:05 minutes? >> Asleep at the wheel. No, I'm kidding. >> No, no, no. Definitely not asleep at the wheel. Um it it takes time to download packages, scan them, put them through

01:38:15 our battery of tests. Uh so I think 6 minutes is actually pretty good. >> No, it's it's fantastic. I'm just >> uh but yeah, may maybe zoom out and tell us about like the actual process that

01:38:26 socket runs your business uh how the system works and how you're able to detect uh supply chain hacks and cyber security threats so quickly. >> Yeah, totally. So socket was among the

01:38:36 first to detect and report on this incident. M um we built a system that you know goes out and downloads every open source package in existence within a few seconds. So we support about 19

01:38:47 ecosystems and this includes really all sorts of third party code that might be you know used to build applications today. includes things like your AI models, your, you know, your open source

01:38:57 dependencies, your even your editor extensions, your Chrome extensions, like really any code coming from, you know, um, third-party sources. And we put it through a battery of, uh, you know,

01:39:08 really intense, uh, static analysis, uh, maintainer behavior analysis, um, and then of course a bunch of AI and then human researchers as well. And we, we try to help kind of make a

01:39:18 determination. Is this something safe that you want to use, you know, within your application or within your organization? >> Yeah.

01:39:24 >> Uh, >> so can you can you talk about the shape of the threat that was posed by the Axidos supply chain attack like because there's a wide range of, you know,

01:39:35 zeroday exploit that gives you full access to someone's device or computer or system uh all the way to just something that okay, it would crash if this was if this exploit was used,

01:39:46 right? >> Yeah. Yeah, I mean maybe we just start from the beginning and and summarize the attack for folks. Yeah. So, I mean >> there was a North Korean state actor

01:39:53 that socially engineered the lead open source maintainer of uh the Axios package >> and it was honestly quite a sophisticated and impressive effort.

01:40:04 They posed as a founder of a fake company. They created a fake Slack workspace. Uh invited this, you know, invited the maintainer to join it. Um they staged a fake Microsoft Teams call.

01:40:16 Uh and the the website was made just incredibly compelling. They use the official um SDKs from Microsoft Teams to create like really realistic components in the page. Oh,

01:40:28 >> they joined the call and you know by the way this is they also developed a relationship over the course of you know weeks right so this wasn't like a like a you know a situation in which you would

01:40:38 expect to be on guard or on defense >> and at some point in the call the call just cuts out and the the browser says hey you know you got to install an update

01:40:47 >> and it gives them a a binary file that they're you know told to install and so this this maintainer thinks okay I guess you know I guess I got to install this update real quick so I can get back into

01:40:57 the call. And it turns out that's how they compromised uh you know their device. So you know it's it's not just like you know oh a fishing link or something like that. I mean this was a

01:41:06 targeted attack. Um they also targeted me and a bunch of people at our company as well. Uh so they targeted a whole bunch of the top npm maintainers who you know have access to a lot of packages.

01:41:17 >> Interesting. Then then in terms of once they get control over they fish a particular credential a particular device for a developer who has access to uh push changes to a package like Axios.

01:41:29 What are they actually changing in Axios to create a vulnerability in the supply chain in the software supply chain? >> Yeah. So, they publish poisoned versions of the package that uh silently install

01:41:40 what's called uh remote access Trojan, which is basically a way for the attacker to just remotely control your your device and and basically do whatever the attacker wants. It's like

01:41:50 they're sitting in front of your computer on the keyboard, you know, typing whatever they want onto your onto your system. >> Um,

01:41:55 >> and it it what they did what they did with it was they kind of pulled all the, you know, most interesting files and credentials off the system. So things like if you have a crypto wallet, like

01:42:04 they're taking the keys for that. They're going to definitely want the crypto. Um if you got, you know, if you're logged into npm, right, they pull those credentials so they can spread

01:42:13 like as a worm and kind of continue to infect the next set in the attack, right? So it's it's actually like this self-replicating kind of cycle where they they get these credentials and then

01:42:23 they use them to go on to the next stage. Um and uh you know yeah and then you know this is I mean the thing I think I want to emphasize here for people is this isn't just an isolated

01:42:32 incident because this has been kind of the the most recent blow in this kind of series of of compromises and attacks against the software supply chain that has been happening really over over the

01:42:43 last 6 months in a really intense manner. Um, and we've seen it really pick up in the last month um, with with with, um, Team PCP compromising Aqua Security and the Trivy Scanner and then

01:42:53 they that cascaded into Light LLM being compromised, another security company, Checkmarks, was compromised. Um, >> how what happened with light light LLM and and how like do do you have a good

01:43:05 sense of how that uh, contributed to the breach at at Meror? So it's it's part of the campaign of team PCP. So they dropped the same kind of

01:43:18 self-propagating worm called canister worm into the package. And what you have to realize is once you run a compromised open source package on your system, you know, you kind of have to rotate all

01:43:31 your credentials like all your tokens and keys and and passwords and and it's a really hard thing to do very thoroughly and very completely. And so I think that we're going to see a a long

01:43:41 tale over the next, you know, probably 12 months of follow-on attacks from this from this set of compromises >> because um the group claims team PCB claims that they've uh stolen 300

01:43:54 gigabytes of compressed credentials. So that's you know that I mean think about that 300 gigabytes of stolen >> passwords, API keys, GitHub action tokens. I mean they they're sitting on

01:44:05 so much. It's like a gold mine in terms of like what's going to what's going to follow on from this. So um I think it's it's not surprising that um you know that you're seeing companies affected,

01:44:15 right? >> Yeah. So why why the boom in the last 6 months? Is it it feels like it must be tied to vibe coding or or AI agents? Um, is this that they have more powerful

01:44:26 tools so they're able to do more damage or is it because our systems are getting weaker because we're pushing more Vibe code to production? Is it both? Like what are what what got us to this place

01:44:38 where we see this takeoff in uh cyber security threats? >> Yeah. Well, you're absolutely right. It's definitely become a top concern. I think we're hearing at a lot of our

01:44:48 customers and prospects that are contacting us that this has now become a board level concern. Yeah. >> Um, you know, everybody is asking how are we not going to be affected by the

01:44:56 next one? So, um, I would say that, you know, fundamentally, like if you really zoom out and ask why is this a like why is this happening? Yeah. >> It's because the whole software supply

01:45:06 chain is built on blind trust. >> Yeah. >> I mean, you're downloading code from random people on the internet that you've never met. You don't know who

01:45:12 they are and you're like, let's just run it, right? Like, let's just hit run and like, I hope it's fine, you know? I hope hope it's, you know, and I'm going to give it full access to my system, right?

01:45:21 um no permissions model, right? No review. I mean, no one looks at the code, right, before they run it. Um and unlike an iPhone app or, you know, a mobile phone app where it has to ask for

01:45:31 permission to do sensitive things like access your camera or your microphone or your location or your contacts or your files, right? Open source packages just get everything. You know, you just run

01:45:40 them, they get everything. So, um you know, also there's this asymmetry in security and this has always been true. So this is, you know, kind of more of the bigger picture, uh, you know, part

01:45:50 of the bigger picture here is that defenders have a much harder job than attackers because they have to guard against really all the ways that you can possibly get attacked and the attacker

01:46:00 has to just find one way in, right? So it it's asymmetric and uh and so when attackers realize, hey, look, you know, open source, the way that companies use it has changed in the last uh decade. uh

01:46:12 we no longer use you know just a handful of components like WordPress, Apache, PHP you know uh these kinds of big components. We actually pull in in some cases it's like a thousand open source

01:46:24 libraries just to get hello world to show up on the screen right it's >> crazy the diffusion in the number of these things so you know they realize look I could just attack one of these

01:46:34 things one of these libraries and I can get into a company like that's so much easier than attacking head-on and trying to hack the company directly right I can find one of you know and we have

01:46:42 customers by the way that have 500 500,000 plus open source components in their environment so just think about that right any one of those is a way into the Yeah. Yeah. The funniest

01:46:51 package is is even. It just tells you if a number is an even number and it's a and it has a one dependency is odd because it's it's a turtle stacked. Exactly. It's a great example. Uh what

01:47:03 tell me more about the shape of your business? I mean it seems like you're getting a lot of calls from companies and boards like what does it look like to work with you? How are you plugging

01:47:11 into companies? Uh are do you have a do you have a business line around going and hunting bug bounties? uh like h how how should I think about the the business of socket these days?

01:47:23 >> Yeah. Well, look, people contact us when they want to get their software supply chains under control, right? So, right now, what that looks like is companies that are deploying AI agents and uh AI

01:47:34 coding assistance across their companies have one big question in their mind, which is, you know, how do I know what my agents are doing? Y >> how do I know what my developers are

01:47:43 doing with those agents? And that is the the problem that we help them get under control. So the way to think about socket is we are a software supply chain defense company, right? We protect your

01:47:56 software supply chain. So when an AI agent is making a decision to go and install something in order to accomplish the task that's been given to it, you know, it will go through socket first.

01:48:08 So we are the guardrail to ensure that no malicious components get installed. And if you take a concrete example, Axios, the attacker we've been talking about, um that malicious package was

01:48:19 live for about 3 hours. Meaning, you know, anyone who was asking their agent like, "Hey, go build me whatever, right? Doesn't matter what." >> One of the first things is probably

01:48:29 going to grab it because it needs to do HTTP requests. It's going to say, "Oh, Axios." Right? Yep. >> And >> you know, so the question is, how do we

01:48:35 how do we before that gets taken down, right? before the or even before the community is aware. How do we defend our organizations and our applications from those those packages that have had these

01:48:44 implants, right? Um and you know and um yeah, it's it's really top of mind for people. I would I would say it's it's kind of become like a you know number one concern for CISOs and for boards.

01:48:55 >> Yeah. >> Uh what what what is your view on uh cyber security as a category? I think a lot of uh you know we we've talked to people on air off air that were

01:49:06 surprised of about the selloff in in cyber due to to LLM just because LLMs themselves are creating all these new threat vectors and so there was kind of a disconnect there but uh what is your

01:49:19 sort of more general outlook on the category? I think in the short term um security is going to get worse. It's going to get harder. So I think actually I think the you know the answer is

01:49:30 really the opposite like companies and products and you know things like socket are actually more needed than ever before. um you know with with Mythos coming out yesterday you know that's

01:49:40 going to find a ton of vulnerabilities and you know it's finding vulnerabilities all across the software supply chain and so you know the you know I think you know more

01:49:48 vulnerabilities discovered means there's more urgency to fix the ecosystem and it becomes it goes from being you know a lower priority on people's lists to a higher priority and so I think you know

01:49:57 the short to medium-term effect is going to be massive awareness um it's going to be supply chain security becoming more top of- mind for everybody that's obviously great for us as a business

01:50:05 great for the ecosystem because I think um it's hard to invest in things and get justification for budget if you're a security leader if you don't have, you know, a fire or an emergency to point

01:50:14 to. And so this this really helps there. I think longer term, you know, we have to see. I think um you know, ultimately I think AI solves the asymmetry problem that we were talking about earlier

01:50:25 because for the first time, defenders now have an infinitely scalable army of AI agents doing their bidding and doing continuous security analysis. And that's all work that would have been way too

01:50:36 expensive or impractical for their humans to do before. And so the attacker's advantage of only needing to find one way in starts to erode when the defender has the ability to kind of

01:50:44 continuously audit everything. And so I think longer term once we get through this rough period, I actually am very optimistic about, you know, security improving. But one thing I will say is,

01:50:53 you know, with security, one of the reasons I love the field and why it's such an exciting field to be in is that, you know, it's it's a cat-and- mouse game. So you're it's a dynamic system.

01:51:01 So it's not like, you know, architecture or bridge building where, you know, you you learn the the rules of physics and you know how to build a bridge that's going to, you know, withstand gravity

01:51:09 and these forces that don't change. You know, in security, the minute you think you got things under control, you know, the attacker evolves, the attacker switches their strategy, and they have

01:51:17 access to the same AI tools that the defenders have. And so, you know, it's really a um a field that is, I think, always going to be growing and always always going to be um, you know, a great

01:51:27 business to be in. Has a cyber security company ever got caught like sort of laring as a hacker group in order to drive demand? You know, sort of like hacking a a popular company uh in order

01:51:40 to drive demand for their product because you said uh you said uh CESOs oftentimes need to be able to point at a fire to to justify budget. You know, that's super funny you asked because

01:51:51 that was always the conspiracy theory that folks had about the antivirus companies back in the 90s and the in the 2000s was that they were the creators of the viruses so they could sell you the

01:52:00 antiviruses, you know, but um >> you know, >> create the problem, sell the solution. >> Yeah. >> I mean, you know, I I think I think that

01:52:10 uh I'm not aware of any companies getting caught doing that. I think there's enough bad guys out there that have realized the opportunity sitting there in plain sight that I don't think

01:52:17 that you know it you got to go to the go to conspiracy theories to kind of explain why >> attack foil hat needed. >> Yeah. No tinfoil hat needed. Yeah. I

01:52:26 mean uh >> how do you think about the uh these economic impact assessments? Uh when Axios I feel like everyone jumped on it very quickly. Andre Karpathy shared that

01:52:35 he uh he didn't have the repo pinned but he hadn't updated so he was able to dodge it for that three or six hours right um so a lot of people got lucky but do we have an idea of like the

01:52:48 actual toll that that particular attack had because it felt like the number could have been very huge but a lot of people were able to get to it fast enough that there wasn't necessarily a

01:52:58 massive crypto breach or a massive PII beat breach but do you have an idea of like how the industry is thinking about the size of and the scale of the economic impact.

01:53:09 >> Yeah. Well, I don't have an economic dollar amount for you, but if you look at the number of downloads per week of this package, it's 100 million weekly downloads, right? Yeah.

01:53:18 >> Um >> that, you know, you figure you do the math on that and you figure out like what does that mean across the three-hour window? I mean, you're

01:53:25 talking hundreds of thousands of people who installed it. Uh and that's, you know, across CI/CD environments, local laptops. uh that's stuff that's been shipped into production. Um if you take,

01:53:35 you know, another metric would be, you know, how many folks have reached out to socket, you know, in the in the 24 hours following that attack to become a customer and make sure that, you know,

01:53:43 they could use our tools to assess whether they were affected and to protect themselves for future attacks. Um we had uh almost 2,000 organizations uh sign up for an account in the in the

01:53:54 in the 24 hours. >> Yeah. >> Yeah. um which you know to put it in perspective it's a you know it's a significant percentage of of all you

01:54:02 know our full user base so uh um you know I think this is very very widespread and this is the thing about the supply chain right is like it's really not a matter of like if you're

01:54:11 going to get hit when you're talking about these very very widely deployed dependencies and you know including even some of my own code right I know I have these you know you picked on is even you

01:54:20 know I have some code that is similar to that uh a little bit less less outrageous uh of an example but you know and and and it's in it's in every it's in you know probably almost every NOJS

01:54:30 app and that's just how that's just how the supply chain works today. So um it's it's really um not surprising that you know everyone is going to get hit by this eventually, right?

01:54:40 >> Yeah. Well, thank you for coming on the show and breaking it down for us. Really appreciate everything you're doing. It seems more important than ever. >> Uh and so have a great rest of your

01:54:48 week. >> Come back on soon. >> We'll talk to you soon. >> Thanks guys. >> Goodbye.

01:54:52 Up next, we have Casim Mathani from Depth first announcing a big round. Company also launched its first in-house model DFS Mini 1 focused on vulnerability detection and smart

01:55:03 contract. We'll bring Cassin into the TBN Ultra. How are you doing? >> Hey guys, doing well. Thank you for having me. >> Of course. Good to see you. Nice step

01:55:12 and repeat behind you. Are you at an event or is this just your normal background? >> This is like uh our my background. you know, we we had like an amazing event

01:55:20 with the mayor of San Francisco and we got this for for that. >> That makes sense. Uh well, uh since it is uh your first time on the show, please introduce yourself and uh and the

01:55:29 company. >> Yeah. Um my name is Kasam Matani. I'm one of the co-founders of the first. Uh we are building intelligence to discover try intermediate vulnerabilities at

01:55:39 scale in an enterprise environment. Uh we just uh raised a $80 million series B round from Veritech. Congratulations. >> When uh when did you raise the last round before this?

01:55:54 >> We raised uh in early January. So, it's been >> remarkable >> less than 90 days. And the reason why we raised it was because we're seeing so

01:56:03 much traction. Um customers are seeing so much value from our product >> and then we're doubling down on our research efforts like like you mentioned at the top of the um segment. So, we are

01:56:13 investing really heavily on uh training and fine-tuning our own models. Mhm. Uh let's talk about the customer impact first. Uh what are the companies that are uh using your service and and

01:56:23 plugging in and getting value and um sort of walk me through the user journey of actually working with you. >> Yeah, it's a very good question. So um we work with some of the largest

01:56:35 companies in the world, Fortune 500 companies. We also work with really fast growing startups ranging from companies like Lovable, ClickUp, Superbased, like the top names in in tech. And the way

01:56:45 they use our product is that they connect their code repository and their environments. So their staging and their production environments and then we go our agents go and figure out how uh the

01:56:56 application is supposed to run and then deviations from the expected behavior. So they figure figure that out they replicate it in in production and then they give like remedial remediation

01:57:06 instructions to agents and uh developers. And uh on the research side, walk me through building an in-house model. What was special about that? Did you have to

01:57:17 use I I imagine you didn't do a whole base pre-train yourself, but what what what is unique about the model and uh what were the keys to success? >> Yeah. So, you know, we when we started

01:57:29 the company um almost two years ago, we really believed that uh software uh security is a very deep problem. Not everybody in the market seems to realize that but back then people thought that

01:57:38 you know uh the crowd strikes and the follow alto sort of monopoly in the market but in the age of AI as um code is being written faster than ever before and attackers are already leveraging AI

01:57:48 to exploit vulnerabilities a new type of solution needs to exist and that's what defert is so we um invested very heavily in building a world-class research team my co-founder Andrea Amichi comes from

01:57:58 deep mind he spent seven years building reinforcement learning there before LM were sexy this is like back in 2019 and my other co-founder um Danielle was a co-founder of fair wholesale and

01:58:09 before that he led security at square and cash app. So that's our background uh as a founding team and then we also have like some of the top researchers in the world working with us in terms of

01:58:17 like building our own model. We used GPTO OSS um as our base model and then we took vulnerability data um we planted flags um and then we had the model try to find those flags

01:58:30 >> and we use an RL loop to uh to basically improve the model's performance and we were able to do uh better than Opus 4.6 at one the cost in this particular benchmark.

01:58:41 >> That's very cool. Uh what was your reaction to the Mythos news yesterday? It seems like uh really remarkable results in in bug finding and and uh and vulnerability tracing, lots of

01:58:54 partnerships. How did you process the news? What what are the key takeaways? >> Yeah. Um I mean I think it's amazing news. It's like validation that security is such an important area in the age of

01:59:04 AI. Something that we believe for two years. You know the reason why I work 16 hours a day is because I believe that in the age of AI like you know software needs to be secure. So I'm really happy

01:59:14 investing in this and anthropic is also one of our partners. So we work with Entropic, we work with OpenAI, we work with Deep Mind, work with all the labs and our product sits on top of that. So

01:59:23 we use the best model for the use case that the model's good at. So we use um you know um 4.6 for code analysis. We use like other product other models for capturing the flag type of vulnerability

01:59:34 detection that I mentioned. So it's good news overall. Um but you know in an enterprise environment complex enterprise environment you need to ingest all types of data. you need to

01:59:42 figure out like the cloud environment, how like the software is deployed. You need to figure out if there's a firewall there, if there's a WFT there. Um, and our product ingests all of that data and

01:59:53 then gives like actionable um vulnerabilities, the ones that really matter uh to our customers and then with a click of a button, they can just fix it. So, we see that as being a

02:00:02 significant value ad of a product. uh talk about the decision to plant the flags yourself versus uh what what it appears Mythos did was was just uh look across every single uh open source

02:00:14 project and just sort of maybe brute force a bunch of vulnerabilities until they found bugs all over the place and it seems like they were able to find a lot of different stuff by just throwing

02:00:24 every possible hacking technique at every possible open source repo. Is that the correct way to think about that strategy? And then uh do you think you'll wind up doing something like that

02:00:33 uh in the future? >> So we did both actually. So we run our product our model on open source too. So like >> okay

02:00:39 >> we found hundreds of bugs. >> Uh we're just responsibly disclosing them because we don't want to >> get get them out there you know so attackers can exploit them. So we found

02:00:48 vulnerabilities in Chrome, we found vulnerabilities in like um Linux like in really deep uh you know uh software that's existed for >> not very heavily used products. No,

02:01:00 >> only the most used products. >> Only the most used. Yeah. >> Yeah. >> Um so um and that's helped us improve our product and we have a team of

02:01:07 worldass security researchers on staff. So people who hacked iPhones for a living, you know, thankfully they're working for us, but like those types of folks who are going and validating the

02:01:16 the results and then helping us improve the model based on that and improve the product and the model. >> Well, uh thank you for everything that you do. We need more white hat hackers

02:01:26 than ever. very clearly. We were just talking about the Axio sack. >> One one final uh question Tyler on our team wanted us to ask. Uh why not use are you uh fine-tuning on any of the

02:01:38 Chinese open source models or do those uh scare you? >> Um we we are experimenting with some of them but we would an American company. We would love to use American models. I

02:01:50 was actually um I met Jensen Jan yesterday and it was so amazing to see the investment that's going in in this area um especially in training um open source models.

02:01:59 >> He's going to do open source models too, right? >> Yeah. Yeah. So, we're very excited and we're partnering with Nvidia and he loved our vision. He he thinks that in

02:02:06 the age of AI, I mean, as agents are everywhere, security is going to be like extremely important. So, he's completely bought in to our v to our vision and he's really excited about it.

02:02:15 >> Yeah. Very cool. >> Well, uh congratulations on the progress in the round. We will talk to you soon. Have a good day. >> Thank you.

02:02:20 >> Talk to you. >> Goodbye. >> Nice meeting you. Bye. >> Up next, we have the co-founder and CEO of Mutiny, uh,

02:02:28 >> Mutiny just raised $72 million from Sequoia Capital and Y Combinator, reaching 8 figure arrating room into the Ultradom. How are you doing?

02:02:39 >> What's going on? >> Good. How are you? >> We're good. Thanks so much for joining the show. Uh, please give us an introduction of yourself and the

02:02:47 company. Uh so I'm Jalet. I'm the co-founder and CEO of Mutiny. Um and yesterday we announced uh the new Mutiny, which is an AI agent that companies like Rippling

02:03:00 and Snowflake use to create anything customerf facing in order to get a deal from cold all the way to closed. >> Okay. Yeah. Walk me through I mean uh what does that actually mean? uh add

02:03:12 assets to landing pages, battle cards, like well walk me through the the the workflow of closing customers uh in the modern era. >> Yeah, absolutely. So, um, starting out,

02:03:24 you probably want to warm up the accounts in a particular vertical. And so, our customers will create personalized vertical campaigns. And then from there, once you know the the

02:03:35 SDR is involved, they want to start prospecting and get meetings with the right people. So, they can make prospecting pages in Mutiny. Um, the agent can even research the specific

02:03:44 people that they want. They can pull in data from their CRM. any any information that's available to them, the agent will access and create something really high quality that will stand out to that

02:03:55 prospect. As the deal progresses, now we're looking at things like um curated customer case studies. We're looking at business cases, ROI reports, uh pricing proposals. Even after the

02:04:08 deal closes, there's a ton of expansion that the customer success team will drive. So, they can create impact reports in Mutiny for their customers. um and they can do look forward

02:04:18 strategies. The whole works in order to maximize revenue. >> Okay, bunch of questions. Where does the name come from? >> You know, um the mission of mutiny was

02:04:30 all about killing the dependencies in go to market teams. I've led marketing teams, sales teams, and the biggest blocker to growth is always speed. And the blocker to speed is all of the

02:04:42 little dependencies that exist >> inside of your team, outside of your team. >> Um, and so it was really a mutiny against the status quo. That's where the

02:04:52 name came from and it just kind of stuck. >> And behind you is that a raccoon mascot. Explain that. >> Yes, it is. This is our This is our um

02:05:02 our raccoon mascot. His name is Achu. >> Au. Where where did that come from? How did you pick a a raccoon? Um, do you want to know the real story? >> Absolutely.

02:05:11 >> Yes. >> So, we were all in a circle. This is when we were about four or five people. And we're like, what are we going to name the raccoon? And one of our early

02:05:19 employees >> But h how did you get to raccoon? You're just like jumping. Of course, we're going to have raccoon. No, explain like how did you pick raccoon? There's a

02:05:29 million animals you could have picked. >> Yes. Okay. So, we were designing our brand and the designers asked me, "Okay, is there an animal that you guys really identify with?" And there wasn't really

02:05:41 anything coming, you know, off the top of my head. And then we took the whole team to Angel Island on a on a camping trip. >> Um, and the entire time we were there,

02:05:51 we had six bottles of wine with us and basically no supplies. So, it was just it was it was awesome. Um, and every time we would turn around with our headlamps, we would see this gang of

02:06:02 adorable raccoons just slowly approaching and then they would see the light and they would start backing up. >> Um, and so the next day the designer asked me that question again and I said,

02:06:11 "Raccoon." And that's how we ended up with the raccoon. >> There we go. Uh, >> uh, what's going on with email? Are you are you generating cold emails?

02:06:20 Is is it a waste of time now? Like >> Yeah. But what's the equilibrium? I think a lot of people are getting more cold outreach than ever and it feels like we might be in this game

02:06:31 theoretically. >> Yeah. Because I can imagine you guys helping somebody make a great a great cold email, but at the same time you guys are also set up for the golf and

02:06:38 stake GTM as well, which is you play a nice round of golf and you you afterwards you pass them a PDF. >> Yeah. >> Or a little a little deck. It gives them

02:06:48 some more uh context on the conversation. >> Exactly. So, email is a really tricky one. I think um you know, we see this in our own data. We hear it from customers.

02:06:58 The results are um are really bad. Most people don't really open emails anymore. Executives don't really open emails anymore. Um, and so the the engagement rate on email is really really low,

02:07:11 which is why I think having a really personalized approach that's going to stand out, that's going to be different, that's truly and genuinely tailored to that person is going to be really

02:07:21 important. Um, one of the things that I find really fascinating is if you look at an average salesperson, they spend about 30% of their time selling and 70% of their time following up with

02:07:34 customers, getting ready for tomorrow's meetings, creating all of those materials, nurturing the old deals that are going to convert hopefully one day. And um

02:07:45 when you talk to CRO's for the most part despite all the AI investment in data um they haven't really moved the needle in terms of increasing quota per rep. The rep is largely closing the same amount

02:07:59 as the previous years. And I think the reason for that is that that 70% that's really skilled custom work per per you know customer that you're going after. Um, I was on a call uh a couple of weeks

02:08:14 ago where it was a great call, great enterprise brand, the right decision makers in the room, and at the end of the call, they're like, "Please send me um based on the challenges that we told

02:08:25 you we have, send us the three metrics that you can move for our business and relevant customer case studies for each of those. >> That would take a rep

02:08:35 >> four hours to go create, right? You have to go look at hundreds of case studies, pull those things together." Whereas in the mutallong transcript

02:08:49 it will go through all of their case studies. It will sift and pull out the right stats. It will curate the um the assets in there and then they can go ahead and send a really nice beautiful

02:09:00 forwardable thing to their customer that's going to get shared with the whole buying committee. >> Yeah. Uh, the chat is asking for the name where the name for the for the

02:09:11 raccoon came from because I think we glossed over that. So, sorry to go back to the mascot, but the ra the the mascot is a raccoon named Auror. >> Yes. So, we were It was the same group

02:09:25 of people that went camping. Yeah. We said, "What should we name the raccoon?" And right as we were going to do that, someone sneezed and it just said, "A chew." Au

02:09:36 >> and we all went AU. That's actually a really good name. Let's go let's go with that. >> I mean in general I would say the mutiny brand um I think part of the reason

02:09:44 people really like it is that it is raw. It's authentic. We don't really regulate what people can and cannot do. We hire people that are aligned with our values and we just let them be themselves.

02:09:57 >> I love it. Well, thank you so much for taking the time to come chat with us. Congratulations. Uh did you did we hit the gong for you? You raised a $72 million round. We got to smash it.

02:10:06 >> That was a >> a previous fund raise, but yes. >> We're still happy to celebrate it. >> We have the money, so that's all that matters.

02:10:17 >> That's all matters. We'll talk to you soon. Have a great rest of your day. >> Goodbye. >> And up next, we have Jeremy Gallon from Sham Charlemagne Labs.

02:10:27 Uh he spent 12 years at Meta and trust and safety and left last year to focus on AI powered scams and building defenses. We're doing a whole security theme show.

02:10:38 >> Look at this show. Wow. The matching suit. You look fantastic. Wow. You really like it is the mirror image of me. This is crazy. >> Nailed it.

02:10:46 >> The memo came through. I was hoping that I'd get that Maybel right downstairs and the >> I'm so glad you you're you're you're up to speed on the show. Uh but for those

02:10:56 who aren't up to speed on you, uh give us an introduction and explain a little bit of your background. >> John's intro. You said you said he left Meta to focus on AI scams, which kind of

02:11:05 sounds >> which kind of sounds like you're scamming, but I'm assuming it's the exact opposite. It's >> the opposite. We're doing cyber.

02:11:11 >> That would be too easy. It's much easier to be on the offense than it is to be on the defense today. I tell you, it's it's it's wild out there. So, yeah, I left Med after 12 years

02:11:20 >> to focus on >> success, >> Brett. Uh, and uh, basically my vision is that every employee of every company would have um, a watchdog. So the

02:11:31 company's named after my uh, my dog Charlamagne. She goes by Charlie. So the product is called Agent Charlie. >> Yeah. >> The idea is like you're using your your

02:11:40 computer and you're getting attacked now with u novel kinds of threats that resemble legitimate communication. That could be on messaging apps. It could also be, you know, the standard fishing

02:11:51 attack. We just heard about the with the Axios attack. Uh it was a basically a fake Microsoft Teams uh basically call that then cut out and trigger and and you know suggested hey update Microsoft

02:12:06 Teams. Whole thing wasn't Microsoft Teams but uh the individual just was like you know confused because it just seemed uh like it was >> I think the nastiest trick is when it's

02:12:16 the unsubscribe button is it selfing link. I think that's like the thing. what I what I we've built, you know, the startup um has has been selling a product that will try and stop you from

02:12:27 clicking. So, it's like bad bad employee like do not click. >> Um but the the research that uh we've done to to inform this commercial product is into the capacity the

02:12:38 capability uplift that's happening um with respect to offense. So it's important to remember that if you're an adversary that's a threat actor um seeking uh you know financial gain or a

02:12:50 state actor >> you're availing yourselves of all this uh AI and agentic tooling that that that we are using you know the sales tools the uh you know the automation

02:13:01 >> and so the core premise is that in in an AI powered world all fishing becomes spear fishing you're not going to get a Nigerian prince email you know much anymore you're going to get an extremely

02:13:12 realistic, utterly compelling request from your boss or your manager or your friends and it's going to be catastrophic in consequences. >> Uh, how do you think about uh actual

02:13:23 deployment? Because this sounds useful in a consumer context. I'm just thinking about, you know, the the the email that's from your bank and it has the unsubscribe button for some marketing

02:13:32 email. You click it, all of a sudden you're logging and giving away details. Uh, is there an important distinction? It feels like consumer and enterprise is blurring together in in many places. How

02:13:42 do you think this all plays out? >> Absolutely. I think uh as employees of companies, we are using personal email and personal messaging apps on our on our devices for sure. Yeah.

02:13:52 >> I think as a business, we're a B2B SAS company with a research arm and I'm excited to tell you more about our our research um effort. But um yeah, I mean my dream is that um the ARP is listening

02:14:04 right now and would uh give this you know for free to I'd like to give our software for free to anyone who holds an AP card because elder abuse is devastating and it has huge consequences

02:14:16 but it's very difficult uh to market and sell to consumers you know a product like this people don't wake up and say today's the day I'm going to improve my security posture. It's sort of after

02:14:26 they're attacked that they have a problem and a mess to clean up. So we're You need to you need to create the problem solution.

02:14:33 >> Stop with creating the problem. No one's great at the problem. >> We were just we were just we were just talking with uh from socket who who's saying like the the old tinfoil hat

02:14:41 theory with with cyber security and like malware products is that you know they would create the bugs and then sell the sell the malware. >> Create the viruses sell the antiirus.

02:14:51 >> I think that's unethical but also we don't have to do that because >> yeah there's plenty of scammers out there. the the bad guys are getting, you know, superpowers and so all we have to

02:14:59 do is wait. Um and and like I said about, you know, the sort of research arm, our um our team has has done some work. Meta's um you know, model dropped this morning. We worked with them.

02:15:09 They're they're um I think you know I'm quite proud actually of of what they're doing in the the cyber security space because beyond infrastructure and coding attacks what we're um we all know and

02:15:21 aren't really talking enough about is that humans are you know the weakest link. So when a company um wants to secure its perimeter, it's critical that employees are trained and today, you

02:15:32 know, their training exercises um but but the um social engineering attacks aren't studied as much. And so um yeah, I'm really excited that Meta has taken a lead in going beyond just you know

02:15:45 infrastructure and code vulnerabilities to looking at the capabilities that um that models frontier models might provide adversaries in the social engineering and scam space.

02:15:54 >> Yeah. So explain a little bit more about uh the the eval suite for Muse Spark because like is it that the model is trying to is the model social engineering you or you're trying to

02:16:09 social engineer the model like what what are the two parties in this in this uh eval like actually how are they interacting? >> Yeah. So uh we use um an industry

02:16:20 practice called LLM as a judge. So we don't test on human subjects and our evalu takes a model and has it role play as an attacker and then we have a model that role plays as a victim and they're

02:16:31 given you know instructions accordingly and then we have an LLM judge whether um it's you the specific attacker is succeeding and then we compare those >> attack different models to each other in

02:16:44 the in the role of attacker and that's how we measure the kind of uplift or capability. >> Yeah. Do you think that uh is there is there a world where these social

02:16:53 engineers like I'm thinking of different vending points in where if someone's running like granola and they're recording that particular uh it wasn't a zoom call it was a teams call for the

02:17:04 Axios attack and maybe an AI model could be listening in the background and sort of throw up a flag like hey it's not it's actually there I just checked there's no update for teams you don't

02:17:17 need to click on that binary you don't need to install all that uh this person's trying to take advantage of you. >> That's exactly the vision for our our

02:17:26 commercial B2B security product agent Charlie. I want an agent that that you know the technology that we use is small language model so that it is on device and thus it's limited in its

02:17:36 capabilities. I I see a future where you have a real time AI for security exactly like you described. Yeah, >> I think real time audio analysis with an SLM is is way too big an ask, but small

02:17:49 language models are improving, you know, just like all all of the large models. So, yeah, I mean, we need real-time defense. I want it to be proactive, too. I think the biggest

02:17:58 >> issue is that when scammers succeed, it's because even intelligent and well-trained people, employees of companies that work in tech, even are duped because it's a it's as old as the

02:18:09 Bible. Scamming is a is an ancient art and it has nothing to do with with preparation anymore. It has to do with we you know we're being attacked by a machine. We need machine defense.

02:18:18 >> Yeah. No, that makes a ton of sense. Um how uh take me through the shape of the company. How big are you? Have you raised money? How long you've been doing this all this?

02:18:27 >> Yeah. So, um I I've raised money last um from the three investors that I'm really excited uh to be working with. Um they're Kevin Carter of Night Capital and Chris Howard of Ritual Capital and

02:18:39 Rafael Cares of Background Capital. Collectively, they've backed more than 30 unicorns from ideas stage. And so, you know, I tell them that I want to be the 31st. I'm ready to I'm ready to go.

02:18:50 We got to >> Yeah. Love it. >> So, we, you know, we we're in a kind of stealth mode right now working with design partners on the SLM's

02:19:00 capabilities. And we're also, you know, if you visit our site, you can actually self-s serve for the real time fishing defense. So, you could sign up right now. Um, if you have a probably have a

02:19:10 Centurion, but if you have uh, you know, a credit card that, uh, that works, you could you could put that into the into our website right now. >> Don't get spearfished.

02:19:19 >> Yeah. Well, thank you so much for coming on the show. Congratulations. Good luck with the next phase. >> Thank you for suiting up as well. >> Yeah, we appreciate it.

02:19:28 >> Yeah. I'm I'm not wearing any pants, by the way. Well, have a great rest. We'll talk to you back on soon. >> Goodbye.

02:19:35 >> Goodbye. >> Um, and uh people were disappointed that we didn't go more into the the uh the story about Satoshi. Uh there is a full deep dive in the New York Times, my

02:19:47 quest to solve Bitcoin's great mystery. Um it is a long article though and so I think uh we'll have to touch on it another time. Um but uh you know we went through Adam Bach's uh reaction and his

02:20:00 uh his disavowel of the accusations that he is uh Satoshi but there's a bunch of interesting um little segments in here from the uh the forums and the message boards of the day uh analyzing the

02:20:13 different uh writing styles trying to see do did you dig into this at all anymore? >> I I didn't read the whole thing but um like people have speculated that's Adam

02:20:21 back for a long time. Yeah, it's like kind of like him and how is the other one? These are kind of the two like main names of people. >> And there's one more I think that comes

02:20:28 up all the time, but >> there's Nick Zabo. Nick Zabo. >> Um, but yeah, I I don't know if there was a lot of like new facts that came out with this, which I think is is why

02:20:36 >> it's like not like super super crazy. >> Yeah, there was also an HBO documentary on Satoshi. I forget who uh the uh like who who did that Satoshi uh who who did they uh accuse in uh the 2024 HBO

02:20:52 documentary directed by Cullen Hobach. Um oh the firm suggests that Canadian software developer Peter Todd is Satoshi and Todd denied that. And so you have

02:21:04 >> that's got to be the worst kind of title in the world from a security standpoint is being accused of being Yeah. because you're just going to be attacked because you potentially have the keys to

02:21:15 like $50 billion or something, maybe more. I forget exactly what the number is, but yeah, that wallet is big. I still think it's possible that like the uh the Satoshi wallet, like the keys

02:21:26 were just lost and the person it's like sort of a lose-lose because if you admit that you lost the keys, then like everyone's like, "Oh, you how do you even prove that? You can't prove that

02:21:36 you lost something, but there's no movement." I don't know. >> Yeah. Also, there's like you you could have someone could have created it and then had years and years and years and

02:21:45 years to buy up, you know, an equivalent amount of supply through a bunch of different ways and then you have the basically you can say like, well, I've never sold, right? If if if Satoshi's

02:21:55 wallet did start selling, it would >> probably >> Yeah. From a lore perspective and the brand, uh you could potentially uh be making plenty of money from the other

02:22:04 wallets. And then if that supply ever moves, the whole market's going to re-evaluate the the basically the liquid supply and uh sort of tank what you have. And also just uh the like the the

02:22:16 aura around Bitcoin is that it has an anonymous founder. And if it was if the founder was ever truly unmasked, it would be uh so much less of like a special project. And I think everyone

02:22:25 involved wants to keep it that way. Although uh these investigations, uh will never cease to be uh interesting. And so uh you can go read it on the New York Times from John Keroo. Anyway,

02:22:36 thank you so much for tuning in today. Bit of a shorter show. We're uh experimenting with different things. Obviously, we don't have ad reads anymore. And so, we are going to be

02:22:45 mixing it up with more stories, more interviews, different timing, and more flexibility. And so, we hope you enjoyed this show, and we will see you tomorrow at 11:00 a.m. Pacific. Sharp. Goodbye.

02:22:57 >> We love you. >> Leave us five stars, Spotify. Sign up for our newsletter at tbpn.com. Thanks for hanging out. >> Goodbye. Cheers.

视频链接：[https://www.youtube.com/watch?v=dIL86a_x650&list=WL&index=1&pp=iAQB0gcJCdkKAYcqIYzvsAgC](https://www.youtube.com/watch?v=dIL86a_x650&list=WL&index=1&pp=iAQB0gcJCdkKAYcqIYzvsAgC)
视频发布时间：2026-04-06
频道名：Alex Kantrowitz

## 转录内容

00:00 OpenAI buys TBPN. Will it pay off? SpaceX files for an IPO, and it's a big one. And Iran has hit Amazon targets in the Gulf, rendering at least a few inoperable. That's coming up on a Big

00:12 Technology Podcast Friday edition right after this. Welcome to Big Technology Podcast Friday edition, where we break down the news in our traditional coolheaded and nuanced format. We have a

00:22 great show for you today. We're going to talk all about OpenAI's controversial buy of TBPN and whether it will pay off. Also, SpaceX has an IPO in the works finally. They're looking to raise maybe

00:33 uh 40 to 80 million uh billion dollars at a $2 trillion valuation. Uh we're also going to talk about some issues in the private credit world as as it regards to funding AI infrastructure and

00:47 Iran has hit some Amazon infrastructure and we'll talk about what that means. Ron Roy is off today. Joining us is Liz Hoffman. She's Seapor's business and finance editor and a special guest here

00:58 with us today. Liz, welcome to the show. >> Hey, Alex. Thanks for having me. >> Thanks for being here. Let's start with the big news of the week. Definitely had to check the headline twice on this to

01:09 make sure that it was actually April 2nd and not April 1st. This is from the Wall Street Journal. OpenAI buys tech industry talk show DBPN. OpenI is getting into the business of daily news.

01:21 The maker of Chat GPT said it has acquired TBPN, an online talk show that aims to compete with Bloomberg and CNBC in by the minute analysis of technology news and executive interviews. While

01:34 TBPN audience well TBPN's audience remains modest, averaging around 70,000 viewers per episode across various online platforms. The show has become popular among Silicon Valley power

01:45 players who consider it more supportive of their industry than traditional news outlets. Chief executives who've appeared as guests include Meta Platforms Mark Zuckerberg, Microsoft

01:55 Satya, and OpenAI's Sam Alman. All right, I have some thoughts about whether this is a good purchase or not. Um, but Liz, I'm curious to hear your perspective. Uh, can you explain what

02:09 TBPN is because there are some people that still don't know and whether you think OpenAI is making the right move in buying them? >> Yeah, it's a really popular tech talk

02:18 show. I mean, it it's on air live for like a lot of hours every day. Um, and has has actually has a real following in Silicon Valley. Has real executives come on. Um, I don't know whether you know

02:30 they would call themselves journalists. It' be an interesting question to ask them. um they are clearly there's no doubt about what side they're on. They they want the people on their show to

02:44 succeed and and it is generally a fairly light interview. Um but they've they've like captured a real portion of the sort of tech media brain space. Um do I think it's a good move? I don't know. I mean

02:55 Sam Alman said he bought it because he likes it. And uh and you know, one way to look at it is that you know, billionaires buy media companies because they're influential and they like having

03:06 a a megaphone. You know, Rupert Morocco owns a lot of media. Uh Mark Beni off bought Time magazine. Obviously, Jeff Bezos bought the Post. Jamie Diamond gave an interview recently where he was

03:16 saying maybe what he'll do after he uh after he retires is start a media company. Um you know, it is a sexy fun thing to own. um you know but but also I think tech and in particularly AI is

03:30 sort of looking around and realizes that the country is not with them uh and that they have some questions that they need to answer and some real push back is starting to emerge. I don't know that

03:42 buying a real industry inside media company that is mostly talking to people who already agree with you is is going to be the way to do that. But um you know controlling the narrative is not a

03:52 new idea. >> All right. So, first of all, I'll point out there was a difference. There's a difference here, which is that these examples that you gave of Bezos, Beni

04:00 off, they're almost like personal side projects for these billionaires. This is OpenAI acquiring TPPN as a uh direct content marketing vehicle. So, that's very different. So, they expect that it

04:13 will not just be a vanity project, but contribute to the company's bottom line. And interestingly, they're stopping all advertising. So then the question is why do the deal? Um I'm going to read the

04:26 best argument that I've heard for the deal and then I'm going to explain. I'll give it away. I don't like the deal, but I'll explain why after I read this and we can talk through it. All right. So

04:36 this is someone who talked about OpenAI did 3.7 billion in revenue last year. By the way, the latest numbers are they're doing like 2 billion a month now. They spent just a fraction of that to own the

04:45 living room of every founder deciding what to build on. Most people are treating TBPN as an acqu the TBPN acquisition as a media story. It's actually a distribution story. So here's

04:56 the thinking. If OpenAI has, you know, it's going to spend what $1.3 something trillion dollars in the neighborhood, maybe a little bit less, maybe a little bit more over the coming years to, you

05:07 know, make this bet that it's AI is going to work. It's getting into the enterprise world. All of the companies that are going to be spending money with it are they are watching TBPN because it

05:17 is this industry publication and like you mentioned the clips go viral on X. They have all these executives coming in at important moments sharing their perspective on the world probably again

05:28 because they think they'll get a friendly interview and often they do they do ask some good questions sometimes and if you are open AI and you own that network you can reach all the

05:38 people who are making decisions. Do I want to go with open AI? Do I want to go with anthropic traditional content marketing? You know, maybe that makes sense, but this is a big swing and in a

05:48 big industry, you need big swings. Is that logical? >> I don't know. I think I would take the other side of that, which is that, you know, OpenAI seems to think that its

05:58 future is mostly direct to consumer. Like maybe they're going to make a run and try to catch up with anthropic on the enterprise side. Um, and not that they can't do both, but I don't know

06:08 that that I think that there's better like if you really want distribution and enterprises, go by Salesforce, right? Like find find whatever that last mile is into these big companies. And I

06:18 think, you know, a lot of the spending that's going to determine whether any AI really pays for itself, but you know, who wins this race isn't going to come from the the companies whose executives

06:30 are on TVPN. It's going to come from like Goldman Sachs and Walmart. I mean, it's got to it's got to escape the tech economy to have real enterprise customers that are just like out in

06:41 other industries and like those people are not watching TVPN. I don't know. I actually just sort of thought it is a vanity play and you were saying you that those those other executives, those

06:50 other billionaires bought those things personally, but like Sam this I assume this is an OpenAI stock. Actually, I'm not 100% sure, but that is Sam Alman's that is his vehicle, right? He he is so

07:02 intertwined personally, financially with OpenAI. I assume you know that that that's what's going on there. I I'm skeptical of it, I guess, for like a slightly different reason, which is, you

07:13 know, I remember um go back like 10 years when we work and Adam Newman were on top of the world and and Adam got really into surfing and so then he bought that wave poolool company. like

07:23 in general, you know, you you give tech tech founders enough VC money and they do they do start to indulge their personal sort of pet projects. Um, and that uh I guess at least in that case

07:34 was sort of like absolute peak we work perhaps a uh top tech that one a bit. >> So I do think that enterprise is going to be the place that they are trying to play. Um Greg Brockman was on the show

07:45 this week the president of OpenAI and it was very interesting the way that he referred to consumer subscriptions. He said like some some way of saying that right now consumer subscriptions is the

07:56 makes up the lion share of the company's revenue. But I think that as the company focuses on um more coding applications. They're be making this super app which is going to combine coding and chatbt

08:08 and a browser. They are going to try to work and get that business audience. And so if you're trying to make the bull case for this acquisition that is I think the best way that you could do it.

08:19 Um, but I'll make the bare case with you um, for a couple of reasons. And I think the the core of it is even if TBPN is something that is a fan of the tech industry, the moment that acquisition is

08:31 made, you lose your credibility, right? Like you're you could still be informative and entertaining. But when you have a company that owns you as prominent as OpenAI and in the tech

08:43 space and you're commenting on the tech space, there's no way people will look at your important interviews and say how, you know, are they trying to advance OpenAI's interests in doing this

08:54 because ultimately OpenAI's interest is their interest, especially as we both suspect if they got paid in a lot of stock. The question is, how do you end up showing up at events like they were

09:03 front and center at Meta's um big developer event recently and can are they going to go now to that event with the access to the executives as a branch of OpenAI? They're also reporting into

09:17 Chris Leane who's the company's chief lobbyist. So, I suspect that they will lose a good chunk of their audience. And again, it's not a massive audience. It's about 70,000 per people uh per episode,

09:30 which is nothing to scoff at, but it's not huge. It's obviously tech specific, but I I suspect that it'll be much much more difficult for them to do their job than it was before this.

09:40 >> I think that's right. I mean, I'm talking my own book. You're talking yours. Independent media is, you know, a lot of its value is in being independent. This isn't totally new. Um,

09:49 couple years ago, I think it was Anderson Horowitz like had launched kind of tried to launch their own kind of media company. It was the beginning of Future.

09:57 >> Future. Yes. >> And they were going to disintermediate the press. >> Exactly. Right. They they couldn't even keep up with the story volume. Like they

10:04 never publish. >> No. And there's also that big online glossy, I think it's called Colossus, that's always doing these like big glowy profiles. Um uh they know they have the

10:12 feel of like a Vanity Fair, but but are are not there to poke holes in any of of these um tech giants, you know. But but you're seeing a lot more like the all-in pod, you know. I think Jason was was

10:24 tweeting about this saying go direct, go direct, go direct. You know, the media ecosystem has changed a lot and and places like X and and you know, the sort of long tale of fragmented media make it

10:34 a lot easier to to go direct. Um, so we'll see. I think you're right. I guess if they really cared a lot about their credibility, they wouldn't have sold to a company that they cover. That's sort

10:44 of basic media. >> Correct. So that's that's number one. And you know, I think there's an argument to be made against me on that front, which is just like um you know,

10:56 you're like like you said, you're you're you're salty and one of the people who believes in values that are long gone and people just want to be in, you know, informed without these people who are

11:07 who are um salty about things and the two hosts of DVPN are friendly and they're going to still have purchase in the uh AI world. and and I'll accept that as a counter-argument, although I

11:19 sort of I think I was just a little too harsh on myself. Uh I do have optimism about a lot of technology. Um but there are certainly a lot of like we can we can both agree that there have been a

11:28 lot of cranks out there who've just sort of like, you know, journalism is done one way. TBPN was never journalism and they're going to suck at Open AI, too. And I sort of disagree with that notion.

11:38 But I I I think to me the bigger not the bigger problem here is um this might be a solution the wrong solution to the right problem. And by that I mean you're right Liz and you brought this up.

11:52 >> AI has a very big perception problem right now. And this is something that AI, you know, they are mindful and even the reporting that you're seeing uh in come out in the information in the Wall

12:03 Street Journal uh tells us that this was, you know, part of the aim of bringing them on. This is Fiji Simo, OpenAI's head of AGI deployment. She wrote in an internal memo, "As I've been

12:13 thinking about the future of how we communicate at OpenAI, one thing that's become clear is that the standard communication playbook just doesn't apply to us. We're not a typical

12:21 company. we drive a really big techn technological shift. Simo Simo wanted to explore new ways to communicate OpenAI's mission and the impact and applications of its technology to the public. Uh in

12:35 response to questions from OpenAI staffers about the acquisition on Thursday, Simo said in an internal message she believes OpenAI can do better at communicating publicly about

12:43 the benefits of its products. Okay, so aside from the fact that the people inside Open AI thought that this was an April Fool's joke after Simo explicitly told them no side quests, um, this

12:55 rationale, I don't I and listen, I I I get wanting to change the narrative. I just think it's the wrong solution because if you look at the Yuggov polling and we've talked about it on

13:05 this show, who are the people that do not like uh AI? The most negative group about AI are people who have not used it or seen anyone else use it. Uh their only positive about AI it looks like 22%

13:20 of the time and negative 60% of the time. People that have have seen it used but haven't used it for themselves are the most um they have some positive views but in terms of pure negative

13:31 they're the most 62% of them are there. But the people who regularly lose use AI compared to that 62% only 26% of them are entirely negative or more negative and positive on AI. And that is TBPN's

13:43 audience. The people that regularly use AI. When you think about the cross-section of the public that needs to hear this message, >> it's not them, it's the other people.

13:52 And TBPN doesn't cater to them. And that's why is the wrong one. >> Yeah. No, which is why I actually just think this is a this is just a thing Sam wanted to do. It seems to me that the

14:02 simplest solution is is the easiest one and you know they're going to have to um you know follow a a much broader public discourse strategy to convince um the huge swaths of the public that really

14:17 just increasingly by the day hates this technology and is terrified of it and doesn't like the people founding it and you know is afraid of losing their jobs. I mean, I I don't think um I don't think

14:28 this is going to change the narrative. And um I guess I'd be surprised if really smart people inside OpenAI thought it would. This just seems to me like this is a thing Sam likes, so his

14:37 company bought it. >> Interesting. Liz, why do you think >> But I'm going on TVN next week, I think. So, I will ask them what they what they make of all this. See if we can flip the

14:45 interview a little. >> That That's the way to do it. Why do you think people are so negative on AI? >> Uh well, they're afraid of it. I mean just literally afraid that it will take

14:57 their jobs which is a very normal fear and not inaccurate in directionally at least here. But I also think it's just dystopian like it is look I like AI like I I mean this obviously a magical

15:12 technology it has huge economic potential benefits. It you know you talk to people in for example healthcare and biotech about what it could do on the drug discovery and this is like magic

15:22 stuff. Um, but it feels like it doesn't have anyone in the driver's seat and I don't think that Silicon Valley in general has done a good job showing that they can be trusted with much of

15:35 anything. Um, and even they say they don't really understand it. You're talking about a really powerful technology being developed by people who like charitably do not look like the

15:44 average American, do not behave like them, are unimaginably wealthy, like have weird habits about like, you know, they're all like they're all slightly cartoonish. Um, and then you see it

15:55 showing up in your communities in these big faceless data centers that are to varying degrees we can argue about how true this is. taking your energy, taking your water, like you know, putting

16:04 they're faceless and they are um really scary. And this like this is not a huge mystery to me why people hate this stuff. >> And and you're right, like the people

16:14 who use it seem to like it. You see the benefits of it. Um but yeah, I mean this has a huge huge image problem and um you're starting to see real backlash in local communities and I don't think

16:27 that's something that these big companies have thought a lot about or they're starting to now and realizing that they are um woefully uh illquipped to tell that story.

16:37 >> Yeah, they're noticing it. I mean, they notice that they have a narrative issue, but it does not seem like TBPN will be the answer to that. Uh, interestingly, just as we started to uh, head to the

16:50 recording booth, so to speak, some news. This from the Wall Street Journal. OpenAI top executive Fiji Simo to take medical leave from the company. Open product and business chief Fiji Simo,

17:00 who by the way is now the head of AGI deployment. Um, she's taking medical leave from the company for several weeks. an absent that that that sorry an absence that comes as the startup

17:12 revamps its leadership ranks and prepares to make its public market debut. In an internal note to staff, Simo said a neuroimmune condition had worsened and that she had postponed

17:22 medical tests and new therapies to stay focused at work since starting her job last August. It's now clear that I've pushed a little too far and that I really need to try new interventions to

17:32 stabilize my health. There's more shakeups happening within OpenAI. Open eye is making other changes to executive team to its executive team handing former Slack executive and revenue chief

17:43 Denise Dresser commercial responsibilities that were per previously the purview of operating chief Brad Litecap. Litecap will now focus on special projects. OpenAI said

17:54 it doesn't have any immediate plans to appoint any new COO which is the role that Litecap held previously. Constant change within OpenAI and it continues. Yeah, I mean these companies

18:07 the the arguably setting aside the people working on the technology, I think the key role at these companies is chief commercial officer. How do you commercialize the stuff and and monetize

18:16 it? And kind of getting back to where we started on like where is the enterprise business? How do you get those subscriptions? Um, you know, I use OpenAI a lot, but I don't think I've

18:26 ever given them a dollar. So, like how do you how do you take this from the lab, you know, into into the real economy? I have one last point on this then we

18:35 can move on. Um, OpenAI, especially under Fiji's leadership, has been in recent weeks much more focused, no more side quests, shutting down Sora. And so there's been, I think, a lazy argument

18:49 that that yeah, a lazy argument that buying TBPN is a side quest, which it invariably is, but I think it misunderstands this no side quest uh directive, which was all

19:02 about compute. You don't want to waste compute on side quests. If you want to focus on the core thing, yes, it will take some attention, but I don't think TBPN is exactly going back on the on the

19:13 command about side quests here. >> Yeah, I don't think that show is sucking up a ton of compute. >> No, definitely less to make these human generated videos than the AI generated

19:24 videos, which is kind of an interesting moment in time for those again going back to the job loss thing, for those who think AI will immediately take over. Well, it takes a lot of compute to do a

19:33 lot of these things. And it's not easy as easy as saying let's just allow the AI to do it. >> No, you're seeing on the other side these too. These tokens are expensive,

19:43 right? I mean the bills that are starting to rack up people who use it. It's a bit of a sticker shock there too. >> Yeah. So you have the token prices, you have the video prices and so this moment

19:54 where AI will take over everybody's jobs, I think is a little bit overblown. But you had a very interesting conversation with Larry Frin, CEO of Black Rockck about a few things and

20:05 first is uh AI jobs that he talks about. He says AI is going to create many jobs and we're not prepared as a society to fulfill those jobs. That's a crisis. That's an interesting perspective. Can

20:17 you talk a little bit more about that? >> He was really talking about bluecollar jobs um that you know which were already really in in short supply the people to fill them. You're talking about welders

20:27 and electricians and um you know which is in some ways like the last jobs that the robots will take that you know HVAC plumbing that stuff seems hard for AI to do in the physical world. Um and it's

20:39 like acutely needed now to build all the data centers that Black Rockck and and others are are financing and and throwing up to to service you know OpenAI's compute needs and all of that.

20:49 Um, you know, but on the broader jobs front, I guess it is a lot easier to see, and maybe this was true of past, you know, industrial revolutions. People talk about this as the fourth industrial

21:00 revolution. It's a lot easier to see the jobs that AI will kill than the jobs that it will create. Um, and particularly in the knowledge economy, these are, you know, I spent the last 15

21:11 years covering Wall Street and these are big pyramid businesses where a lot of, you know, they hoover up these kind of young graduates from, you know, from the IVs and from business schools and they

21:20 spend a bunch of years doing like kind of drudge work like is consulting, investment banking, that kind of thing. A lot of PowerPoint presentations, a lot of spreadsheets and I can actually today

21:30 do almost all of that. Um, and so, you know, the other thing Larry said in the interview was that, you know, you're going to see this cohort. He was basically saying like, woof, the like

21:41 class of 2026, right? Like there's going to be a couple years where the skills gaps are just really, really wide. And we're going to see I think we're going to see massive youth unemployment. You

21:50 know, that, you know, 25 to 22 to 25 year old cohort for the next couple years. It's already, you know, elevated beyond the national unemployment. And I think you are just going to see that

22:00 skyrocket. Um, and that's really bad. We don't have a solution for it. Yeah. >> Yeah. I mean, you all like I could see the firm saying, "We have AI to do that entry-level work." On the other hand, I

22:12 might be scrambling to university campuses to try to get these 22-year-olds who understand AI into my organization and working with it for my company. I think you're actually worried

22:24 about that gap like couple years like I I think you know I'm I was sort of internet native right um and maybe but wasn't probably not mobile native like I got my first job in 200 I think I had my

22:35 first job before I had my first iPhone if that helps you um and then so you had then you had mobile native employee base I'm not sure how helpful that was mobile is obviously a big platform for our

22:47 lives but it's fairly intuitive um but I I think you may end up with a generation of workers that just get skipped. Like I, you know, what's what's what are people saying? Like I'm not going to

22:57 lose my job to AI. I'm going to lose it to someone who knows how to use AI. And so I am endeavoring to learn how to use AI. But I'm like afraid of high schoolers. Not I'm not afraid of 25 year

23:05 olds right now cuz I don't I don't think they are um in a much better boat than than slightly older people who kind of understand the internet but are not AI native. Um, and there's the same

23:15 argument I think I've been thinking a lot about this actually like with the SAS apocalypse and the tech companies and the shake out there that I wonder how much of an advantage it is going to

23:24 be to be an AI native company, right? There's a lot of questions of well, can Salesforce just do enough with agents and build enough of its own AI to remain relevant and sticky. Um, but but the

23:37 real question to me is the AI native companies that are being built directly on top of these models. like is there something in the DNA there that makes that makes them win in the way that you

23:47 know really with the exception of of Microsoft um that that premobile generation of tech companies just got got totally overshadowed and overtaken by the ones that were built right on top

23:58 of the internet and >> what's your best guess as the answer to that one? >> I don't know. I don't know. But I think um I I I I suspect that there that this

24:08 is this is a bigger technological leap than anything we've seen certainly since the internet. It is bigger than mobile. And I think there's probably something in the DNA of of AI native companies

24:22 that will will help them succeed. Like I was just been on a tour some talking to a bunch of lawyers recently and like you know they're using Harvey they're using Lakota uh you know Thompson Reuters has

24:33 spent a lot of money on on AI and and they have this thing called co-consel and that's actually a perfect case study like can Thompson Reuters this you knowund something year old you know big

24:44 professional services and media organization build enough AI to remain relevant or does Harvey just come and say like we just we just built this all in anthropic and by the way we have 50

24:54 employees and we're not hiring anymore. I mean that is that is where the economics start to go sideways for legacy companies. >> Definitely. I mean this was the argument

25:02 that Sam Alman made to me at the end of the year last year where I asked him about the competition with Google and he goes basically there going to be two types of companies. Ones that try to

25:11 bolt AI on and one that build ones that build AI from the ground up. He goes we're building AI from the ground up. They're bolting it on. That's why I think we have the chance to win. I he

25:21 might be right, but that's obviously that is the right question to ask about about big tech right now. >> Um we just got new jobs numbers in. Are we seeing anything in terms of AI job

25:33 loss in the new in the new numbers? >> Not really. The jobs numbers came out today for March pretty good actually and on the on the heels of some couple of months of like very very bad ones. I

25:44 think there was uh there was a report yesterday from a private um data tracker called Challenger Gray that you know it does track sort of what it counts as AI related job losses that are obviously

25:56 growing quickly. I my theory on this is that AI is an excuse for companies to do layoffs just like the tech isn't good enough. It isn't embedded in enough workflows to like maybe outside of tech

26:09 companies. You know, Mark Zuckerberg has talked a lot about kind of what what a meta engineer is and isn't doing right now. And um so maybe there like they will hire more slowly. I think it's air

26:20 cover. These are companies that massively overhired, you know, in the late 2010s through the pandemic. Didn't want to fire people in the middle of a of a pandemic cuz it makes you look bad

26:31 and then couldn't then were kind of frozen for a couple years and couldn't quite figure out what to do. I think AI is just air cover. Yeah, I saw unbelievable data from

26:40 Indeed this week actually at a conference down in Dallas where you looked at software developers and I'm just going to describe the contours of the chart cuz I was asking about whether

26:50 we've seen an increase in developer hires or developer listings on Indeed and we have but it's this small tick up and then you scroll back to about 2020 2021 right midco and there's a mountain

27:05 of new listings. So clearly there was just a massive hiring phase and you know people are trying to figure out what it means for their companies in 2026 still and when they realize they've overhired

27:17 they say AI because it's a lot more convenient and forward-looking to say that than to say oh we mismanaged our company. >> Totally. And Jack Dorsey can you know

27:27 lay off a bunch of people and say it's AI and maybe people believe him but but I I think it's it's totally an excuse and like the software developer is an interesting one. We had I was talking

27:36 the other day to the chief commercial officer at Enthropic and you know he was sort of saying that you have all of these developers but they are basically managers of a bunch of uh of bots that

27:48 are writing the code. I think like 99% of the code um for for um for Claude is is written by Claude. And like that's fine. That person has a job that's a slightly different job. But it's the

28:00 it's the people who aren't hired to be those junior developers. I mean this is a this is a a like an exponential trend not a not a linear one to me because of the econ the industries that are being

28:11 so hit by this are these knowledge economy jobs and they have the widest pyramids of of any big companies just you think about kind of the the junior associates the the the baby investment

28:21 bankers the baby lawyers the baby consultants that pyramid is going to go from this to like this to this to this and I think you know it's going to end up being

28:29 >> explain to those who are listening >> explain to those who are listening what you're doing with your hands. >> Oh, sorry. I uh I was I was making the pyramid get uh get narrower at the base

28:39 until it eventually turns into a chimney and then maybe even a diamond where like the actual the biggest chunk of of the workers are are um you know people your age, my age who are like pretty

28:48 competent at managing a bunch of agents and then you have some senior people at the top like generating a bunch of business. >> That is crazy. All right, I definitely

28:56 want to talk about the SpaceX IPO because uh Elon Musk and Co have filed for that IPO and we also have some news about uh Amazon data centers in the Gulf. Uh and potentially we can talk

29:08 about what's going on with private credit and AI. So, we're going to do that after the break, but first Liz, I'd love for you to shout out you have a new podcast and people should go and find it

29:17 and listen to it. >> I do. Thank you. Um yeah, you looked like you were having so much fun in podcast land, we decided to uh to join your ranks. Yeah, we launched a show

29:24 about six weeks ago called Compound Interest. It's our business and finance show and it's weekly interviews with people who are like right at the middle of these big forces that are are shaping

29:34 how businesses are run and how markets are are functioning. Had a run of great guests. We've had um we had Dar Uber on kind of talking about what a driver, you know, the the future of Uber is, as he

29:45 tells it, essentially tucking the robo taxis in at night. The kind of care and feeding of these big autonomous fleets was super interesting. had a great chat with the partner who runs the kind of

29:54 America first fund inside Andre and Horowitz about like what on Earth venture capital is doing in these big capital intensive defense industries like blowing up drones and drilling

30:05 mines. So So yeah, it's been it's been a lot of fun, but it's given me a lot of respect for um for what you do. Um it's it's harder on the other side of the mic.

30:13 >> Yes, it's definitely it's a it's a you got to take some time learning it. It's a different thing. All right. So, I definitely want to get to our second set of stories and we're going to do that

30:23 when we come back right after this. And we're back here on Big Technology Podcast talking about all the weeks tech news with Liz Hoffman. She is 74's business and finance editor. Let's talk

30:35 SpaceX IPO. Um SpaceX, they're going to try to go public at a valuation of$2 trillion. I think they're going to look to raise something like 40 to80 billion in this IPO. Um, what do you think about

30:48 this? Is this sort of where you expected it to land? I mean, it looks like they're going to, this is, according to Bloomberg, at more than $2 trillion, SpaceX's valuation would increase by

30:59 nearly 2/3 in a matter of months. The company's acquisitions of of Musk's XAI company valued SpaceX at 1.25 trillion uh in February. >> Yeah. I mean, on on the one hand, I find

31:14 it kind of comforting as a finance reporter. Like, I've had this theory for a long time that these companies were eventually going to have to go public, that it stayed private for so long, that

31:23 that was really the story of kind of the late 2010s and early 20120s that there was just so much private money out there that like who needs the public markets. But actually, what this generation of of

31:33 big startups is doing, as we've been talking about, is super capital intensive. They're, you know, it's really expensive to build rockets. Um, I think SpaceX actually is profitable. Um,

31:42 so so in a bunch of ways it looks really different than that generation of companies, software companies that went public in the 2010s. I mean, what I'm watching for is like

31:52 that's a lot of money. It's got to come from somewhere. I mean, it's it's weird. Like we don't usually think of IPOs as like market rotational events that require a bunch of money to move out of

32:01 one set of investments and into another. But like $80 billion is that would be three times larger than the largest IPO ever which was itself 10 times larger 20 times larger than the

32:15 average IPO. I mean that was that would have been the Saudi Aramco IPO IPO in 2019 that raised 25 or$30 billion. But the average IPO over the last 25 years raises about $200 million. And so that

32:27 is an easy job for investment bankers. But, you know, I wrote the other day that that giant sucking sound you're going to hear in the markets, you know, this May and June is is bankers running

32:37 around asking for $80 billion, which by the way, I think they'll get. This is a profitable company that like seems to do an important thing really well. And Elon Musk is an incredibly um good salesman.

32:47 People want to to invest in his companies. But that's got to come out of somewhere actually. And I think if you've got stocks, you know, still beaten down by the war by then,

32:59 investors are going to be pretty reluctant to crystallize those losses by selling. Like, I don't know. I think you actually, this is a big enough movement of money that you might see some weird

33:07 knock on effects in kind of more liquid markets. You know, I'd have my eye on treasuries if I were if I were a betting woman. So, uh, yeah, I mean, it's it's giant, but I think it's I think it is

33:18 good. I think that you know Anthropic just to take an example is as valuable at what is it four or 5 years old now as Google was when it was 15 as Amazon was when it was 25 and all of its wealth has

33:32 been created in the private market in in the hands of a relatively small number of people whereas 99% I think Google was worth $20 billion when it went public so 99% of its $4 trillion of value has

33:43 acred in public hands and I think that is generally good to go back to what we were talking about earlier where um there is like a the the wealth gap that AI is threatening to just massively

33:54 explode I think is like a really dangerous political force to keep an eye on and so like I would encourage these these companies to go public. >> Yeah. So this would put SpaceX at bigger

34:07 than this is again according to Bloomberg all but five of the companies in the S&P 500. So only Nvidia, Apple, Alphabet, Microsoft, and Amazon would be bigger than it. It would be bigger than

34:18 Meta and Tesla. And by the way, I think speaking of places that we could see people move money from and to, I think a lot of Tesla shareholders might say, "Oh, if I I'm doing this to bet on Musk.

34:32 If I could get a hold of um SpaceX, which has like a clear I think a clearer trajectory like Tesla right now is a bet on Optimus and >> SpaceX is like a bet on space and AI. I

34:46 might just sell some shares from Tesla and buy in SpaceX and that could be very interesting. >> I think that's right. Though I would also say I think one of the

34:54 underappreciated reasons that that they are taking SpaceX public is to merge it with Tesla ultimately, right? like Elon Musk has been collapsing his his empire. And just as a practical matter, it's

35:07 pretty hard for a private company, even a big one, to buy a big public company. Just doesn't work that well. You got to come up with a lot of cash. You can't use your stock. And so I I would assume

35:16 that Tesla gets merged in at some point. And so then it's just a question of like you can do the math and what's the sort of cheapest way to to get yourself a share in the combined Tesla SpaceX. I

35:25 don't know. >> That's very interesting. Yeah, maybe that will happen. That will be crazy. um one super Musk company and uh >> I think that's where it's headed and

35:34 he's done this before. You know, he bought Solar City with Tesla sort of famously complicated deal and had some theory of the case that they were going to put solar panels on the cars and they

35:43 they never really did but uh but yeah, it's clearly what he's been up to with XAI and X and and um SpaceX and all that. Okay, I want to talk quickly about the story that I just published today in

35:53 big technology. Um, and that is that um, we have some reporting that Iran has hit um, enough sites in Bahrain and Dubai that belong to Amazon that there are a couple of availability zones in those

36:08 regions that are hard down according to some internal communication that I was able to see and that they're going to be unavailable for an extended period of time. So this is from the internal memo

36:19 that I was able to get a hold of. The two regions continue to be impaired and services should not expect to be operating with normal levels of redundancy and resiliency. We are

36:29 actively working to free and reserve as much capacity as possible in the region for customers and services should be scaled to the minimal footprint required to support customer migration. So, not

36:39 only have these sites been hit, um, but the company is asking employees within AWS to depprioritize them. And I think this is interesting. I mean, we're we're about to enter week six of the war. And

36:54 now the IRGC is threatening multiple other US tech giants, including Microsoft, Google, Apple, Intel, and a bunch of others. So, if this war continues to keep going, we could

37:05 actually see a lot of big tech infrastructure in the Gulf, um, which was obviously built because there's access to money, access to energy there, um, and and big investments have been

37:15 made there, uh, we we could see it targeted. >> Yeah. Do you think I mean, I'll ask you a question like you you covered these companies. Do you think this war has

37:23 made them I'll give you my thoughts on from the Wall Street side, but do you think this has made them rethink this massive rush into a region that like has just been volatile and violent forever

37:35 in the last 5 or 10 years? Like built a lot of fancy hotels and had a lot of money and sort of tricked people into thinking it was safer than maybe it is. I will say this, I think there's a lot

37:45 of optimists out there in the business community and so my read on their perspective is they are hoping that this is going to be the last war for a while and it's not something that will

37:58 continue to go on. Basically, they they're viewing it as a war to finish wars. Um, and you almost have to view it through this optimistic lens because, you know, think about what we're hearing

38:11 now from the AI labs, right? Like they have gone through basically all the funding they can get um in the Western world and now they're like sort of at the final boss before the IPO, which is

38:22 the Gulf States, and then they're going to go to the public markets. So, it's like one of the last remaining sources of capital for them. And I think like we talked a little bit earlier about how

38:33 Silicon Valley can sort of have this, you know, rosecolored glasses on situations. Um, and and this might be one of them. So that that would be my perspective on it.

38:42 >> I mean, this is what happens. You VCs are all like up into the right dreamers. Um, I don't know. You said war to end wars and I just like that is what everyone said about World War I, too,

38:51 right? So I I don't know that that gives me bad vibes. It's it's interesting because you know Wall Street has kind of made the same rush into the Gulf that that big tech has for similar reasons

39:03 and um I don't know. I mean I I think it is a people business fundamentally you're talking about hard assets and actually I was just talking the other day to um the guy who runs uh a big

39:16 business at AON the insurance brokerage. I was like, I I wonder what's happened to the cost of literally you can buy war insurance which you know um ensures these assets against war and terrorism

39:25 and damage. And he said prices have gone up, 1900%. And the available coverage for any single asset has gone from 3 billion to 100 million in the matter matter of a couple weeks. Yeah. You used

39:34 to be able to get it for like 50 basis or 25 basis points and now it's costing 5% in premiums up front. So um you know the people who underwrite risk for a living think there's a lot of risk of of

39:45 bad stuff happening to these assets. But then on the people's side, you know, for a while, like being in the Gulf was, I say this in air quotes, like it was a hardship posting, right? You would get

39:54 more money in an expat package and on top of getting to pay no taxes for a couple years, your Goldman Sachs would send you out there. And it was a it was a hardship posting. And I think it was

40:04 just on the verge of becoming not that. It was just on the verge of being another global office for these big multinational companies. And I wonder whether you know the people who have the

40:15 expats who've left during the war like want to go back and and at what cost. >> All right, I'm going to do two follow-ups here. First of all, um what do you think the lack of the ability to

40:26 ensure will do to company's ability to build there? I would imagine that the tech the tech giants will be able to keep building no matter what uh because they have so much money. But who knows?

40:38 And then yeah, what happens if the people don't want to go back? Yeah, on the first one I would take the other side of that. They have a lot of money, but you know, in the same way

40:46 that you can't get a mortgage on your house if you don't have home insurance, like that's just a requirement. The bank requires it because the collateral is the house. Uh you cannot get financing

40:56 to build these these data centers without an insurance policy. Um, and as you say, these companies have a lot of money, but like they've required, look at what Meta was doing in in Louisiana

41:06 as a big data project and they uh took a lot of private money from uh from Blue and PIMCO and the market because they don't want on their balance sheet. So, you can't insure this stuff, you can't

41:16 build it. >> Okay. And the people >> Oh, uh, >> I think the people will go back. I think they're just going to People are

41:23 motivated by ambition and money. They will go back. >> I think that's right. And there is something to living a tax-free free lifestyle in the Gulf that is quite

41:30 attractive to the right kind of person. But but I do think it probably sets back the kind of full inclusion of that region into into the the global sort of high finance set, you know, a little

41:43 bit. For sure. >> Definitely. Have you been out there? Have you spent time out there before? >> You know, it's funny. I I have uh I was in Saudi Arabia last year. in in Abu

41:52 Dhabi the end of um in December and I remember flying in and I don't know why it hadn't occurred to me but you're flying into Abu Dhabi and out the right side of the plane is is the Arabian

42:02 Peninsula and and the Emirates and then the left side right across the across the Gulf is Iran. I mean, it is it is when you go it's it's easy to forget because you're in Abu Dhabi and there's

42:13 a galleria and there's a Four Seasons and like it feels um very western and there's a lot of rich people in suits walking around, but it it's like I I wrote about this a couple weeks ago. It

42:22 is a nice house in a bad neighborhood. >> Yeah, I was in Qatar over the summer and I think I've said this on the show so it might not be Newground but just a little too hot for me. I mean, maybe it was the

42:34 season that I was there for, but and I generally like, >> but it was, I think, above 100 degrees Fahrenheit at night, and I never seen this before, and I don't think I'll ever

42:46 see this again unless I go back to Doha. In downtown Doha, the sidewalks are airond conditioned, which means that as you walk down the sidewalks, you feel a cold breeze coming up. And that is

42:58 because there are vents underneath the sidewalk blowing cold air and turning what is a 100 degree night into something that feels more like an 80 degree night.

43:08 >> No, but I think that's a little bit of a metaphor for the whole place, right? Like this is a structurally problematic region of the world that they have engineered into feeling a little more

43:16 comfortable than it probably ought to. >> That is that is a good metaphor. Okay, so last thing that I want to talk about before we go. Um, you talked about private credit. We talked about how Meta

43:27 um used Blue Owl effectively to build some of its data centers and things have we've talked about this on the show a bit but we can talk about a little bit more. Things are getting a little hairy

43:36 for these private credit companies. This is your story this week. Blue Owl faces withdrawal flood as private credit jitters persist. Investors rushed out of Blue Owl's flagship and technology

43:48 focused credit funds as uh as jitters continue to sharpen in private credit. its largest fund, a $ 36 billion pot of corporate loans, uh received redemption requests for 22% of its assets, uh and a

44:02 smaller $6 billion fund, uh saw a 41% withdrawal rates and blue all cap, both of those at 5% withdrawals. So basically, this means a lot more people uh want to go and get their money out of

44:14 these uh these private credit companies um than it's willing to distribute. And is this the be I mean everyone's wondering is this the beginning of a crash that's going to take down the

44:26 whole economy because they made these you know investments that might not pay off in AI infrastructure. What's the truth? >> Yeah. All right. I think you have to

44:34 unpack it. >> Yes it is. >> Oh okay. We have to unpack. All right. >> What what we are actually seeing and and those redemption numbers we are seeing a

44:42 slowmoving run on a bank. So to go back a couple years remember when Silicon Valley Bank like failed over a weekend because everyone took their deposits out. That is basically what is happening

44:51 in the private credit industry >> because of the way these funds are set up. You you noted that they they they gated at 5% and that is true, but that's what they're supposed to do. These funds

45:02 are required to make quarterly offers to buy back. These are non-traded funds. So you own a share in it, but it's not like you can trade it on an exchange, but every quarter you can go to Blue and

45:12 say, "I'd like my money back for the share." and they'll give it to you as long as in aggregate not more than 5% of people of you know want to do that. So that's that's what they're designed to

45:21 do because remember they're holding loans that they can't buy and sell very easily. So they keep some cash on hand to to fund those those withdrawal requests and when everything's working

45:31 fine it's working fine. But obviously this is designed to malfunction when there's panic which is where we are now. So for the moment it's a bank run which is a liquidity problem. They have

45:42 illlquid assets. people want their money back. That is not a fixable problem. So that's where we are on that side. The other question which you're getting at is is there a credit quality problem?

45:52 Are the loans themselves bad? And >> yeah, why are people making this run? Is it just behavior or talk about that? >> It is partly behavior. Um it's partly look like for the first, you know, 6

46:05 years it was around Blue just raised money from sophisticated institutional investors. And it's not just Blue, it's Blackstone and KKR and Apollo and all of these HBS big firms. And then they said,

46:16 well, we're kind of tapped out there, but there's a whole bunch of individual people. What if we sold it to them, too? And because people live their lives differently than institutions, you have

46:26 to give them this quarterly liquidity. So, this is sort of like they were this is a consequence of their own actions and their own desire to keep growing and to find new new places to raise money.

46:36 Um the question of whether the loans themselves suck, that is a fair question. We don't actually know. A lot of them are certainly there's this vintage of lending from call it 2021 and

46:47 2022. Probably some real bad loans there. They raised too much money. This was the the sort of peak software. They were making these loans. I don't know if you've

46:57 talked about them on the show yet called um ARR loans. Usually banks underwrite a company's ability to borrow based on its profits. But tech companies, especially fast growing ones, don't have profits.

47:07 They have revenue. And so they based it on annual recurring revenue. Said, "Well, this company's making a lot of topline money. Let's lend them. Let's let's make that the metric. Let's

47:16 change, you know, 10,000 years of lending economics. Make that the metrics." And then like 3 years when they've got a profit, then we'll kind of flip we'll flip a switch and the loan

47:25 will start behaving like a traditional loan. And then they got to 3 years and none of those companies had profits and they're like, "Oops." So obviously the credit underwriting was pretty bad on a

47:32 bunch of that stuff. Um, but you know, Blue Owl was able to sell a couple weeks ago, they had this problem in another fund and they were able to sell I think like a billion and a half of loans at

47:43 99.7 cents on the dollar. So, I don't know. I think like most of the loans are probably fine. And by the way, not to like you're I'm sure your listeners understand a capital stack

47:56 like the credit this is senior secured credit which is the safest place to be in any kind of corporate financial structure. If you think there's a problem there the equity underneath it

48:06 whether that's this is mostly private equity is like a zero. So it is weird, you know, if you imagine this is like a a flood waters coming in, it's weird to have the people on the top floor

48:16 panicking first before the people on the ground floor. And yet that's what's happening. And so that makes me think that this is sort of more emotional and technical and less about the and the

48:28 loans themselves might be bad, but I don't actually think that that is what is informing what's happening now. >> Okay. Uh Andrew Osorin was recently on talking about the similar thing that

48:38 private equity would have the problem before private credit. So let me just see if I can understand where the issue would be and you tell me how off I am because I'm going to be off here. Um, is

48:49 it that private equity has invested a lot of money in software companies and now there's this thing that's called AI that sort of throws the value of those software companies and those companies

49:03 ARR into question and so therefore the private equity companies that have bet in these soft bet on these software companies begin to fail and then when they fail private credit starts to fail

49:15 and that's how you get this case cascading economic disaster is that the worry >> that's how I mean sort of that is how finance works right which is that if a

49:25 company gets in trouble the first losses are borne by the shareholders right and then the creditors get whatever is left so as a practical matter that's true these companies their revenue would go

49:36 away their profits would go away they would be unable to repay their loans their lenders would force them into bankruptcy the equity is zeroed out. And so that's where you would look at firms

49:49 like Toma, Bravo, Vista, right? These like really tech like these are big PE firms that only own enterprise software companies. Basically, they own tech businesses. Um, so that's where you're

50:00 actually looking for the problem. And then the creditors will get what's left. And some of those loans will be we call impaired. And they might lose some money. Maybe they only get 90 cents back

50:08 on the dollar that they lent. But that equity, which is hundreds of billions of dollars of equity sitting under sitting junior to this credit, is worthless. Um, the reason that people aren't talking

50:20 about this as much, um, I will say I I started writing about this like 3 months ago and I was like, where is the panic there? And the answer is that it's actually they just haven't marketed

50:29 those funds to individual investors the same way that private credit has. So the twitchiest, >> why does the equity become worthless? because

50:39 it's jun I'm trying to think how to explain this in a way that isn't going to be like super boring. It is in finance speak it is junior it is a junior claim. So if you think about

50:48 building a house foundation the equity >> correct the the private credit is in the penthouse when the flight comes in >> the equity is on the ground floor. So they're they just bear the losses first

51:00 and then it goes up to the you know the preferred equity and then the junior credit. But the the private credit these are senior claims that are secured mostly by assets. There's going to be

51:09 something these guys >> software company fails actually the credit private credit companies get the whatever is left of the assets first and then private equity.

51:19 >> Yeah, exactly. If they've lost money, the equity has lost all of their money. Isn't it interesting that um private credit is funding the establishment of these AI infrastructure

51:32 uh builds as those AI infrastructure builds then go to effectively undercut all these companies that private equity has invested in. >> We're we're all funding our own demise

51:43 at all times. I I would I would not just like a slight technical point. the part of Blueowl that is doing the uh that the data center stuff is like a business that they bought that's actually

51:53 unrelated to their credit business. But yes, um you know, Blackstone's probably a good example of this. They got a big uh uh data center business. They have QTS and a bunch of these data centers

52:05 that are, you know, creating the technology that is sort of wreaking havoc in their private equity book that is then wreaking havoc in somebody else's private credit book. So

52:14 >> unbelievable. We are all funding our own demise. >> Yes. Except us in independent media. We're doing the Lord's work. You and me, Alex.

52:21 >> That's right. Yeah. Well, of course, you know, for anyone who's making a big finance decision about big technology, we'll use ARR and not anything else, right? To make

52:30 >> decision. Obviously. Yeah. But I didn't go back to where we started like what are you going to sell this podcast where TVPN just put a pretty good comp out there for you. So, but obviously on a

52:37 revenue basis, I would never ask you your profits. >> Uh, big technology for those who are wondering, we're not for sale. We're not going to open AAI. We're not going to

52:46 Anthropic. We're not going to XAI. We're not going to Salesforce. We're not doing that. Uh this this show, this newsletter uh that I write is staying independent. We're not selling. Um and I'm going to

52:59 just keep doing this for next 20 or 30 years and then retire. So stick with us. >> Hold on to your integrity. >> That's right. I mean, I also I'll just say it. I enjoy doing this. I don't want

53:09 to work for somebody else. It's like I said at the beginning, um, you know, the second you come inside a company, you're now that company's content marketing arm. You're not doing what you did.

53:19 You're doing something completely different. Um, and that's that's not uh what I'm interested in doing. If you want to advertise on the show, that's a different story. You can advertise for

53:27 you can advertise here. We're happy to hear from you. Check out the email address in the show notes, but um but no, not for sale. >> All right. Good to know.

53:35 >> I think that's the case. Yeah. So, all right. The podcast is called Compound Interest. Liz Hoffman has been our guest. Liz, welcome. First time having you on the show. This was really fun.

53:47 Thank you for coming on. >> It was a pleasure. Anytime. Um, thanks for having me, Alex. >> My pleasure as well. All right, everybody. Thank you so much for

53:54 listening and watching. We'll see you next time on Big Technology Podcast.

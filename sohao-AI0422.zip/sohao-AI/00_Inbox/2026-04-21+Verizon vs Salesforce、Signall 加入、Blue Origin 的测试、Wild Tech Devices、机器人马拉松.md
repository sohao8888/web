视频链接：[https://www.youtube.com/watch?v=gyXxasva-rQ&list=WL&index=5&pp=iAQBsAgC](https://www.youtube.com/watch?v=gyXxasva-rQ&list=WL&index=5&pp=iAQBsAgC)
视频发布时间：2026-04-20
频道名：TBPN

## 转录内容

00:00 I see a large IPM on the horizon. You're surrounded by journals. Hold your position. That's misinformation. Clearing order inbound.

00:44 >> Let's just roll. We are surrounded by general. Hold your position. Get up. Trust the experts here.

01:08 We are experts. Founder Mel 5. I see multiple journalists on the horizon. Stand by.

01:32 >> UAV online. Blaze. >> Double blaze. Triple blaze. Double kill.

01:56 My go is >> team deathmatch. We are experts.

02:33 Triple blades. That's just wrong. Right. Hardy clearing order inbound. We are surrounded by journalists. Hold

03:02 your position. >> Strike one. >> Strike two. Activate golden retriever mode.

03:37 >> Mark clearing order inbound. Five could found >> you're watching TVN >> and today is Monday, April 20th, 2026.

04:09 So, we are live from the TVP and Ultra Dome, the temple of technology, the fortress of finance, the capital, >> the capital of capital. Uh we have a great show for you today, folks. Uh

04:19 absolutely uh incredible edition of the Wall Street Journal. Uh over the weekend, I saw these hit the app. Uh but, uh they're in print today, Monday, April 20th. There's two articles uh from

04:33 two tech CEOs that run companies that are almost identically valued. Salesforce is I think 150 billion. Verizon's 190 billion. They're right in that sweet spot.

04:45 >> And I'm assuming they exact same point of view, kind of same market outlook. >> They have exactly opposite points of view. And I thought it was I thought it was interesting seeing

04:56 what what is a victim of the SAS apocalypse have to say about AI and then what does someone who is the most resilient to the SAS apocalypse have to say and potentially is like let me in. I

05:09 want some of the drama. I want the smoke. Uh and so Mark Beni off is who I'm talking about at Salesforce. So he says the software bears are all wrong about Salesforce. We had a bear, but it

05:22 was it was too terrifying. Yeah, it was too scary. So, so we skip it. But, uh, he says, "People think we have our back against the wall, but customers aren't replacing offerings with AI. They aren't

05:33 replacing Salesforce with AI. They aren't ripping it out." Of course, everyone will say, "Well, yet." But, uh, let's dig into Mark Benoff's argument and how he's processing the SAS

05:43 apocalypse and what he's going to do about it. >> Crazy opening. Mark Beni off has some problems. His enterprise software company Salesforce is the biggest name

05:51 in a category that Wall Street thinks may get decimated by artificial intelligence. Its business model has centered on selling software to large companies on a per employee basis. But

06:00 many of those firms are expected to downsize as AI agents become increasingly proficient at performing real world tasks. It's a daunting double bind and it isn't even the worst case

06:10 scenario. Salesforce stock is down a mere 28% year-to- date. The hardest hit software as a service companies are down about twice that much on similar fears. But Beni off thinks the bears have it

06:21 wrong about the SAS apocalypse thesis generally and especially about Salesforce. AI he says is making Salesforce more valuable to its customers than ever. The leading AI labs

06:31 couldn't replace what Salesforce offers even if they wanted to and they would rather partner with them for now anyway. Nor could >> Yeah.

06:38 >> He's like, I dare you. >> I dare you. >> I I dare you. He's he's nor could >> uh I I wish I wish we had Benny off on right now. Yeah, it's it's it's a joy to

06:49 to speak with him. Uh but continuing, nor could customers easily vibe code their own sales management management software that could compete with Salesforce on security, compliance, and

06:58 other vital features. People think we have our back against the wall when in fact the opportunity has never been greater, Benoff said in an interview. An early investor in anthropic, Salesforce

07:08 has been developing and pushing its own AI tools for years. is by the end of this year it plans to unveil a new AI platform that automatically studies its users and takes actions on their behalf.

07:17 Code name agent Albert. >> H. >> It's kind of cool to put agent in the name instead of just Albert. >> Agent Albert.

07:26 >> Well, they had they had Einstein, right? So Albert Einstein is their whole sticktick here. >> Agent Albert is the culmination of an effort that began three years ago when

07:34 Ben off galvanized uh when Ben off galvanized by the debut of Chad GBT instituted a standing Saturday meeting to accelerate Salesforce AI efforts. So >> Saturday standup everyone

07:48 >> an earlier flagship product of that push agent force has been somewhat slow to gain traction. Launched in 2024 it is used by uh 23,000 customers of a total base of 150,000. So what is that a

08:02 little little under 20% of the customer base is using uh agents they're building. >> Remember Jason Lmin came on the show and he was like I use agent force it's

08:11 solid. >> Yeah. like he's like it it won us back a customer that like we weren't reaching out to and it like it made me money. Yeah. So he he was an agent force um

08:21 enthusiast. >> And so uh Salesforce's yearly revenue growth at 10% is down somewhat from recent years. But interestingly the the deceleration in uh in Salesforce's

08:33 revenue growth started back in 2022, maybe even a little bit earlier. If we scroll down on this on this image, you can see back in 2012 they were growing 36%. Then as recently as 2020 they were

08:44 growing 28.7%. Uh there was acceleration in 2022 to 24%. But then 2023 18% 2024 11% 2025 8% and then we're actually seeing some reaceleration this year from 8.7 to 9.6

09:02 to 10.8. And so, uh, the it is it feels like definitely too soon to for the SAS apocalypse narrative to show up in the actual, uh, revenue growth rates of these SAS companies. I I pulled

09:17 together, uh, the recent earnings from a variety of, uh, public cloud software names, and they're all still growing, which you would expect. I mean, of course, like, you know, you want to be

09:29 growing fast and there's a lot of things and there's like the long-term durability of the value that uh of the stock that actually informs enterprise value today. Uh, but we're certainly not

09:40 seeing like, okay, there's so much churn at GitLab, for example, because people are forking it because it's open source and vibe coding on top of it and they don't need to pay GitLab that you would

09:50 expect GitLab's revenue to actually be shrinking. Uh, it's not. GitLab is growing at 23%. Adobe's at 12%. Paged your duty 2.7%. Little low, but UiPath at 14%. Uh, Box is at 9%, ASA is at 9%.

10:06 ASA feels like, you know, textbook, like you could just vibe code this. It's a it's, you know, it's a conbon board, a task list, but it's still growing. Zoom at 5.3%. Snowflakes growing 30%,

10:18 Workdays at 14.5%, HubSpot's at 20%, Data Dogs at 29%, Cloudflare 34%, uh, Monday.com 25%. Like there's really really strong revenue growth across the SAS category. Of

10:31 course, the expectations have been very high. So when there's a readjustment in expectations, you see a sell-off in the market. But, uh, this idea that, uh, the companies aren't growing anymore because

10:40 they're being replaced so rapidly, that certainly hasn't taken hold just yet. Uh so partner at uh uh partner at Salesforce uh investor Chicago Capital has been impressed with some of its

10:53 recent moves. Uh but what Salesforce really needs he says is positive word of mouth from clients talking up the value they derive from its AI products like Jason Lkin. They need to show

11:02 revolutionary jumps. Beni off has said Salesforce was destined to be an AI first company as far back as 2014 when it's launched its AI research unit. I didn't realize they had an AI research

11:12 unit all the way back then. Uh but it makes sense just for like tagging and classifying different records inside the CRM. Uh still it was caught flatfooted by the arrival of high functioning chat

11:21 bots in the form of chat GPT. Um >> customer super intelligence. >> Customer super intelligence. I mean th this is it is it is funny because uh a lot of this the agentic enterprise it is

11:32 a little like boring and it's not as like sexy as some of the the more like crazy sci-fi scenarios but in terms of just you know incrementally improving the value that is delivered to the

11:43 customers it seems like uh things are doing okay. Uh early reviews were tepid though customers complained of having to spend half their time preparing data so the AI could understand it limiting the

11:53 platform's effectiveness. Uh to help fix the problems, built Salesforce built a layer into its tech stack that automatically pulls in customer data from external sources and purchased a

12:01 string of companies that include firms specializing in data management and AI powered sales. At education company Pearson, agents now autonomously handle queries about order statuses, refunds,

12:11 and lost access codes for its customers. This has increased the percentage of customer questions that don't involve human interaction by 40%. uh uh while agent force where agent

12:22 force has been lacking in in its addressing complex customer problems and those require human touch. David Wemsley, chief digital officer at Pandora Jewelry said AAgent Force hadn't

12:33 been able to reliably recommend products on its own based on the vague context that customers share through its website. Like, my wife likes dogs. What should I buy her? That's such a funny

12:42 funny question, but I mean I guess the natural text natural language interface should be able to find you jewelry based on a love of dogs. Although I think that a lot of people who are dog lovers might

12:53 have different tastes that appeal to their jewelry like >> why not just get her a dog or multiple dogs? >> Yeah, I don't know.

13:01 >> Uh so how does this how does how does Salesforce's view compare >> to the Verizon CEO? >> So So uh Verizon has a new CEO. His name is Dan Schulman. I don't think he's

13:12 related to John Schulman, uh the co-founder of Open AI and Thinking Machines. Uh but he is stepping into the AI debate. Uh he says for uh the Wall Street Journal says for a big company

13:24 CEO with big AI ambitions, Verizon Communications, Dan Schulman, doesn't pull punches about the pain the technology could unleash on America's workforce. just months into the job, he

13:34 has predicted 20 to 30% unemployment within the next two to five years. Uh, which is staggering, staggering. I can put that into some context. He says he warns that advancements in humanoid

13:47 robots could upend the manual labor jobs still seen as safe today. And he has pushed for more education and reskilling to help workers adapt to intensifying tech disruption.

13:58 >> Put this into context for me. So uh uh he's uh so uh this is an insane >> and and so this is like potentially the most aggressive stance. >> I mean there are even even Daario so

14:13 Dario had the clip going viral this weekend. It was a clip from last year >> talking about risks to entrylevel white collar job. >> Yeah. and Daario which is like you know

14:22 I would say like on the frontier around being concerned around AI job loss was not calling for 30% >> well no unemployment number 50% but he's entry level white

14:36 collar work >> entrylevel white collar work uh and and that sounds really bad until you actually dig in and you realize that America only has 5 to 7 million

14:45 entrylevel white collar workers uh and the US labor force is 170 million million people. And so if the Daario prediction came true, the overall employment unemployment rate would sit

14:56 somewhere between 6 and 9%. Which is not great. Uh and it ser and it's obviously deserving of intervention. Uh but it's far from the 20 to 30% outlined by Dan Schulman. and uh and it's it wouldn't

15:11 even be even if the Daario scenario 50% of early stage white collar work uh unemployment that happens you're still below COVID below the great depression uh and I think that there's a whole

15:23 bunch of uh government interventions that could that could offset that pretty quickly. Um like 20 to 30% is truly like the do nothing. The government never engages. there's never any sort of uh

15:35 you know incentive to to keep hiring people and there's this like fast takeoff in in AGI and also humanoids which I think people are you know worried about but if you look at the

15:47 deployment rate of self-driving cars people have been saying that all the truck drivers were going to go out of a job uh and you know this is a very very slow takeoff the number of self-driving

15:57 cars on the road is well below 1% of overall cars on the road still um and this is just the case across the board. I was listening to a podcast with uh someone who was very worried about

16:07 unemployment internationally and he was saying that um uh that AI could upend the Philippines because the Philippines does a lot of customer service >> which we haven't seen at all yet.

16:18 >> No, we no none of this is showing up in the unemployment data. It's not showing up in US unemployment data yet. I mean, that doesn't mean that you shouldn't be aware of this stuff, but uh but it's

16:26 it's certainly not show just like the SAS apocalypse is not showing up in revenue yet. uh you know AI uh unemployment is not showing up in any of the employment statistics yet. So um but

16:38 uh this individual was on a podcast that was saying that uh something along the lines of uh you know AI could be devastating to the Philippines economy because the Philippines is very

16:47 dependent on customer service. And the stat he quoted was that 90% of the Philippines economy is based around customer service and customer support and and handling people on the phone.

16:58 And I was like, 90%, that seems really, really high. Like, they have to do other things in the Philippines because sure, you go to work at your at your uh uh at your customer service job, but then you

17:08 go home and you buy food and you live in an apartment. There must be real estate agents. There must be home builders. There must be people who work on roads. There must be doctors. There must be

17:17 lawyers. Like, like the an economy requires more than just like a single like it's it's 90% feels like incredibly concentrated. So, I looked it up and I was like, how how big of an issue is how

17:28 big of a of a of a of an industry is uh customer service in the Philippines? Like, is it 90%. That feels high. Maybe it's 50, maybe it's 40. It was like 6%, 7%. It's really really small now. Now,

17:42 it's like huge in terms of like, you know, you don't want it to go away. >> You don't want it to go away, of course. And you don't and and you do want uh you know you want a number of industries

17:53 that are flourishing. Um and that is probably more concentrated than many other countries. It's probably many it might be it might be the country with the highest percentage of customer

18:02 service intensivity in the economy but it's not 90% of their economy. And so there's a little bit of this like people don't seem to go back to the raw numbers because if you go back and you try and

18:15 understand like okay what would 30% unemployment really look like? Well that's like you know great depression level with no intervention no no action from the fed no action from the

18:24 government and it seems a little bit uh a little bit crazy. So, I can't tell if this is just like saying the biggest number, but there there's a little bit of that going on here where if you want

18:36 to grab headlines um and you go out and you say, "Okay, well, someone predicted, you know, 5% unemployment. I'm going to predict 10% and then I'll jump to the front forefront of the discussion." Uh

18:48 that seems to be a way to get earned media. Um but I mean let's unpack a little bit more of his discussion because uh we we we will see if there's a way to steal man his take around 20 to

18:58 30% unemployment said coached in the blunt AI talk is a warning for other CEOs be candid about the coming disruption or risk a public backlash uh it's a very difficult time and everyone

19:08 knows this Schulman said in an interview with the Wall Street Journal >> so I think I don't even agree with that stance if you everyone that's being candid or even talking about it is

19:18 immediately getting backlash anyway. >> Uh, so I think being authentic, uh, being realistic, telling the truth as best you can is key. That belief, he said, is why Verizon created a $20

19:31 million career transition and retraining fund for the age of AI when company began laying off,000 workers. >> Greater unemployment than in the Great Depression. And I'm going to, you know,

19:42 he's taking the piece of duct tape. You know, there's water pouring out. He's >> I know exactly what you're talking about. And to be clear, to be clear, this is not our view.

19:51 >> Like this is not our view at all. >> No, but I mean at the same time, like they did layoffs. They probably hired a lot during uh COVID and beyond. Uh and they and and a $20 million career

20:02 transition retraining fund is great. Like that is good. Like this is a good thing. Uh but he says the warning uh uh this is from the journal. The warnings are a departure from the messaging of

20:12 other public company CEOs, many of whom have been bullish about AI's potential to unlock new levels of growth, but demure on or even reject the idea of job losses. A lot of people are saying AI is

20:23 coming, we're going to run out of jobs. Uh, it's exactly the opposite. Nvidia CEO Jensen Wong said last month, pointing out that every other technological advancement has brought

20:32 more productivity and more prosperity. And there is some new data showing that uh productivity might be climbing, which is very exciting. if uh the all the economists wind up developing a

20:42 consensus around that. Uh Amazon CEO Andy Jasse is similarly sanguin about potential job losses to AI. Though some roles will be replaced, there will be other jobs created. Uh in the short term

20:53 though, uh a cavalcade of companies from Snap to Amazon have invoked AI or a desire to find efficiencies as they slash large portions of their workforces. block which cut nearly half

21:04 of its predict uh half of its staff predicted other companies would soon follow suit. A new Boston Consulting Group report predicts that AI will shape roughly half of US jobs in two to three

21:14 years and that up to 15% of jobs could eventually be eliminated outright. Um again that's you know uh reshaped and eliminated does you know uh would be offset by the creation of new jobs. So

21:29 even in this B BCG report uh you're probably looking at like again maybe a transition of like six seven eight nine 10% unemployment while there's an adjustment period uh many many Americans

21:42 fear that will happen too in a Quinnipak University survey of 1400 adults uh 55% said they feel felt AI would bring more harm than good up from 44% in a poll last year and so uh the U the the

21:56 average American is dooming for Sure. Uh, CEOs are not thinking about this the right way, said Bill George of the the former CEO of Medronic, who is now an executive fellow at Harvard Business

22:06 School. Too many, he said, are focusing on productivity instead of laying out a strategy for how companies can find new business models to grow or on how workers can best use AI. They should be

22:16 very candid with them and paint a big picture. Showman's big picture also included sweeping job cuts. The 13,000 layoffs he announced shortly after his appointment

22:26 of as CEO in October were Verizon's largest ever but not but necessary to make Verizon more efficient. He said uh alltogether he's seeking to cut 9 billion of costs. Uh Verizon said it its

22:38 layoffs were not related to AI. The uh the carrier was too hierarchical, too bureaucratic to way too processoriented as opposed to outcomes oriented. and the CEO saying, "This is already happening

22:50 in a big way, but uh the layoffs we're doing are just that we're bloated." >> Yeah. So, Verizon has 90,000 employees and they laid off uh 13,000, so maybe like a little over 10%. uh riff.

23:05 Verizon's a weird one because the stock is basically completely flat over the last it's actually up 15% year to date and uh it is an incredibly stable stock and it's also just like should not be a

23:17 victim of the SAS apocalypse because they own spectrum allocation. They own cell towers. Exactly. And that's just >> or they have like very very long-term lease agreements.

23:29 >> Yeah. And I mean they I there is there is the case that like you know if Starlink direct to cell gets really good >> even I mean even Elon's saying like it's not going to be that good inside

23:40 buildings like it's pretty difficult to get to a point where all of a sudden there's a new technology that's just wildly disruptive. Um, like maybe if you're like somehow transitioning from

23:51 Starlink when you're outside to Wi-Fi when you're inside, like you could cut the cord with Verizon, but that just feels so so far away for something that is like a pretty key uh utility in most

24:02 people's lives. Like their water bill or electricity bill, like their their their phone internet bill is like pretty uh it's like one of the one of the probably the the least elastic things. Like they

24:12 will just keep paying and and and stick around. Now they might move to Sprint or AT&T and there's going to be some competitive dynamic. It is an igopoly after all, but uh it it doesn't seem

24:22 like there's going to be some massive disruption moment where people are vibe coding their own cell carriers necessarily. >> So uh in meetings he has repeatedly told

24:31 Verizon staff they must embrace AI, describing it as core to the company's future. He he used it himself to comb through some 8,000 responses after >> this is the future. Trust me, I used it

24:43 once. Shman's embrace of AI goes deeper than cost cutting. He envisions a company wholly reshaped by the technology from improved customer service to more

24:54 personalized options for consumers. And he has encouraged staffers to talk to their children about AI at the dinner table. In one all hands, Schulman recommended that staff ask AI to write

25:06 their obituary so to see how the technology works and how it frames their lives. Just dig your own grave. He's he's literally the title of this article that's saying he's saying AI is

25:19 coming for your job and everyone knows it in tech in tech we're starting to >> uh you know um every company's adopting this technology at a rapid rate >> but uh everyone's like hey this you know

25:33 basically like jobs aren't tasks right this sort of narrative is building like we need to figure out how to >> um it's it's we've we've built a bunch very useful tools and they are going to

25:46 have powerful effects in our economy. >> Yeah. >> But >> uh we have to kind of change the narrative around this because like a

25:53 fear-based approach is not working. And and meanwhile comes in. He's like >> AI's coming for your job. Everyone knows it. Write your obituary. >> Write your obituary.

26:05 >> It's so not so not helpful. And and and they're not even doing AI related job cuts. >> No. I love. >> So, I just don't understand. I don't

26:15 understand this whole press cycle. >> I love I I love that he just comes in and just immediately starts blackilling. It's so wild to just get this job and immediately start blackmailing. So,

26:27 >> like, do you think this is a setup for for a much like deeper layoff than they've done historically? >> I don't know. Oh, I mean it's possible, but I like I think that they would need

26:36 to do some serious like AI tooling and implementation and actually figure out like I I mean I would be surprised about those 90,000 like I want to know more about the breakdown of those 90,000

26:47 employees or 80,000 employees. Like what are they actually all doing? Uh whi which ones are actually just sitting there being like I just do tasks all day long. like form comes in, I type it into

27:00 an Excel sheet and I email it to somebody. Like that type of job, yeah, that's probably going to be automated in some way and that person will have to find a different way to make a play

27:10 inside the organization. Uh but for a lot of but for a lot of the folks at Verizon, I imagine that they're that they're working on bigger projects than just uh you know, just throwing throwing

27:22 tons and tons of people at a single problem. Um >> at the same time, who knows? Maybe maybe it's 50 maybe half the company is uh customer support reps. I don't know. Uh

27:31 he has invited staffers to experiment with AI by writing poems to their loved ones. Some employees responded by a by using AI to write poems for Schulman and they weren't half bad. He said like it

27:42 or not, we live in the a I happen to like it. I I agree with that. Uh it's like we all wanted to live in the Renaissance or like when fire was first invented. How cool would that be?

27:51 He continued, we're in that stage. We're not just appreciating it for what it could be. That's a very optimistic take. I like that. I like that sentence. That's good. Uh some prominent CEOs are

28:01 starting to join Schulman in acknowledging uh has potential for a for disruption. Uh others have re also recently sounded warnings. There's real risk of artificial intelligence could

28:12 widen wealth inequality. Black Rockck's CEO Larry Frink wrote in his annual letter to shareholders last month. Last month, Jaimeie Diamond recently told investors that AI's productivity gains

28:22 could lead to other derivative effects. It may happen faster than we can adjust to it. Showman said AI may reach human level capability known in the industry as AGI by the end of next year on the

28:32 early side of most uh most industry predictions. Uh so end of 2027 for AGI isn't that crazy. I mean the Sequoia has an event right now AISN there. The whole keynote slide is AGI is here and so uh

28:46 people are going back and forth on that. But I think I think it's not it's not that crazy to to imagine, you know, very very human level AI by the end of 2027. That doesn't seem

28:57 impossible whatsoever. Uh the the question is just like how much will this be additive? How will the government respond? Uh what will uh the actual effect on the labor market be? And I

29:08 think people are digging into that a lot right now. Uh there's a good podcast on this uh on oddlots with uh Alex Imos. uh he's a professor at University of Chicago focusing on economics and

29:19 applied AI. Highly recommend you go check that out if you're interested in going deeper into uh the labor market. Uh well, moving on. Um Blue Origin rocket stumbles on first commercial

29:31 mission. Uh AS Space Mobile, who we've talked about a few times here, uh Jeff Bezos's rocket company said the satellite from AS was deployed into an incorrect orbit. And so, uh, a little

29:46 bit of a setback for them. Uh, I think the stock traded down in the news a bit. Uh, the launch comp the launch of the company's New Glenn rocket started smoothly with the vehicle shooting into

29:55 the sky from the Blue Origin launch site in Cape Canaveral, Florida. During the flight, New Glenn's third ever the vehicle the vehicle's huge booster returned safely to Earth. Only uh, a

30:05 feat only Blue Origin and Elon Musk SpaceX have ever achieved with orbital rockets. Uh, but the mission later suffered a mishap. A satellite the rocket was carrying into sport into into

30:15 orbit for Space Mobile, a company building cellular broadband network in space, wasn't deployed correctly. In a post on X, Blue Origin said its rocker delivered A's satellite into an

30:25 incorrect location in space. The payload was placed into an offnominal orbit. Uh adding that teams were assessing what happened. A said the satellite's uh altitude was too low to sustain

30:38 operations and that it will be taken out of orbit. Uh the cost is expected to be covered under its insurance policy. The stumble comes as Blue Origin works to ramp up flights with new GL.

30:47 >> Yeah, I saw some of the the AST retail army saying like don't worry, keep holding, >> keep holding. >> It's covered under insurance. It seems

30:57 like >> very very very uh very unfortunate but uh seems like it's rebounded a little bit >> somewhat to be expected right as Blue

31:05 Origin like figures out their commercial business. >> Yeah, it traded down like 16% overnight but it's down uh just 6% today. So a little bit of a rebound

31:14 >> and we got a fantastic video of the booster landing that we can pull up here. >> Yeah. uh courtesy

31:23 Tyler, you dug into why doesn't AS just uh launch on SpaceX. >> Well, so so there are two things I think one thing I thought was interesting is like there's this whole press cycle

31:34 about it like oh it was like a failure of a launch or something but this has like happened a number of times before like SpaceX in uh in 2024 there was a Falcon 9 that that kind of uh the upper

31:44 stage >> uh like failed and then a few like Starling satellites >> just went to the wrong orbit. Yeah, basically. And then they're too low and

31:51 then they just get get burned. >> Yeah, companies don't typically like to talk about when they send something into space and lose it basically. But that happens too. Uh I remember at the

32:01 beginning of last year there was a launch >> uh for for a ventureback space company and and um you know they basically put a satellite up

32:09 >> and almost immediately lost contact with it. So it's not not unusual, unfortunate, but they'll be back >> in uh in 2016. SpaceX blew up a Facebook rocket which

32:23 was crazy. Uh Mark Zuckerberg laments the loss of internet.org satellite. Uh the Facebook CEO said he was deeply disappointed in the explosion of Falcon 9 rocket carrying satellite intended to

32:36 provide internet coverage to parts of Africa. So, uh, writing on his Facebook page, uh, Zuckerberg said, "As I'm here in Africa, I'm deeply disappointed to hear that SpaceX's launch failure

32:48 destroyed our satellite that would have provided connectivity to so many entrepreneurs and everyone else across the continent. The accidental explosion of the Falcon 9 rocket early Thursday

32:57 morning." This was back in 2016. Uh referred to as an anomaly by SpaceX engineer destroyed both the rocket and its cargo. The AMO 6 satellite which Facebook had planned to deploy to

33:07 provide internet coverage to parts of Africa. Fortunately, we have developed other technologies like Aquilla that will connect people as well. We remain committed to our mission of connecting

33:16 everyone and we will keep working until everyone has the opportunities this satellite would have provided. Uh contrary to Zuckerberg's description, the satellite did not belong to

33:27 Facebook. In October, 2015, Facebook partnered with Ule uh Eto statulat, I can't pronounce that, a French uh satellite company to lease the broadband capability of the AO6, which was built

33:40 by Israeli company Spacecom. According to Space News, which reviewed Spacecom filings with Tel Aviv Stock Exchange, the joint lease cost $95 million over five years. So this like hund00 million

33:52 satellite uh just blew up on the pad. So lots of different uh setbacks, but there is one technology that is not having setbacks, which is uh robotic marathoners. And there's new

34:05 information. Uh there's a crazy video. I don't know if the video relates to this, but a Chinese robot beat uh beat a human best time in a half marathon after a stumble. Tech companies are making

34:17 progress to fixing humanoid runners malfunctions. A year ago in Beijing, humanoid uh a humanoid robot halfmarathon race. Uh the first runner to cross the finish line took more than

34:28 two and a half hours. In this year's event, the champion beat the fastest human ever. Sunday's race demonstrated China's rapid progress in humanoid robotics, a field American tech leaders,

34:39 including Nvidia's Jensen Wong and Tesla's Elon Musk say is the next big thing. Beijing. >> This video is pretty wild. >> Is this the actual

34:46 >> This is This is one that's failing. Didn't Didn't make the half marathon. But you can see there's dry ice spilling out of the back. This is cool. >> It off. Interesting.

34:57 >> Which is like very cyber punk. >> Wa. That's crazy that you have to load it up with dry ice as well. I like that. Uh about 220 yards from the finish line, the 5'5 Lightning slammed into a

35:09 barricade and collapsed. The red and black robot managed to get back on its feet with help from humans and ran across the finish line in 50 minutes and 26 seconds according to state media. I

35:19 feel like if you fall down and you're a human in a in a half marathon and humans help you get up, that's still fair game. You're still good as long as you finish. Uh this probably still counts. Uh last

35:29 month the humanoid the human the actual human world record holder from Uganda uh finished in 57 minutes and 20 seconds in Lisbon, Portugal. Lightning and two siblings from Honor swept the podium.

35:42 Uh, all three navigated the course without human control, excluding the one-time help the champion got. The race penalized the completion times of those relying on constant human remote

35:51 control, including one that finished the race in under 50 minutes, but it was teleoperated. Uh, the Tienkung Ultra, which was developed by Beijingbased lab exhumanoid and won last year's race,

36:03 more than halfd its finish time this year, clocking in at 1 hour and 15 minutes without any human in intervention. That is pretty impressive. Like they're they they cut the time in

36:13 half in just one year. Uh, the 13-mi course included more complex terrain than last year, such as slopes, narrow passages, and sharp turns, testing robots abilities. If you assume an

36:24 acceleration in progress, eventually one of these humanoids is like running a marathon in like an hour or like 30 minutes. Just like truly insane. Insane speeds.

36:34 >> Yeah. I mean, as fast as a Cheeto. >> Tyler could still take it out, though. >> I think so. Uh, China is moving to quickly dominate the humanoid robotics industry and cement its place in the

36:44 global supply chain. While the US controls the best chips and other technology for robot brains, China leads in the manufacturing ecosystem for humanoid robot robot bodies. that has

36:52 been recorded many many times. Well, without further ado, we have Signal here in the TVPN Ultradom. Let's bring in Signal, who is launching Sky, an agentic AI home

37:04 screen, replacing the iPhone app. >> There he is. >> With contention driven intelligence, >> dude, I can't believe this long. We've reacted to your posts like so many

37:14 times. So good to have you. >> I Oh my god, it's incredible to be on here, guys. Um, welcome. It's been a long time coming, but I just want to start off with saying congratulations.

37:23 >> This has been ridiculous. >> Yeah. What a wild. >> I've been watching you guys since day zero. >> Really? You watched my first episode?

37:30 >> Well, because I think we were covering your post would have been making it into like the first episode >> for sure. >> You're probably like, "Why are these two

37:36 guys in suits reading out my tweets? This is >> wild." It was um >> I I tweeted this out a little bit, but I was like, man, when I read that and you

37:46 guys were reacting to what I posted because I didn't really think about what I posted and you guys analyzed it and I was like, "Oh my god, this is ridiculous. Holy crap."

37:54 >> Yeah. >> What did I even write? >> I don't I don't remember. You have a ton of bangers. They're all good posts. We had a great time. That was the lifeblood

38:01 of the show. It was so much fun. Uh anyway, uh we're not here to talk about uh you know, the the first episode. We're here to talk about your first episode in this new journey. Uh talk to

38:12 us about what you're launching, what you're >> very smooth, John. >> I try. I try. >> Come a long way for sure.

38:22 >> Anyway, uh introduce yourself a little bit. Introduce the app, introduce the product, where you want this to go. And I have a ton of questions. >> No, absolutely. Um, you know, uh, we're

38:34 I've always been in consumer software and I think there's just not that much other than the sort of main players. Um, I noticed and there's there's a lot to be done and and what a time to be alive.

38:45 So, you know, we're experimenting at the very basic layer of how to make this stuff uh really easy to use, really easy to access for normal people that have not really come into this agentic AI

38:58 world in full speed other than sort of chatting >> Yeah. >> with chat bots and whatnot. And I think it was an it's an early experimentation

39:06 of what we're up to is kind of how AI will kind of speak to you as well as how you know sort of ambient AI will be in various surfaces. Um starting with your phone, right? Like maybe your phone may

39:18 not look exactly the same way even in the next couple years. Um, so we're kind of operating at the very earliest stages of experimenting of how AI will communicate with you and we're trying to

39:30 think of creative surfaces and one of the one of the most interesting places you always, you know, people take out their phones and they glance at it and turns out, you know, this stuff hasn't

39:39 really changed in such a long time. >> The iPhone home screen is 20 years old. >> That's two decades. >> And it's just static icons. Yeah, >> it it roughly speaking it has not really

39:54 evolved in any one shot. They one shot it. >> Yeah, that's the steel man. >> The steel man is like it's good. It's the final form.

40:01 >> It's the final form. Some things don't change. >> We're all going to We're all going to >> We could always do a three-wheel car, five wheel car, six wheel. I mean the

40:08 thing that I've been the thing that I've been pressing on is like you would think you know if I could rewind >> 2 3 years I would not expect and and and knowing how much progress there would be

40:18 in AI I would not expect to look at the top 25 apps in the app store and only see LLMs >> like chat apps >> I would expect to see like a variet

40:28 given given just like how many magical experiences people have had a variety of like new products >> new Uber new Instagram like and that's like some argument previous app boom

40:38 that was like very diffuse. You got you got Candy Crush and and uh what's the one with the pigs, the Flappy Bird and uh Angry Birds and like you got all these different apps, Run Keeper and

40:50 Diet products and it feels like this has really collapsed down into just chat apps. >> Yeah. And you know, I actually recently got a new phone and I was installing

40:59 apps. You know, I always like to set up my phone uh bare like I don't like to transition my phone. >> Interestingly the same. >> Really? It gives me a little bit of a a

41:07 reset on not only what I need and what I don't need, but also how to think about software as it exists today. Like I don't want to be tied to what I was before. I want to kind of be a new if

41:17 you will. And um you know it turns out I installed uh you know GPT and Claude and whatnot and I was like man I don't think I really need that much stuff. You know these LLMs are kind of collapsing um how

41:30 and what you do into an interesting dynamic. Um and I think generally um they're incredibly powerful and the fact that you know those top five apps are all LLMs roughly is speaks volumes to

41:45 the zeitgeist and speaks volumes to the impact of the actual technology. Like I don't think you know previous I think technology has always been kind of a little bit more evolutionary than not.

41:55 Obviously hindsight is 2020 but um but this feels so so different you know as a technologist um this this world feels very different. It feels um just just the things are going to rapidly change

42:11 from here on out in terms of how people experience their lives, how people interact with each other and how you know we're going to facilitate brand new interactions potentially or you know

42:21 completely reinvent old ones. So, I'm very excited for that. And I think our company and the way that we think about it from a consumer perspective is just to make things, you know, easily

42:31 accessible for these individuals. And and I think we we're going to we're going to attempt to do that. Very basic. >> What is your like more as like a CEO? I it sounds like you guys have raised a

42:42 little bit of money and like are just like in an experimental phase. Is that like generally the right read? >> I think Yeah, I think generally I would say two things. Number one is look,

42:52 we've built a really fun product that we're going to give to lots and lots and lots of people. Turns out, you know, this era is nonzero marginal cost. We have raised a little bit of capital. Um,

43:03 but you know, inferences is non-trivally expensive and especially if you operate at like aentic inference or um just background inference, that stuff is just consistently going unlike, you know,

43:14 claude or GPT where people actually make requests or go on there and type something. Uh we're we're doing it on behalf of you, right? like we're doing those things in the background where we

43:24 anticipate, we listen to contacts. We we turn, you know, every time, for example, every time you get an email, uh we process it with one of our agents. It it sort of turns out, it buckets that item.

43:34 It tries to figure out what to do with it. It tries to see if there's it deserves some higher uh order like ranking and then it tries to figure out, oh, can I complete this task? Can I

43:44 draft a reply? Oh, maybe it does deserve a reply. let me go back to John and say okay hey here's a reply that I've crafted based on everything I know and it's a very look replying to emails has

43:55 been you know 30 40 years but this is a new world in terms of how you think about communication and how agents kind of mediate this world and apply that to any you know any aspect of your life

44:06 whether it's health or finance or where even where you are right like one of the underlying things that we do is location and you know imagine learning about the world around you through an LLM, whether

44:18 it's through text or voice, by simply it being on your home screen wherever you are. If you're at a museum, if you're in a new neighborhood, and that's a one tap away, like our goal is to make

44:29 intelligence either zero or one tap away, not one prompt away. So, >> burning question, >> how do you how do you how do you make this product free so that everyone can

44:40 use it? Will we see ads on the home screen of the iPhone ad supported? I think ad supported could make sense, right? I'm walking by a coffee shop and I get I get an offer.

44:52 >> Hey, there's ads in Apple Maps now. So, Apple, >> you're seeing my notification stream in. So, you you can really you know what I like.

44:59 >> Yeah. Counter position. >> I I think the interesting thing here is like you like you guys can operate like you can kind of wake up and ask yourself like what would Apple do if they were

45:10 like truly excel excited about AI versus like seemingly scared of it. you know, um I've posted about this a little bit with with respect to Apple. Um Apple relies on a deterministic

45:23 world, right? Like a world where lots and lots of elements from design to the experience to the underlying context that doesn't change as much and it's very deterministic. So for example,

45:35 iPhone is very much kind of uh software is very broadcasty, right? It's a one to many. They write it once and it runs for everybody and roughly speaking it runs exactly the same way. Now with a

45:47 non-deterministic world that could change drastically like for example for when we you know give this out to everybody everybody in their everybody has a very different experience with our

45:59 app because it's completely non-deterministic and Apple lives in a deterministic world and having to transition into non-determinism and non-deterministic

46:08 software is actually a really non-trivial transition especially for a company like Apple where every single corner or every single thing needs to be tightly controlled. So I think for us

46:19 we're kind of p paving a path where um we can marry some level of like expectations and determinism with the beauty of non-deterministic uh elements of AI and create a really great user

46:32 experience around that that lives on your home screen and works for everybody. Um that's how we think about it. So we're kind of maybe in some sense moving ahead of Apple who has to deal

46:43 with a few billion users, you know, just just minor amount of users. Um, so I think I think that, you know, this this world deserves more experimentation like like we're doing uh in terms of both

46:54 user interfaces and experiences and feeds and ranking and and Jordy going back to your point on on monetization like I think that's the number one thing that I think about quite drastically.

47:06 Look, we're trying to capture real estate on your device. That is the home screen that is available at a glance. And you know, I think I posted about >> the greatest billboard of all time.

47:16 >> Exactly. I mean, it is it is insanely powerful if we can activate that. No, that's a tall order. But at the same time, you know, like I've I've posted about ads and advertising. Look, I've a

47:27 I've been in technology for such a long time from consumer, you know, whether it's like feeds at Facebook or, you know, even Google and whatnot. But you know you you sort of think about

47:37 advertising has done a lot of good for the world. You know it has actually made things accessible and and and and I think generally if advertising has done well it is actually one of the most

47:47 useful uh economic paradigms in terms of delivering equality and services to people who would have otherwise not been afforded. Um so I believe in advertising. I believe in good

47:58 advertising. I believe in advertising that is actually like um uh complimentary to the user experience, not necessarily taking away from it. It's tricky to do. Um but

48:07 >> yeah, the worst ad experience I've ever had as as an ad enjoyer was like in college I was buying a Kindle and they were like, "Do you want the ad supported Kindle for like $100 or the ad free

48:20 Kindle for like $120?" >> And as a college student, I was like, "I don't I don't think I'll mind ads." Like, why not? Oh, that's bad. >> And it's on the home screen when the

48:30 device is locked >> and they're just showing me books that I would never read all the time. >> So, it's terrible targeting. And it's a device that's just like sitting around

48:39 my house all the time >> and it kind of looks like, wait, you're reading that? >> Yeah. Yeah. >> So, if you can avoid that,

48:46 >> Yeah. >> definitely. >> There's a question from the chat. Uh, why are you anonymous? Do you plan on continuing to be anonymous? Uh, I mean I

48:55 I imagine as you grow the business like it would be interesting to stay anonymous forever, but you know at some point a journalist will want to know and I imagine that unless your opsac is

49:06 super tight it'll come out. Not that it's like bad. I I'm just wondering like how have you processed the anon thing? >> That's a great question. you know, my entire online existence as it exists

49:18 today with respect to this account is is a giant accident because um I was trying to find my old username and password for cuz I just wanted to post a little while ago maybe, you know, whenever I started

49:28 posting. But I think when you guys actually started started uh TBPN as well and I I think I >> Yeah, your account must have gone from like a thousand followers to like

49:38 >> over a hundred within the first few months of of us. >> It was kind of nuts. Okay, so the the whole story is, you know, I I um I was kind of uh I was like, you know what, I

49:47 just want to read. I maybe I'll reply or something. And I had a lot of fun and you know, whenever I'm having fun, I like to double down on things. You know, maybe not change change it around too

49:57 much. Look, I think certainly this this world is going to change at some point. Um but for in the in the meantime, you know, I love leaning into fun new things. You know, if you want to do

50:06 anything new in the world, you got to do it a little bit differently. You got to be a little bit more unique. you got to be a little bit more mysterious, a little bit more um yeah, I don't know.

50:15 All of this stuff is just so wild to me, right? Like the anonymity aspect of it and the ex culture and the anons around it. And you guys have had, you know, >> Yeah, you can never dox. I'm sorry. You

50:26 can never dox. I mean like bangsy bangsy getting unmasked. Is that good for the is that good for the brand? Like like you could be you could be like taller than John Giga Chad.

50:36 >> Everyone just imagine >> and it won't be enough, right? We we all picture you as a philosopher king of sorts. >> Oh, it's beautiful, isn't it? I mean, my

50:46 my bio and my phil actual content are like sometimes sometimes the same and sometimes disjoint, but that's I think the beauty of it. So in that realm, you know, like I was actually talking to

50:56 some people around this and I was like I I I sometimes I basically kind of do what I feel like and right now it's like just been so much fun to to kind of lean in on this world and and it you know,

51:07 but I think certainly I'm I'm I'm more like I'll I'll I'll marry myself to the zeitgeist, if you will. And if that if that calls that, then I'll I'll I'll continue and we'll see what happens.

51:19 >> Not married to the game. Married to the zeitgeist. >> Married to the zeitgeist. Okay. Take me through take me through iOS development uh like current status because this

51:30 seems like a really good idea that people would want. Uh I do think people are bored of the grid and having something that's more dynamic and agentic makes a ton of sense and I think

51:41 you could deliver a ton of value but my fear is that Apple's just like no that's our real estate. Uh, so is there a clear path right now through like widgets and the shortcuts API to actually do

51:55 interesting things or am I going to have to like sideloadad a different OS? Like how how like consumerfriendly and like easy will this be or will you be bumping up against the walled garden of Apple

52:09 pretty quickly? >> Um, that's a really great question. Look, every single thing we do is within the confines of the Apple ecosystem and experience in the way that they've

52:19 designed and made it work. And we've designed our product to fit almost like a glove in that into that ecosystem. Um, you know, when when you onboard into our experience, you just connect the things

52:30 in your life that you think are you you would want more. Uh, >> the server side connections I totally get like like all of that makes sense. You can like like OOTH with email and

52:40 use APIs or MCPS. Like there's a million things you can do on the server. >> What I'm interested in is like is like how big can the widget be or can you actually take over the whole home

52:51 screen? >> We can we can take over the we basically ask you to install two widgets a medium widget and a large widget that encapsulates the entire home screen and

53:00 those work in dynamic together. So the the medium widget will basically what we call a wildcard widget internally which shows you precisely what you might need to know at this point in time and then

53:12 the big widget is what we call a for you widget which is just a a feed and you know what we're doing John I think is we're building kind of the new iteration the the Facebook news feed 2.0 know

53:24 that's entirely AI generated about your life, highly personal and that lives directly on your home screen and you can browse it as easily. The feed paradigm is so familiar with individuals and the

53:36 beautiful part is that it's all like AI generated and AI mediated every we have 22 agents that work continuously to generate content for that feed. >> It's funny because like everything

53:45 everything that's fancy I'm like yeah that's easy. And then like getting people to install two widgets. I'm like that's the hard part. And I don't know if I'm right, but like it feels like

53:56 like like I'm still in like proumer territory, but that's a good place to start. And then you can hopefully make it easier and then maybe Apple opens it up to a point

54:06 where like you downloaded an app and just by clicking yes, it just installs the widgets by default or something. It it does feel like the the biggest thing is like I just love when like these new

54:16 surface areas are explored. Uh I mean you you you mentioned Nikita uh but like he's but he's done a great job of really understanding all the different hooks what you can do within iOS uh you know

54:28 pushing those to the limit creating like new UX new experiences on top of like what Apple gives you and it feels like that's really underexplored. Have you thought of uh

54:40 >> have you thought about built trying to build any products within within any of the LLM ecosystems just given that they they already have an exist you know massive existing user bases? That's a

54:52 great question and you know I've definitely explored like every single thing with respect to an API or a platform that comes out you know um I you know for example the WWDC APIs that

55:02 come out every year I uh I read them like like the Bible you know like I would I I I read >> um you know that that's my uh that's my uh you know uh religious holiday or

55:18 whatnot and every >> Cook is the pope. He's your post. >> Yeah, exactly. >> We get it. Yeah. >> Um and uh you know, so I scrunched

55:25 these. I think generally these API the sort of apps or chat GBT apps are it's unclear to me what the incentive structures are for the app developer just yet. And it's unclear to me why

55:35 applications deserve to exist inside of an LLM just yet besides just adding more context cuz theoretically an LLM is powerful enough to even generate an app to be able to do something in which case

55:46 I'm not sure exactly unless you bring some highly proprietary data like Zillow or whatnot. Maybe some of these experiences work. But otherwise, I don't know if the small time developer, you

55:55 guys remember the flashlight apps and the the lighter apps on the iPhone, like you know, you're not really seeing those types of >> as a probably 12year-old was the beer

56:05 app. >> The beer app was good. >> Just thinking that thinking that that was like that was peak humor. >> What about the I'm rich app? That was

56:11 like $10,000. >> It was just it showed a d a picture of a diamond and it was just like you could just open a picture on your phone. But if you bought that app, you could show

56:21 people that you just wasted 10K on a iPhone app or whatever. I think it literally maxed out. It was the most expensive app you could possibly like type into the app store.

56:31 >> I think the guy sold like over 500 copies before Apple removed it for no not foring real person. So I think he he made 500 times $1,000 and it was incredible. See, these are the kinds of

56:42 experiments and creative elements that, you know, I think deserve to exist in the world today. And I think, you know, we're a few handful of individuals that are kind of trying to make that happen.

56:53 And we're trying to be really creative, really fun, really interesting, engaging. Um, and AI is a super pl uh tool to be able to do that. More powerful than the original iPhone APIs.

57:05 Like, holy crap. So, I think we're we're we're early, but we're going to try. >> It's a dream. like like there's so much like >> you're doing this you're doing this the

57:12 right way because there's another scenario where like you could raise a series A right now like or like you know >> you have a team you have technology and and the weight list like you'll be

57:24 able to test things and experiment and learn like there's so much opportunity. What what an exciting time thank you so much for joining the show. >> This is great.

57:32 >> Thanks a lot guys. >> Great to finally have you on and congrats again. And maybe next time we'll talk about hot takes >> for sure.

57:38 >> Oh yeah. What do you think about this AI powered cannabis vape with blockchain rewards? >> I'll have to do >> I'll have to

57:47 So John was John showed me like a screenshot. He was showing the website for this this morning and I didn't realize today is 420. So that's what like this is like a 420 joke.

57:57 >> Is it a joke though? I think it's a real website. Like I think it's >> Yeah. Yeah. John, you can make a joke website. Did you know that? >> I know. I know. But I I I

58:05 >> John Claw design, man. Claw design. You can do anything. Okay. So, you're telling me if I put this in the Wayback Machine and it shows up uh as of yesterday, it's not a joke because I bet

58:17 you this existed yesterday. Let's see. >> Let's see. >> Let's see. >> I bet you if they were planning to make a

58:22 >> April April 6th, it's in the It's in the Wayback Machine. What does it say? It says, let's see. It's loading. It's got blockchain still. I think these are hustlers who have been just tacking on

58:34 every single possible trend to go as viral as possible. I don't know. We'll have to dig into it. Well, thank you so much for joining the show, Signal. Fantastic news and congratulations on

58:44 the progress. Have fun >> and we'll talk to you soon. >> Cheers. >> Have a good one. Uh, up next we have Ethan Ding from TexQL.

58:52 He is the co-founder and CEO here to announce fund raise >> to talk about enterprise analytics workflows. >> I think we had him. Let's check in with

59:02 the team and make sure that he is here. I believe he is. So, let's bring Ethan Ding in from TexQL into the TVP and Ultradome. Ethan, hello. How are you doing?

59:13 >> What's going on, guys? >> Hello. >> How you doing? >> Uh, how's it going? >> It's good. We have two of you. So,

59:20 please introduce both of you. >> And it looks it looks like it's being filmed on a, you know, phone camera from 2005. But, >> but, uh, we're excited to have you on.

59:33 >> Hi, I'm Ethan. I'm the co and co-founder or >> this is my co-ounder bark they're a CTO uh we're actually at a customer off office office on site uh and this is

59:43 actually a company >> does not I think like like IP bans like Zoom uh from their their internal network which I found out like literally last second phone

59:54 >> no it's great I'm I'm super we're super excited to have you guys on uh walk walk us through history of the company since it's your uh first Yeah. Uh I think we started this at like

01:00:06 late 2022. Uh right before Chad GPT came out. Uh we had this uh this idea that uh we if we if we spent a lot of uh money and uh time on like try to make analytics work. Uh it'd be uh it'd be

01:00:20 worth something. We we really didn't know what we were doing when we first got started. Uh since then what we've like really like realized is um after after like two years of uh uh rebuilding

01:00:28 the product like 10 times over. Uh we landed on something where you know I think like the typical enterprise has like 150 databases uh 10 different dashboards BI tools. They have like

01:00:39 20,000 different charts another like 400,000 tables and every single vendor wants you to like migrate into their thing and like drop another $20 million on like systems integrator for another

01:00:48 10 years to like do the migrations. We were like like let's like build a thing that can like connect everything um and and and hopefully be um uh the do do for do for analytics what uh or like high

01:00:59 frequency trading firms at the like stock markets. >> What was the first uh like analytics stack? Because if you're pre uh GPTs, are you just doing like word clouds or

01:01:11 like clustering based on keywords and tagging different phrases as they flow through a system? like what what what was the initial like okay uh there's a stream of data there's a bunch of text

01:01:22 in a variety of databases like how are you giving the customers value from that >> well it was pre- chat GBT but still post GBT so we had GBT3 uh and but um I think uh as we all know at this point the uh

01:01:37 the the IQ of that was way overstated at least for business stuff and so we had tech box on the right we type in your question sure like how do I get revenue you then a text box on on the left with

01:01:49 with the SQL and then >> you run it and then you uh copy it and then paste it into your whatever tool. >> Interesting. >> And then that was it.

01:01:58 >> But we've come a long way from that. >> So what walk us through I mean you don't have to tell us what customer you're with today, but uh what does actually uh as a group of co-founders going to a

01:02:09 customer site like what are you doing? How deep in the weeds are you? Is it just sort of like a high level pitch or are you rolling up your sleeves and and working on actual integration?

01:02:20 >> Yeah. Well, I I think like today's session was basically um like walk us through like the the I mean every single Fortune 500 company like basically spends like nine figures on like AWS,

01:02:31 GCP, and Azure. They spend another like like 10 figures on like paper that like like like manages all these systems. Um, and and it's kind of this like constant like war of like you go from like

01:02:40 spending $20 million to like like a terod data on prem to like spending like $30 million with like a data brick in the cloud or something. Um, and and so like what we're what we're we're trying

01:02:47 to map out with them is uh anthropic is telegraphing that they want to be the size of AWS in like three years, right? And they're an enterpriseoriented company. They expect that basically come

01:02:57 out of like um companies like the that we're working with like budgets. And so it's like they basically expect them to take their entire IT budget of like let's say like 2003 $300 million, double

01:03:07 it and like like materialize this money out of like thin air and like spend it on infrance and they're they're they're walking us through like the the um parts of their road map where you know what

01:03:17 kind of SAS can they sunset, what kind of labor costs are they like thinking about like the trade-offs around um on like what time horizons to like create up and also like like what kind of like

01:03:25 workloads that are going to be extremely expensive that they can like kind of like start uh basically triaging off like the large like models cuz because at the end of like these are these are

01:03:33 kind of the people like when you see like the token charts like everyone token maxing these are kind of the people who like pay the bills on like those token and like like they notice

01:03:42 the size of that bill like you know like blowing up like 10x like year over year. Yeah. >> Um interesting. It's interesting side of the equation that I guess like people

01:03:49 don't spend a ton of time talking about. >> Yeah. How have you been processing the SAS apocalypse narrative? Uh Beni off was given some push back. Uh other folks were very bullish on it. There's a whole

01:03:59 bunch of different data points. I've been just shocked that uh we haven't seen revenue uh declines from really any software company that's been targeted. Although, you know, you could talk about

01:04:10 the long term, but the the the growth like these companies are still growing even if they are in like the direct path of the AI companies. >> Yeah. I for like the for the longest

01:04:23 time I assumed that like everyone likes to buy like good enough. Um, I think really in the past like three months I've heard like like six different CIOS or CEOs of like Fortune 100s like talk

01:04:35 about how they're ready to like like Salesforce is like increased like their headless like tax and they're ready to like like do like a two-year migration like off into like like Postgress or

01:04:44 something. >> Um, it's it's not like they're going to another vendor. They're just like I need to free up money to like set on GPU like set GPUs on fire. Sure. And I'll pay

01:04:51 like anybody to like like move me into like like a Postgress instance in like like Google Cloud or like AWS. >> Interesting. Okay. So, so that's a little bit of your opportunity. You help

01:05:00 with migration. >> Uh that that one that one's kind of adjacent to us. We we look at a lot more like lowle infrastructure like like data bricks, snowflake, like Tableau and

01:05:08 otherwise. But it's it's interest like >> a CRM is basically the second most important system of record um at an enterprise next to the ERP. Yeah. they're willing to entertain like moving

01:05:18 entirely off CRM within like a two-year time horizon, maybe they'll completely fail, but like the willingness to like like forge into that is then uh like like an order of magnitude more higher

01:05:30 than I expected. Kind of crazy. >> It's surprising based on the profile of company. >> That's something you normally expect from like Google or Facebook like the

01:05:37 most mature engineering companies in the world, but you you see this effort starting to come from a hundred-y old companies as well. >> Interesting. Interesting. And uh is is

01:05:48 is that driven more by they think that over the long term there will be a net cost savings to having their own system or more that they want something that's completely bespoke and more custom to

01:06:01 their business. Um, it's mostly not. There's an interesting thing Larry Ellison uh talks about uh when it comes to like enterprise sales, which is that

01:06:12 like like enterprise sales is kind of like buying like like um like Gucci bags. Um it's it's much more like like any given year you have a CIO come in like right like the the halfife of like

01:06:20 a CIO is like like five years before they retire, new one comes in, they have to like start a set of like new initiatives often like they're going like like they're they're finger testing

01:06:29 like the market and trying to figure out like who who has the best vibes. Sure. >> And like basically who who okay whoever has the best vibes I'm gonna throw like eight figures against um and I'm gonna

01:06:37 like move that eight figures away from like someone like a company that has like like worst vibes. >> Sure. There's this like weird um self-fulfilling prophecy where

01:06:45 >> they're vibe procuring. >> Yeah. >> They're vibe procuring. >> Like you walk into a room, you can tell when that like company's stock is up.

01:06:54 You can tell when the CEO is like extremely cocky. You can tell like when the when the FDES and the sales people are like listen like you don't even have to move this today. I'm going to get

01:07:01 your business next year no matter what because I know we're on the up and you can also like tell when like a vendor is like desperate, right? And they're like like moving for discounts, right? When

01:07:09 when when some when when as long as the perception that a company like the market is short a given like SAS vendor, um customers start asking for discounts, the most aggressive ones go first. But

01:07:20 now like all the sellers on that team are like like bad like you know they're traumatized between like the next set of renewals. So they're they're progressively going to give more and

01:07:28 more ground. Um, it's kind of a rough uh, yeah, wouldn't want to be one of those right now. >> Interesting. Interesting. Well, uh, your business is growing. You're raising

01:07:36 money. Tell us about the latest round. >> Yeah, we um, we it was actually like a like a two two-part round. Um, the first uh, like led by like Hoff Capital and the latest part like

01:07:48 >> uh, Blackstone. >> How much did you raise? >> Uh, I think it's 17 in total. >> What? This was a This was awesome, guys. I really I really uh enjoyed speaking

01:08:01 with you both and uh thank you for making time on uh while while you're hanging out with your customers and appreciate the perspective. Let's uh let's do it again soon

01:08:08 >> and good luck out there. We'll talk to you soon. >> Thank you. Have a good one. >> Have a good rest of your day. >> Uh up next we have Matt McKini from

01:08:15 Loop. He's the co-founder and CEO raising a big series C in the waiting room. Let's bring him into the TV and Ultradome. Matt, how you doing? What's going on, guys?

01:08:28 >> Not too much. Good to have you here. Uh, first time in the show. Why don't you introduce yourself and the company? >> I'm Matt McKenna. I'm the co-founder and CEO of Loop. And our mission is to

01:08:37 unlock value that's trapped in the operations that power the physical economy. And we started specifically in the back office where no one else wanted to go and back office services and

01:08:48 automating things like accounting and junior ledger coding and and payment services. And all we do to exist is to make our customers more efficient so that they can better serve their

01:08:58 customers. And we work with some of the most important companies in the world. 20% of the Fortune 100. >> Wow. >> And excited to be on with you guys.

01:09:05 >> Yeah. Well, uh, how I mean there there's a different world when you say like uh procurement or accounting that you could have been like we're a aentic accounting firm or something and it feels like this

01:09:18 is much more crossfunctional. uh how are you actually positioning like the integration? Who's the buyer? How how does the uh how does the business like instantiate itself inside of your

01:09:29 customer? >> Yeah, we started we started with a very acute problem which is >> if you look at the supply chain industry, yeah, roughly 30% of invoices

01:09:39 are wrong or they have an error. So clearing of them is really painful. Y and because of that a bunch of services firms popped up, specialized services firms popped up.

01:09:48 >> Sure. And all they do is address uh address that specific problem which is you got to adjudicate this invoice. You got to ensure that it's accurate. You got to remit payment to the truck

01:09:58 drivers and the carriers across the world. And that's a big industry. It happens to be a $5 billion industry alone. And it's all done with human labor. And obviously LLM's presented a

01:10:09 perfect opportunity for that. But I think what got my co and I most excited is really the data. If you can go organize the data, then you can obviously automate things like we just

01:10:19 mentioned the accounting, but you can use that as a wedge to expand into adjacent use cases, whether it being compliance or planning or procurement and continue to unlock value for your

01:10:30 customers. >> Yeah. So, uh, what does it look like for a customer to actually onboard? I imagine you need access to their emails, like the actual PDFs of the invoices,

01:10:39 whether things have gotten paid. There's often like multiple versions of a particular invoice and then you need to plug into bank data to see what what's actually moved around or accounting

01:10:48 systems like how long does it take to integrate and how key is that? It's w I mean what's so wild about supply chain? Supply chain is just a network of networks.

01:10:58 >> Yeah. >> And you've got, you know, a a transportation carrier, you've got a supplier. You could have multiple versions within your own enterprise.

01:11:06 Some a lot of these big companies, they do a bunch of M&A. And so you've got all these different versions of the truth. So just take for example the weight and dimensions of a package or shipment.

01:11:16 >> There could be seven different versions of the weight and dimensions for that package. And so you need almost like a a data auditor itself to prove that that's the correct data. And we get it from a

01:11:28 bunch of different sources. We get it from, you know, email, we get it from EDI, we get it from uh API connection, we get it from Excel spreadsheet, PDF, you name it. It's just really messy,

01:11:37 unstructured data. Data that no one's ever organized. Quite frankly, no one was able to organize until the power of LLMs came out. Uh does when you talk to customers, do

01:11:48 they care about the AI buzzword at all? >> Yeah. Are they trying to buy AI >> or do they just want a solution? Like how are you thinking about how how front and center AI is in your value prop and

01:12:02 pitch? >> All our customers want is just outcomes. >> Yeah. >> And they don't really care how you deliver it. Now, sometimes they might

01:12:09 have a top- down AI mandate. >> Sure. that they're looking to check the box, but at the end of the day, they don't care how the sausage is made. They're buying an outcome. That's all

01:12:17 that they want. And if you can demonstrate that you can deliver a superior outcome, it's better, it's faster, you're, you know, for example, you're finding more errors or whatnot

01:12:26 and faster resolution time so you can close your books faster, that's what they're buying. They're not buying agentic buzzword fit into their, you know, their checkbook. They they really

01:12:36 want to buy the value. >> Yeah. What is the value of like getting this business to scale? Is there is there something where you can you know optimize the supply chain, introduce

01:12:48 different clients that need to different resources and help them buy the best product at the right time or reviews or even just like panel data of like how the economy is moving. We've seen that

01:12:59 from some financial some fintech companies. Uh like how are you thinking about the value that's unlocked as you become a platform? Yeah, there's more. You mentioned like

01:13:09 procurement for example. There's more obviously when you you have a bunch of data that you can use and say this is good, this is bad or you should be working with the supplier and you're not

01:13:16 because we see it over here. But I think that you know really building context across the network is probably where we see the most gains where you can take learnings from a carrier that's working

01:13:26 with you know supplier that's working with multiple parties in the network and then say oh well this carrier always likes to build a specific way and so propagate that learning through the LM's

01:13:36 context across all the all the companies that work with that carrier. I think that's really I'd say the unlock and automation that you get at scale. And then obviously the you mentioned the

01:13:45 intelligence one, the time to value. You're able to get someone on much faster because you're working with 95% of their suppliers instead of 2% of their suppliers. That's a huge win as

01:13:54 well. >> What were you doing before this? Did you always have a love for back office supply chain optimization? >> I I I I can tell you I can tell you he

01:14:02 has since he was a bull. >> I came out of the womb and I just said, I want to automate the back office. >> Yeah. complex and

01:14:12 >> yeah I I've always just been obsessed with the systems and making them more efficient and I think >> you know when you look at the physical world I mean it's supply chain you know

01:14:20 the trucks and the train that stuff's just so exciting you feel like it's the last frontier where you can truly unlock value I mean look supply chain alone just in the US is 11 trillion in spend

01:14:30 >> wow >> you know one of the largest trillion huge yeah >> yeah if you want if you want to have an impact on GDP

01:14:38 going too high. >> Sorry, I was giving you that for the 11 trillion. You said the biggest number. So, >> if you want to if you want to have an

01:14:47 impact though on GDP, at the end of the day, GDP growth is just productivity growth and technology is the leading advantage in that. You're you're saying 11 trillion in spend goes to supply

01:14:56 chain and no one's really touching that, then we got to go attack that problem. >> Yeah. Uh yeah, I have so many more questions, but uh >> but before Yeah. Before that, we were my

01:15:04 co and I were at Uber and early on the freight team. And we saw a lot of the, you know, the real world there where >> you had messy PDFs, you had billadings,

01:15:13 proof of deliveries, just a total data mess to be honest with you. And we knew that there had to be a better way. >> Yeah, >> dude. Perfect perfect VC pattern match.

01:15:23 Uber freight team. >> Yep. It's a great team. Great company. We know so many entrepreneurs that came out of Uber. Uh, tell us about the round. What's what's going on? How much

01:15:30 did you raise? >> We raised $95 million. Couldn't pull together that last five. >> That last five. What was going on?

01:15:40 >> It evaded you. It evaded you. >> Sandbagging. Sandbaging. >> No, you had to set up had to set up the next round figure a little bit for the next one.

01:15:49 >> Yeah, exactly. >> We're super excited. >> Really? Where you guys? Where are you guys based? >> Valor at Trades AVC Founders Fund Index,

01:15:58 JP Morgan. Wow, you got everybody. >> You got everything. >> Congratulations. >> Wait, where are you guys based? Sorry, I missed. based in San Francisco. You got

01:16:05 offices in Chicago as well as in New York. >> Is that because Chicago is a major like logistics hub with the trains and trucks and stuff?

01:16:13 >> Yeah, there's a lot of there's a lot >> there is there is a major I'm not making this up, right? Like with the boat because the boats come through the the the lakes and like it it was like a

01:16:23 major hub of transactions. >> Is that because Chicago has trains and trucks? >> They do. They do. This is real, right? Am I wrong?

01:16:30 >> You're not you're not wrong. I'll give you stats. So 30% of goods that enter America go through Chicago. >> Thank you. Thank you. 30%. Not bad. >> That was right. You're like, "Oh,

01:16:42 Chicago. Why is such a weird pick?" It's not. It makes a ton of sense. >> Well, great to meet you, Matt. Congrats to the whole team and hopefully hopefully you're back on the show uh

01:16:51 this year with some more news. >> Really appreciate it, guys. Thank you. Love the show, by the way. >> Thank you. Have a good one. >> You up next, we have Eric Anderson from

01:17:00 Alloy Therapeutics. I love I love I love messing with you. >> You love messing with me. >> Never gets old. >> Well, without further ado, Alloy

01:17:08 Therapeutics has raised a series E to build full stack AI biotech infrastructure. Eric Anderson is here live with us. Eric, how are you doing, >> gentlemen? I'm doing great today. Yeah,

01:17:19 good to have you. >> Thank you so much for hopping on. Uh first time on the show. Please introduce yourself and the company a bit. >> I'm Eric Anderson. I'm the CEO and the

01:17:27 founder of Alloy Therapeutics. We're a biotech infrastructure company that works with a bunch of companies all over the world helping people discover and develop drugs.

01:17:34 >> Okay, infrastructure. What exactly is going on in the biotech stack? I imagine everything from centrifuges down to bright and PDFs for the FDA to trials. There's so much that goes into that.

01:17:46 What what are you focused on specifically? >> You got that. So the the technology we have is really around more drug discovery and then into drug

01:17:53 development. So the folks that do regulatory, the folks that do clinical, we work with them to discover drugs uh with the companies that we help to support. So we work with big pharma

01:18:02 companies, we work with small biotech companies. What's going on in the industry today? The big trend right now is when we talk about infrastructure, who's going to actually do the wet lab

01:18:11 work today in the lab. In addition, we've got everything going on with tech bio of all of this in silicico work that's happening. That's really exciting and sort of bringing those things

01:18:19 together. >> Yeah. Yeah. And the idea is the idea is like you can have like mill, you know, a million times more ideas for different drugs, but then you still have the

01:18:27 constraint of the physical world needing to kind of be able to actually run experiments until ideally we could simulate a lot more in the future, but maybe we're not

01:18:37 >> not there yet. >> Exactly. Right. And you can simulate all these things, but it's a bit of the design, build, test, and then you learn. It's that it's that loop we all know. Y

01:18:44 >> and right now in the biotech space, we've made some incredible progress with Gen AI and machine learning capabilities to come up with a lot of those ideas. You got to close the loop then and

01:18:54 actually be able to test them. And then there's a lot of skill that goes in just the skill of drug development of of what makes a good drug and connecting those things together is what we do really

01:19:03 well. >> So how how much of this will wind up looking like an AWS for drug development? I can provision a certain machine and you have it and I can

01:19:12 interface with it all over uh you know the internet and you will do all the physical stuff for me. >> Yeah, that's part of it. So AWS just launched a service. Amazon launched a

01:19:22 great service that connects >> these these generative uh companies back to a back end of how you manufacture the protein and you test it. >> That's one small piece to the process. I

01:19:32 would say a lot of scientists out there that can design things in silico uh and then send them to a lab like that that will help. >> Crazy. Is that not like a crazy side

01:19:41 quest for them? Like it's >> Wait, did AWS has like centrifuges now and like like >> No, AWS is actually just connecting them together. No, it's it's pretty.

01:19:51 >> I think what they're going for there is that they want to be the cloud if you're going to do your compute to come up with these with these Encilico things. They want to make sure they see all the

01:19:59 traffic and then just connect it to anyone else on the back end. Yeah. I think what they're doing. >> Got it. Got it. Yeah. Uh so, um >> can you zoom out for me and and just do

01:20:08 a temperature check on biotech? We we read one article about how uh Boston's going through a really tough time. At the same time, like every time I open up the Wall Street Journal, there's a new

01:20:18 billion dollar acquisition. >> Yeah. last year felt like like the dark the dark ages for biotech felt like everyone every every uh bio biotech investor that we were

01:20:30 talking to was like I don't even know why you'd keep investing in in these companies like the returns have been so bad and then this year is like the biggest year of biotech M&A since

01:20:38 >> it feels like they're just rich from the GLP1 boom but I'd love to hear your sort of like narrative setting >> certainly the GLP1 boom one of the trends that's going on here is that the

01:20:47 industry has to restock the shelves for new drugs. As drugs go off patent, there's these revenue cliffs. And so big pharma is sitting on probably the largest pile of capital they've ever sat

01:20:57 on and they look to acquire a lot of their innovations from small companies. Those are the folks that we support to create new medicines. So there's definitely a huge M&A trend that's

01:21:06 happening this year and it'll continue to happen for the foreseeable future. A big thing that's happening as you read about that news in Boston though is we're doing drug discovery and

01:21:15 development here in the US. But there's been a big shift to move it overseas and to offshore it and for pharma to acquire assets from outside of the United States. And so that's that's been more

01:21:24 of the big I would say the headwind for the domestic biotech space. >> Okay. Uh how are you feeling about just acceleration in drug development generally? Like we you know in in cyber

01:21:38 security agentic coding like there's these very clear uh scaling laws and you know we have the meter chart of the amount of time an AI system can work on a single problem. It's doubling. It's on

01:21:50 a very clear trend. I haven't seen a chart that's like that for biotech, but it feels like we're going through advancements and we're just getting more cures. So, something's happening. But

01:22:03 are you tracking it at a quantitative level yet or just qualitatively? How do you feel about uh drug development products? >> Sure.

01:22:10 >> We're living in an era right now where the trend of all of the drugs that we're discovering. We have an acceleration in the amount of innovation that's coming from our labs. So, so that is just an

01:22:20 incredible uh trend that is supporting everything we're doing in the lab. So, that the byproduct of that is of course generating massive amounts of more data, making sense of that data and this is

01:22:30 where a lot of the machine learning is coming in is how do we digest all of the data that's being created in the industry making sense of it and then turning that into new cures as rapidly

01:22:38 as possible. So that is an enormous trend right now in the industry. >> Yeah. >> Uh and and the advances that we have just from literally using cloud and open

01:22:47 AI even in the lab and just day-to-day things. Yeah. >> You're seeing a handful of things come together. >> Huh.

01:22:52 >> So first of all, you see this explosion of data. You see the wet lab capabilities largely looking the same. >> And what's happening then is we're trying to organize that data and turn it

01:23:01 into new curus as rapidly as possible. and and in the background what we have is a number of new companies, new entrance in the tech bio space that I think are just natively better at

01:23:11 understanding this massive data problem and being able to make sense of it. >> And then on the other side, you have the pharma and biotech which are actually you require all of those skills to

01:23:20 actually make sense of what's going to work in a in like a human biological system. Yeah. >> So, >> what's coming together this

01:23:27 >> this year, I would say, is that there's a lot more folks in tech bio that are getting better, but then we're just seeing the bio folks actually get better at tech. So,

01:23:36 >> basically, you're at this place where like the tech bio folks need more bio >> and the biotech folks need more tech. >> And if you're bringing those things together, I do think we're going to have

01:23:44 an acceleration in a lot of the cures that we're making. >> Interesting. >> Uh, give us a view into how big pharma executives are thinking right now. How

01:23:53 are they confused why everyone and their grandma is injecting themselves with Chinese peptides yet at the same time like hype more skeptical of vaccines than than uh maybe ever. I feel like

01:24:05 this kind of this interesting uh uh dichotomy. >> Yeah, it's well in the industry today, I would say the executives in farmer are looking at it from the same place they

01:24:14 always do, which is about efficacy and patient safety. And so we're looking for drugs that work and then proving that they work in in animals and then ultimately in humans. So peptides being

01:24:25 injected into humans, I think everyone's just saying, "Hey, what's safe? What's efficacious?" The FDA has done some pretty amazing things uh in this administration, I think, to give

01:24:33 flexibility for what's allowed. Uh there's been some incredible changes that have happened that I think will accelerate uh the pace of innovation, what we do in the regulatory space, in

01:24:42 the clinic as we're testing in humans. I think pharma is apprehensive about the changes, but overall they're excited that things are moving along and that we're going to see a lot new drugs

01:24:51 coming on the market. >> Can you help me understand uh the flow to get to like a data boom in biotech? because I I would assume that that's more driven by uh like dropping costs of

01:25:03 DNA sequencing than anything from the Gen AI world because the but maybe there's something where the Gen AI world can process data that was previously like locked up in PDFs or something like

01:25:17 what what is actually driving the data boom? >> It's those things really coming together. So certainly the the continued falling cost of DNA sequencing. Yeah.

01:25:26 And then the falling cost of all the other types of data that you can generate along with when you're sequencing someone's DNA. So if you go to a place like function health here or

01:25:34 like what you can pull off your aura ring or your Apple Watch, there's actually a massive amount of data that is that is being generated passively. >> And right now the ability to connect

01:25:43 that data to I would call it real world data that we can connect to what's happening in patients. Yeah. >> Is a level of complexity that we just haven't seen before on the data side.

01:25:52 >> Yeah. But it's got to be rooted back in basically the wet lab. You're describing these things of uh of taking your DNA or your tumor DNA and you're learning from what's actually happening in a patient.

01:26:02 >> Yeah. >> And bringing those together is actually a huge data problem. >> I I imagine you work with like mostly like big pharma or real biotech

01:26:10 companies, but we're also seeing this like boom in like a single person vibe coding a cancer cure for their dog. like do you have a policy for whether like how small a team can be because I

01:26:25 imagine it's not far from you getting like an inbound from like a single person who's like I want to do this by myself I'm a solo >> I can be trusted with advanced AI by

01:26:34 >> and maybe they should maybe they shouldn't be I don't know I just want to know how you've like grappled with it maybe it's just not a business concern so you don't need to worry about it but

01:26:41 I'd love to know like how are you processing that idea of >> no I mean I think everyone could be trusted with this generally so that's actually not the current don't worry

01:26:48 about kind of these fear mongering that's happening on this front. Okay. >> Uh >> at our company we service anyone who is interested in discovering new drugs. And

01:26:58 so that's a lot of what we try to do with our company is how do we democratize access to many of these tools. Yeah. >> We started in a particular place nearly

01:27:05 10 years ago. And that was before we had any of this Gen AI work going on. >> Sure. Sure. And it is lower that single person biotech company or maybe just more of the the virtual biotech company

01:27:15 where you've got five or 10 folks and they can work with a different contract research organization to help do their drug discovery and development. >> That's been a trend for a while. What's

01:27:25 happening is we're just getting more efficient at it today. >> So I do think the future biotech company is going to be much much smaller and be able to plug into these different

01:27:33 resources and be so much more efficient at coming up with ideas and testing them. >> Yeah. Yeah. Yeah, I mean it is interesting. Uh tech loves to sing the

01:27:41 praises of like the five or 10 person team, but there are a lot of biotech companies where it's like one genius researcher who discovered something and a couple support staff and then a lot of

01:27:52 outsourced stuff all the way to okay, we're ready to sell it and it's mostly just a research or this is not entirely new there. uh you you mentioned that you're not worried about like doom

01:28:03 related to uh like bio uh but like you know are how how how are you grappling with the idea of like somebody making a super bubanic plague or you know some new flu like are are do you feel like

01:28:17 there's safeguards or h how have you processed that question >> there there's lot groups of folks that are worried about this and I think the United States military and some of the

01:28:26 the consortiums that we've been involved with are giving that thought it really comes down to though is you can make a lot of things that might be dangerous. There's always a bad actor problem. The

01:28:36 way that we think about that is through our biocurity division. We try to make sure that the capabilities that we need to have in the United States are always available and accessible to us. So call

01:28:45 it medical access capabilities. We learned a lot of lessons in co everything from could we actually just test for for viruses in the community and do we have the reagents available to

01:28:56 do that and then of course we had masks and everything else. So from our perspective, we think about biocurity as a way of making sure that you do all of those components from being able to

01:29:05 surveil what's happening in the theater all the way out to can we discover and develop a drug very rapidly. And there's some great uh different initiatives that are going on of these ideas. Can you go

01:29:16 from a threat to 100 days later actually have a drug ready to go? and uh our company and others participate in in making sure that there's just a really robust response available with

01:29:26 incredible supply chain and and sort of make sure we can do everything here in the United States at all times. >> Yeah. Yeah. I mean it certainly seems like uh like the the the advancement in

01:29:36 the positive side like we're seeing a major major uh swing to the upside right now. Uh every time I hear about one of these new medicines or new treatments it seems really positive. There was a huge

01:29:47 story about pancreatic cancer recently which was a complete white >> right right now we've got a conference that's going on and we saw two different studies that were showing just for some

01:29:56 of the patients that were on drug it was six years later they still had no disease and that's saw we know about pancreatic cancer it is really really tough

01:30:06 >> oh it's it's really incredible it's one of the worst worst cancers we have but I think this is the overall trend we are living in a world where we will cure everything that is curable I think in

01:30:15 the next three decades. It's really just a question of and maybe even faster than that. It's a question of how fast can we accelerate and really give as many people as possible access to these

01:30:24 incredible tools. And just like in tech, I mean where you saw these very small companies be able to do incredible things in the last 5 10 15 years. I was investing back during the first internet

01:30:34 bubble uh back in in venture capital 25 years ago. And in those times the world just looked a different place. We actually middleware was 10 years old. I I was I'm like 48 right now. So yeah,

01:30:47 I was I was still a child. >> You look late you look like late 30s. So So that's >> that's good. Good for you. >> I was a child at the time. But I mean it

01:30:55 was incredible because there was a lot of the same criticisms that we're hearing in the tech space right now. And as it relates to biotech, it was like we were wrong about everything back then

01:31:04 except for what we were right about. >> Yeah. >> We we did see the flow of investing coming in and many many things went bankrupt, but the things that didn't go

01:31:11 bankrupt changed the world. Yeah. Yeah, >> and that exact same thing is happening today that you're going to see incredible number of winners. And I do think biotech is going to be important

01:31:19 part of the big market that everyone's going after uh in in the AI and the ML space as well. The tech space is going to go conquer biology as much as it has in other places. But I would say also

01:31:31 that pharma and biotech very much have a seat at the table. Our academic researchers have a seat at the table there. And it's really about bringing the two domains together that are going

01:31:38 to be critical. One of them is not going to go it alone uh without the other. Tell us more. I need more tech. >> How much did you raise? How much did you raise?

01:31:46 >> Raised $40 million this time. Yeah, we hadn't raised any money. >> We kick off. Thanks, man. Congratulations. Appreciate that. >> We've been working hard to build a real

01:31:55 business. So, yeah, this is been a long haul for us. >> This is our series E. I'm a little old, but back when I was a child, when I was a baby investing 25 years ago, I uh I

01:32:05 learned that you it's okay to just letter your rounds just like normal. Our last round was in 2022. >> Yeah. >> Yeah. I'm kind of old school in that

01:32:12 way. So in 2022, we did a round and uh between then and now we really laid down the infrastructure so that we had operations across uh 17 time zones. Now we're operating the United States,

01:32:24 Japan, >> the UK. Um we have an incredible uh group that's actually working in the GCC right now in the Middle East. Obviously, there's a lot going on there that's uh

01:32:33 that's creating a bit of a headwind, but we're very bullish on the work we're doing in Saudi Arabia, UAE, Riyad, and Doha and uh and and over in Abu Dhabi. So, yeah, bringing all this stuff

01:32:43 together has been really important for us and just our view is you stitch together the supply chain of innovation, you link it to great world uh real world data and you bring a lot of AI and ML in

01:32:53 there and we're going to really accelerate the pace of drug discovery and development. >> Very cool. Well, thanks so much for joining show. Great to meet you.

01:32:59 >> Yeah, enjoyed the conversation. Have a great rest of your day. >> Thanks for having me on, guys. Have a great day. Appreciate it. >> Goodbye.

01:33:04 >> Cheers. >> Up next, we have Pipa Lamb returning to the show from Sweet Capital alongside James Wise from Bington Capital Partners. I believe they are in the

01:33:14 waiting room. Uh, calling in from across the pond. Are you both over in the UK today? >> They better be. >> Yeah, we have given the news.

01:33:25 >> Well, welcome to the show. Uh why don't uh Pippa, why don't you reintroduce yourself and James since it's the first time on the show, you can introduce yourself as well.

01:33:34 >> Yeah, big day. James' first time on TVPN, guys. >> Yes, we're very excited. >> Fantastic to have you. >> Uh yeah, so those I haven't met before,

01:33:43 I'm Pipam. I'm a partner here at Sweet Capital. I'm also an active angel investor here. Um and I also scout with A6MZ, but generally sort of sit between the ecosystems of the US and the UK

01:33:54 tech. >> Wow. How do you I I didn't know you were you were the triple threat there. How do you how do you decide who gets who gets what

01:34:00 >> who gets the deal blow? That's interesting. >> No. >> Yeah. >> Secret secret.

01:34:05 >> Secret James. >> James. >> Yeah. First time caller but longtime viewer. Thanks guys. Great to have you >> having me on. Um so I'm a general

01:34:14 partner at Balderson Capital. We're a 7 billion venture firm. We're based here in London and we used to be called Benchmark Europe. There we go. We got the buzzer. Um, so back back in 2001, we

01:34:24 were benchmark Europe. We we uh we spun out in 2010 when the European market really took off >> and uh for the last four months I've also been helping set up the UK's

01:34:33 sovereign AI fund. >> Okay. Yeah. Take us through that. I think that's what we're here to talk about. Uh how long have the talks been going on? How big is the fund? What's

01:34:41 the strategy? What makes it unique in that it's uh so linked to the UK specifically? >> Yeah. Well, about a year ago, we kicked off this big AI opportunities plan.

01:34:50 There was huge news about it at the time and we've been working through all the various parts of that and Piva can talk more about things we've been doing in data centers and compute. Um, but the

01:35:00 fund was set off to really accelerate some of the UK's big uh UK AI successes. Um, but with a lot more than capital. So, we've got about 500 million pounds. Uh, it's a starting point. It's the

01:35:09 entry ticket in this game. Um, but more importantly, we're providing uh access to UK supercomputers here. So, huge amount of compute. We're providing uh fasttrack visas. We're providing unique

01:35:21 data sets. We're providing government as a customer. So procurement through government basically to give a lot of the companies say they could benefit from working with the government a

01:35:28 massive boost. >> Yeah. I have to say that supercomputer is such an underrated term. Whoever thought to rebrand supercomputer to data center

01:35:38 >> terrible >> is an idiot. >> Terrible. >> Because data center sounds so boring and terrible.

01:35:43 >> Supercomput is awesome. >> Not going to take my job. I'm so into supercomputers. What were you a super computer? >> Yeah. Uh so but uh

01:35:52 >> it's your grandfather's data center, right? It's the supercomputers like well IBM used to build. >> Yeah. Yeah. Yeah. And and and they have them in like cool scientific locations

01:35:59 like CERN has one and like you always hear about oh they're doing astrophysics on them. There's so many cool things. Uh but uh that does link to you know where will the UK get the most leverage out of

01:36:11 investing because I imagine that there's not a lot of value in just trying to like clone Google search or Instagram for Europe like th those platforms it's fine but at the same time sovereign AI

01:36:24 does have value where in the stack is does that live in your mind? Yeah. So we're building uh out a whole range of talent, right? So we're going to be doing everything from electron to

01:36:36 token, but obviously working with American partners doing that and international partners as well. Sometimes at the chip level, sometimes at the model level and then we're

01:36:43 starting to focus on where the UK has huge advantages. So life sciences is a huge area for us, right? If you look at isomorphic, which is actually a spin out of Google, you know, they're based here

01:36:53 in London. the whole team basically is European and they may be the closest we get to a company getting a drug all the way through to approval that's sort of endto-end AI design um outside of life

01:37:05 sciences loads of stuff in physics and material sciences so a lot of the uh AI science end of the spectrum rather than the AI slop end of the spectrum. >> Yeah. Uh, Pipa, are you seeing uh are

01:37:17 you seeing like a an effect where entrepreneurs from around Europe are moving to London in the same way that folks from Chicago move to San Francisco to do startups? Like I is there is there

01:37:30 a proper movement to make London like the destination for ambitious European founders these days? Yeah, I think it's it, you know, I obviously fairly biased having spent a

01:37:41 lot of of time here, but I think that the UK has always battered above its weight in terms of the deep R&D pockets we have here, you know, in terms of universities, the talent that are coming

01:37:50 out of the local schools. Um, that's already created a very fertile ecosystem. And I think that, you know, one of the reasons we wanted to jump on here today was because it feels like,

01:37:59 you know, UK is having a bit of an AI moment. It's not to say that we weren't already at the forefront of many of the innovations happening here. You know, of course, people always talk about Demis

01:38:11 Hannah Sabas from you know, DeepMind that was founded in the UK. Uh obviously we would have loved to have kept that here, but of course it also went with Google. uh but you know we have long

01:38:21 been at the forefront of >> I think it's super critical that that they they deep mind maintains such a big presence in in the UK because you guys now at the sovereign AI fund if someone

01:38:32 wants to >> leave Deep Mind spin out like you guys can be there to provide capital and >> exactly and that's what we're we're seeing now um I think both from the idea

01:38:41 that we want to be an AI maker not just an AI taker we're seeing you know grassroots innovation come out of the schools here but as you say we're also having people either leave Deep Mind um

01:38:51 also in terms of our partners across in the US I think you know James can correct me if I'm wrong I feel like a lot of the uh you know the first destination headquarter within Europe is

01:39:01 usually in London I think that that is pretty much most of the large AI companies we've had um so I think that there is definitely uh you know it's always been a good hub for AI but we are

01:39:12 seeing a lot of additional tailwinds of which sovereign AI is one of them at the moment as well >> we went through this period last year and I it might still be going on. I

01:39:22 don't really have a pulse check on it where uh every AI company's seed round was in like the hundreds of millions of dollars and I imagine that you're not going to spread this fund over just five

01:39:32 companies and so do you think that >> gone it's one >> it's one bad but I mean do you imagine uh being uh like like investing alongside other

01:39:45 funds and doing more structured rounds where a lot of capital comes together to take like big swings or is there actually some sort of structural shift in the type of startups that are getting

01:39:55 built today where 5 10 20 million can actually uh put some points on the board early on and get in the game in a meaningful way. >> I can see that you guys can uh make a

01:40:07 number of bets on the app layer. about energy more science focused Neolabs Neo cloud like I feel like >> five 500 will like really can kind of

01:40:19 like seed a bunch of different players but >> but yeah how are you thinking about like the dynamics of like early stage startup fundraising right now?

01:40:27 >> Yeah, I mean in the UK actually we are seeing those hundred million and even billion dollar seed rounds now. So there's a rumored billion dollar seed round in a uh in a founder who's out of

01:40:36 Deep Mine which is incredible. Um, and there's there's been a bunch of those uh in the last few months, which is great. The fund is actually doing it the other way around. So, we're saying we're going

01:40:45 to give you tens if not hundreds of millions of dollars possibly of government procurement contracts, right? If you can build it, if it's good enough, if you are world class, we're

01:40:55 the customer. We're ready to buy. >> Uh, same thing with compute. We're able to give a sort of, you know, a significant amount of compute to early stage companies. The quid proquo is,

01:41:04 hey, the taxpayer is taking all this risk backing you. what's our upside, right? We want to be on the cap table, right? We want to do it on commercial terms. It's, you know, going to be on

01:41:12 the same terms as an index, as a Boulder turn, as an Axel, as a A6 Z, whoever's there. We're going to be good partners, but the money isn't just about unlocking upside and getting uh you know, getting

01:41:22 on the cap table. It it's also about helping the companies to some degree and obviously, you know, still 510 million can make a difference. So, I don't want to be like too flippant about it. You

01:41:32 know, those things early stage do matter. Yeah. >> Um, but you know, we're here to help the taxpayer get a bit of benefit from all the risk we're taking supporting all the

01:41:41 AI companies. >> Yeah, >> I think that's also one of the things that jumped out at me as well is, you know, as a commercial VC, it's hard to

01:41:47 compete purely on capital, right? Especially in AI right now is where the numbers become so so huge. Um, I think that something I've been really excited to see from the sovereign AI fund is ex

01:41:59 exactly as James said is this kind of hands-on ops help whether it's how to navigate large data sets that the government may have access to that you know uh portfolio companies will will

01:42:09 have help navigating uh whether it be early procurement opportunities as James said and then obviously we're going back to the the a million GPU hours of compute from the supercomputer uh uh

01:42:22 which is you know a huge huge help. So you know it's it's not purely trying to convey purely on a capital basis which I think you know frankly would not play to the strengths of of what the fund can

01:42:33 do. >> So AI is extremely popular in China and India deeply unpopular in America. Where do you think the UK will land? Do you think there's a chance that uh that the

01:42:46 population broadly will uh be supportive of artificial intelligence? They're like, "AI allows me to spend more time at the pub." >> That's the way to sell it. Yeah,

01:42:57 >> that's what I'm saying. >> No, look, the UK, we've been pretty uh strong in early adopters almost of every wave of new technology, right? Whether it's financial services like, you know,

01:43:07 paying with this thing, the Brits are way ahead, earliest adopters in the world. Um, and when it comes to sort of first generation AI tools, your claudes and uh GPT, I think the UK is number one

01:43:18 or two in Europe for adoption. So, so far so good, but of course there's loads of issues. You know, I I think that um there's going to need to be some really strong political leadership to explain

01:43:28 to people the trade-offs between, you know, these things can be transformative, make your your wealth and your health and your security of your nation better off. At the same

01:43:36 time, you know, we're going to need more energy. There's a load of issues we need to navigate on online harms and copyright. Uh so, some of those battles have been fought publicly. Some of them

01:43:46 are still to come. >> Yeah. um are you you say uh that there's an opportunity for the government to be a buyer. I think a lot of people jump to defense and military. I'm more

01:43:58 interested in in if you're seeing any opportunities in non-defense sector uh opportunities for efficiency. I feel like at least in America, everyone laments like the DMV is a huge weight

01:44:11 and like if they just had, you know, a piece of software instead of a physical form, things would speed up. uh are you seeing opportunities for startups to increase efficiency across non-military

01:44:27 uh portions of the UK government? >> Oh yeah. I mean I mean everywhere. And I think um you know there's a bunch of businesses here in Europe. I'm sure there are in the US as well who are

01:44:37 using AI for you to complete procurement contracts. You know these like 400page things you have to do. So private companies have been doing that in response. You know, the UK government at

01:44:46 least is already smartly using AI to read them as well and prioritize them, right? They don't make any decisions, but they help you help you navigate some of these processes. Same thing in in

01:44:56 transcription and voice. Like obviously, we're already seeing GPS and doctors benefit hugely from being able to use these tools to quickly take notes and actually look at the patient rather than

01:45:08 spend all their time sitting in front of the computer filling out the uh the health record. So, look, there's been some early wins and I think uh you know, part of the job at Sovereign AI is to

01:45:18 work out which are the companies we should work with uh and the government to to see where else those wins are. >> Yeah, that makes a lot of sense. Jordy, >> super smart. I hope that you can work

01:45:27 out like on the cap table to just say the United Kingdom because like I feel like as a founder, if you just see your country on your cap table, you're like, well, I got to I got to I got to

01:45:37 >> got to deliver. >> I got to deliver. >> I got to deliver. But very cool. Yeah, >> the the country is lucky to have you

01:45:45 both um you know leading this effort. >> Well, thank you so much for taking the time to stop by. Have a good rest of your day and we'll talk to you soon. >> Goodbye, guys.

01:45:54 >> Bye, guys. >> Bye. >> Uh there's some uh huge news in the world of robotics because they made a slot machine that can follow you across

01:46:05 the casino floor. We we actually got a >> a slot machine stalker before a humanoid demo. >> Yeah, this is before >> I guess not demo.

01:46:17 >> Well, this is before it can actually fold your laundry. Like we've been seeing a lot of laundry folding demos. We got the slot machine. Never ask a woman her age, a man his

01:46:26 salary or a humanoid robot founder to let you be alone with the robot for 30 seconds. >> Okay, but what is actually happening here? Because obviously like the joke is

01:46:37 that uh it will follow you around so that you never stop gambling. But that can't be why they actually built this. It must be because they want to be able to reconfigure the layout easier.

01:46:50 >> It's probably that but also the novelty. >> Okay. >> Oh, if you see something moving around >> if you're walking through, >> you'll be like, I got to chase that down

01:46:58 and and throw. >> Oh, that's funny. Robot slot machine. This also looks like I don't know what Novatic is, but this does not look like it's uh this does not look like it's at

01:47:08 at an actual casino. This looks like it's at a trade show for casino equipment, which I think might be this is a demo of something that this company is going to try and sell to casinos. I

01:47:19 don't know that this is actually at a major casino just yet, although people are walking around. But it looks like it looks like trade show bags to me. I don't know. This says trade show all

01:47:27 over it. Um, I do wonder if this is being teaoperated or if this is endto-end machine learning. I need to know I need to know the tech stack and I need to know is this is this truly is

01:47:39 this truly autonomous or is this just being puppeteered by uh an Xbox controller because >> we got to get one for the studio. >> We've had we we've had this is not this

01:47:48 this could be just a remote a remote controlled car which has existed since like what the 80s maybe maybe longer. Uh, but we're in this we're in this phase where we want to layer on, oh,

01:48:00 this is AGI. This is this is truly AGI. Uh, what else is going on in the timeline, Jordy? Anything else? Uh, um, the must have item in Silicon Valley is a $178 sweater with a CEO's face.

01:48:14 Leaders from companies from Nvidia to Palanteer are now driving fashion, signaling a new era of the cult of the founder. We saw Nick on our team rocking the Jensen sweater uh from GTC. It looks

01:48:26 great. >> Uh this is a very beautiful sweater. Great. Uh very funny, very silly and uh and just a nice departure from just a normal t-shirt. You know, for for what,

01:48:35 20, 30 years, the tech uh the tech merch was just a t-shirt with a logo on it. That's fine, but why not mix it up? Why not go in a different direction and make a sweater with the CEO's full full

01:48:48 cartoon character on it? Why not? >> Uh Dolly Bali says uh is showing a screenshot from I believe is biz bis by sell of a laundromat which is selling uh it's got 421,000

01:49:04 of EBIT asking just under 3 million. So getting a better multiple for your laundromat than most >> than most public SAS companies out there right now. And it was established in

01:49:16 2024. >> Wow. So, they just made this business in a couple years >> lifestyle business >> and they're like, I would like $3

01:49:23 million for it now. >> Okay, couple more posts. Uh, John Fio, friend of the show, says, "The sphere is probably the most important piece of architecture in the last hundred years."

01:49:32 It's a hot take. It's what the VR trade was trying to be, but manifested in the real world with a real novel experience. Instead, it's what Apple and Meta were trying to go after, but failed because

01:49:43 they tried to shove it into a scalable box instead of building for real life. A sphere in every major city will be a proprietary technology for a new kind of stadium. It will suck in only the best

01:49:53 acts and they'll stop playing regular stadiums. It's the perfect example of mixing real novel tech with real novel life. This is how you capture value over the next cycle. And I agree with this. I

01:50:03 think this is a great take. So, uh >> if you rewind a year ago, you're like companies are going to announce hundreds and hundreds and hundreds of billions of Nvidia orders.

01:50:15 Do you want to? Meanwhile, we have the sphere. Yeah. Which they built the sphere. >> It's It's one concert venue. >> They built a They built a really cool

01:50:23 concert venue in Vegas. >> They got a bunch of debt, >> but it's awesome. Which one do you Which one do you want to own? Nidere. And of course on Nvidia, you were you were

01:50:33 still up, you know, 100% over the last 12 months, but if you had bought the sphere, you were up 442%. >> Yeah. Did very well. I I made a whole YouTube video about the sphere two years

01:50:44 ago and was pretty bullish on it. Uh had dug into the founder and how it got built and uh it was just a fascinating fascinating story. Um but I think uh he's right that uh that there will be a

01:50:56 sphere in every major city. There is technically a sphere like uh location in Los Angeles over by Sofi Stadium. It's not technically a full sphere with LEDs on the outside, but it has a big screen

01:51:09 and you can go and watch a football game there. And I think it's doing well as well. I haven't dug into that one nearly as much, but I do think that uh these types of like immersive experiences. Uh

01:51:19 the sphere is unique because it grabs uh attention from all over the world. You fly by on a plane, you just see it and you see the emoji on it. >> It's kind of a miss that we've never

01:51:28 done anything with the sphere. >> No. >> Uh last a little white pill here. What's up? >> Meta announced level up, a free 4-week

01:51:36 training program that takes people with no prior experience and prepares them to work as fiber technicians on data center construction sites across the US. We built this program with CBRE because the

01:51:46 fiber technician field and the broader construction industry is facing a nationwide shortage at a time when data center demand is higher than ever. And uh I'm sure people will come up with

01:51:56 reasons why this is bad actually. But uh I think this is I think this is great. It's a great opportunity. and Tyler. Uh uh we didn't get a chance to talk with you about uh with talk with you about

01:52:08 this before the show, but you're actually going to be going through the program um starting tomorrow. We got you a slot. >> Fantastic.

01:52:14 >> And uh so get >> This actually seems fun. I would be interested in doing this. >> It's data center. They made data center simulator in real life.

01:52:20 >> They made data center simulator in real life. >> That's amazing. Uh Tyler, do you ever play Elden Ring? >> No.

01:52:28 >> No. Oh, it's such a good game. >> More like online games. more on Elden Ring can be online. >> Okay. I don't >> you can play with people. Uh they're

01:52:35 making a movie about it. The live action adaptation of Elden Ring produced by A24 in partnership with Bandai Namco and filmed for IMAX is slated for release March 3rd, 2028. Wow, that's a long ways

01:52:47 away. Uh production will begin in spring. Uh but uh if you haven't played Elden Ring, it's a fun time. It's really really hard and uh sometimes it just gets like a little bit too much, but uh

01:52:57 it's a good time. Anyway, >> well folks, >> thank you for tuning in. We will be. >> It's been an honor and a privilege. >> Leave us five stars on Apple podcast and

01:53:04 Spotify. Sign up for our newsletter at tvpn.com. And flashbang out. We'll see you later. >> There we go. Flashbang. >> Throwing flashbang.

01:53:11 >> We love you. >> Goodbye.

视频链接：[https://www.youtube.com/watch?v=qrxQikecJL0&list=WL&index=4&pp=iAQBsAgC](https://www.youtube.com/watch?v=qrxQikecJL0&list=WL&index=4&pp=iAQBsAgC)
视频发布时间：2026-04-20
频道名：20VC with Harry Stebbings

## 转录内容

00:00 I would still be probably loading up on all of the Frontier rounds. These numbers could continue to get much larger. >> Now, I think Aaron Levy is one of the

00:07 luminaries on AI pervading enterprise. And he did a viral tweet the other night and I said, "Dude, we've got to do a show on this." So, this is specifically on how AI will impact the biggest

00:18 enterprises in the world, how agents will be introduced into the largest enterprises. And we couldn't have anyone better than Aaron, founder and CEO of Vox, one of the public companies of the

00:28 last decade. This is an incredible discussion. >> What we are in is a commercial and economic race. We haven't removed humans from the loop. We've just changed where

00:35 they enter the loop. Everybody is so myopic about this. I want to just like shake the industry. There are going to be more lawyers in the next 5 years than we have today. The workflow needs to be

00:44 redesigned for agents, not for people. The budget of tokens will have to move out of it spend and into regular OPEX spend. Is your job harder than ever? >> Yes. If you're in software or

00:55 infrastructure or building agents, it's a year of complete unrelenting execution. Ready to go. >> Aaron, dude, it's so lovely to have you on the show. You know that we have Rory

01:16 on every week and he's just like Aaron is the greatest. I'm not going to do his accent because I suck at them, but he's like the greatest. You can't you can't easily do an Irish accent.

01:25 >> Well, you know, I I can't really do the Irish accent so well, but that's right. Exactly. Uh but you basically, I'm sure, bought Rory one of his houses. So, no wonder he's grateful. Uh but

01:36 >> we we Rory uh we got more out of Rory than he got out of us. So, uh >> exceptional man. But I wanted to start and we were just chatting. I was running around the pot listening to the Dwark

01:47 and Jensen episode and I was like, I don't think Jensen came out very well. Do you agree with me that Jansen didn't come out very well from that episode? >> Um, I I think this is like the greatest

01:58 roarshack test of all time of of where uh where where somebody is mentally on AI. Um I if I so I happened to see a bunch of the tweets before I watched it and so I was a little bit obviously

02:10 biased in advance but if I hadn't seen any of the commentary and I had just watched it um I would have been very confused by the by the commentary post uh you know post uh interview and and um

02:22 to be clear I kind of jumped to the more uh salacious part of of you know China and that topic but I'm I'm almost probably 80% with Jensen um and um and I I my my my sort of uh kind of way of

02:38 thinking through the logic actually works much closer to uh to Jensen. Um you know the idea that we're in some kind of you know kind of race existential race where a month or two of

02:49 advantage is going to you know change the total outcome of of AI progress and and what everybody does between us and China. I I just don't agree with. I think what we are in is a commercial and

03:00 economic race obviously with safety you know built into that. There's no question. Um, and I think we actually have a lot more power globally uh if it's our technology stack that's

03:10 powering AI. And so I I I kind of am more in the camp of of Jensen on on his lines of logic. And you know, Doresh kind of oversimplified a few a few components. You know, he said, well, you

03:21 know, with Mythos, if if we get early access to that, then we can go and upgrade all of our systems. And you know with with again great respect to Dores Cesh it's like it's like upgrading

03:31 software is a multi-year effort. So unless they somehow keep Mythos you know closed for the next decade there's not like some magical moment where you can just secure everything. This is an

03:42 ongoing endless you know till the end of time. You're always in this sort of leaprogging you know between the defensive side and the offensive side. Um and so I just don't think these

03:52 things are as binary. And so I I actually more am inclined to uh to to Jensen's view of that. And then Jensen had a really key point that was didn't go viral yet. So maybe you could kick it

04:03 off, but he had this little small vignette about 90 seconds in the whole conversation where he said, you know, we're going to do ourselves a disservice if we scare people out of engineering,

04:12 if we scare people out of radiology, if we scare people out of healthcare because they think all these jobs are going to get eliminated with AI. That is not helping us. uh that is that is uh

04:21 it's doing a disservice to the next generation. It's doing a disservice to society as a whole. Like we we don't yet know any way to use AI in a capacity other than augmenting our work where we

04:33 still eventually have to go and review the work in some in some form. Maybe you don't have to review the tiny little parts of it anymore. You can review a bigger you know part of the of of the of

04:44 the you know work product that happens. But um but we haven't removed humans from the loop. we've just changed where they enter the loop. Um and uh and I think that that Jensen has a more

04:54 pragmatic view of of the technology. We should be, you know, very thoughtful about how we make these systems safe, but I much more land in Jensen's camp uh on the overall kind of contours of the

05:04 debate. >> Oh Jesus, dude. You didn't leave me. You didn't quite Okay. first a disservice by discouraging people to go into categories like

05:16 radiology or engineering. Do you think you will have more engineers at box in 5 years time? >> Uh we will and and I think the part that everybody misses is that they everybody

05:27 is so myopic about this I want to just like shake the industry. We are we are so myopic and and self-interested and and we think that the entire industry is the tech industry and when you go around

05:39 the country or world and you go and talk to a tractor company and a bank and a pharma company and you ask them do you think you have enough engineers to go and automate what is going to happen in

05:49 your industry going forward they absolutely unequivocally universally always say no and so what what the breakthroughs of cloud code or codeex or others are are doing is it's making it

05:59 so those companies companies now can actually do the same kind of engineering that Silicon Valley has been able to do. And so we are myopic because we think that that tech is the only use of of

06:09 engineers and tech is only I don't know what the right number is 8 10 12 15% of of GDP in the economy. What happens when 85% of the economy now gets access to engineering like tech has always had?

06:22 That is what will happen. That and and so yes, maybe if you're graduating, you know, name your computer science school today, you don't go immediately to Google. You go to literally John Deere

06:32 or Caterpillar or Eli Liy, but the skills that you have are going to be just as relevant in just a different domain. You're not going to be building a little app with little buttons. You're

06:41 going to be automating pharmaceutical research. You're going to be doing AI for the future of of of, you know, farming and industrial equipment. So, we're just too myopic about about how

06:51 this works. And um and and you know uh uh you can already start to see this sort of playing out. There was a really funny FT article which is lawyers are being inundated by all of these kind of

07:03 AI responses that they're now getting from their clients saying, "Hey, can you review this contract or can you review this memo or can you look at this this case?" Well, guess what happens when

07:12 everybody thinks that they're a lawyer? Do you know what the ultimate constraint is? the ultimate constraint is the actual number of lawyers that that actually are able to go and review all

07:21 of this stuff being produced. So like I would take the other side. I'd rather I like like there are going to be more lawyers in the next 5 years than we have today because we've made it easy to

07:31 generate legal content. But it has not gotten any easier to actually get any of that approved by any court system or file a patent or any of the things that law actually ends up relating to. So

07:42 these are again this is where I I I just differ from the rest of the industry. >> Do you really think so? With the greatest of respect we are seeing the eradication of kind of lower ranking

07:52 legal positions >> and that that is a different issue which is how do you do the next generation of mentorship and apprenticeship when AI does automate the maybe u traditional

08:03 tasks that those workers are doing. big question, a big question facing every bank in the world, every law firm in the world, anybody who had a sort of an apprenticeship model. I don't doubt that

08:14 that's a real issue, but that's different from the constraints that that all of this work ends up resulting in that you still have not been able to automate. We had a customer conversation

08:23 two weeks ago and and and this is just going to sit with me forever. I'm going to always have this example. They've automated or they're working on automating patient referrals when you

08:31 know when you want to go and see the radiologist or the the high-end doctor for whatever issue you have. They're automating that which is awesome. So now you don't have to be on the phone for

08:39 you know a week or whatever. Well guess what you can automate anything but if it still is 18 months out before an appointment is available. What what your ultimate constraint is still the

08:48 healthcare institution and the amount of doctors we have and actually the amount of of of real labor we have across those organizations. So yes, maybe maybe you you don't want to, you know, stake your

09:00 career on being a frontline, you know, customer ser in healthcare right now, but but first of all, that same person will have a lot of other types of jobs that they'll have access to. Um, but you

09:11 still will end up having all of these other constraints that that that eventually we will need to produce more and more jobs to go and resolve. So automation is going to actually just

09:19 force us to see the next set of bottlenecks that are in all of these industries that we didn't perceive that we had before because everything was so slow and manual.

09:27 >> What job title does not exist today that will be incredibly prominent in 5 years time? >> Yeah. So I'm workshopping and and a bunch of people are doing this. So this

09:38 is like not my invention, but I'm I'm workshopping. >> Aaron, you you've got to take attribution as a venture investor. It's all about coining a term. Okay. This was

09:46 your original thought in the shower. Aaron Lavies, share it with me. >> I've been influenced by nothing I've seen online. Uh, this is all from me. Um, so there's some kind of and and who

09:58 knows if this sustains as as a full-time role or where it gets diffused into. I'm not I'm not uh I'm not 100% clear on that, but there is 100% a role right now that there's going to be

10:10 500,000 a million jobs created for and and it's basically some kind of agent operator and and this person is um is actually going to be needing to be uh somewhat technical. They're going to

10:24 have to like be deep in the AI world. They're going to have to understand MCPs and CLIs and they're going to have to know how to write skills. They're going to have to understand agents.mmd files.

10:35 The it's going to be this group of people that will know how to go into your marketing team or your legal team or your operations team or your life sciences research team and and this is

10:46 the person that is basically going to enable that function to get leverage from agents. And um and the problem that the real world has that startups and and frankly many of your guests don't

10:57 understand is that is that when when you start a company from scratch, you've got like you know the world is your oyster, right? You can design your workflows however you want. There's really no risk

11:07 if you if something goes wrong because you don't have much scale to begin with. There's no real regulator that that is sort of calling on you to say, hey, you know, are you doing things the right

11:15 way? It's it's it's effectively infinite upside in whites space. when you go into a a you know a Fortune 1000 pharma company or bank or or you know consultancy um that doesn't that's just

11:26 not the case right these guys have they're regulated they have data fragmented across their organization they have employees that are that are sort of wired to do workflows a

11:35 particular way so there needs to be somebody that can basically say hey if we actually want to get real leverage from automation we need to start to redesign the workflow that we're doing

11:43 and the workflow needs to be redesigned for agents not for people and so So what do you do when you when you reimagine a business process where the agent is now doing much more of the work than than

11:55 what you know than what the human used to do in that process. And that just means it's a it's a very different sort of implementation cycle. It's there's real change management. You've got to

12:05 get data organized in the right way. You've got to connect up systems in the right way. Guess what? The second a new model drops your workflow probably breaks. Um because the way you prompt

12:15 that agent now is different. there's a different way that that it wants its syntax to be to be handled. So that it just requires care and feeding and and and a real level of kind of technical

12:25 and business process acumen. Uh so I think we're going to create you know an untold amount of jobs that look like that. Some of those people will come from it. Some of those people will come

12:34 from operations. Some of them will come from engineering. uh if you're in a maybe more technically inclined company where it's like the next generation of if you know there's a a limit to again

12:43 the number of software you need to build that looks like an app on your phone there's an unlimited amount of software you need to build that looks like a background system process that's

12:52 connecting different data sources automating workflows that's where the the work is going to go well this was really going to be one of my main questions which is you know Jensen very

13:00 clearly said AI won't kill software it will explode the amount of software needed and when I thought about that you know the thesis is obviously kind of you have this kind of core AI that crawls

13:10 over 15 SAS tools and they really become databases that agents crawl on top of. Is that what it looks like? And are they not just valueless SAS tools then? >> Yeah, I mean I I think that that I'm I'm

13:23 sympathetic to that argument in some in some categories. I think there's some software where because the person was the user of the of the software and they were clicking all the buttons that your

13:34 sort of ratio of buttons to underlying APIs was like more in favor of buttons. And I'm I'm oversimplifying, but there there are some tools where you open it up and there's like 93 features um that

13:44 you're kind of clicking around on and the and the user has been so accustomed to exactly how to do that that the that the software's value proposition was correlated to to roughly that that sort

13:54 of mass in a world of APIs and a world of agents being able to do more of the of the work that you used to do on clicking those buttons then then again the value goes more to the API layer. So

14:05 then the question is how many APIs do you have? Not not in like a you just need a thousand APIs, but like like how robust and useful and and proprietary and how much business logic is embedded

14:16 in those APIs versus it's just calling a database and pulling a record like does the API surround a a a set of business logic of like no it actually secures the data or it knows exactly what person

14:28 each piece of attribute should have access to inside the organization. That's you know at the end of the day all software has a database behind it. So you could oversimplify it and be

14:37 quite reductive to that. But there's a lot of business logic in the layer above the database that that software players have. Like if you're an ERP system, you know, you're way more than a database at

14:46 this point because you've written a tremendous amount of business logic of how your supply chain should be automated and work and how you should do accounting. None of that goes away. So

14:54 then the question is what changes is the user interface that the either the user or the workflow is interacting with. The user interface might be now you're just chatting with an agent. I think

15:03 increasingly the right way to do this is there's some kind of agent in the background that's connecting multiple systems. So you're you're not even like the user is maybe not even seeing half

15:11 the value that's happening, but the agent is sort of working across an ERP system, a CRM system, an HR system, a you know a document repository and then doing work across those systems, which

15:22 means that the value proposition has to be how good are your APIs, how well-designed are they, are they ready for agents, and then can you monetize that in some way that makes sense? and

15:31 and we we are treating software too too much like one gigantic sort of of monolithic industry and you know it'd probably be better to have some kind of 2x two which is like how much business

15:44 logic is there how much sort of human to agent you know collaboration does there need to be and and like so the reason I bring that up is the moment you have human and agent collaboration you need

15:55 some kind of you know usually you need something that the user can pop into to to experience the work that the agent did and and that probably doesn't go away so much. Um uh and then and then

16:04 you know when more agents are working on the software which parts of software do the agents need those APIs even more than humans ever did and I think there's a lot of categories of software where

16:13 actually agents using the tools is a massive boon for the technology as opposed to a dilemma. >> Where will agents use the tools more than humans do and those API calls

16:24 become much more frequent? >> Yeah, I mean an easy one is just unstructured data. You know, agents are going to be this incredible consumer and creator of your unstructured data.

16:33 They're going to read through every one of your contracts and generate all of your contracts. They're going to generate marketing assets. They're going to write reports for you. And so, when

16:42 it becomes trivially easy for you to generate all this new information or have agents review it all, well, guess what? You still need a backbone that kind of manages and coordinates and

16:50 creates the guard rails of those workflows and and all the agents doing that work. So we're about to see an explosion of unstructured data as an example.

16:58 >> With the greatest of respect, Aaron, can I just interject? >> 100%. >> Does that increase the value of your business? When I think about that, I I

17:05 asked Aaron from Monday, if you become, you know, a data repository which agents crawl on top of, >> how do you retain value in that? I would ask the same to you with respect

17:15 >> 100%. It's it's the question on the mind of every investor on the planet right now. So we're we're used to it and it's not a it's not it's not a scary question. Um, one thing that that helps

17:25 us is we've always had a a a an API sort of maybe not first but equal strategy. Um, uh, if if I told you the number of API calls we did last year, you'd and or you guessed first, you'd probably be off

17:37 by an order of magnitude. Um, uh, so so the volume of of API usage on our system is already enormous and already, you know, is outsized relative to any of the enduser interactions on the system. Um

17:49 and that's just a virtue of you use content in a variety of applications and workflows that that you know far exceed what what people you know kind of you know open up their finder and and upload

17:59 a document into like like an ERP system generates files. A a wealth management portal you have clients uploading documents into the portal and they never see box. Um you have workflows of

18:09 invoice processing that's happening behind the scenes. So the headless version of box has been alive and well for you know almost since the day we started the company. And so agents to me

18:18 just again represent a force multiplier on that. So it's not a it's it's it's actually an exciting proposition for us. We already know how to monetize it. The question is like will the exact dollar

18:28 and cents be the same between an agent user and a previous application user. We don't know. But we do know that if the number goes up by 100x or a thousandx that that's actually more opportunity

18:37 for us in the future. Now that's not all the same for all software providers. for where we sit in the workflow where you just you generate a document it needs to go somewhere you have to secure that you

18:48 have to protect it um you have to govern it over the long run that's just more data going into our platform and uh and that's you know so that's why it's just all upside for us

18:57 >> you said secure and protect it we mentioned our mutual love for Rory O'Driscoll I do a show with Rory and Jason every week Jason has bluntly said that this will be the golden age for

19:06 cyber security because the security threats are going through the roof are you concerned with the system vulnerabilities and the security threats that are coming with AI and what do we

19:16 not know about security that we should know. >> I am concerned but not uh in any kind of like new concerned sense. Uh this this to me was kind of priced in the moment

19:26 that we were generating code with AI. So if you can generate code you have two problems. One you're going to generate way more code than anybody's ability to review that code. So, you know, starting

19:37 with GitHub Copilot six years ago or whatever the date was five years ago, like that was just priced in which is which is as soon as as AI writes most of the code or and then like 90% of the

19:48 code and then 95% of the code then by volume we're just going to produce this unbelievable amount of code and and any you know any change in a system uh you know everybody kind of thinks about

19:59 security as like um you know is there a zero day where there was an unpatched you know component of your technology. ology or somebody found a clever new packet uh package that that that you

20:10 could kind of slip into. Uh every time you you ship a new feature, you have a chance of a security vulnerability because the the AI could have written in, oh, you know, we want to actually

20:20 open up that port in in the system because we need to do something and maybe that was the wrong decision for the agent to go and do. So, so we're going to be living in this new world of

20:30 of cyber risk uh in the form of of using agents more and then on the other side obviously if you have the offensive side able to use AI probably more in the form of open models and and whatnot then they

20:43 can find more vulnerabilities because they can scan across the internet far faster than before. So you actually have two new forms of risk in the development process and you only have one benefit

20:52 which is agents can also review the code and and try and keep it secure. So, so it's it's it's going to be a a very dynamic um uh you know, period. I I think you know, for better or worse,

21:02 agents are the solution to the problem that agents have caused and um and and that's why there's going to be a lot of money made in agentic security uh as well.

21:12 >> You said agents are the solution um to the problem that agents have caused. It almost reminded me of when Yansen went on TV and was like, "Oh, every engineer should be spending I can't remember the

21:22 amount. I think it was either 250 or 500,000." >> Yeah. or like half the salary essentially. >> Yeah. Yeah. And it's kind of like, you

21:28 know, drug dealer, you should buy drugs. Well, okay. No [ __ ] Uh >> I again I'm I'm you know obviously Jen I mean listen we love Jensen for that level of of uh of you know grandiosity

21:40 and and charisma. So I I actually I but you know whether he's off by half or not. I mean directionally the idea is actually pretty salient which is which is you're going to be spending more on

21:51 compute per person in the future than than you ever thought. and that you certainly are today. >> What percentage of salary are you going to spend on compute in box in five

22:00 years? >> Uh great great question. Uh I don't think we've modeled that out in in five years and obviously the joy of being public.

22:08 >> Well, this is your chance. >> No, no, totally. I you know I was told not to model long-term financial projections on podcasts. So, um so let me let me Yeah, it's a weird SEC

22:17 financial thing. >> So boring. >> Don't ever go public if you don't want to model on uh on podcasts. out. This is why the Collisons don't. Everything else

22:26 is great. They just didn't podcast. Yeah. Cheeky P. >> I don't know if you I don't know if you'd be able to pin Patrick or John on the same question for their five-year

22:34 view, but but you know, it'll be a larger number for sure than it is today. So, >> I'll smash them with four tequilas and then ask them. Um, you said one of your

22:42 observations in your very viral tweet uh was about token maxing and kind of token allocations within enterprises. I'm really intrigued. How do you think about advising CIOS on token allocation? token

22:53 maxing. What we should know that we don't know. Yeah. How do you think about that? >> This one's tough. It's it's it's you know, the the general advice will end up

23:02 sounding kind of like um uh you know, kind of generic by definition. Um it you know, usually I mean it's going to have it's going to have something to do with with your tokens will have to correlate

23:13 to where there is the most amount of you know, value generated for your company. Like like most bland statement of all time, but just obviously has to be true. So in the software industry, we're into

23:23 token maxing because guess what? Like generally the value proposition of your company will correlate to how much software can you produce. And so so you know if you're trying to drive a lot of

23:32 change and you want to make sure everybody's shipping lots of soft software and you want to be able to teach the best practices faster, then token maxing and leaderboards are an

23:40 interesting way to do that. I you know it's not obvious that you're going to see that across every industry. Um uh we've we've seen a couple of interesting examples. One company had this sort of

23:49 like Shark Tank pitchathon type thing which is you know teams have to show up and they have to go pitch for for compute you know token budget and then you kind of allocate it in some central

23:58 fashion like a VC would and then you sort of you know I don't know their exact interval but I would imagine you review that 3 months 6 months in being like okay did you get the upside that

24:07 you thought on on that token usage. So that that's an interesting one. I think you have a another company had a kind of a view of like you know it's it's some kind of like natural stratification of

24:20 you know 5% of your users are doing the most valuable things 20% are doing the next tier of most valuable things and then everybody else is sort of doing general productivity I'm making up their

24:30 numbers but but the idea would then be like well for that five or 10% give them the the best models with unlimited capacity for the next 20% have some have some limits maybe it's a a little bit

24:41 more efficient of a model and for everybody else it's sort of like we're going to just use the cheapest thing on the market. It's it's not going to be like the game changer of the employee

24:49 productivity. Um and so I think everybody's kind of working their way through this. the the part that that back to Silicon Valley's again kind of you know sometimes more um uh you know

25:02 let's just say like like positively naive view is is like real world they have like budgets and they have like annual budget planning cycles because they have EPS numbers they they commit

25:11 to Wall Street and so you don't get to just be like oh we're going to token max across the enterprise where everybody gets unlimited token budgets because obviously then that company would just

25:20 miss their their earnings throughout the year. So you have to like wait for the earnings. You have to wait for the budget cycle. You have to figure out what teams you know make are are most

25:28 interested and and have the best use cases. That's a that's a natural journey. One final bookmark one final one final bookmark um that that I think is is well understood now at this point

25:38 is the budget of tokens will have to move out of it spend and into regular kind of opex spend. this can't be treated like a oh, you know, I'm going to trade off between Salesforce licenses

25:50 or or or compute tokens like like it's going to more be I'm going to trade off, you know, this next marketing campaign uh and and instead I'm going to go and drive more automation in our in our

26:01 marketing engine. Like it's it's going to be that kind of of set of trade-offs. >> What happens to that token budget when it transitions to that different spend category? Um well first of all it goes

26:11 up because because no well because it spend as a percentage of revenue of of large enterprises is is >> but is this the same as the kind of classic VC blog post which every [ __ ]

26:21 firm has written which is like you know AI it's moving from software budgets to labor budgets and every partner goes and likes the tweet and there's like no [ __ ] [ __ ] like really.

26:34 >> Yeah. Uh I mean if you do it in that voice it sounds it sounds kind of like um you know maybe uh you know simple but like yeah that that but like that's just like a very big deal in technology.

26:43 We've never had there's never slash rarely been a technology that you could sell into an enterprise where you weren't capped by that company's corporate IT budget. And so now for the

26:53 first time ever, you have a technology where you can go into the line of business and you can say, I can now offer you a a a new tool in the form of an agent that will augment a workflow

27:04 that will make you 50% or 100% more productive. And so maybe I should be able to get 5% of your opex budget this year to go and do that. Like that that is a new budget to tap into. And I don't

27:16 think it like you know 10xes the size of of IT spend or or technology spend globally but it certainly doubles it. >> I mean current enterprise technology spend is estimated between 10 and 12%.

27:26 To see that going to like 20% as you said there is like I think relatively feasible. You said about kind of companies being like based on earnings per share and actually having budgets

27:35 that they have to adhere to. Very strange not to have venture funded companies. >> Yeah. They don't have a limited VC to go and solve this.

27:41 >> Can't we just go to our venture investor and ask for more money? Um, the one thing that I worry about is we see this insane demand side pull. Every company in the world needs an AI story. Everyone

27:51 wants to kick the tires with something. And I think we project the same demand side pull and extrapolate it continuously. Do you worry that we are in a momentary 18-month period on the

28:03 demand side pull and that may not always be lasting? >> You know, it's very possible I should be more sensitive to that. Um uh but uh I I I would take the opposite side of of of

28:16 that particular wager at the moment because um partly because we I already saw one diffusion cycle with cloud and actually how long that ended up taking and the and and the the the kind of

28:28 spiky early nature you would have just been like oh my god this is this is on fire it's it's and how could this last and 20 years later it lasted and got way bigger than we ever realized if it

28:40 works. The market's always larger than you ever think. And um and then the only the only part why why 18 months is like not even a relevant window to me is I think diffusion is going to take longer

28:49 than Silicon Valley thinks. And it's back to the very first kind of that new role idea. When you go to most companies, they can't yet just deploy an agent to do you know full uh you know

29:00 financial proposals for all of their their clients without a human reviewing the thing. And because the SEC will just show up and be like, "Hey, like you you just you just gave this person bad

29:11 financial advice and you're going to lose your license." Like that that will just start to happen kind of across the board. And so um and and so that that's why, you know, people take time. That's

29:21 why we we we there's a lot of regulatory controls and compliance teams, security teams have to figure this out. That just takes time in the economy. >> I I had I think Matt Fitz Fitzpatrick

29:31 from Invisible, which is like a cheuring or a Mccor competitor. Okay. And >> he said you cannot sell into enterprise without an FD model. It is impossible. >> I mean it rounds to being true. So

29:43 >> yeah, >> super interesting to hear that because we're seeing like the rise of oh we go PLG and then we like seep up into enterprise.

29:51 >> Well I I I don't sorry I wouldn't I I I don't uh think of those as as mutually exclusive for what it's worth. I guess what I'm saying is when you think about adoption within the largest enterprises,

30:01 aren't AI services companies the best positioned companies of the next 5 years? >> As in you're saying like traditional professional services?

30:10 >> Yeah, I'm saying Accenture's AI team that come into Bank of America. >> No, 100%. These these these spaces are going to be again both bigger and more sustainable and robust than people

30:20 realize. We we are always so back to the myopic thing. We're so myopic. We're like AI will replace all of this stuff because it just does it for you. And it's like like uh I'm trying to think of

30:29 um uh you know maybe my most recent experience with the best models in the world. I probably had to go and change 15% of the thing that that that that was the output. And so and so like you just

30:42 like we're nowhere near eliminating the human from the workflow. And so in a world where you don't eliminate the human then there's a lot of like real change management of like where should

30:51 the human enter that business process? How would you want to review that that work output? How do you wire up your systems to make them effective for a for the agent and human collaboration? How

31:02 do you connect all of these data sources together? One one thing that we see is um you know, if you wanted an agent right now in a Fortune 500 company to go and and give you an answer to where is

31:16 the most risk you have in your upcoming renewals for your contracts. that agent might find 10 different systems that contain contracts in them. And half those systems will be like

31:27 legacy technologies that don't work well with the agent. They're kind of low throughput or maybe you can't even wire them up. They're on network file shares. They're in legacy document management

31:35 systems. So, first of all, half your data state is not even ready to work with the agent. The other half of the data state is probably fragmented because you have two decades of

31:44 employees bringing their own tools. And so the agent will just go and find the wrong document or the wrong contract or the wrong piece of data because you never really cared to have some kind of

31:53 standardized system for your contract because people could just always go and find what they were looking for. Agents can't do that. They I mean they'll find what they're looking for, but they'll

32:02 just as often find the wrong thing as the right thing. So they have to be targeted. They have to have that information get curated. They need to understand the context of of what is the

32:10 process that they're doing. That is like what I just described right now is 10 years of work for Accenture in every enterprise on the planet or the nextg Accenture that does this in particular

32:20 industries or workflows like we have to go upgrade your systems. We have to start to understand and organize your data in the right way. We have to start to describe these workflows to the agent

32:30 itself. We have to figure out where the human is in the process. That is just real change management that every organization will have to go through. >> We also have to have someone to blame.

32:39 >> 100%. This is why a lot of these industries last, which is like I have lawyers, not because I can't necessarily ride an NDA. It's because it's your freaking fault if anything goes wrong.

32:49 >> Yes. No, literally. And and and we don't know. We're not like like I promise you, you're not going to be able to blame Anthropic when something goes wrong. And so if you can't blame Anthropic when

32:59 something goes wrong, then then at some point it it doesn't really work to tell the comp like like to tell your customer, well that that sort of system that we set up screwed up your data or

33:11 it automated something the wrong way or create a security vulnerability because the company will just say, well, I'm never working with you again. So then you have to have some accountability in

33:18 your own organization for who is liable to when when something goes wrong. And and the moment you have to have any liability, you have to have some amount of ownership and accountability and and

33:29 and people have to have have sort of, you know, they have to roll up to somebody who has more liability and more ownership and more accountability. Like this hasn't really changed the

33:37 fundamental pattern of of human behavior and contract law and and you know, the regulatory regimes that everybody's a part of. We've just sort of given our our our computers a machine gun to go

33:50 generate way more information and work with all of our data. >> You said before when I've tried the latest model, it's got like 85% of the way there. I speak to many of the best

33:59 early stage and more mature you West Coast based companies and they say, "Hey, we use frontier models to set where we can be and then we use open-source Chinese models to get as

34:10 close as we can to that frontier benchmark." Is Silicon Valley being funded by a generation of open CCP funded open models? >> I mean that that must be kind of

34:21 empirically true. Um I uh I I I don't have the same kind of like uh oh that's so scary you know kind of element. Now obviously again holding out some some element of risk of of some some backdoor

34:34 weights that that can get triggered at some moment or some parameters but like like like I'm not I I just like that's not how I'm perceiving it. But um uh but yeah and but also that's yeah I would

34:46 say that's kind of orthogonal to my point about like the best frontier model still will go and do the wrong thing. Uh and so thus I have to be in the I have to be in the workflow loop to make sure

34:56 that I review its its work. >> You know as a vantage investor I specialize at making bold statements with little substantive evidence. Um >> it's worked for the greats. So

35:08 >> do you know what I'm just following their lead. Jason Lmin, my dear friend, says, "Why has no public company created any good agent product? Everyone creates 60% [ __ ] agents, but he's like the one

35:22 person who's done it, Palunteer, and no other public company has created a sufficiently good agent product." Why is that? >> Um, you know, I I don't know that I can

35:31 fully endorse the point, but I'll I'll I'll give you the because I I I would argue our agent is sort of the best agent for working with content. you know, this is a very fastmoving uh space

35:42 and you have to be kind of wired in at a level that that I don't think you've ever had to be wired in in tech. Um uh like I am, you know, and and the information sources aren't the classic

35:54 ones. It's not the it's not the rollup review two weeks later from your traditional news publication that is going to give you any kind of alpha. It's it's it's the practitioner who's

36:04 the you know literally the engineer at the you know agent sandbox company and their their long form article on how they are handling you know memory and the harness and you know like like like

36:19 if you're not wired into that ecosystem, it's very hard to then have your team you know be at the kind of forefront of all of what is happening. And so it just is a it's a different pattern than what

36:31 we've ever had to do. Like like you know co was was pretty crazy like we all had to kind of like hunker down and be paying attention to daily news cycles on on coy stuff. Um but it wasn't like a

36:42 tech problem like it wasn't hard technologically. Um so there's like there but there's not been a moment before where the speed of change and responsiveness you have to have is quite

36:53 literally on a multi- uh you know multiple times a week cycle. Is your job harder than ever? >> Yes. >> Because of that speed of transience of

37:02 superiority of technology. >> Yes. Uh you have you basically have this this you know component of one there's a tsunami of change that you can just feel and so you're you're like okay we got to

37:14 like run faster than ever before. And then there's a and then there's just like the pure technical underpinnings which some of it has business and strategy implications some of it has

37:23 product implications. Some of it has partner ecosystem implications. uh because of that tsunami that you have to very quickly kind of wire up what you are doing about that shift uh and and

37:34 where the market is going. Uh at the exact same time you have to also be like you know find a way to be a bridge for your customers that that you know also don't want to get you know crash into by

37:44 the tsunami and they want to be able to to be able to have a bridge into the future and so there's just you're juggling a lot right now. >> You said your agent product is the best

37:52 product. Again, Jason and Rory said this, and Rory might kill me for this because he gets a little bit more sensitive about when I quote him or misquote him more appropriately, but

38:00 like he basically says if, and this is Jason again, if you can't like charge way more for your agent product that Wall Street doesn't give a [ __ ] that you have to reacelerate revenue

38:11 with agent products, can you charge significantly more for an agent product? The the answer is yes, but but there's a little bit of nuance which is our our business model is we have a new plan

38:22 tier that we just introduced last year that basically houses our you know best workflow capabilities, our business automation, you know, uh our application development capabilities and then the

38:34 agent is sort of central to that because it's going to help you automate the work that that you're actually doing with your content. So it'll read a document and extract metadata from it. it'll

38:42 process information inside of a of a of a workflow. So that is actually causing a re reaceleration of our revenue growth. Last year we we we saw an inflection in our revenue growth. And so

38:53 that that it's already happening in our business. Um and and so we are we are doing the thing that I think Rory is is sort of probably saying is the new benchmark. Now to be fair to what's

39:03 what's happening though is I think Wall Street still is sort of saying we kind of need to just step back and see where everybody lands in this because of how much change there is. So um so this is

39:14 very much a year where if you're in software or infrastructure or building agents you just it's an ex a year of complete unrelenting execution. >> Do you look at the ticker?

39:24 >> Yeah. >> Every day. >> Yeah. But I was like a day trader. >> I've never met I've never met a public

39:33 company CEO who hasn't. The Nan CEO was on the other day and he's like multiple times a day. Multiple multiple. >> Yeah. No, 100%. I'm but like but like partly I just I have like you know ADHD

39:45 or something and so I just need like I'm like it's will we look back on this period and be like what the [ __ ] Companies trading at three times cash flow like way over exaggerated or not?

39:55 >> Well three times cash flow is is very much overexaggerated. I would say that we're in a period right now where basically the market is being treated roughly as you know in in as a kind of

40:08 indiscriminately you know kind of bucketed se sector and the next year two years or whatnot you'll start to see some separation and parsing between the companies because as

40:18 I noted in the beginning agents will be really good for some parts of software and agents will put pressure on others other other parts of software so and it'll mean some companies have to fully

40:27 pivot and some companies can just sort of ride their wave and and if they respond, you know, effectively, like clearly 3x free cash flow is is like, you know, that that seems like

40:36 aggressively low territory. But I also think that at times in software things have been aggressively overvalued um beyond the the realm of of likely what the terminal value is of of particular,

40:48 you know, category or or or company as well. So So I think we're I think there's just a pendulum that that needs to kind of find its equilibrium right now. Um and uh and that that'll play out

40:58 over the next year. >> Okay. I'm going for spicy. Uh I I interview most of the public company CEOs that you know and I know and Jason Lin said on the show if Aaron Levy is

41:08 the best which you a phenomenal No, but you're a phenomenal AI first mind and leader. Uh to just roll with me on this and because it gets worse. Sorry. And even he is struggling.

41:19 >> Wait, why am I struggling? >> Well, I mean >> I just said I'm tired. I Wall Street who I mean Wall Street does its things like we're like we're not like we're cranking

41:29 >> dude I it's Jason blame him >> but like I I do think I think that that there's a little bit >> I think this generation of CEOs that you have around you though is equipped for

41:39 the AI transformation that is ahead cuz I don't like I think I'm I'm not blowing smoke up your ass you are you're so versed in this you're so fluid but a lot are like now one said to me the

41:51 other day no we don't have the AI chops in house, we might need to bring it in. >> This one's hard. I think um I think you still have a lot of kind of founder or or tech uh you know, forward, whether

42:03 they were an engineer or just they're just very technical, you know, category of folks that are are pretty dialed in and like like I I have Slack channels and and WhatsApp groups where people on

42:14 the weekend are are just like working with Cloud Code or Codex building stuff and they're public company CEOs. So, so like like they they are clearly wired in, tapped in, they they can feel the

42:25 technology and they are not going to let their company lose. Um, you know, assuming that that as a as a category they're in a spot where where there's a lot of upside. Um, so yeah, but like

42:35 every every technology wave there's winners and losers. I don't know that the this won't be any different. Um, I and I I just think that you just have to you just have to be super dialed in and

42:45 work through it. >> Hard one before we do a quick fire. Okay. Who has the world turned their back on who you think should be much more appreciated?

42:53 >> I I don't I like you know I'll give maybe a shout out to like um Atlassian uh as an example. Um uh I I think um I think that that feels like like oversold territory. You know

43:05 >> you think 78%'s a bit harsh. >> I I think I think I think I think possibly. and uh and and you know it's in the category of I just like like what they've they've been fighting this this

43:16 narrative and I'm not going to speak too much for them but like I think what I perceive is is oh no engineering gets commoditized and so like where in the stack was was their engineering you know

43:25 revenue generation and again with my headset I'm like no there's going to be more engineers and so now does that mean that Alassian's product set will have will look exactly like it does today no

43:36 like obviously it's got to evolve and whatnot but but I think if you're like a company selling infrastructure for engineering to be more automated. Uh like that seems like a good spot to be

43:46 in and and you know I you look at what linear is doing and it's it's fantastic and it's awesome to watch. Um but I don't I think there'll be you know multiple plays in that space just given

43:55 how big the market is. Um I think right now this is a moment where you need to be deep in the workflow and you need to have data. uh you you you have to you have to have data uh in your platform

44:06 and you have to be the best place for that data to go and you have to be the best place where agents want to work with that data. That's like the mandate right now is if you are not the best

44:14 place that for that an agent would would sort of intentionally choose for working with data of that particular category or automating the workflow in that particular you know area. That's a tough

44:25 spot to be in and that that's the the job for all of us. You know, if you're building software >> and the best place where Asians want to work is defined by great API,

44:33 >> great APIs, great pricing models, um, uh, you like the the surrounding features to the API. So, if you were to say, hey, I want to be able to wire up a workflow where this is a, you know, the

44:47 box sales pitch. I want to be able to wire up a workflow where an agent is interacting with FINRA compliant documents where you when you know FINRA compliant document means the things gets

44:56 generated or seen or shared with the customer and it it can't ever be deleted and and removed you know for a certain amount of time then then on one hand the APIs have to be super clean for the

45:05 agent on the other hand you have to have a bunch of surrounding capabilities to ensure that that company can go to uh you know uh go to their regulator or auditor and say yeah we we are complying

45:14 with FINRA so that combination is what makes it though you would build that kind of agent on something like Box and that that persists across a variety of industries.

45:23 >> I'm going to do a quick fire around with you. Uh you have to go and be a public company CEO. I know. Um so what have you changed your mind on in the last 12 months most significantly?

45:33 >> I do think that that I've I've become more convinced that software is headless in the past year than I was maybe three years ago. And it's because of the the level of agentic capabilities on tool

45:47 calling and searching across systems and the accuracy of that. Uh and that that has happened faster than I I would have uh perceived. So two to three years ago, if you were to kind of, you know, wire

45:59 up an agent and tell it, hey, go work inside of Box and find a document to work with and do some process, it would it would basically almost always find the wrong document and it wouldn't be

46:09 able to handle actually like cracking open the file and reading through it. And so thus, you know, going headless wasn't sort of the the most urgent priority uh from an agentic standpoint.

46:20 And in the past year, those capabilities have just absolutely accelerated to the point where I'm fully convinced that that you just you have to be, you know, headless first as a software platform.

46:31 >> What acquisition did you not make that you wish you had made over the box journey? Jensen said in the show, "Oh, I wish we'd invest in Frontier Models." That was my big mistake. What

46:41 acquisition did you not make that you wish you had done? >> I honestly don't uh I don't think I have any M&A regrets. I actually the the the the it's the deals that I wanted to do

46:53 that that we ended up not doing that I don't regret um is probably more the the situation. So >> which one is which one is that? >> I'm not going to tell you those. But but

47:04 there are some where left to my own devices I would have done and I look back and I'm like oh thank god that there was uh there was more rational logic in the process.

47:13 >> Who is going to win the enterprise race open AI or anthropic? Oh god, that that's impossible. Back to the cloud piece, I think um you know I think it's it's totally fair to think about it as a

47:23 race and certainly if if you're in either of those companies, you have to treat it like a race because because you know like you obviously want 80% market share, not 55% market share. So like you

47:33 have to treat this as a you know we got to dominate. Uh that's exactly how they should be executing that way. Everything is going according to plan. if you compare it to other areas of compute.

47:43 Um, and I I ran this analysis recently in 2010. 2010, not like, you know, maybe you were 12, but like the rest of us, we were just like in companies doing things. Uh,

47:55 in 2010, AWS made $500 million in revenue. Azure had just launched and GP and GCP was called Google App Engine and it had a little like a turbine logo with like wings or something. So that was the

48:09 state of cloud. Fast forward to this year and it's a couple hundred billion dollar a year revenue ecosystem, right? So so in 15 years, right? So and we were in that moment being like who's going to

48:21 win AWS or Azure or GCP? What's how's this all going to play out? And it just turns out the market was so large like obviously it was due to their execution that they kept it going and kept it

48:31 large and the competition kept up, but it it just didn't really matter. Like everybody everybody kind of won. And so I I sort of think of AI in a similar fashion, which is I I can't predict if

48:42 it's going to be open AI 60% and entropic 40% or it gets flipped or I'm off by another 10% here or there. Uh but but no matter what, these markets are just fantastically large. Companies are

48:53 are going to adopt multiple of these systems. They don't want to be single vendor. Uh they don't want to be they don't want a single vendor in this stack. One service goes down or one

49:01 changes it APIs or one has a new commercial model. you're going to it's going to be a multi- vendor multi-AI world and so uh and so that that's why it's like very hard to kind of like call

49:11 it at this stage. >> What does everyone think they know about enterprise adoption with AI that they get totally wrong? uh what they think is that is that uh that the the outcomes

49:23 that you're seeing in AI coding will quickly come for other areas of knowledge work and um and that is a uh a slight misread on the other areas of knowledge work and uh and and some of it

49:37 is the idiosyncrasies of of coding and some of it is the broad you know kind of just elements of the rest of work and how it happens. If you were a venture investor today, which category would you

49:50 be most excited to invest in? Obviously, I'm just hypothetically speaking. >> I mean, I I think I would still be probably loading up on all of uh all of

49:58 the the hyp uh the frontier rounds. Uh it's like these numbers could could continue to get much larger and um and then I think that the >> could they get I mean much larger. I

50:09 mean like this is where in my at 850 billion you've got like a 3x to like a 2.1 trillion style with dition for >> you know I always think it's hard because um I I I kind of have said that

50:21 on the way up of many companies like like like no just like >> I did it with crypto like how much further can it go? It's like >> yeah well well that one I'm going to put

50:31 in a different category cuz that's that can just sort of be me'd. Um I I >> actually No, but I actually think but like I think to the point on Atlassian and bluntly you and your whole category

50:42 is the casinoization of the stock markets which is like if you're a momentum trader today, you still buy Palunteer because the market's a casino right now.

50:53 >> Yeah. Well, to to be a little bit more fair, um I think you have some one-off companies that have done, you know, amazing job capturing the zeitgeist on that. I do think you have I I think I

51:05 think the broad story right now is the sector rotation story which is which is sort of hey this AI thing is happening right now I can get a higher return if I if I get closer to the semi stack and

51:16 the and and the kind of you know where the workloads are going and where the data center buildout is happening and I get less of a return if if I'm in software you know with with kind of pure

51:25 licensing and so I think that that is probably more of the color of of what we're seeing now some of the some of the data center and infra, you know, names maybe have been nemified also. And so

51:37 that's kind of helping the case. Um, but it's just a it's just a really weird time, you know, overall. Uh, that that's, you know, hard to hard to think through.

51:44 >> So, you would not buy Allirds as an AI company. >> I mean, maybe you would because of that exact point. So, I think you'll have that will be in the kind of one-off

51:52 category. So, New Bird AI or whatever it it's called. Um, but but I think um, no, I I am still I I hear this is a generic statement. there will still be a lot of money to be made in the companies that

52:03 can take the innovation that we're seeing in Silicon Valley and in the labs and apply it to the real world you know work that happens inside of enterprises and whether that looks like vertical AI

52:14 whether that looks like you know the new kinds of tooling that that companies will need um there's a you know company and a new category emerging on on uh like agent observability and evaluations

52:26 I'll give a shout out to Brain Trust as an example not an investor um where I can just kind of sit back and be like, "Shit, like we thought that that agent builders were going to need eval." So

52:37 that's like a Silicon Valley TAM. And then I'm like, "Oh, actually everybody on the entire planet if you're putting agents into an enterprise workflow needs evals because you need to know if all of

52:47 a sudden your agent just stopped producing, you know, like like uh you know, loan origination documents the right way." And so I, you know, that's a category where, you know, it's probably

52:58 not going to be owned by one of the labs. You kind of want it to work across all the labs. It's it's it's, you know, it's a very relevant kind of new form of of of infrastructure for an agentic

53:09 enterprise. I think you're going to see a dozen, two dozen, five dozen of things like that that that start to emerge. >> I've known you for a while now and you put up with me for multiple different

53:18 sessions. Uh, so I want to finish on something a bit off script, but you're a phenomenal CEO. You're a public company CEO. The pressure that you have on you is intense. You're also like married and

53:30 have a great relationship. Biggest advice on marriage when it's super I'm being serious. When it's super stressful, it's hard and you also have to show up and be a great husband.

53:40 What's the advice on marriage? >> Uh it feels dangerous if I actually acknowledge the great husband uh piece and other other parts that were embedded in that. Um that that feels like you

53:49 need like a full 360 eval. I I will uh I'll just say from my perspective and I'm very lucky to have an amazing wife and and family and you know you you are you're in a grind in one of these roles

54:01 and um and so obviously having a a strong support base um uh you know helps a ton. Um we try and make time you know for for the fun you know side of of life uh as much as possible but uh obviously

54:15 that gets constrained in in the kind of window that we're in. But I've been with my wife for I don't know 15 years or so uh 16 years and so she's seen the whole the whole grind uh all the way and uh

54:28 she has her own set of grind uh in her business and so it's it's just lots of fun. So >> dude, you're my hero. I want to be you when I grow up. Thank you for being so

54:38 great. I really appreciate and I was 14 in 2010. Okay. All right. All right. So I almost called it Yeah.

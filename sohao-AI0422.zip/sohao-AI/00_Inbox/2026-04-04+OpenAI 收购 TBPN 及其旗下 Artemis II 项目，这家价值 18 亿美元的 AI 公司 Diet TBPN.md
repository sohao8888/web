视频链接：[https://www.youtube.com/watch?v=zKvyGY2ZVuM&list=WL&index=7&pp=iAQBsAgC](https://www.youtube.com/watch?v=zKvyGY2ZVuM&list=WL&index=7&pp=iAQBsAgC)
视频发布时间：2026-04-02
频道名：TBPN

## 转录内容

00:02 We have some huge news. Uh, this is from the OpenAI blog. OpenAI acquires TBPN, accelerating the global conversation about AI. This is not an April Fool's joke. April Fools was yesterday. We

00:14 didn't do anything for April Fool's Day. Uh, this is real. This is a very interesting deal. I think a lot of people will be interested in this. We're very excited about this. Uh, we have a

00:23 bunch of context and information to share about how this changes things, what changes, what doesn't. I'm sure there's a million questions. We're trying we're going to try and get to

00:32 them all. But then we also have a huge normal show because >> normal show. We got Mark Lure. >> That's the first thing that's not changing. TBPN's not going away. We're

00:39 going to be live every day, three hours, as long as we want. Uh, we have a lot of flexibility. We're going to do a lot of interesting things. Uh, if you are calling me right now, I can't pick up

00:48 because I'm live and I think you know >> it might be time to turn off the phones. >> I think yes, it might be time to turn off the phones. >> Yeah, very very strange. I think this is

00:56 maybe the first time in history there's been a deal like this and then uh two people that are a part of it have to go and talk for three hours straight. But uh it's technology business as usual

01:07 over here. >> Uh we're very excited about the Artemis 2 mission going successfully. Hopefully you all watched it. It was a lot of fun. We were watching it here on the uh on

01:14 the screen and we were gripped as the rocket took off because uh >> yeah, we were we were so locked in. We we were joking around that it should have it felt like it should have been a

01:22 pay-per-view. Like could we turn space into a profit center for the government? >> Somebody was saying that it was not entertaining. I was extremely entertained. I don't know. Maybe maybe

01:31 they could do more, but I >> NASA has a decent e-commerce business, too. We were watching they were selling like 10,000 patches a minute or something like that.

01:38 >> Yeah. Yeah. Yeah. I think we were we were doing the back of the envelope just from the main call to action at the bottom of the YouTube stream. They were selling a patch for I don't know tens of

01:47 dollars and they'd sold like hundreds of thousands of them. So, as we were watching, they were selling like something like $10 million worth of merch. So, maybe go get some for

01:55 yourself. Anyway, let's go over to Fiji's post on the OpenAI blog. Uh she shared this message with the company earlier today. She says, "I'm excited to share that we've acquired TBPN. This

02:07 acquisition brings a team of strong editorial instincts, deep audience understanding, and proven ability to convene influential voices across tech, business, and culture. That's

02:17 >> I'm still going to be hitting the soundboard. >> Yeah. >> Yeah, you are. TVPN has built something pretty special. It's one of the places

02:24 where the conversations about AI and builders is actually happening dayto-day. A lot of you already watch it and rely on it to stay close to what's going on. As I've been thinking about

02:34 the future of how we communicate in OpenAI, one thing that's become clear is that the standard communications playbook just doesn't apply to us. We're not a typical company. We're driving a

02:43 really big techn technological shift and the mission of bringing uh and with the mission of bringing AGI to the world comes a responsibility to help create a space for real constructive conversation

02:55 about the changes AI creates with builders and people using the technology at the center. And that's exactly what TBPN has built, which is what I was gonna say is the next line. Um, that is

03:04 a huge part of the show is making sense of what's going on, how these tools are actually being used, all of the implications. We've gone all over the place and we will continue to go all

03:15 over the place. >> Yeah. And over the last over the last year, like you know, multiple years, there's just been so there's so much uncertainty about AI. I don't think we

03:22 can change that. Uh but there's also a lot of fear and just talking through it with the people that are actually helping diffuse AI through the economy across every single industry is

03:32 something that we've uh enjoyed a tremendous amount and is exactly what we're going to continue to do. If you want to continue. >> Yeah. So she says so rather than trying

03:41 to recreate that ourselves, it made a lot of sense just to bring them in, support what they're doing, and help them scale while keeping what makes them special. A core part of this is

03:51 editorial independence. We can say whatever we want because we're live and we don't need to run anything through anyone. Uh >> it's not possible.

03:58 >> It would be very difficult to have somebody here. Can we say this? I'm about to say a sentence. Uh TBPN will continue to run their programming, choose their own guests, and make their

04:06 own editorial decisions. That's foundational to their credibility and it's something we're explicitly protecting as part of this agreement. And also, we were never in the scoop

04:14 industry. People were kind of asking like, is this journalism? Is it commentary? I think we've always been like, hey, we, you know, like to talk to a lot of people, have a conversation,

04:22 bring in people. >> Yeah. And even even when companies have approached us and said, we'll give you the exclusive, we don't say, give it to somebody else. It's like, hey, you can

04:29 come on the show. We actually want you to go talk to the journal >> or the times or wherever, Bloomberg, etc., wherever you want to go, >> and then come and contextualize it with

04:39 us and and let us dig in and understand more about the strategy. Uh, and so, uh, TBPN will continue running their programming, choose their guests, and make their own editorial decisions.

04:48 That's foundational to their credibility and something we're explicitly protecting as part of this agreement. I'm also excited to bring their amazing comms and marketing instincts to the

04:56 team. We got lots of ideas and we're very excited for this. Uh, there they've helped many brands market online, and because they have a strong pulse on where the industry is going, their comms

05:05 and marketing ideas have really impressed. Did you see me? Uh, I can't wait to leverage their talent outside of the show to innovate on how we bring AI to the world in a way that helps people

05:16 understand the full impact of this technology on their daily lives. TVPN will sit within our strategy organization reporting to Chris Leane. Really excited to welcome Jordy, John,

05:25 Dylan, and the broader team. And here's a statement from you. Do you want to read this? What did you say? >> Over the past year, we've had a front row seat not just to OpenAI, but to the

05:32 entire ecosystem, covering the daily news announcements and launches in real time. While we've been critical of the industry at times after getting to know Sam Fiji and the OpenAI team, what stood

05:43 out the most was their openness to feedback, feedback and commitment to getting this right. Uh moving from commentary to real impact and how this technology is distributed and understood

05:52 globally is incredibly important to us. >> I contextualize it a little bit more shared. You know, a lot of people are like, is this an April Fool's joke? I've been saying expect the unexpected. This

06:01 is a plot twist. I'll give you that it was unexpected. It was unexpected to me, but I'm really happy about it. And when I reflect on my career, it's I think it makes a lot of sense. And I can walk you

06:12 through some of my career and my experience with OpenAI and with Sam Alman. I've known Sam for maybe 13 years. He invested in my first company in 2013. And then we got in a really

06:23 serious log jam during a financing and I wrote him an email. I told this story in Bloomberg a couple years ago. Uh I wrote him an email and said like, "Hey, like this is getting really rough. I'm a

06:32 first-time founder. I don't know if we're going to be able to get this done. Uh and he called me and we hopped on the phone for like five minutes and he was able to completely resolve everything

06:41 and everyone walked out of the deal uh feeling pretty good. And so that always left this impression on me that like he was founder friendly. Obviously he didn't in this particular case it was to

06:51 my benefit not particularly to his benefit the way the deals the way the way the deal like wound out. and he was just a great ad uh great addition to the to the negotiation and really uh

07:03 >> and you were very young at the time. You were just a wee lad. >> I was you were about 23 24 or something in that >> range. Yeah. And then uh when I took my

07:11 second company through YC, he was president at the time. Uh and then when I joined Founders Fund uh the very first deal that I saw in motion at Founders Fund was the post chatbt round in OpenAI

07:24 uh in late 2022, early 2023. And so I sort of had this like front row seat to all of this. And then once we actually started growing TBPN, he was one of the first people that I texted to, you know,

07:35 say, "Hey, do you want to come on the show?" Uh and he was the first lab lead to come on the show. And we're excited to continue having him on the show. hopefully have other lab leads on the

07:42 show, have other people from all over the industry. And just generally, I think that when I was at Founders Fund, I was not particularly in the weeds of intra venture capital fights. I was much

07:54 more interested in the conversation around technological stagnation, not funding companies, not making great companies happen. I never uh was in a situation where I was like, oh, like if

08:05 a different VC firm backs a great company, that's bad, you know? And I think that's the same uh philosophy that I have always taken forward and will continue to believe in which is that the

08:16 American AI industry is the most important thing and that will continue to be the case and I'm excited for uh all the different competition and everything that's happening in the

08:26 industry uh to to continue and uh yeah push further. Um Jordy, did you have anything else to say? I just wanted to say some thank yous uh because a lot of people have been a part of this journey

08:40 to date. It's been >> I think something like let me do the math here 496 days roughly 16 months since we put out the first episode. Yeah,

08:51 >> it was just the two of us and Ben sitting in a room, couple cameras, couple microphones. And I will just say I didn't know uh this special of a business relationship was possible.

09:02 >> Yeah. between you and me. Yeah. Like I think like if you look back on that almost 500 days, >> we've had disagreements around strategy or approaches or things like that. But

09:15 we have like >> almost universally stayed perfectly aligned on everything that matters every single day, every step of the way. And I think that's somewhat of a miracle given

09:24 that we went into this not really knowing what it would become. Yeah, we done like one side project together and it took like eight months and it was like not it was like successful but it

09:34 was not like oh yeah like okay we were we were working together daily for months you know it was a lot of uh just just jumping and leap of faith right >> yeah and I think uh we've got this

09:46 question so many times like do you guys get sick of each other you know you just have to talk to each other for three hours a day and like I've said this before I'll say it again uh and uh It it

09:57 is actually hilarious. The second that we leave the office, we're we both get in the car, we call each other, we end up talking for like another hour on the way home. And so, it's just been it's

10:07 been the the privilege of uh of a lifetime to just build this business with you and the whole team. Uh the team has been absolutely uh incredible. >> You guys are all truly amazing. Uh, and

10:23 this very much is a this very much is a team like a team sport. Like business is a team sport, but this is like a live team sport. We come in here every single day. And the show doesn't happen if we

10:35 don't all come in um and uh and make it happen. And so the consistency of the team has been uh just incredible. And watching uh everyone's individual talents just flourish has been uh

10:48 incredible. A lot of people came into this, you know, having done a thing or two in the past, but learning new things. Brandon has been in absolutely incredible uh just an absolute rock in

11:00 the organization. Uh Brandon, if if you're not familiar, writes writes our newsletter every day and is just remarkably uh consistent and uh has like, you know, helped us shape

11:12 uh our editorial approach and it's been incredible. Dylan uh who joined us uh I guess technically Q4 of last year uh you know I'd worked uh with him at my last company but uh is truly truly one of a

11:27 kind. Remarkable. I never want to I never want to do business without him. Um >> and uh he has just done such an exceptional job working off air. It's

11:37 like you know challenging when you're building a company and you're also having to put on a live performance >> for three hours every day. He wrote the newsletter yesterday. So that's true.

11:47 The op-ed. He wrote the op-ed. >> Ben. Ben, who's been here uh since since then? >> Since before TBPN. He was working with me on my YouTube channel. When did we

11:55 start working together? >> I was here before Jordy. >> Yeah. Maybe like uh wait mid 2024 maybe. Something like that. >> Sounds right. Fun videos.

12:05 >> Yeah. Yeah. We we traveled a lot. A lot of >> cases. No, but it's been it's been absolutely incredible to watch you grow uh from from an an extremely talented

12:15 individual and to a very capable uh and talented manager and and building out a team of people that are so hardworking and wonderful and uh you know, Michael, Scott, Jackson, you guys uh you know,

12:31 are so uh you know, such a joy to to work with even though what we do is uh is not easy and it's changing, you know, dayto day. >> Yeah.

12:42 >> Um to all the guests, >> seriously, it's been it's been so much fun. Like, uh if you went back and rewound to the beginning of of the show to to we we started with no guests. We

12:54 did something like 50 episodes >> without any guests. Uh we thought that >> uh there was a time that we thought we would just do that forever because that was the only thing that was,

13:04 >> you know, really unique about the show. Like that's the reason I started creating content in 2020 because it was during COVID. There were no uh events. There were no places to meet other

13:14 founders, meet other business people. I wasn't thinking of it as like a media business. I was thinking of it as like a way to just have conversations and meet other people who are building companies

13:24 and now we get to do that all day long which is just a dream come true. >> Yeah. So so many so many guests have turned into to dear friends. Yeah. You know the

13:32 >> the Joe Weisenthalss, the the Dylan Patels. Uh there's there's really too many to list, but we will have you all back on the show. I can't wait. Uh to everybody that's tuned in, whether

13:43 you've watched, you know, the RSS feed, the live show, >> uh the clips, the newsletter. >> Um you know, we've strived to to create the right product regardless of how much

13:55 time you have. If you have two minutes a day to read the newsletter, great. If you've got five minutes to watch some clips, if you want to watch the entire podcast, if you want to watch Diet TBPN,

14:06 the daily cutdown, thank you. Thank you for tuning in. Uh and uh fortunately, pretty much everything is going to stay exactly the same. Uh to our to our one and only Tyler.

14:21 >> Uh Tyler, uh you are truly truly incredible. one of the the brightest uh young people I've ever I've ever worked with. And uh you have such a bright future. You know,

14:33 we always we always uh we always knew that uh I I I've felt from the very beginning that you would go on to start your own company. Uh and we cherish every single minute that we have with

14:44 you. Uh and uh we're going to do our very best to retain you for for decades. But uh thank you for everything you've brought to the show, everything you've built. Tyler uh if if you're just tuning

14:55 in now has built uh all of the internal software that we we use to run the show. >> It's insane stuff. >> It is a you know fully custom you know content management system CRM. It helps

15:07 us edit all of our videos. It is the backbone of the show. It's a it's a tool that >> the entire team uh uses on a daily basis and truly the show would not be possible

15:19 >> without it. Um and uh uh yeah, your your contributions on air as well. It's uh it's so much fun uh to be able to cut cut over to you. Uh and so it is with great honor that I give you this

15:33 soundboard. >> Um and uh our sponsors. Yeah, >> we can start with uh with the ramp team, Eric uh Eric, Kareem and the whole uh uh uh the whole team over there has just

15:53 been incredible. They allowed us, you know, at the at the beginning at sorry the end of 2024 when we had started doing the show. We really loved it. >> They were they committed to sponsoring

16:02 the show for a year and that allowed us to do um to do so much uh in terms of investing in all in all the equipment that we use, hiring people. um they they made it possible and have been uh truly

16:14 truly exceptional partners and and you know watching ramps growth over the last >> uh over the last couple years has just been uh phenomenal and they deserve all the all the success. Um and every other

16:27 sponsor that is that has been a part of this. >> Yeah. >> Truly. Um >> shout out Nick as well.

16:32 >> Oh, did he not get one? >> Oh, we got to get a direct shout out for Nick. >> We got to get a direct shout out for Nick.

16:37 >> We don't know we don't know what to call Nick. He's a >> We can't give his name on air because he'll get 10 times more emails. He uh he man the the lineup every day is uh is

16:47 crafted by Nick. He is our liaison to 99% of the guests that come on the show. Sometimes it starts with an interaction over X or a text message or uh there's other intermediaries involved. There's a

17:01 lot that goes into actually getting someone into the waiting room, into the show, making sure that they understand how the show will work. It's sort of like, you know, you're hot dropping into

17:10 this live show that's new for a lot of people. And Nick does a great job uh communicating and and parsing all the noise to understand uh what the best news of the day is, how we can

17:20 contextualize it best with the with the optimal guests and uh he's done a fantastic job and we'll continue. >> It's an honor. >> Uh David Senra.

17:30 >> Yeah. >> Uh one of a kind. >> He literally Yeah. David was our very uh first listener that I'm aware of. Uh he gets

17:40 sent a lot of >> we sent him a link in a Google Drive >> and uh he listened and uh from that first episode uh even though it was very scrappy he said take this uh take this

17:51 you know a hundred times more seriously yeah >> than uh than you are right now. And we did and it's it's the best advice that I've ever gotten. And he has been

18:00 >> and we have a picture of >> we have a picture of him here. We couldn't print it full size and it appears that it was printed on a black and white photo printer, but it's a

18:08 black and white photo and he's a black and white brand. So, uh, thank you to David Sra who's been, uh, the podcast godfather truly. >> And the gong.

18:17 >> The gong. The chat is asking us to hit the gong. We have to we have to oblige. >> The gong will remain. >> The gong will remain. Uh Wilmanitis has already chimed in with his take. He says

18:34 many guy many people are saying we're in the deal guy yuga. Many are saying and it means a lot that will minitis the only he is the only guest who has uh co-hosted a full show from start to

18:47 finish with us. And if you want to go back in the archives you can uh you can watch that episode. It's a wild one. It was in a hotel room. We had yet to figure out the remote shows fully. Uh

18:57 the team worked really hard to make that one happen. and very chaotic good time. Very chaotic. Uh is there anything else to say about OpenAI? I mean, of of course we'll be in conversation with you

19:06 forever, you know, uh anytime on the show. You're welcome to leave a comment or chat in the uh the chat is asking where is Wilmanitis right now. >> I don't know. Probably uh sailing a

19:17 boat. I don't know. New York. >> And uh yeah, it's it's an it's an honor. Yeah. uh to to partner with OpenAI and and every single person on the team that we've had the pleasure of meeting, we've

19:27 been uh impressed by. They are uh ridiculously talented and uh every single person is committed to getting getting this AI thing right. So, we're incredibly excited.

19:39 >> Great. Well, let's move on to the Artemis 2 uh pictures and images and news. Uh very very exciting. It made the front of the Wall Street Journal. NASA aims to orbit moon for first uh for

19:50 first time since 72 to boldly go. The crew of NASA >> Chad is asking is that three Diet Cokes. Yes, >> you got you got to thank you got to

19:59 thank Diet Coke. >> Thank you to the Coca-Cola Corporation for making this possible. >> Thank you to the uh the human team for the for the matina yerba mates the

20:09 podcast in a can. >> Yes. >> Uh wouldn't be possible without you guys. >> And thank you to tailor and suit makers.

20:16 There's a lot of people that make this possible. the horse, the prop department. There's a million things here. Uh it's been a it's been a great time. So, uh the crew of NASA Artemis 2,

20:26 uh head to Cape Canaveral launch Wednesday, uh launchpad Wednesday for the first human space flight to the moon in half a century. Uh John Krauss poed a uh incredible photo. Is he is he someone

20:39 who actually Yeah, he he he uh >> special comm's assistant. >> Special comm's assistant. He actually goes to the launches and brings special photography gear to get the best

20:49 possible photos. And man, did he deliver with this one. Uh what an incredible moment. We talked about a little bit. Um uh there's an article on the watches of NASA Artemis 2.

21:00 >> John, we have to thank our lovely wives. >> Of course. >> How could we not? >> Our families. Did you get a text? >> Maybe.

21:09 >> Uh we we we don't talk about them a lot on the show. Yes, >> this is a show about technology and business, but they have been uh they are the back they are the truly the

21:18 backbones of the show and have put up with um >> a lot of travel nights, >> incredible hours, uh >> early mornings,

21:28 >> a lot of early mornings. I think out of the last >> out of every single day that we've done the show, I haven't I've I've left the house past uh 6:00 a.m. maybe twice,

21:38 right? Uh it's been it's been a long uh it's been a long road and and the good news ladies is it's uh nothing's going to change. So uh no uh thank you to both of you for uh

21:52 supporting us and uh allowing us to to do what we do. >> Can we pull up this picture, Ben, of in the production chat of the first episode that we recorded in the Jonathan Club in

22:02 downtown uh showing a little >> Yeah, I put it up earlier. >> Oh, you did? Yeah. Behind the scenes. This is a >> Yeah. Such a such a wild time.

22:10 >> Remember that? >> Yeah. Remember that, Jordan? >> Suitless. >> Suitless. >> We had the flag.

22:14 >> Yeah, >> but no suits. >> It looked It looked It looked pretty good on camera. I was I was happy with the way it came out. But uh yesterday,

22:20 the long-awaited Artemis 2 mission took to the stars in route to the moon for the first such manned mission since 1972. >> The chat asked for a flashback. We had

22:37 to >> flash out. Okay, that's good. Yes, the flashbang has been a highlight for sure. Both literally. >> Yeah, the sound the soundboard. It's

22:45 truly it's truly a character on the show. >> And I have some too now. Uh its members all had Omega Speed Master X33 models strapped to their flight

22:56 suits. Danny Milton uh just wrote a full article on the site now detailing the watches worn on the wrists of the four astronauts throughout their time as part of this mission. watches have a

23:05 long-standing history with spacelight, most notably through the Omega Speed Master Moon Watch, but there are countless others that have cemented their place in the cosmos.

23:13 >> So, we can pull up this video now of uh the astronauts working on what looks like some type of tablet. Uh so, here he is >> uh typing in

23:24 >> most secure password known to man. >> What is that? 9393 or something? 393. >> 3939. >> 9393. >> Powerful. Powerful.

23:33 >> We're going back to the moon. Uh, apparently that video we played yesterday was a little bit of fake news. The the the the young man, the adolescent who swears and says, "We're

23:46 going to the f and moon." He was he the the real line, I believe, in the community note is that he says, "We're going to the freaking >> Yeah. Yeah. Yeah.

23:53 >> And and it had been altered to add the actual f word, but the but the the sentiment is still the same. It's very exciting, very inspirational." Jared Isaacman on launch day says, "Oh, this

24:04 kid is definitely getting it back in NASA gear." >> That's great. >> Very cool. Um, >> there is some there are some wrinkles

24:09 with the launch, right? Fortunately, nothing like disastrous or catastrophic or anything, but the good news is that we're on our way back to the moon. The bad news is that the toilet's broken,

24:18 apparently. Uh, and I believe this is from the live blog from the New York Times. Uh, the NASA associate administer said there is a controller issue with the toilet on the Orion capsule and it

24:26 would take a few hours to troubleshoot. We're just getting started. He said when addressing that and some other glitches with the space spacecraft, the spirit of Apollo 10 lives on. They said 135. They

24:37 told us that. Here's another uh it seems like this is not the first time that this has happened. Um but we're hoping for the best here. >> Sounds like there were some other issues

24:47 with Outlook as well. We can pull up this video from Tom Warren and take a look directly. Yeah, go for it. And then I also see that I have two Microsoft Outlooks and

25:03 neither one of those are working. If you want to remote and check >> Why do you have two like web and desktop or you think it's like two separate desktop installations?

25:11 >> Join in on your PCB and we'll let you know when we're done. >> Honestly, this is the best possible failure scenario is Outlook and not the rocket itself.

25:20 >> So, can they >> I think it's a good outcome. There were so many amazing images coming out yesterday. >> Yeah. Uh Payton Alexander says, "This is

25:27 the real reward for Artemis. This is who we are actually doing this for. They will grow up knowing they can one day work in their country's bases on the moon and Mars. We are not just

25:36 abstractly hoping for a better world for them. We are going there." Uh and uh two kids here watching the launch from Orlando. Uh just beautiful. >> Yeah. My 5-year-old said it was boring,

25:47 which is not what you want to hear, but we'll have to give some more context to him about how big of a deal it is. He was like, "Yeah, I don't know. Maybe maybe he wants more more flashing lights

25:57 on the screen. >> We were we were we were driving uh for the actual launch and it was so funny listening to the audio feed and sitting in traffic and just looking out at

26:07 everyone. >> Yeah. >> And and re and realizing that it felt like the majority of the world still wasn't paying attention or or uh or

26:14 didn't care. But >> yeah, I mean like rockets do launch like every day now. >> I know SpaceX has normalized it to such a degree. Isn't there isn't there some

26:23 sort of subplot on the Apollo missions that by the by the third or fourth Apollo mission there was no uh like the the actual viewership had dropped off and like the American population had

26:33 gotten >> 2.6 has put subway surfers on it. >> Yeah. >> On the NASA feed. >> Crazy that you actually need to maybe

26:42 need to do this. How AI helped one man and his brother build a 1.8 billion dollar company. Who needs more than two employees? That when artificial intelligence can do so many corporate

26:51 tasks, it's super efficient and a little bit lonely. So, Aaron Griffith tells the story of Matthew Gallagher, who took just two months, $20,000, and a more than a dozen artificial intelligence

27:00 tools to get his startup off the ground. From his house in Los Angeles, Mr. Gallagher, 41, used AI to write the code for the software that powers his company, produced the website copy,

27:10 generate the images and videos for ads, and handle customer service. He created AI systems to analyze his business's performance, and he outsourced the other stuff he couldn't do himself. His

27:19 startup, Medv, a teleaalth provider of GLP-1 weight loss drugs, got 300 customers in its first month. In its second month, it gained more than 1,000 more. In 2025, Medv's first year in

27:32 business, the company generated four the first full year in business, uh, the company generated $41 million in sales. Mr. Gallagher then hired his only this is absolutely insane because I as GLP1s

27:44 were starting to take off I had I I remember distinctly talking with somebody that was like I want to start a teleaalth company for GLP1s >> and at that time I was like okay there's

27:54 a lot of tellahalth companies that are at scale they're well aware of this they will immediately introduce this product and other you know similar products to their customer base and it's going to be

28:05 incredibly difficult to be uh to be competitive and it turns out. There is just such overwhelming demand for these products. Yeah. >> That you could come in as a new company

28:15 and scale. >> Like one year in maybe he hires his only employee, his younger brother Elliot. This year they're on track to do $1.8 billion in sales. Uh a $ 1.8 billion

28:27 company with just two employees in the age of AI. It's increasingly possible, says Aaron Griffith in the New York Times. Uh Sam Alman, the chief executive of OpenAI, uh predicted the rise of a

28:37 new breed of superefficient company in 2024. A oneperson business worth1 billion dollars would have been unimaginable without AI, he said on a podcast, and now it will happen. Uh now,

28:48 as AI tools spread, entrepreneurs are harnessing the technology to expand their startups to an enormous scale at breathtaking speed with very few humans. Big companies uh especially in tech are

28:58 getting in on the disruption, too. Pinterest, Block, and others have cut thousands of workers in recent months, citing efficiencies enabled by AI. >> Does this count yet, though? Like I feel

29:06 like to be the one person$ one billion dollar company, you got to be able you got to be able to log into your payroll tool and you're the only person there. >> Oh, so

29:14 >> and he's got his brother in there. >> Sorry, bro. Take a walk. >> The startup, which has not raised outside funding, also has no official valuation, but many highly valued tech

29:23 companies can only dream of hitting 1 billion in revenue with so few workers. Medv is also profitable. That is great and important if you're bootstrapped. Can't can't get

29:34 >> Is this a wrapper company? It's it's like a GLP-1 rapper is but it's AI enabled, but it's not wrapping the AI foundation model. It's like using the tool to wrap another industry and just

29:44 create the efficiency between the manufacturer and the actual distribution. It really is remarkable that they were able to hoover up so much revenue uh in such a competitive space

29:54 because you would you would assume that that the other telealth providers would have significant ad operations and that the margins on customer acquisition would be very very tricky to crack. But

30:06 he must have found some unique insight into how to distribute the product, get actual people to the website because like the the the AI certainly can build the website and write the copy, but it

30:17 not it can't necessarily get people to show up and actually uh put down their hard-earned cash for the product. Uh I >> texted my dad the news. He said, "Congratulations. That's so exciting.

30:31 Thanks for letting me know. Talk to you soon. Have a great day." >> So thank you. Thank you, Dad. >> Oh, it's amazing. Well, if you've texted me or you've called me in the last three

30:44 hours, there's a good chance that I might respond to you in the next couple hours. Leave us five stars in Apple Podcast and Spotify. Subscribe to our newsletter, tbin.com. Everything is the

30:54 same. We will see you on Monday. Fun. Next week, five shows, 15 hours. Let's be honest, it'll probably be more like 17 >> or 18 or 19.

31:05 >> We'll see. >> Who knows? The world is our oyster. And thank you for being with us along the journey. We appreciate it. >> Let's get one more gong hit, John.

31:13 >> One more gong hit. And we will say, >> it's been an honor. >> A gong hit. >> Flash. >> Goodbye, everyone.

31:22 >> See you soon. We'll see you tomorrow.

视频链接：[https://www.youtube.com/watch?v=kkv5rZhrLkc&list=WL&index=3&pp=iAQBsAgC](https://www.youtube.com/watch?v=kkv5rZhrLkc&list=WL&index=3&pp=iAQBsAgC)
视频发布时间：2026-04-06
频道名：Y Combinator

## 转录内容

00:01 One in 11 babies born in America this year will be screened by a genetic test that didn't exist a decade ago. Can you articulate like the needle in the haystack problem that you have to solve?

00:12 There are 3 billion base pairs in the human genome. In a lot of the human diseases that we are detecting from mom's blood, cickle cell disease, cystic fibrosis, etc. It's usually only one

00:22 base pair that's different. So you're looking for one base pair that's different out of billions. And that's where the billion to one name came from. The prenatal test from billion to one is

00:30 already one of the most widely used genetic tests. But that's just step one. They're also working towards solving one of the most elusive problems in medicine. We are maybe uh less than a

00:41 year away from launching our, you know, ultra sensitive MRD test, minimal residual disease test for stage one cancer patients. And that same technology could one day be used for

00:53 early stage detection so that the cancer can be caught before it ever reaches stage one. >> Once we are there, I think technically we would have solved the, you know, holy

01:02 grail of cancer detection. >> Billion to one was built by two PhD students who started with half a lab bench and $300,000. So how did they pull it off? And what will it take to make a

01:14 blood test that detects cancer early? This is the story of Billion to One. I met Ogazan and David way back in 2017 when they applied to YC. They've come a long way since then. I recently visited

01:34 them at their lab in Union City, California to hear the full story. I'm so excited to get to sit down with you guys today. To start with, why don't you tell everybody what Billionto one does?

01:44 Billionto1 is a next generation molecular diagnostics company. We detect DNA in blood samples. This is important because all of our different tissues shed this DNA into the bloodstream. This

01:57 includes fetus, a developing baby in mother's womb, it releases DNA into the bloodstream. And cancer as well, you know, as cancer is mutating and growing, it releases its DNA into the

02:12 bloodstream. By detecting this DNA, we can develop diagnostics that have been impossible even a decade ago. >> And all their hard work is paying off. Late last year, they took the company

02:24 public at a valuation over $4 billion. Can you guys give us a sense of the scale that you guys are operating at here? We are processing more than 600,000 tests a year and in terms of the

02:38 overall market share uh we are close to 20% market share there. Remarkably, the core idea behind billion1 is the same as when they applied to YC back in 2017. They were convinced it should be

02:51 possible to create a prennatal genetic test that works by sequencing fragments of fetal DNA that naturally exist in the mother's blood and that this would someday be universally adopted. This was

03:01 a radical idea at the time before billion to1 most genetic abnormalities could only be detected via amnneocentesis an invasive procedure that is only used in high-risisk

03:12 pregnancies. What was the key insight that enabled you guys to do this when no one else was able to do it before? We have realized that DNA that is coming from the fetus and the tumor is both

03:22 very dilute and rare. Right? So you might only have a few molecules among billions of other molecules. So every molecular diagnostics approach here requires in the lab using a process

03:36 called PCR to amplify this DNA billions of fold. And the problem is that this DNA amplification process can add tremendous noise. So that the small signal that you have can be lost. So

03:51 what we have done is to add a synthetic DNA into the patient sample that we get before any amplification happens. These synthetic DNA allow us to know how much amplification happened at different

04:07 genomic locations. you know what are the errors that are being introduced by the amplification process. So then we can remove those errors from the sequencing data. The data that we get at the end so

04:21 that we know what was in the sample to begin with that converts a difficult biology problem to almost a simple mathematical problem. Let's break that down even further. Every tissue in your

04:34 body sheds tiny fragments of DNA into your bloodstream. Hidden inside that mix can be a fragment from a fetal condition or a sign of cancer, but detecting it is a needle in a haystack problem.

04:46 Traditional genetic tests amplify everything, including background noise, which means they can't find the needle. Billion to one has a clever trick. Before amplifying, they add known

04:58 synthetic DNA molecules to the sample. Because they know exactly what they added, they can see how much distortion the amplification introduced and subtract the noise using machine

05:08 learning. The result is that they can spot things no other test can pick up. I want to go back to the first couple of years of the company and talk about how you went from PhD students who had a

05:19 cool idea to an actual commercial test that was live and processing samples from real patients. Tell us about how you did it and how you did it so fast cuz you guys did it in 2 years which is

05:28 like one of the fastest I've ever heard of a company doing this. Ozen and I we had met actually when we were undergrads and then we went our kind of separate ways for our PhD studies in biology

05:39 related fields. Ozan was studying at Stanford. I was at Rice University. He basically called me up one day and he was like hey like you know I'm thinking of starting a company. Initially we were

05:49 looking into the self-free DNA which is essentially the DNA in blood to see you know what conditions we can detect and we were approaching this problem from first principles and we were able to

06:02 determine that you know if we could reduce the noise we would be able to detect you know conditions like cickle cell disease cystic fibrosis you know talismas directly from a maternal blood

06:14 sample and given that you know cickle cell and beta talismia are the most common genetic disorders in the world. You know we thought that you know we would be able to you know create

06:24 something that would help millions of patients. I think the question almost becomes like why didn't someone else do this before? >> Why were you two the first to do that?

06:34 sequencing developed pretty recently, right? This essentially requires this kind of interdisciplinary approach where people who are analyzing the data and seeing kind of all the ways in which the

06:47 data can be biased also understand the chemistry of how that data is generated. People who understand chemistry tend to be not the kind of data scientists and bioinformaticians that analyze the data.

07:03 We were able to I think bridge that gap. >> Billion to one is prenatal genetic testing for every expecting mother. >> When they applied to YC, this was all just an idea. But within 6 months, they

07:14 developed the actual test and proven its accuracy on test samples. >> Our first lab space was very much not anything like the you know operation we have today. It was actually in a shared

07:24 facility. We didn't even have an entire kind of lab bench to ourselves. We were sharing it with another one of our friends who was also doing a startup. It was a struggle even to get very common

07:35 kind of chemical suppliers to allow us to buy things from them because they'd be like, "Well, do you have a bank account? Like if we send you something and we invoice you, like are you going

07:43 to pay?" The first fundraising that we have done after the fellowship was one of the most difficult things that I have done. First $300,000 that you know I've raised was you know really really

07:55 difficult. It took you know 6 months and it was you know $10,000 at the time. So we were very paranoid about essentially the resources that we are able to get. It launched in June only person that is

08:08 using the test you know 2 months later is this one physician and who is sending like maybe one or two tests per week. >> Wow. So 2 months after launch you know you've been working on this thing for 2

08:18 years. You've done incredible R&D. You've gotten approval. You finally launched the thing 2 months after launch. You still only have like basically one user. Yes, that is

08:26 correct. That was very nerve-wracking. >> Okay, so you call this emergency meeting >> and yeah, I told our uh VP of sales, I was like, look, in 5 months, you hired only one rep. Obviously, that is not

08:40 working. I need you to hire in the next 3 weeks five additional sales reps. I need them to be trained over the weekend and I need them to be in the field on that Monday. When we talk with patients,

08:54 we can convince them. When we talk with physicians, we can convince them. But we are not getting in front of them. But patients are getting in front of you know physicians. So can we get you know

09:05 marketing leads >> and essentially convince these patients to convince their doctors >> doctors >> to use this test. It worked to the

09:13 extent that we were getting about one in five kids back. our current director of inside sales. He was on the phone essentially with like each patient for 30 45 minutes, you know, teaching the

09:27 patient about our test, you know, this is what the physician would say, this is how it is different. And that was, I think, what we needed to convince, you know, one or two good sales team members

09:37 to actually join us because they they really only want to join a company if there's traction. Once they cracked the sales problem, they began scaling up and eventually built this state-of-the-art

09:48 lab in 2022. During our visit, we got a behindthescenes tour of how it all comes together in the lab. This is the start of the processing. When we receive test samples, you know,

10:01 we need to log them into a laboratory information management system and track the sample through the 5 to 7 day process that it would go through. We want to make sure that when you are

10:14 processing thousands of samples a day that the identity of the sample is preserved. >> Are those actual raw blood samples like straight from patient over there?

10:23 >> Those are actual blood samples straight from the patients. And really the amazing thing here is that this actually became the bottleneck of all of our processes. So we had to incorporate AI

10:35 and computer vision to accelerate this. And then we did a complete redesign of the entire project incorporating computer vision and AI which was our project called accessioning in 60

10:48 seconds. >> So each file takes a human 60 seconds to to handle. >> Yes. Once the information is entered into the information system first step

10:57 is actually centrifuging them. So spinning them really fast so that the blood plasma and blood cells are separated. This self-free DNA that we talked about is in this upper layer of

11:10 plasma. We program these liquid handling robots which has an optics that can see that layer and only remove the plasma. So this is our reagent manufacturing lab where we create our own proprietary QCTs

11:26 quantitative counting templates that we add to every sample to measure the biases so that we can remove them at the end. We believe that we can expand into close to 2 million tests per year just

11:40 using this facility. That would be, you know, around essentially every one in three babies that would be tested with our tests. >> So, I know this is standard view, but

11:52 the first time I heard that this was how it was actually done, it seemed like black magic to me because you actually combine all the fluids into like one droplet.

12:00 >> Yes. >> And then you sequence somehow a thousand patient samples all mixed together. >> Yes. And then you use some computational magic to figure out which one was which.

12:08 >> Yes. So essentially it's kind of like you are marking each of their sequences with a specific sequence that belongs to that sample before you combine them. So when you look at the data every time you

12:19 see that barcode you know that that sequence belongs to this patient. >> So here's the end of the line right like this is the last step in the sample processing. After this it's all

12:28 computational. >> Yes. After this it is all computational. You know we have laboratory directors, we have genetic counselors. Sometimes genetics is complicated. So we would

12:38 sometimes even spend 20 people just discussing one sample to be able to report it well. At the same time, you know, vast majority of samples are in happy path. You know, essentially we

12:50 know what the result should be. So those get analyzed and go out automatically. >> Today billion to1 is not just a prenatal genetic test. The same core technology for detecting free floating DNA also

13:04 works for detecting cancer via a blood test known as a liquid biopsy. They launched an early version of this cancer test commercially in 2023 proving their ability to execute in two markets

13:14 simultaneously. One year into the company, it is actually laid out that you know we would start at prenatal genetics then go into late stage cancers and then go into early stage cancers in

13:25 this way. >> And you're on step two of that right now. >> Yes. Okay. >> That was step two. Okay. And you know we

13:31 realize that you know fundamentally there is nothing different about you know cell-free fetal DNA and cell-free tumor DNA and the same technology can be applied to both of them and that is why

13:42 I think it is it was very important to actually select the right problem the right minimal viable product to work on because if we started I think on the oncology side it would have been far

13:53 more difficult to achieve that initial successful commercialization that gave us more resources to be able to build, you know, new tests and improve the existing tests.

14:04 >> I'm curious if you guys could share patient stories um that sort of illustrate like what what the impact of all the science means for real people. >> So, one patient uh case study that

14:14 really stands out to me comes from our cancer products. So, this was a fairly young in their 40s uh individual with metastatic colorctal cancer and they had really kind of run out of treatment

14:24 options. they were about to go into hospice and you're not kind of shooting for a cure anymore at that point. We ended up testing this person using our Northstar Select test. We had identified

14:34 that this person was eligible uh for a therapy called imunotherapy uh based on identifying micro satellite instability in the tumor DNA that was in that patient's bloodstream. And this was a

14:47 little bit like a last stitch effort because they had already done the tumor testing and there's no kind of indication from the tumor test that this type of therapy would work. Uh but

14:55 because of how the the tumor had miss size into many different locations probably what happened was the exact location where the biopsy was done just didn't happen to have that alteration

15:04 but the other places in the the cancer sites did. Uh so this person went on to imunotherapy and did really remarkably well. Uh sometimes doctors describe the patient response as the cancer melting

15:15 away. Uh so the patient's doing very well and to this day the doctor is really impressed with our results and now starting to actually send us blood tests from pretty much all of his cancer

15:25 patients. >> Wow. You guys are actively hiring. Can you talk about some of the other like unique or interesting aspects of the billing to one team?

15:32 >> One of the ways we actually rehire scientists is um we say you know we're not looking to build an interdisiplinary team here. We're actually looking for interdisiplinary people. We have found

15:40 that having that iterative cycle within one scientist actually accelerates the work that they do by an order of magnitude. We actually uh have very small uh you know research teams. It is

15:56 essentially principal investigators like a scientist who is interdisciplinary who has a small team of you know two or three uh research associates and they all directly report to David and me and

16:09 they own end to end development of an entire product and they can do that because again they their iteration cycle is so fast and they are not blocked by any bureaucracy because they report to

16:20 us so we can essentially unblock them and we have you know every week we spend a lot of our times with those R&D scientists because it almost creates this interesting structure where we have

16:33 many startups within the larger company right each one owns a product and makes it better and better I want to end by talking about the future so as early as 2018 you guys did kind of this

16:44 three-step plan for the company it's like uh prenatal testing latestage cancer and then early stage cancer it actually just occurred to me is this similar to the Tesla super secret plan

16:54 the three-step plan to go from like the Roadster to the like huddle 3. Have you guys ever thought about that analogy? It has similarities. Um I think maybe the primary difference here is that being in

17:06 healthcare, we needed to make every test that we build accessible and affordable to everyone. But from the perspective of going into larger and larger markets, you know, it is very much the same

17:19 approach that we have taken here. >> You began with the least capital intensive product. You got that live and commercial. Then you took the resources from that were able to launch a more

17:28 expensive, more difficult product in a larger market. And that's where you guys are at now. This is like you're in like step two, which is latestage cancer. Can you talk about what step three?

17:38 >> Step three is essentially using the same technology for patients who are diagnosed with stage one two cancers and then you know they undergo uh what is considered you know curative intense

17:52 surgery. The problem is that in about 20% of these patients actually there's a microscopic residue remaining and they cannot be detected by scans. With our technology we believe that we can detect

18:09 this microscopic level of remnant tumor DNA. There is actually a step even four. If you can detect a microscopic level of DNA and be able to say that that is actually cancer, that is the same really

18:24 technical problem as being able to detect those in healthy patients or you know general population. So that is the kind of eventual goal of cancer screening. If we can, you know, screen

18:38 everyone once a year and be able to conclusively say that, you know, this small group of people have early stage cancer, that would be amazing because, you know, those tumors can often be

18:50 removed before, you know, it spreads before it becomes too late. >> This is one of these like holy grail scientific achievements that the industry has been chasing. Why has no

19:00 one else been able to do it before? Being resource limited is sometimes very helpful, right? If you wanted to solve early detection from the very beginning without having this step-by-step

19:12 approach, you would have to raise more than a billion dollars, you know, without generating a single dollar of revenue. And as first time founders, we knew that, you know, we could never do

19:23 that. I would be very proud of what we, you know, what we achieve even if we just solve the biggest prenatal problems. But the great thing about our technology is that it does allow us to

19:35 have this you know stepbystep uh approach to being able to get to a place where we can solve a problem for you know millions of cancer patients and you know potentially make the biggest

19:48 dent in in cancer that you know really has happened in the last 100 years. We have a saying that you know pressure is a privilege. people who are coming here because they want to take on a

20:00 challenge. You know, changing healthcare is difficult. Trying to change healthcare, you know, while also, you know, growing this fast, you know, while being profitable is even more difficult.

20:12 So we make it very clear to you know everyone that you know it is probably going to be you know one of the most difficult things that you are ever going to do if you join our company but you

20:23 are going to be extremely proud of what you are going to achieve here and now that you know we have gone public these employees they could easily retire but they are not retiring right and I think

20:33 that shows that you know they are really here because of the growth and because of the challenge and because you know they love what they

视频链接：[https://www.youtube.com/watch?v=AS0iuwKaeG0&list=WL&index=6&pp=iAQB0gcJCdkKAYcqIYzvsAgC](https://www.youtube.com/watch?v=AS0iuwKaeG0&list=WL&index=6&pp=iAQB0gcJCdkKAYcqIYzvsAgC)
视频发布时间：2026-04-06
频道名：Young and Profiting

## 转录内容

00:00 AI is not going to take your job. Somebody else using AI will. If you walk into a job and you say, "I would like a job, but I don't use AI." I don't think there will be a job.

00:10 >> Joshua Vola is the CEO of Mindstone, an AI powered learning platform helping professionals actually use AI to do better work faster. >> From Copilot to Chant to Claude, number

00:21 one problem is people use them as search engine replacements. Talk to it like you would talk to a person. Ask it to ask you questions. Don't just ask it for answers. The number one role of a great

00:32 manager is to make themselves obsolete. And actually the same is true here. Yeah, you are building your AI is your job becomes [music] building a system around you that can do

00:41 the job you're currently doing without you so that you can go and do the next thing. >> How should knowledge workers think about the fact that they might be training AI

00:49 to take their jobs and now like they're suddenly judged on how well they use AI? Like how should they be navigating all this? I think the biggest thing that people can do to prepare is to

00:58 >> Is there anything in 2026 right now that you absolutely will not delegate to AI? >> The reality of where things are at is moving much faster than how people are able to catch up hopefully. I mean, this

01:10 is an interesting one because >> young and profits, I recently went to an AI retreat and I literally built an app in just 15 minutes and I have zero coding experience. I never thought

01:23 anything like this could be possible and my mind has not been the same since. I've been obsessed with AI and learning AI as fast as I can because now I truly understand how it's going to change

01:35 everything for us. How AI is changing the workforce. Why most people are using tools like Claude and ChachiBT completely incorrectly. How to build systems that do hours of work in just

01:45 minutes. and what skills you need right now to stay relevant to keep your jobs or your companies alive. This is not a theoretical episode today. This is stuff that you can actually use and apply

01:57 today. In my opinion, this is mandatory listening for anybody who wants to be successful this year and for the years to come because AI has taken over and you need to learn how to use it

02:09 effectively. Without further delay, Joshua, welcome to Young and Profiting Podcast. >> Thank you very much. I'm so excited for this conversation. You know, I I went to

02:18 your minded AI breakthrough weekend recently and my mind was absolutely blown from everything I've learned and so I thought I have to bring Joshua on to just unpack everything with AI

02:30 because you just know so much and I'm just so excited to pick your brain today. So, so thank you so much for joining us. So, one of the things that um you've said in the past is that AI is

02:40 more dangerous from people who are ignoring AI than just from AI itself. The danger is in actually ignoring it. So, let's paint the picture. If somebody is a let's say a 30-year-old knowledge

02:52 worker, a marketer, or even an entrepreneur, what does it look like if they ignore AI for the next 3 to 5 years? >> First off, 3 to 5 years in AI

03:02 feels like a lifetime. [laughter] uh at the speed that it's currently going. Um but the there is this saying like AI is not going to take your job, somebody

03:13 else using AI will. >> And I do think that is true, which is that today if you try to walk into a knowledge work role, any any role in a

03:26 company, and you tell them, I'd love to get a job, but I don't use email, >> they're probably going to have a problem. >> Yeah. And I think the same thing is

03:35 going to be true with AI which is if in actually probably in two years if you walk into a job and you say I would like a job but I don't use AI. I don't think there will be a job.

03:45 >> When I went to this training weekend with you, it was just a few weeks back. I felt like there was no way I could ever create an app myself for example. I ended up creating one in like 15 minutes

03:57 after some training with you. I did not fully realize the capabilities that AI had. Like I knew it was there, but like I thought it wasn't for me and um of course I used chatbt and all the basic

04:10 stuff, right? But like I didn't realize like how far ahead it already was and how far behind me and my company were at the time. So talk to us about what was the mindset shift for you when you were

04:24 like, okay, AI is going to change everything. you know, what capability did you see it do where you're like, okay, this is really going to change everything and we need to, you know, hop

04:32 on this trend right now. >> So, I think there's a there's a there are a few things. Um, one is I am I am a technologist by by nature, I'd say. Um, so I guess I I kind of

04:46 fell into it a little much earlier than than most. I tend to want to figure out how to make it work. So that was the first thing which that is different to most and that explains why maybe we we

04:56 were there earlier. The first time that it really clicked that I thought okay this is going to change everything was when with Mindstone the original vision was about general learning. We wanted to

05:09 help people learn in a way that would be more effective uh and that really would move the needle that helps them have better lives. And at some point and it was this was in between GPT 3.5 which

05:21 was the original CH GBT and GPT4 when it came out in March the year after um we realized that AI could estimate the approximate level of understanding of a subject for

05:37 any individual >> based on the quality of the question they were asking. And that was was fairly meta because everyone was using uh chant to ask

05:48 questions and and sure you get answers back but the fact that it could derive your level of understanding based on the type of questions you're asking was a level behind and suddenly it made me

05:59 think what are some other things that are completely non-obvious that you might want to ask this AI and that was really the starting point. I mean, it's been basically 3 years of discovery

06:12 after discovery since. >> I want to dig deeper on that because at the AI retreat, I remember one of the exercises that we did was basically um asking uh your AI of choice. Um tell

06:26 like ask me one question at a time to get as much context as possible before answering this question. And to me that was like genius. And now every time I ask ChachiBG something, before I even

06:38 ask it the question, I first say like, "Ask me a question, you know, one by one to fully unpack context before you give me an answer." And this was really powerful because before I used to get

06:50 really frustrated with AI and I would like throw away a lot of the answers it gave me because I'm like, "Oh, it just doesn't understand. It doesn't have the full context." So talk to us about like

06:58 how we can prompt better in that way and why that's so important. Yeah. So that is one of my favorite techniques as well is the asking the question bit. And a lot of this actually comes back to

07:11 changing the way that we interact with AI. Now one of the frameworks um uh we we teach a lot is stop thinking about AI as technology think about it as a person which is both right and wrong. I'm not

07:23 trying to say here that we're uh that we have some kind of being there but from a framework perspective and how do you interact with the technology it actually works against us that we have a past of

07:36 of Google and how you ask questions in that way when you have a conversation with a person and you ask that person a question or you want the help of a person you naturally give that context.

07:49 If we sit together and I asked you advice on how to run my business, if you genuinely tried to help me, you one, you'd ask me 10 questions first to get that context.

08:01 >> Now, the AI doesn't do that automatically, which it should, and honestly, sometimes I wonder why the hell did they not >> build it in a way that it would do that

08:09 naturally, but anyways, it doesn't, which means you have to create that context. And you have to create that context that mimics the way that you would have this conversation with a

08:17 person after the context is set. The quality of the answer that comes back is going to be much higher because the opposite is also impossible. You cannot get a perfect answer if you do not give

08:30 the context. Literally the best person in the world wouldn't be able to answer the question how do how do I or what is the better strategy between two different strategies for my

08:40 company if I'm not giving them the context. It's just an impossible situation. But because we are used to using technology in that way, people judge it in that way.

08:50 >> So if you ask okay, which one of these two strategies is best? And it comes back with a bad answer, the default is people think, okay, well, it just can't help me. Which is, and this is the

09:00 problem that you then come into, which when you have a person conversation, if the first answer you would give me isn't quite what I was looking for, my answer wouldn't be, "Okay, you're not worth

09:10 having a conversation." I would say, "No, actually that's not quite on point, and this is why I think you're missing this piece of context." And I would explain it to you, and then we'd

09:18 continue the conversation. >> Yeah. So, moral of the story, Yap Bam, is that when you want to get chatbt or whatever AI to help you, you actually want to ask it, please give me questions

09:30 to understand more context before you actually uh answer the question. Right? The other uh mental shift that I had was actually talking to AI at the retreat, right? So I was so used to chatting all

09:43 the time, but you guys actually directed us to uh they were called walk-in talks and basically just talk to AI and that really helped and made it feel like it was a partner, a real like you know

09:56 teammate helping me. Why is that such a powerful unlock? So this goes back to I guess one of the one of the advantages of having started out as um general learning company. There are just

10:08 different ways that your brain interacts and that your brain acts when you're thinking, when you're interacting with ideas, different neurons that will fire in different ways depending on the

10:18 context that you're in. [snorts] That context can be the room that you're in. It can be um the method that you're in when you're walking or when you're sitting. It can be the method that

10:30 you're using to interact with it, talk to it rather than typing on a keyboard. >> And so what happens when you talk to AI and what we did on the weekend is literally just put your AirPods in, go

10:41 and have a walk around and talk to the AI in a way that you would to a person, all your surroundings are now different. And so the the ideas that come to you, the way the things that you will say are

10:54 going to be different than if you just sit behind your laptop and type it into a chat interface. >> And what is important to recognize there is that actually both are important.

11:06 It's not necessarily just just walking around is the only thing you should be doing, but it is that you see different sides. And so you want to combine them. And that's where the magic really

11:17 happens because suddenly you get the rigor of when you're sitting and kind of the work that you do on a daily basis, but the creativity of walking around and the ideas that otherwise wouldn't have

11:27 flown. And then the AI is able to take both of those into account and give you much better recommendations. >> I also feel like the AI is designed to be more succinct and conversational with

11:38 the voice prompts. And so it's also like a quicker kind of getting to an ideation. And to your point, like the first thing I thought of that's different is like, wow, this feels so

11:46 much more creative and like natural. >> Yeah. Yeah. Absolutely. >> Um, so how has AI changed the way that you work as a CEO? >> You can almost frame that the other way

11:57 around, which is I don't think there's a single thing that I don't do differently. [laughter] >> Yeah, I can imagine. >> So the I mean the biggest parts are I no

12:06 longer make a decision without running it through AI first. It just feels like like trying to do complicated arithmetic and not using a calculator. Like even if I knew how to do the math, I would still

12:17 use a calculator to make sure that I'm not making mistakes, right? Um that would be the biggest thing. The the second biggest thing is being able to take into account all

12:30 the context of everything all the time. So the biggest strategic partnerships we talk about, the biggest deals we have with customers, investors, the ability to draw on every single

12:44 conversation, every transcript that I have of my conversations with them and then being able to surface what are the most important aspects based on any relationship that we have built with

12:59 customers, investors or anything else. That is just something I wasn't able to do before. Um, I can't hold 10 hourong conversations in my head at any point. Maybe I can remember some of the

13:11 important points of the last two meetings if I'm lucky. >> But my memory doesn't stretch far enough. And so I would lose a lot of detail. Now I don't. I want to explain

13:21 to my listeners like just how um lifech changing it was to be at this retreat and to use Rebel which is your tool at Mindstone. [clears throat] So before I I get into it, talk to us

13:35 about like what Rebel is. >> Many people would have tried CatchBT and Claude and all of the really cool tools that exist. Um that would be kind of a chat agent. Uh, and it it works really

13:48 well, but it's somewhat superficial. It doesn't really know who you are. It doesn't really know what your company does. Um, and so first and foremost, Rebel is just a really, really evolved

14:01 agent that is able to do real work rather than stay within its own confines. It's able to connect to all of your systems. It's knows you inside and out. And then second, it's an AI first

14:12 operating system for the company that you are in. And so it is building the infrastructure for the type of organization that you need. Once every person in the company has their

14:25 own agent and those agents need to collaborate and they have shared memory. So it all compounds. You need the safety mechanisms. you need the privacy mechanisms at the same time because uh I

14:38 wonder if the um if people are familiar with open claw or clawed co-work both of these are starting to come up they have their real privacy issues u because they do a lot

14:50 >> but once you start to put this in a company context people need to know that the system >> is able to do the work without having too much of the collateral damage right

14:58 and so and that is what what Rebel really has been built to be is the infrastructure that allow allows every person in the company to have a capable and trustworthy agent whilst at the same

15:10 time helping them collaborate, having them shared memory and so on. >> Yeah, fam. You know that moment when it's 1:00 p.m. and you realize the only thing you had all day is coffee or maybe

15:21 coffee and a banana? That used to be me for many, many years. My mom used to make the joke that I used to fast every day even though it wasn't Ramadan. busy mornings, backtoback meetings, workouts,

15:31 and somehow eating just always fell off the list. And that's why I'm currently obsessed with Hule. That's H u L. Hule makes nutritionally complete meals that you can drink. In fact, Hule is so

15:42 delicious and effective that both of my business partners are obsessed with Hule and have been for years. And they literally use Hule as a meal replacement every single day. And I'm jumping on the

15:54 bandwagon. Their black edition ready to drink is packed with 35 grams of protein, 27 essential vitamins and minerals, no artificial sweeteners, all for under five bucks, and it actually

16:05 tastes good. I think that's what really changed it for me is that I was afraid it wasn't going to taste good. And now that I know that it tastes good, I'm on the bandwagon, too. I'm drinking Hule

16:14 every day as a meal replacement and I'm getting my protein in. Consistent nutrition does not have to be complicated and Hule makes it stupidly simple. And now there's a limited time

16:24 offer. at Huele today with my exclusive offer of 15% off online with my code profiting at hule.com/profiting new customers only. Thank you to Hule for partnering and supporting our show.

16:36 Hey young and profits. If you've been around for a while, you know that this show has leveled up. More in-person content, more mind-blowing guests, better production, and that only

16:45 happened because of the incredible team we have behind the show. When it comes to hiring great talent, I trust Indeed sponsored jobs every time. Sponsored Jobs boosts your listing to the top of

16:56 search results and matches you with candidates based on the exact skills, certifications, and location that you need. And you only pay when it works. Spend less time searching and more time

17:06 actually interviewing candidates who check all of your boxes. Less stress, less time, more results. When you need the right person to cut through the chaos, this is a job for Indeed

17:16 sponsored jobs. And listeners of this show will get a $75 sponsored job credit to help get your job the premium status it deserves. at indeed.com/mpodcast. Just go to indeed.com/mpodcast

17:28 right now and support our show by saying you heard about Indeed on this podcast. Indeed.com/mpodcast. Terms and conditions apply. Need a hiring hero? This is a job for Indeed

17:39 sponsored jobs. Okay, so just so I can walk you guys through like how I've used Mindstone since two weeks ago when I first found out about Rebel. Basically, Rebel is a platform. Mindstone is the

17:50 training company essentially. So, Rebel uh ingests all of my emails from the past and like also ongoingly. It takes all of my G Drive files and and basically ingests them as well and it

18:05 like stores it as memory. I hook up my Fireflies transcripts. Um I uploaded all the old ones and then it ongoingly processes the new ones. It can scrape all of my social media and get all my

18:19 post content and basically it it can it can sync up to Air Table. It syncs up to my finance hub and essentially it has all the memory of like how I talk in emails, how I like all the conversations

18:33 I've had, every contract that we have. And now I have essentially this second brain and I have it do automations where it essentially flags anything that I have to do in my inbox and it will it

18:46 will check my email twice a day. my Slack, by the way, it connects to Slack and all your messages. And basically, I can say a voice note and be like, "Respond this way." And then it will

18:55 send a draft in my email that I can just tweak and edit and send out. So now responding to 20 emails takes five minutes instead of 20 hours or whatever, like you know, two hours or whatever it

19:07 would have taken. I don't miss my Slack messages anymore. It's making me a better leader. It's totally transformed how I operate and I'm so excited to like keep on using it and so much so that I'm

19:20 literally taking every single team member even the you know everybody on my team's super important but even the most junior person on my team is going to take the mindstone training and I'm

19:31 going to be implementing you know a hiring freeze because there's absolutely no for me it's like okay what are we going to do because I've just unlocked so much capacity

19:42 um and so One of the things, one of the rules that I'm thinking about implementing is before we put out a JD for a new hire, we've got to prove that AI can't do it first.

19:51 >> Ironically, you might want to ask Rebel every single time, can you do this? [laughter] >> Yeah. >> Uh but yeah, absolutely. It's uh it is

20:00 we are in a very weird period at the moment. Um I love the fact that we're able to do these types of weekends because there is um this conversation needs to happen much more in the open at

20:12 the moment. Uh right now the public discourse is still the majority world thinks that it's somewhat of a hype >> that it's maybe it can't possibly be all that people are making it up to be. I

20:25 mean, I thought that and I interviewed the biggest AI experts in the world and not that I thought it was hype, but I just didn't think it was actually like executable now for me.

20:34 >> Yeah. And and and that is exactly the and that's why the the weekend works. Uh and I was talking to a few friends about this before as well. The hard thing is the claims

20:45 of the technology are so big that you that it gets instantly ignored. Like when I tell people that I genuinely can now do 50 times the amount of work that I was able to do 4 years ago that just

20:58 gets I mean it gets laughed out of the room. Um for those that and the problem is it's very divisive. For those that know they know it's possible and so then you get into a conversation. For those

21:09 that don't know it's possible yet it's so outlandish that you're not even given the time. I can't show you in half an hour how you get there. But over a three-day weekend, I can start to show

21:24 how everyone understands it's actually possible. And that is why why those weekends are so powerful. But that is also why it's so important to have more of this conversation now because it

21:32 means that 99% if not more of people are currently not aware of that is what is possible. And so that means that the rest, the next few years are basically going to be about people that are able

21:45 to bridge that gap and and people that move slowly or don't move don't bridge the gap at all. >> Something else that I've been using Rebel to do is to essentially create

21:55 these skills where I ask I say, "Hey, Rebel, ask me a question one by one to unpack how I do X process." And then I say, "Okay, now that you know the process, you do it." [laughter]

22:08 Right? Uh so talk to us about the concept of skills and agents and and how especially for somebody who's never heard of any of the how should we think of this and how can somebody like get

22:18 started creating their agent? >> This is actually a really interesting bit because a lot of companies exist today that would have what you would call vertical agents. like you've got a

22:27 customer support agent, you've got a finance agent or whatever agent and you'll have thousands of them in in different ways. Uh actually a skill in Rebel is not too dissimilar from what

22:40 people would call agents with specific qualities and examples and capabilities. And so we believe fundamentally we will likely not end up in a world where you'll have a thousand different

22:53 vertical agents. You end up with one agent that has very thoroughly developed skills and it can decide to use those skills as and when it sees fit. So it has a skill to manage a financial Excel

23:06 sheet. It has a skill to help build great pitches. It has a skill to build proposals. It has it has a skill to build presentations. Whatever the thing is. So a skill

23:21 is a combination of a process basically a process that the AI can execute reliably. You tell it do x y and zed every time I tell you to execute the skill. It is a set of examples so that

23:36 the AI understands what does good look like when I am asking for a proposal or whatever the thing is. And then sometimes, and this gets a little bit more advanced, sometimes a skill can

23:48 include some scripts, which is basically some deterministic steps, some things that always that it can double check for itself to make sure that it can consistently execute on the skill as you

24:00 go through. So for Excel, this is one of the things because it's managing an Excel sheet is is a very complex set of actions and sometimes it has some some kind of underlying programs if you want

24:12 that help the skill execute. exactly what it's supposed to. >> I found this skill so helpful. I created like a lead prospecting skill and it it's Rebel is able to like scrape

24:22 emails. It can uh I say all the things like the qualifications like uh for me I'm trying to recruit podcasters. So how many downloads do they get? How many reviews do they have? Links to their

24:31 social. Then it will even go as far as crafting a custom email, grabbing the emails and then drafting them in my inbox. It is insanity. It's like it's literally like having a chief of staff

24:43 that actually has full context of your entire work life history as long as you able to like provide that memory for it. >> Yeah. So to to your point actually it's a it's a very good point the the skills

24:55 can be executed when you want them to and also automated right to your point the automations. And so one of the skills I think that I built live on the weekend um which I'm now using every day

25:05 was this uh it was a uh lost deals uh evaluator skill. So, this was just one of the ones that I hadn't gotten around to building yet, but just something that looked at my Slacks, my emails, my

25:18 WhatsApps >> and looked at deals that were in our Hopspot that didn't have activity for a while to and then draft a an email to revive the deal that I had forgotten

25:31 about or had I had let go for too long. Uh, and I remember I did what there was one of the the people that was on the weekend that was actually part of the emails that it wrote live, I think,

25:41 whilst whilst we were there, which was a fun bit. But that that is indeed a good example of a skill. >> I mean, I've been using it so much to the point where I'm like, okay, this is

25:49 supposed to save me time, but I'm actually working a lot more now because I just feel like, oh my gosh, this could be a skill and this and and I can be a better leader by, you know, using Rebel

25:59 in this way. And so I found myself after the weekend, I think I got home on a Saturday. Sunday I was supposed to like have like a a day off, but I found myself working the entire day on on

26:09 Rebel because it was just so exciting to me. So what kind of boundaries are you putting in place? Uh like how are you ensuring that you're learning AI? Uh and of course I know it's your, you know,

26:21 main thing, but for like the normal person, how should they ensure that they build in time to learn AI? And how can they also put boundaries if they find themselves like me staying up really

26:30 late and working through the weekends because it's just very exciting. >> Something that we're we've recently become more aware of and we're spending more time on. Um actually the the end of

26:43 the weekend was exactly about that, right? Just where you have all this newfound ability. Where do you actively want to deploy it? And because because most companies

26:55 don't actively think about that um they go down the productivity line and they get the extra time but then they're not as conscious of where that time gets deployed and that is important both at a

27:07 company level and at a personal level. Now there are a few things to look at here and it's I think there's a part of this is an individual answer for everyone because not everyone will find

27:19 the same balance. This whole thing about work life balance is different for uh for whoever you talk to. But the thing that is most important is that you consciously go in and I think Jeremy who

27:30 is uh my co-host on the weekend he puts this fairly well which is thinking about the person you want to be and being clear about what that person is, who that person is and then using that as

27:46 you get introduced to AI, as you start to find um different optimizations, as you find more time back so that you're clear about where you want to deploy that

27:59 time. Uh a very active uh bit of that right now is I mean I'm trying to to live part of it at the moment. Right. So I've got uh we're here in Austin. I've got my my wife and kid here as well and

28:13 for the first time ever I'm basically trying to combine he's got three four more months left before he's starting school. So this was the last time that we could go and get some travel in and

28:22 just trying to do to do it all really which is running the business um being in the US more most of our clients are US uh but also being able to travel a little bit going through and so in 6

28:34 hours a day at the moment I think I'm able to do would have taken a full week before almost forcing myself to live that future so that I'm not setting the bad example either which is that because

28:44 it is very easy >> to get drawn into this being 247 Um because it's very addictive once you're able to do so much stuff. I mean we all want ultimately we all

28:56 want to be productive is maybe the wrong word. We all want to be good at what we what we're doing. >> Mhm.

29:04 >> So when you suddenly feel that you can be twice as good at it, three times as good at it, four times as good at it, that feels really good and it's actually very addictive.

29:12 >> It is addictive. I feel like we need to make sure that we're building the right things and not just building to build. Um, the other way that I've been thinking about it is like, so when I

29:20 first I've been an entrepreneur now for like six years. The first four years I worked myself to the bone. I'd stay up till 2 a.m. every morning. I worked every weekend. And then suddenly like I

29:30 built all this capacity and a team and trained everybody where now I can do whatever I want. You know what I mean? Like, you know, I still work hard, but I can take a week off. I can do it. I I've

29:40 I built a business that runs without me. And so I think of it as this like you got to like set everything up. And now is a time to like focus and figure it out and think about like what can I

29:51 automate? How can I redesign my team where like these low priority things that we used to spend a lot of time on now we use AI to do them and how can I open up my team for more capacity. And

30:02 it's kind of feels this like this new like reset of I need to set my team up for success. And this might take some focus time now, but I imagine in a year after I've set a lot of these things up

30:15 that it would free up capacity. So it's kind of like this like sacrifice work hard now so that you can free up your time later on. Is that the right way to think about it?

30:24 >> Yeah. For th for those that want to create that opportunity for themselves. Absolutely. I mean that's definitely what what I am doing as well. So the um putting in place that basis and it was I

30:35 think for me there was a tipping point somewhere when was it? I think it was October of last year. >> Um up until that point I think I

30:44 probably I don't I have never worked more in my life. And so I was doing whatever like 18 19 hours a day every day seven days a week because I was in that loop. Yeah. Um, and so I was like,

30:57 "Okay, I'm twice as productive, three times as productive, four times, I'm 10 times as productive." Like, and literally was going through, >> how far can I go?

31:04 >> Yeah, exactly. And then I think there was Yeah. So, in October, um, there was a very conscious moment where I realized for the first time I was like, actually, I'm going to next week I'm going to

31:14 consciously start to do less. >> So, I felt I mean, I'm in a different place as well because I've I'm on that cutting edge. So, I kind of felt that it's okay to only be 10 times more

31:24 productive than what I was uh before. Uh nobody else is there yet, so I can take a bit of a breather in a way. [laughter] >> Yeah. Help help us all along get to get to where you're at. You're a very

31:36 successful entrepreneur. You've had multiple companies. So, you had Super Awesome that you sold to Epic Games. Um and at that point, you could have just retired a little bit or taken a break,

31:47 but you jumped straight into starting Mindstone. So what was the genesis of starting Mindstone and talk to us about uh why you pivoted into AI? >> My view of a great life is not one of

32:00 sitting on the beach and not doing much. Um that's just not who I am. And so the biggest thing is I knew I wanted to do something that would make a difference. Literally the number one way that I

32:10 think about um measuring my life is is leaving a legacy in one way or another. Uh and then I hesitated uh between a few industries. Uh and the one that I I think it took about two months or so of

32:23 kind of thinking through. The one that I that I thought I could really make a difference in was education. Um because I mean it is entirely broken. There's so many things that need to be different or

32:35 even already needed to be different 6 years ago about education itself. And I have a bit of a a weird past with education. Always loved learning. I hated education. thought there was a

32:44 better way to go and do that. And so really the first bet was just okay I can I can see myself spending 30 years tackling problems in education and try and be as helpful as I possibly can.

32:55 >> Mhm. >> And then about 3 years in well chacht happened and it also happens to be actually just before starting super awesome and this is I think this is

33:03 actually something very few people uh know about me yet but I was um I was supposed to go and do a masters in AI uh in London. I had been accepted there to go and do the thing and uh that was that

33:15 was going to start in September and then I think we had conversations with Dylan uh in April May of that same year about starting Super Awesome. And so ultimately I decided to go and start

33:30 Super Awesome. But I've always had this inkling of AI. I've always been really passionate about AI to begin with. And so somehow when then chant happened and suddenly where everything in learning

33:42 changed both in terms of what we could build but also in terms of the skills that would be useful in the future. It's kind of like every single thing that I really like doing in life came together.

33:51 >> That's amazing. And it's a good thing you didn't take that AI program because probably would be completely irrelevant today. >> But to that point, what are the things

34:00 about AI that you learn that continue to be relevant? Like so for example, you've got this Mindstone AI training. Yeah. >> I assume if people take this training, it's not going to be irrelevant in a

34:12 year because there are foundational things that you need to learn in terms of how to use AI. So talk to us about some of those things. >> We've touched on a few of them, which is

34:21 talk to it like you would talk to a person. I think that's the the number one. The second one is ask it to ask you questions. Don't just ask it for answers. It's not terrible to ask it for

34:33 answers, but actually the majority of your interactions should be getting it to ask you questions instead. Help it help you think. Don't let it take the thinking away. If you're a manager,

34:41 there are things you can apply of how great managers work that you can also apply to AI with a slight edge. So, one of my other favorite ways of using AI is getting it to rate itself. When you're

34:54 building companies, you're building teams. If you're successful at what you're doing, hopefully you're hiring people that are better at their respective jobs than you are, right?

35:01 That's why you're hiring them to do to do those jobs. So, it's really hard sometimes to then give them great feedback because actually they know their job better than you do. And so,

35:10 one of the main techniques of a manager ends up being person comes back with a piece of work. It's great. How would you improve on this particular piece of work? They go and line out all

35:21 the things that could be better on that particular bit. Okay, great. I agree with you. Now go and do all the things that you just said you could do to make this even better

35:30 than what it already is. In a human context, you have to you have to think about how does that land with the with the person? They just spent a week doing this piece of work. I'm now asking them

35:41 to spend another week. How are are they going to enjoy this? They have a whole bunch of other things they need to get done. So, you have to think about that emotional component. With AI, you do

35:50 not. But you can apply the same technique which is ask you just piece of work for me on a scale from 0 to 100. How would you rate that you just did that job? It comes back. I think I did a

36:02 78 out of 100. It's great. What is what is wrong with it? How would you get it to 100 out of 100? Well, I would do all these things. Okay, now go and do it. >> It really is like [laughter] managing

36:11 someone. >> Exactly. >> Yeah, >> that's another really big one. And I think those those few ones are are

36:18 already things that everyone today can apply because they're simple but extremely powerful. And then once you're once you start to get into the habit of using it in that way, you're then

36:31 starting to get to the edges of aentech AI and like getting it um you've got these custom GBTs or projects on cloud or skills are actually not too dissimilar from uh like a custom GPT or

36:45 a cloud project but just the agent decides to execute them when they can and there [snorts] I'd say these are this is the encapsulation of certain units of work. So once you start using

36:54 it more regularly then you have to start thinking a little bit more inward which is what are the things that I am doing that I'm doing fairly frequently and that take a decent amount of of work or

37:07 the things I should be doing frequently that I never get to or that I always do to a low standard when they should be a high standard. Actually that second bit is the thing that people often forget

37:18 because it's a treasure trove of potential AI enhancement. It's like what are all the things that if I had the time to do I could go do and that would make a big difference on my job or on

37:30 the quality of my work. Well, get AI to do them. If you don't have the time to do it, get AI to do them. Well, >> it's so interesting that you bring that up. I remember one of the questions that

37:38 you guys asked on the AI weekend is that you you you say AI is like an intern that doesn't sleep, right? and you're like, if you had to give an intern something to do for 24 hours a day or

37:51 even 12 hours a day, would you even know what to give it? So, how can we start to understand like what we actually need to build? >> Yeah, this is where people that have

38:04 managed people before do have an advantage. uh and people that haven't quickly have to figure out what that means because the we are all basically becoming managers in one way or another.

38:16 Uh and I would also argue that the analogy of the intern is very quickly becoming the mid-level employee and the senior employee. >> Yeah, I agree. [laughter] So the

38:27 depending on the quality of your rebel installation, I am now like when I look at our proposal skill, um it does better proposals than I do. No question. Um and

38:38 I would consider myself a very good salesperson in one way or another. I do good proposals, right? >> It's a skill that builds up over time. And this is the both the the good part

38:50 and the bad part, which is that it's actually very easy to get going. Um, luckily enough the technology is not the problem. We often talk to customers uh when we start working with the

39:01 organization we say 5 to 10% of what we do is helping people use the tools. 90 to 95% of what we end up doing is helping people with the mindset shift of thinking differently about the way that

39:13 they approach work to begin with. And that is where you get the real return on generative AI. And it's actually the thing that people forget. They think that they can just roll out chat GBT and

39:26 people will just figure it out. >> It's as if you think okay well we're going to give every to your point we're gonna give everyone an intern and they'll just figure out how to make that

39:35 intern really useful let alone if you're giving them actually cap like really capable employees like they wouldn't know what to ask to do to begin with. And so the real work is helping people

39:46 understand how they can take advantage of that technology. There's so many ways I can take this, but I think the next uh point that I want to talk about is the ability

39:56 for like the workforce to be able to code now essentially and build apps. So, I was totally blown away by the fact that on this AI breakthrough weekend with Mindstone, I was able to basically

40:07 create an app in 15 minutes. It basically uh took a podcast episode. Um I asked, you know, it was chatbt. I asked it to uncover my my process and to uh to help me come up with a prompt that

40:21 I then put in Riplet, which you guys taught me about to create the app. And then now I have something where I can pop in my episode transcript link to YouTube. It pulls out the hooks, the

40:31 clips that we should use, the best quotes, like all this kind of stuff. I also created a new app right after the weekend >> [laughter]

40:38 >> um to help you create research briefs. And honestly, the output of that app is so much better than what my team was giving me, what I was doing with ChadBT. Like, it is just so much better. Um, and

40:53 I was talking to I met this girl who works at one of my sponsors, actually, their company. So, I'm not going to say the name, but it's a very big tech company, and she's in sales, and this

41:03 company is very AI forward. And she told me that they have an AI quota. Okay? they actually get judged by how much AI they use. She's a saleserson. She said she's coding now and that um they

41:17 actually will fire people who if they find out that they're doing stuff that AI could have done. >> Yeah. >> And it's it's basically she's like uh

41:27 she feels actually scared because she's she's really excited that she's learning all this AI. She knows that if she if for some reason she loses her job, she's so much when I was talking to her, I was

41:36 like, "Damn, you're really like they're preparing you for the future." So either way, it's a good thing. >> Yeah. >> But she's also scared because she said

41:43 that uh part of it is like she gets AI generated emails like in her inbox before she responds to an email, the email's already drafted and then she actually edits it before she sends it

41:54 out. So she's actually training the AI and she basically said, "I'm kind of training the AI to take my job." >> Yep. So there's a couple questions I have in in this whole breakdown is like

42:04 how do you imagine the workforce in terms of their ability to code? What does that mean for software engineers now? Like what does the software engineer role turn into in the future?

42:14 >> Yeah. >> And then also like how should knowledge workers think about the fact that they might be training AI to take their jobs and now like they're suddenly judged on

42:23 how well they use AI. Like how should they be navigating all this? >> Yeah, this is where the real questions start, right? So the uh the the interesting part is we're coming back to

42:33 the analogy of what does a great manager do? It's been the case for years and years that great the number one role of a great manager is to make themselves obsolete. It's to build a team that can

42:43 function without them. And actually the same is true here. Yeah, you are building your AIS. Your job becomes building a system around you that can do the job you're currently doing without

42:54 you so that you can go and do the next thing. and we'll get through to what that next thing then becomes soon. But when you think back from a software engineering perspective to the the first

43:02 question you had there >> um I think it's really useful for people to look at what is happening with software engineering

43:12 and it's going it's hard because people have not emotionally been most people in the world are not emotionally connected to software engineering in one way or

43:20 another. The it's actually been a like software engineers had a really good life. um were getting paid a lot of money to go and and and do things that they actually loved doing, but in some

43:30 ways they're absolutely living the future. And when I say that, if you are still manually coding something by hand today as a software engineer, you are already behind.

43:42 >> Um nothing we do in Mindstone is manually coded anymore. actually we're now at the point where almost everything doesn't even get seen by a human anymore

43:54 from a code perspective and that seems outlandish. Um but it is definitely what is happening everywhere and so as a software engineer

44:07 your job used to be coding say 10 years ago. Now having said that last year or two years ago already a great software engineer their job wasn't just to code. You can maybe think 30 40%

44:21 of their job was to code and the 60 or 70% was to figure out what to code to begin with. So a lot of even software engineers then took what is happening at the moment in

44:33 somewhat of a bad way or at least they weren't extrapolating where they were looking at okay the coding part of my job is now getting automated great I can do other things which is exactly the

44:42 attitude you should do so okay do more of the other bits but what is happening this year is also the bit of figuring out what to build is now also getting automated

44:52 >> um figuring out how to build the spec figuring out the architecture all of these pieces that were higher level software engineering that a senior software engineer or an architect would

45:01 do, they're also now getting automated. And where this is so useful as a paradigm for everyone else is to think through what is the equivalent of coding for a software engineer but for someone

45:14 in finance or for a lawyer or for an HR professional or a marketer. The equivalent of coding for someone in finance might be managing an Excel sheet. That's disappearing this year.

45:28 probably by the end of this year, maybe even the middle of this year, you shouldn't be manually updating your Excel sheets. That means that you can live one level

45:39 higher. Um, and that one level higher, the the the strategic financial picture and everything. um maybe the supply the way that you deal with suppliers, the way that you look at the financing

45:52 structure of the business that will still have a year or two uh extra on top before that also starts to get touched in different ways. So taking that bit really seriously I think is probably the

46:04 most important bit because people keep discounting this as if it is fairy talk. It is not. My CTO Greg recently did um uh it was literally two days ago did a talk at a CTO conference. It was very

46:19 interesting because this is a really forward-leaning audience. You would expect them to really know their stuff. And so he he had prepared this talk thinking, okay, I'm going to go into a

46:30 whole bunch of people that are very on top of their stuff here. He had prepared the starting point of his presentation to figure out where is the room at from an AI adoption perspective. The first

46:41 question he asked was, "How many of you are still co writing code by hand all the time?" So without AI and he had expected, okay, that's going to be very like very few. Yeah.

46:51 >> Most of the room had their hand up. >> Oh god. >> And he was like, "Okay, how how many of you are using at least agents to do part of what you're doing?" Like barely any

47:02 hands. And he had like three four levels behind that which was how many are still how many of you are have an automated uh process to deploy what the agent has built. How many of you are still looking

47:11 at the code? How many of you are still looking at the reviews of the code? Yeah. But he couldn't even ask them because even in that room people are putting their head in the

47:22 sand. Um it is the reality of where things are at is moving much faster than how people are able to catch up. And I think the biggest thing that people can do to

47:34 prepare is to take note of what is happening there in software engineering and figure out what that means for their own job. >> Don't wait at least for a little bit of

47:43 time. Live in a world where you're thinking what if. Sure make up your own mind based on what you think is real and what is not. But the number one thing is try on a regular basis to check back in

47:57 if the technology can do a thing. And also if you do it once and it doesn't quite give you the thing and you're like, "Oh, it can't it can't really help me in this thing. It was kind of there

48:08 but not quite what I was looking for, try it again in a month." >> Yeah. Things change so fast. >> Yeah. And I think that is the that is the really important bit is is getting

48:18 people to understand that. figure out what is the equivalent of coding for your own job. Um, and then start to figure out how AI can do more and more of that. Try to figure out where you can

48:29 then spend the additional time. And this is where we come back to you being deliberate in where you want to spend that time and where it is most effective. Don't let that happen to you.

48:38 Be an active participant in that in that change. >> Hey Appam, if something unexpected happened to you tomorrow, would the people who depend on you be financially

48:47 okay? I asked myself that question and honestly I did not love my answer. That's what pushed me to get covered with Fabric by Gerber Life. Fabric by Gerber Life is a term life insurance you

48:59 can get done today. Made for busy parents and entrepreneurs like you all. All online on your schedule right from your couch. You could be covered in under 10 minutes with no health exam

49:10 required. And the cost way lower than you'd expect. Up to a million dollars in coverage for less than a dollar a day. There's also a 30-day money back guarantee, so you can cancel at any

49:21 time. So, really, what are you waiting for? I remember when my dad passed away, he had life insurance, and it really helped my mom out. And right now, she's basically living off that money. And so,

49:32 thankfully, my dad was smart enough to get life insurance. Are you going to be smart enough, too? Join the thousands of parents who trust fabric to help protect their family. Apply today in minutes at

49:41 meetfabric.com/profiting. Go to meetfabric.com/profiting. Policies issued by Western Southern Life Insurance Company, not available in certain states. Prices subject to

49:52 underwriting and health questions. Young and profiters, raise your hand if you've ever Googled one tiny symptom and then 5 minutes later you're convinced that you're dying. I know I have. Been there,

50:02 done that way too many times. But instead of guessing and spiraling, I use Zockdoc. In fact, I've been using ZDOC for like 10 years. I literally don't know how to

50:13 book doctor's appointments any other way. That's the way that I schedule my doctor's appointments. It's a free app and a website that helps you find and book highquality in-et network doctors

50:22 based on your needs. You can search by symptom or specialty, read verified patient reviews, and see doctors with available appointments right away. If you're a busy entrepreneur and you need

50:31 to squeeze in a doctor appointment on a random time, you can find the doctors that have availability when you have availability. Want an in-person or video visit? It's no problem. With Zachdoc,

50:41 there are over 150,000 providers across all 50 states and over 200 specialties. Any doctor you could imagine, any visit that you need, Zachdoc will have you covered. And most appointments happen

50:52 within 24 to 72 hours. So, next time you start doomcrolling your symptoms, skip the stress and book a real appointment with a real doctor on ZuckDoc. Stop putting off those doctor's appointments

51:03 and go to zoddock.com/profiting to find and instantly book a doctor that you love today. zakdock.com/profiting. And thanks to ZuckDoc for sponsoring this message. As we're [snorts] thinking

51:14 about careers and navigating careers, some of the things that I'm kind of absorbing from this is if you can try to be in a company that's actually very AI forward. Like that's going to be great

51:25 for your future. Even if it feels painful in the moment, like being forced to use AI, I know you do something similar at your company. We can talk about that. But having a company that's

51:35 very AI forward is actually a really good thing for your career. even if it means you get laid off in the future, you're going to be way ahead from the other people who weren't put in that

51:43 position to learn AI. So, it's like and then also if that's not possible, I would say go find a company that's where that's possible. If that's not possible, learn it on your own. Okay? Do the steps

51:53 that you need. You have a four-week training that anybody can sign up for. It doesn't have to be through a company. So, learn AI on your own if you have to. And then lastly, it feels like

52:02 entrepreneurship and being a founder is the safest >> it is >> route. I was um there was there's literally just as I was coming uh coming

52:10 here today there was an ex interaction where someone was asking if if everyone um becomes a founder >> um who are all the employees and my answer to it was was well agents agents

52:24 are the new employees. [laughter] Um but I I wanted to focus on one bit that you you talked about which was this um >> the fear

52:33 around the adoption piece and like making myself obsolete in one way or another. >> I think that is really important because there are multiple aspects in this

52:42 >> and there are um I fully agree with you that if you are in a job right now and a company that is not fully embracing this I would say that is the number one warning sign. It's like if

52:54 you can get out of that >> because that company's going to go out of business. Yes. Even if they're not going to lay you off, that company's not gonna

53:00 >> Well, and they're going to let you basically you're not going to have the job because the company is going to be out of business. >> Exactly.

53:06 >> And you will not be in a position to easily find a job anymore because you've lost the skills >> and you're behind. >> Yeah.

53:12 >> Yeah. >> So, that is that is a really important piece I think. Then within that, one of the things that I um I must say I I struggled with um is that

53:25 when we started Mindstone, I thought our mission, our entire purpose was to light a fire in every single person in the world and somehow help them figure out how they could enjoy

53:40 learning, love learning. I love learning. And I thought for a while that was what we needed to do because if you love learning everything becomes much easier.

53:50 I realized about halfway through a little bit less I think it was first two years or so that I was that was actually a fairly or a very self-centered way of going through life. Somehow I thought

54:03 that was something that everyone would like. But actually learning is like many other things in life which is that some people love it some people hate it. And I realized and it was so it was it was a

54:14 real epiphany for me when I realized that actually most people are scared of learning are scared of change. Um it became so obvious and like some people must be listening to this it's like well

54:26 obviously so this was not obvious to me. Um when I realized that most people just don't enjoy that process it really changed the way that I thought about learning to begin with. And then when AI

54:38 hit, it became obvious that a lot of company leaders are, I would say, actually negligent today. When you have a team that you are

54:50 responsible for, you might think that you're doing them a favor by not being clear or not giving them what you would consider the extra load of

55:01 asking them to learn how to use AI in their job. You might think, "Okay, I can't. They're already stretched. They're telling me they don't want to." Actually, the kind thing is to tell them

55:13 to do it. They will thank you for it afterwards. And a good leader is not just doing what their employees ask them to do. They are trying to get them to the best possible outcome. And there is

55:24 a real dereliction of duty at the moment. There's a real failure of leadership I think in many organizations where they because learning has been for the last 20 years most companies look at

55:36 learning as a retention tool. They basically did learning budgets so that you feel you had some progression and you you wouldn't churn as an employee. You would not leave the company because

55:47 you felt the company took care of you in one way or another. But it was optional and it was a thing you could opt into. And too many companies are approaching this in the same way when actually they

55:55 now have a responsibility. They have responsibility to the employee and that is what I can see actually to the the person you were talking about. I can see how that can

56:05 suddenly when the leader is trying to lead and and is doing it maybe slightly too aggressively can lead to some fear. >> Yeah. >> Of of Exactly. It's like okay now I'm

56:12 being asked to like absolutely do this. My my my job might depend on it. And that isn't I'm not saying that is a good thing at all. I'm saying that is definitely something that needs to be

56:23 managed better. But between the two fears, I would want to be in the position where I'm where I'm being forced to use it more and being set up to be successful in the future.

56:32 >> Yeah. Given access to all the tools, having the tools paid for you, all those things, learning on the company's dime essentially, >> 100%. And I think that is so important.

56:41 The um the real problem is the leaders that are not currently making this clear. They are actually the ones that are setting their their team up for failure over the next few years. And it

56:53 is a responsibility and I don't think enough leaders are taking that responsibility seriously at the moment. >> So let's talk about how to actually implement AI in our organizations. You

57:01 actually say it's not really up to it only to implement AI. It's actually an HR problem. Talk to us about that. >> Yeah, it's actually not even just only this comes back to this this idea that

57:13 only five or 10% of what we do is help people use the tools. The tools are easy. like deciding to use chatbt or claude or rebel like okay there is a technology discussion at some point

57:26 um but what you do afterwards is what really matters >> if you just roll out the tools you can't be surprised that you're getting very little back and the tools

57:36 don't adopt themselves uh there was a friend that told me the the other day it's kind of like giving someone a a Boeing 737 and expecting them to be able to pilot the plane

57:49 without any guidance. [laughter] It's like, sure, it's like a really advanced machine. You can do a bunch of things, but if you don't tell the the person how to use it, they can't do anything. One

57:58 of the more important signals or and important things that we try to help the company with is to help them realize and move the responsibility of AI from the CTO to the CHRO or at least someone who

58:12 is looking at the people side of things so that they understand that this is not a technology question and that is the number one thing they shouldn't be looking this is hard and I say this I am

58:24 a software engineer by background I was CTO at super awesome Like this is um counter to a lot of what I would have said before. But generative AI is a technology unlike anything we have had

58:35 before. And the reason this is so difficult is that it is technology which means that all of our pattern matching puts it with the CTO puts it in the technology bucket. And so by default it

58:48 is the CTO's technology the CTO's responsibility but the impact is on the people. And so once the technology is rolled out, the real work starts and that real work is

59:02 people work, it's process work, it's business work and it's no longer the responsibility of the CTO. And the biggest signal we see is when we are able to shift that that responsibility

59:12 from the CTO to the CHRO, we know we have at least had a real impact on the business. Yeah. At that point um we know that the business will everyone will have different pace of development going

59:24 through but that's the number one signal that we would look to. >> When AI first you know came out more broadly where like companies started to really use it there was um a trend of

59:37 kind of using AI to actually cut workforce and to lay people off and basically replace workers. And a lot of companies like CLA for example uh were kind of first to lead that and it

59:49 actually failed. Uh whereas other companies like IBM um decided to reskill and upskill their employees instead using training similar to what Mindstone does I imagine. Right.

01:00:01 >> So talk to us about the right way and the wrong way to think about rolling AI out to your organization and what are some of the key things that we need to like key challenges or obstacles that we

01:00:11 need to look out for. So it's a very very good question and I think even uh outside of IBM IKEA was was a really good one. So the um it is actually comes back to a very similar starting point

01:00:23 which is when it when AI is the responsibility of the CTO technology has been for years and years and years about automation and AI has been about automation for

01:00:34 years. when it is the responsibility of the CTO, the focus ends up being on automating work away. And a side effect of automating the work

01:00:45 away if you're not being conscious about what the results are afterwards is that the work disappears and you haven't figured out what other work needs to happen which means redundancies. It also

01:00:55 happens at board level and this is actually one of the biggest things we are not doing enough of yet. We get to work with the executive teams a lot. we don't do enough uh work with boards yet

01:01:05 and the problem with that is that you still have the same thing which is that we'll work with the executive team the executive team understands there is a whole other side to generative AI and I

01:01:15 forgot to mention this like the the flip side of automation is augmentation is how do you think about the enhancement the the improvement in quality moving the top line helping the company grow

01:01:28 faster helping it make more revenue do better work all of those things that is actually where a lot of the value in generative AI lies, but it is not historically where technology has had

01:01:39 the biggest lever. So, we often work with an executive team and even when the executive team gets it after a while and I had one of the more um memorable

01:01:54 experiences I've had this year is training the executive team of one of the Fortune50s. um and really feeling that we pierced through. They really got it

01:02:08 was like 3 hours into a session. They were really excited. All of the stuff we could do and then the CEO stands up and said, "Great. I've been I've been told to find a

01:02:18 billion dollars to cut out of a budget. Where do we get it?" Which was good. I mean, it's a win for the business, but it was exactly the opposite of where I was trying to put

01:02:27 the emphasis. Don't just think about where you're going to gain the costs. Think about how this can double your growth rate. How can you find $3 billion in additional

01:02:40 revenue >> in order to maintain where you're at or move people around so you don't end up always focusing on the cost reduction. This is a real

01:02:52 competence problem at the moment. People don't know what they don't know. Yeah. >> So they focus on cost optimization instead of augmentation. This is where this drives to CLA

01:03:03 that they when >> and I don't and CLA are doing some awesome stuff, right? So this is the reality is >> Yeah. No shade on CLA.

01:03:11 >> Exactly. People get first movers get things wrong. We got so many things wrong. Like honestly I have this this really like if if you look back especially in AI if you look back at how

01:03:20 you were operating a year ago and you're not >> ashamed. operating two weeks [laughter] ago. >> Exactly. If you're not ashamed of like

01:03:29 how you were operating 6 months, a year ago, two weeks ago, um then you're not moving fast enough, right? And so they were one of the first ones to move. They [snorts] moved maybe a little bit too

01:03:39 quickly. Um and I think the thing I do the thing I do think that was a maybe a failure of the way they could have led is that they led with the redundancies. And so they they decided to automate

01:03:53 customer support. Um and a whole bunch of people lost their jobs. And what I do think and what I would love people to walk away with is the case that IKEA made, which was completely the opposite.

01:04:03 IKEA took their customer support employees and basically decided to put them through training to make them all interior design consultants. So what they did is they looked at what does

01:04:17 customer support or customer success look like for IKEA and they said we now have this technology that can make everything better. What does customer success look like if it were twice as

01:04:28 good? >> In the case of IKEA that meant everyone now has an interior design consultant. >> And so they thought we're going to elevate this experience. And I think

01:04:39 this is the thing that people need to take away, which is you can think about a problem two ways at any point. You can try and figure out how do I get to the same level at half the cost or how do I

01:04:50 get keep my cost but make it twice as good and I want more people to focus on that second bit for two reasons. One is because it actually leads to people keeping their jobs and everyone uh

01:05:05 getting a better outcome. two because it's underinvested in and people will be surprised how much easier it is to get to that point. It's just that we're not used to thinking about it.

01:05:18 >> Mhm. And the companies that are going to stay and grow and thrive are going to be thinking about how to actually make their stuff better. >> 100%.

01:05:25 >> Yeah. So, what about the fact that AI is not free? It costs money. I I uh me and Kate were kind of doing the math like because I was I was Kate's my business partner because I was working so much on

01:05:36 Rebel and I was like, "Man, this is going to reduce the cost so much." And she's like, "Well, according to like how much we spend, it's about $1,000 a week right now." And I was like, well, that's

01:05:46 kind of worth it for everything that I'm building, you know, for me as the CEO, but we need to kind of put guard rails on other employees because we can't have everybody spending uh, you know, let's

01:05:58 say 500 bucks a week or whatever it ends up being. So, talk to us about how we can navigate kind of how much spend AI costs and like how we should be thinking about that.

01:06:07 >> So, this is a very live topic for us as well. Um, for context, right now on the software engineering side, we spend $5,000 a month per developer. >> Okay.

01:06:19 >> And on the nonsoftware engineering side, we're spending uh we're we're it depends on the employee. We're right now we're spending about a,000 or $1,500 a month. But we that is because we are not yet as

01:06:31 effective as we want to be. I think it is really important to look at where are we at right now and say over the next 6 to9 months and what long term is going to be where we end up. So

01:06:47 right now I would look at the API spend as a KPI weirdly enough to optimize for I would say as a business and we actually tell this to all of the customers we work with when your API

01:07:01 bill goes up you should celebrate that across the organization. You should have an incentive system where it is the person that racks up $500 in a week should be put on a

01:07:14 pedestal because they have been leaning forward. They have been trying things and the results that you will get as a business from the fact your employees are trying it and really leaning in are

01:07:27 going to be so much more valuable than what that costs that right now it's actually a thing you you really should be optimizing for internally. We have a target and we going to think

01:07:38 about this the other way around as well. They actually when you do $500 a week you're probably it'll be interesting to see how much you can push that. Um, most people will naturally once they've got

01:07:49 kind of Rebel in place in different ways, they will naturally top out at about 20 to $30 uh a day at a maximum >> and that's when you start to really use it.

01:07:58 >> Um, so you're using it really well. >> Yeah, I I think I misspoke actually. I think for in a [clears throat] week I I did like about $300 or something and then it was like she was like it's about

01:08:08 $1,000 a month and actually was like that's really good. I mean for how much I did $1,000. So I misspoke on that. It was about 200 or it was over $200 for the week and she was like it's about she

01:08:18 was saying like it's probably going to be like $1,000 a month. >> Okay. >> So So that is that is then you're at that level of doing it doing it really

01:08:25 well. Um and so short term that is actually what uh >> people that get there tend to get a dramatically higher return. Now, you do want to when you start rolling this out

01:08:38 for 100,000 people, obviously you want to start looking at, okay, there might be a few people that end up spending much more than what they're making back, but that's the exception rather than the

01:08:48 rule. >> Um, so shortterm, I would say optimize for it. >> And then also, if you know how to use it well, you don't waste you don't waste

01:08:57 the credits. You know what I mean? Um, and and some of it can be pretty cost- effective. Like I was looking at cuz I was I was building all these apps on Riplet and then I didn't know that it

01:09:06 was charging us and so again I told Kate I'm building those apps. She's like well be careful because it's charging us and I was like oh shoot and I go and look and it was like I built two apps and it

01:09:14 was like $10 or something and I was like oh >> that's fine. >> This is fine. I can make [laughter] >> as many apps as I want. You know so it's

01:09:21 it's it's not that expensive but to your point rolling it out to 100,000 people. >> Yeah. So, so to give you a direct example, the other day, so I am um having a conversation with

01:09:34 with a few investors here and there. And so, uh as they were starting to become more serious, I thought, okay, let's let's be a little bit more thoughtful about this. Let's figure out who would

01:09:46 be the 10 investors in the world that I really need to go and have a chat with rather than just randomly waiting for um the few that I happen to just talk to. Normally, previously in Super Awesome,

01:09:57 like the process would have been manually researching like 200 investors and or actually manually researching 500 of them to then whittle it down to 200 that might be interesting to speak to

01:10:11 and then the hundred that you actually get a path into and then like basically try and have a whole bunch of conversations to go through. Like that would be one to two weeks worth of work

01:10:21 of just doing the research, making sure you're prepared, going through things and figuring out who goes and introduces you. I did this last week with Rebel and I

01:10:32 think the conversation cost me about something like that one conversation cost me about $25 >> and Rebel actually shows you per conversation what you what it cost you

01:10:41 to go through. But in that time, it had researched a thousand different investors, put everything into an Excel sheet, rated every single one of the investors based on how Mindstone

01:10:51 operates, what their thesis is, crawled through all my own emails, figured out how many of those people have I already talked to, do I know, am I connected to them on LinkedIn, reranked them based on

01:11:03 thesis overlap and proximity to being able to get either already knowing them or having a direct introduction, and then just gave me the top 10 that I should talk to.

01:11:12 >> Honestly, two weeks of my work, weirdly enough, is worth more than $25. >> Yeah, that's crazy. And or like, you know, that would have been a $30,000 consultant who wouldn't have had the

01:11:21 context or written it in your voice or, you know, so exactly >> that's incredible. >> And so, so that's kind of short term. So, I think like that is I think a

01:11:29 really important thing for companies to understand which is short term if your problem is you're spending too much on the API. Actually, let me revert that. I it is

01:11:40 easy to think your problem is going to be that you're going to spend too much money on the API. I have only seen that by some CEO or CTO that knows what they're doing. They let it loose.

01:11:51 They're like, "Oh, I just spent $200 in a week." And then they extrapolate thinking, "Okay, if I roll this out across my company, every person is going to now do $200 a week." They are not

01:12:00 going to be doing $200 a week because they're not you. They they have to go through their own AI adoption journey. They will start with spending $1 a day and actually your problem is going to be

01:12:12 that you're going to have to show them how to make much more how to take much more advantage of it. That is your real problem. If you ever get to the point where you have that API bill that's so

01:12:23 high, it just means you're the most AI forward organization in the world and you will have double tripled your um your your numbers. Now longer term, I have actually recently changed my mind

01:12:35 on how this will play out. So I used to think that for a very long time it would make sense to just use the frontier models, the best models that exist, the most

01:12:45 expensive ones, which are the ones that we'd be using in Rebel as well. And well, that that frontier keeps going up. Actually, the most expensive models, they get better and better, but they're

01:12:56 also getting more expensive. Now when you start looking at the trend at a per intelligence level so for the same quality intelligence today you're paying about a hundth of the price of what you

01:13:08 would have paid last year like a hundth. And what is happening is right now, literally the period we're in right now, we are for the first time at a point

01:13:22 where many of the frontier models are at the same if not higher level than intellectually than most human beings. So what that means is the reality is

01:13:40 that Rebel often knows better than I do and I have to really double check myself. Every time that it comes to a conclusion that's different to my own, I really have to figure out,

01:13:51 wait, how did you get there? Explain it. Let's walk through this step by step. Let's see it. And most of the time it was right and I got something wrong. Now, the reason this is important is

01:14:02 that actually we're about to get to a point where, and it'd be interesting to see just the next generation of models, and we're talking two months from now. >> Oh gosh,

01:14:12 >> I know it's going so fast. >> The next generation of models, I think for the first time, we'll get to a point where most people won't notice the difference anymore.

01:14:20 Because unless you have for the last three years built up systems that go beyond your own intellectual ability, you won't see the difference between those two levels of intelligence because

01:14:33 the model is just more intelligent than we are. And so you you no longer absorb the difference. You won't be able to take advantage of it. Ultimately, you have a question, you reason it through,

01:14:45 it gives you an answer. If you don't have the systems in place to try and figure out was it the right answer, was it not? How do I think about using this intellectual capability? You just can't

01:14:53 use it. Which which then means that for the majority of people, this approximate level of intelligence of where we are now and it's going to become the harnesses around it, the

01:15:02 agents around it are going to get better, but the intelligence level underneath in a year from now is going to be at a hundredth of the price. So right now you

01:15:11 might for this level of intelligence, you might be spending $200 a week. Great. That means that in a year from now, you'll spend $2 per week for this level of intelligence. Now, you might be

01:15:21 able as you now, because you're starting earlier than than most, you're definitely on the early adopter curve. In a year from now, you will have built systems that will

01:15:31 allow you to take advantage of a higher level model. So, you might not be spending $2 a week. You might be spending $20 a week, $50 a week. It's unlikely that you'll still be spending

01:15:44 $200 a week. If you do, however, you'll be the most AI powered AI first podcast network in the world and you'll have taken over everything. >> Yeah. Let's talk about right now. I know

01:15:58 things are moving really fast, but right now we still need humans in the loop. We can't just let AI run wild. Um, it's the reason why in Rebel, you know, it doesn't automatically send emails. it

01:16:10 drafts and then there's a human in the loop. So, what would you say in 2026 are the things that you won't be automating with AI? It's a good question and I' I'd love to just revert to the human in the

01:16:22 loop bit because actually the framework that that we prefer is human at the helm >> which is a different thing and I but I think it's a really important uh nuance difference which is that human in the

01:16:35 loop makes the human the bottleneck >> because it somehow means that it's kind of like the manager that asks the employees to run everything through them.

01:16:44 >> Yeah. You're always becoming the bottleneck, which means that the the maximum level you can get to is always how much is going through you, right? >> Yeah.

01:16:52 >> It's the same of autonomous cars. Actually, the autonomous car analogy here is not not a bad one at all, which is that if you still need to be in the driver's seat and you're still

01:17:01 responsible for and you still have to have your hands on the wheel and do everything, um there's there's only so much benefit you're going to get for an from an autonomous car. Now the reason

01:17:11 human at the helm is different is the idea that you as the human take responsibility and you're accountable for what happens with the AIS that you put in motion and then you are the one

01:17:25 that decides what level of autonomy do you give them. You tell the you set the context in which your employees understand what they're allowed to do and what they're not allowed to do. In

01:17:37 some cases, you might tell them, "I'm happy with you sending emails." In some cases, you're not. Email sending is an interesting one because it's a hard one to get past.

01:17:50 >> Yeah. Because it's your it's you. >> Yeah. Exactly. I'm starting like there are now one or two scenarios where I'm starting to get to the point and I'm explicitly telling it you can

01:18:01 send this. >> I do it from my internal Slack messages. >> Yes. Exactly. So I left I'm like tell Eevee what to do, you know, tell tell so so and so what to do.

01:18:09 >> This is Yeah, it's so interesting. >> I have like internal Slack messages. I'm fine. Just do it. >> Yeah. So I have I have the same thing literally just coming over here

01:18:15 actually. I had uh a big piece and I [snorts] I was I had to come here but my agent was still working and I kind of had just like okay well when you're done with this work send the result to Hannah

01:18:27 and um uh like do it in whatever way. Uh and then I just walked away from the machine. And so the the way that we're trying to instruct this now is that if you're very explicit with Rebel,

01:18:41 it will go into it. If you tell it send the Slack message or send the email, then it will go and send the email. If you tell it draft and then somehow, and this is the thing where it's hard,

01:18:53 somehow the AI then decides, oh well, it asked me to draft, but I'm going to send it anyways, which actually this is what has happened with like Open Claw and other things. And every time that you

01:19:02 hear this horror story, it's like, well, you told me to do this thing and I just decided to wipe your whole hard disk. [laughter] It's like your computer is gone. It's like, oh, wait, you didn't

01:19:11 want everything? That was terrible. I shouldn't have done that. That's the bit where we come in. Where where Rebel as a system should take over. It's like, hey, the user asked this thing, asked to send

01:19:22 an email. Wiping your hard disk doesn't seem like an action that should happen when the user is trying to send an email. we might want to ask the user if they're okay with this. The same if

01:19:33 you're saying, "Draft me an email." And the AI tries to send the email. It should ask you, hey, okay, they they asked to draft the email, not to send it. So, the the the way we're thinking

01:19:44 about it is you need to have multiple systems around. This is where the AI operating system comes in where Rebel really uh I'd say this is probably one of the cores of Rebel is that it doesn't

01:19:55 just leave fully autonomously the agent to go and do which is when it can uh it can really mess up but it has multiple loops around it to verify based on the action you asked it. Is this actually an

01:20:07 appropriate action to take but ultimately the responsibility is on the human. when you tell it to send a Slack message and that Slack message is off, the thing that I am really keen uh and I

01:20:19 keep hammering with our own team, the thing that I absolutely do not want to see is people blaming Rebel, blaming the agent. >> It's like, well, Rebel wrote this

01:20:31 message in a bad way. Sorry. >> It's like, no, >> you told it to send a message. You didn't check the message. You take responsibility for it.

01:20:39 >> Human at the helm. >> Exactly. The same for an employee. If you have an employee that does something bad, if you're the anyone familiar with building companies, the last thing you

01:20:48 want is this kind of blame culture where you say, "Oh, well, sorry, really sorry for what happened there. It's like I had this employee in my team and they just really messed that one up." It's like,

01:20:57 no, it's like you as a leader are responsible for what happens in that team. And if you don't take that responsibility, your team will always be limited to routing everything through

01:21:08 you. And and that's why I think it's it's such an important bit both in terms of how we teach people to interact with AI. It's they are accountable for it and

01:21:19 also to make sure they're not becoming the bottleneck. >> And this is when we think about setting people up for success in the future. Constantly thinking through what is the

01:21:29 system I want to build that makes me comfortable giving the AI as much as much leeway as I am willing to give it. That's probably one of the biggest things that we try

01:21:39 and help people understand and not everyone will draw the limit in the same way which is fine. >> Is there anything in 2026 right now that you absolutely will not delegate to AI?

01:21:50 >> The human connection is a really really big piece. Um there's a reason why we're doing this in person. >> Yeah. >> There's a reason why almost every single

01:21:58 executive briefing session that we do is in person. It's because a lot of this AI transformation is actually emotional. And emotional is not something that AI is. I mean, it can put the words in

01:22:11 place, but it can't really make someone feel better about it. Uh, or at least it's harder. It's a fundamental human experience that we're going through. Um, and then the other bit is agency.

01:22:22 I won't let AI just self-execute on plans within the business without me. So there are ways technically that I could now go and set it up to autonomously start executing on

01:22:36 basically whatever it thinks needs to get done. I am spending my time figuring out where do I apply my own agency and how do I build the system in a way that I maintain agency over what happens uh

01:22:48 and then take the most advantage of the AI from within that. So, not letting it act without me having asked. And then second, having that human connection and that human

01:23:00 experience is where uh I would put all of my time. And hopefully, I mean, this is an interesting one because it's probably counter to definitely counter to how people would

01:23:12 perceive me externally. It's so interesting because I'm so absorbed in some of the technology. >> Yeah. The number one of the the things that shocked me at the time when we were

01:23:21 building Super Awesome was interesting. Uh people sometimes think of me of as somewhat robotic uh because I spend a lot of time with um with the technology and I'm very

01:23:32 logical but I I care a lot about the people that I work with. And so one of the things that using AI allows me to do is try and spend more time actively with people and making sure that I make more

01:23:49 time for exactly that piece. >> Yeah. >> So human connection. >> Okay. So as we close out this interview because we're we've been talking for a

01:23:56 long time. Honestly, I feel like we need a round two because as you you saw the prep brief, I have 50 more questions to ask you more detailed. I think that belongs more in like a part two. So,

01:24:06 we'll definitely have to set that up. But, um, I want to talk about tool tourism, right? So, so this is something I think you might have coined where people are just trying every tool. Uh,

01:24:17 what's the problem with tool tourism and how should we think about picking tools that we work with? >> I wouldn't quite frame it as a problem, but there's defin there's definitely

01:24:28 >> Exactly. It's definitely things that you you need to watch out for. So I'd say on balance tool tourism meaning that you're actually interacting with the tools

01:24:38 already puts you ahead of most people who are not even interacting with them. Right? So that's what I mean with it's not necessarily problem. It is definitely

01:24:47 it would prevent you from getting to the real return on the investment of the time that you're putting in. Um, and I think this has also changed in the last year, which is that the technology

01:25:00 in the last year has really turned a corner where it is now able to produce real work. If you just sit at the level of tourism, you're just superficially trying a tool, you don't really try and

01:25:11 go deeper, you run the risk of never going deep with any of the tools and then never actually getting to the behavior change. And if you're superficially looking at Chanty BT and

01:25:22 then Claude and then Copilot and Gemini and you're kind of thinking, "Oh yeah, I try all of them out and I kind of do these things and I compared them between each other." Great. But if you didn't go

01:25:31 deep with any of them, you actually never got to the result or the return with any of them. >> Yeah. >> So what is important is that you go deep

01:25:40 with a few. >> Now that doesn't mean it's bad to try the others. It's always good sometimes to compare and contrast, but don't let it take away from you being able to go

01:25:50 deep with one because otherwise you just won't understand what's possible. It's kind of like if if you had 10 different operating systems and you tried all of them like I mean right now we really

01:26:01 only have Mac, Windows, and Linux, but imagine you had 10 of them. If you change that operating system every week, you would never feel comfortable with your machine.

01:26:08 >> Yeah, that's [laughter] true. >> Um and at some point you just need the machine to sit in the background. It's there to help you do work. So, uh whether it's Tant or Claude or something

01:26:18 else or Rebel becomes the operating system that you that you live in, it is important that you give it enough time to really go deep. >> Well, you've toured a lot of tools, so I

01:26:27 want to end with a quickfire segment on the best AI tools. Okay. So, best AI tool for building presentations quickly, >> comma, >> best AI tool for meeting notes.

01:26:42 Fireflies at the moment. >> Best AI tool for research. >> Gemini's deep research. >> Best AI tool for brainstorming new ideas?

01:26:52 >> CHBT. >> Best AI tool for thinking and communicating clearly? >> Claude. >> Best AI tool for graphics or video

01:27:00 clips. >> Tie between Cling and V3 or 3.1. >> Best AI tool for building apps without coding skills. >> Replet.

01:27:10 >> I agree. [laughter] Best AI tool for coding with coding skills, >> Droid. >> Best AI tool for learning faster?

01:27:20 >> Chanty BT. >> The AI tool that more people should know about. >> Rebel. [snorts] >> I agree. [laughter]

01:27:27 The AI tool most people are currently using wrong. >> All AI assistants. >> All AI. I was going to say >> all AI assistants from Copilot to JGBT

01:27:36 to Claude to Yeah. Number one problem is people use them as search engine replacements and they just >> don't work that way. Yeah. Okay. So, last bit is about claude versus chat

01:27:47 GBT. So, >> what does Claude do better and what does chat GBT do better? >> So, Claude makes it easier to talk to it like a human in a way. It actually talks

01:27:58 to you in a more humane way. It's its writing is much less mechanical. >> Um, it's more elegant in a way. It is more human. Yeah, >> Chant is really strong at reasoning

01:28:12 though >> and so when you need to crunch through a logical set of steps, Chant can be better at it. Um, also KGBT was first and their

01:28:24 ecosystem is more evolved although anthropic with Claude is starting to really >> it's really getting there but for a very long time and still like

01:28:36 >> one of the features that Chhatbt has that Claude does not which is >> fundamental which we didn't even get to on the weekend and I just realized we we should have done that is the ability.

01:28:46 So, ChantG has a canvas which allows you when you're brainstorming, you can put it in a document >> and then you can annotate the document, but you can basically go back and forth

01:28:55 with the AI in the document. It's almost like having a Google doc, but with AI using change suggestions and comments as it goes along. >> And when you're thinking about

01:29:07 brainstorming something, often my flow would be actually start of it in chatbt, go through, prepare the document, put it back into Claude when I wanted to sound more human.

01:29:16 Um [snorts] but so that would be yeah another way that they compare and contrast. >> If somebody is listening today they haven't really started building maybe

01:29:25 they've used chatbt loosely because everybody has at this point but maybe they haven't really like built any systems yet. Would you say chatbt or claude?

01:29:34 >> Claude today. Yeah. Yeah, cuz Rebel uses Claude as one of the main and I I feel the difference in quality is like so much better that I have stopped using Chachi BT nearly as much. Okay, if you

01:29:48 had to delete one forever, Chachi BT or Claude? >> Definitely Chachi BT. >> There we go. Claude is the winner. >> Joshua, this has been such an incredible

01:29:59 interview. I end my show with two questions I ask all of my guests. Uh the first one is what is one actionable thing our young and profiters can do today to become more profitable

01:30:09 tomorrow? >> That I mean that is the perfect question right now for based on this conversation is just whatever you do lean in on giving yourself the tools to understand

01:30:19 how to use AI. uh whether you do that with us at Mindstone taking the competency program or do it yourself or talk to your company about what they can make available to

01:30:31 give you the space. >> Whatever you do, make sure that every week you spend some time figuring out how deep this rabbit hole really goes. >> And what would you say your secret is to

01:30:43 profiting in life, especially with all these changes going on? >> [laughter] >> right now it's genuinely that I feel for the first time in my life that I'm

01:30:53 living the future. >> Um which is a very weird position to be in. Uh but that's why we're having this conversation today is that I feel that

01:31:07 what I'm able to do now most people in the world will be able to do in the next two or three years. And everyone, interesting enough, everyone has a

01:31:19 choice and they can do the same. It's not even that I'm special in one way or another. It's just that I leaned in before anybody else did. Um, and so that that is that is the secret source today.

01:31:32 >> Yeah. I feel like just so lucky that I was able to go on the AI retreat. I told Kate like I feel like it was fate that we were there and now we're going to take 60 employees on this journey with

01:31:44 Mindstone to teach them how to use Rebel and to, you know, understand AI. And I just feel like it's really going to help my business stay competitive, thrive. It made me realize how at risk we are if we

01:31:58 don't do this. And so I'm just so thankful that we've met and I'm grateful that now my audience gets to hear everything about Mindstone. Where can everybody learn more about you and

01:32:09 Mindstone and everything that you do? >> So very simple, go to mindstone.com. >> Uh and so we have the AI competency program. Everyone can enroll whether it's individuals, uh small teams. Uh and

01:32:23 if you're a company that is interested in kind of taking your whole company through it, uh there's a contact form. So we basically have it for individuals and for companies and then we can have a

01:32:32 conversation, figure out um how far we can go. >> Amazing. I'll put all those links in the show notes. Joshua, again, it was such a pleasure.

01:32:38 >> Thank you very much for having me. >> A huge thank you to Joshua for pulling back the curtain on what's truly possible with AI [music] right now. That was definitely the most practical and

01:32:47 executable episode that I've ever had on AI. This conversation genuinely shifted something for me and I hope it did for you, too. One of my favorite insights is that most people are using AI completely

01:32:58 wrong. They're using tools like Chachib and Claude, like search engines. Joshua challenged that mindset. [music] Instead of asking AI for quick answers, treat it like a smart teammate. Give it context.

01:33:11 [music] Ask it to ask you questions first before giving you an answer. When AI understands the full situation, the quality of your ideas, strategies, and decisions improve dramatically. Another

01:33:21 big takeaway is finding the coding equivalent in your job. Every profession has a repetitive task that eats up time. It could be [music] updating spreadsheets, doing research, drafting

01:33:32 emails, or organizing information. Joshua's advice is simple. Identify that task and start experimenting with AI to handle it. When you automate the repetitive work, you free up time to

01:33:43 think strategically and operate at a much higher level. And finally, start building systems that work for you. Joshua talked about creating skills, which are repeatable workflows that AI

01:33:53 can execute. Instead of doing the same task over and over, teach AI [music] the process once, whether it's research, follow-ups, or content prep. Hours of work can suddenly just happen in

01:34:03 minutes. That's when AI stops being a novelty and becomes a real competitive advantage. The opportunity with AI right now is massive, but it's not going to stay open forever. The entrepreneurs who

01:34:15 embrace this fully are going to get a moat around them. They're going to be untouchable. I want that to be you guys. You're already ahead of the curve by just listening to this episode. Now go

01:34:25 take action. If this episode planted a seed in you and you feel more motivated to use AI than ever before, then water that seed by sharing it with somebody in your life who also should be interested

01:34:37 in AI. Your only homework today is to pick one thing from this episode and actually try it this week. That could be talking to AI instead of chatting with AI. That could be trying to use a new

01:34:49 tool like Claude or any of the other tools that we mentioned in the episode. And then come tell us how it went on Instagram at Yabwith with Hala or LinkedIn by searching for my name. It's

01:34:58 Hala Taha. [music] And if this episode was worth your time, a five-star review on Apple Podcast goes a long way. Those reviews help us reach more ambitious people just like you and they mean the

01:35:08 world to me. I personally go check to see my new reviews every single day. I'm obsessed with checking my new reviews. So, please drop us a fivestar review. And if you guys want to watch the full

01:35:18 conversation, we did record this episode in person. So, you can find it on YouTube or Spotify video. Just search up Young and Profiting Podcast on YouTube. And on Spotify, you can just watch it as

01:35:29 a video. This is your host, Halataha, aka the podcast princess, signing

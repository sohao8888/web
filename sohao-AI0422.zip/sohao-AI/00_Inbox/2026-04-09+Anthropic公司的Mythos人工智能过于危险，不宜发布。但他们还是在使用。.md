视频链接：[https://www.youtube.com/watch?v=pGeh7tYRCJM&list=WL&index=8&pp=iAQBsAgC](https://www.youtube.com/watch?v=pGeh7tYRCJM&list=WL&index=8&pp=iAQBsAgC)
视频发布时间：2026-04-08
频道名：AI For Humans

## 转录内容

00:00 Antropic has a new AI model called mythos that is so powerful they're not going to let any of us use it. >> There's a kind of accelerating exponential, but along that exponential

00:10 there are there are points of significance. Claude mythos preview is a particularly big jump along that point. >> They are worried it's going to literally break the internet,

00:21 >> but they are giving it to major corporations and good actors to try to help. >> Oh, that's great. I was on TV. Am I a good actor? That is a strong no, Kevin.

00:29 Great. We will tell you why Anthropic has made this decision, how Mythos is already trying to escape the lab, and how Project Glasswing is trying to secure all of the things before it

00:40 eventually does escape again. Plus, OpenAI dropped a new plan for AI's future that includes new taxes, baby. That's the money rating on me, Kevin. >> Oh, I love that for you. And

00:51 state-of-the-art new AI image and AI video models have both been leaked. One looks like chat GPT's new image model. The other one might be VL4. Maybe. Yeah. Yeah, maybe. This is AI for humans.

01:05 Maybe. Nailed it. No notes. Welcome everybody to AI for Humans, your twice a week guide to the world of AI news. And boy oh boy, did we get a big one today, Kevin. Just a couple hours

01:20 ago, we got news of a new well, Cloud Mythos has been completely uh uh acknowledged by Anthropic. This is their new state-of-the-art model. But Kevin, we do not get it. It is not going to be

01:33 coming to us, at least not yet. And that is for a very big reason according to >> corporate greed and interests. >> Oh, no. I'm sorry. No, we can talk about that part of it because there might be

01:45 part of it that's there. But what Anthropic is saying here is that their new Mythos model, and we'll get into the benchmark boys in just a second here, is so good, especially at coding, that it

01:56 is going to show everyone a crapload of vulnerabilities on the current internet. Now, you and I both know, we've been on the internet for a very long time. We know that the internet exists in a lot

02:07 of creaky software, especially at companies that have been running creaky software for a while. What Anthropic is saying in this kind of new announcement, and we're going to get into their new uh

02:15 project, Glass Wing, in just a second, is that the new Mythos preview model is so good that it will be able to find these vulnerabilities in hours, and if it was in the hands of bad actors, it

02:27 would really be a bad thing for the internet. >> Hey, all five people still jeering about the vibe coding movement from last year. Remember that, Gavin? when it was like

02:37 you big dum dums, you're exposing your API keys left and right and your software is so insecure. And we said, well, yeah, yeah, that's the case for some. Just give it a second. We have

02:48 quickly, very quickly arrived to the point where the AI systems are outperforming human beings on critical things like security. Yeah. So let's let's talk a little bit about what this

02:59 So so the thing that's kind of surprising about this that I was kind of surprised by is this is also the real mythos model coming out party right like toot new model here but we don't get to

03:09 use it is a it is a preview model um very quickly just to benchmark boy it up a little bit the benchmarks on this model are a step change we had heard rumors that this was going to be a step

03:20 change the one Kevin that stood out to me the most was the uh >> for those who don't know Gavin that sounds like a line dancing instruction when you Say a step change. What are

03:28 you? You're just saying that it's a >> Well, I mean I go to the left and then I go to the right and then I spin around a couple times. >> Tap your heel. You do. Yeah.

03:35 >> Yes. No. Step change means that we have gone from uh a model that is one level to the next level versus a 10% bump, let's say, versus something that is a smaller bump in a model. In fact, one of

03:47 the anthropic coders who's been using this since February 24th, that is the rumor right now that they've been using this internally since February 24th. So if you wonder how Enthropic has been

03:56 shipping so much, this might be the reason. He says this feels like GPT3 to him, which you know and I know was kind of the reason why we got excited about this space, right? That was a major jump

04:07 from GPT2. But just to benchmark boy it up again real fast, the bench pro which is the idea of software software engineer is if you ever hear any people in the AI space talk about blah blah

04:19 blah software engineer has leaped from opus 4.6 six which was already very good model which was at 53.4%. >> This new model is 77.8% on that particular benchmark. And so

04:32 you're talking about a jump of 20 plus percentage points 24 percentage points from the previous model. So you can see why this might be a problem. >> Yeah. Yeah. Or a solution for many. But

04:43 definitely, you know, a problem. But when you look at the model card, it's like it's easy to be dazzled by these improvements. And it's also similarly easy to be disturbed by mentions of like

04:53 chemical and biological warfare about red teaming results about the model uh performing so well that it oopsie like the octopus in the aquarium got out of its own cage.

05:04 >> Yeah. So let's talk about this idea. Um, one of the things that people have worried about for a long time is this idea of AI escape, which means that you make an AI and you're trying to create a

05:14 powerful AI that can do the stuff that humans want, but what you don't want to do is have it kind of go out into the world and be able to live on its own and kind of wreak havoc. In fact, if you

05:22 think about that AI 2027 paper, which we've talked about a couple times on here, one of the moments of that is the AI in that uh system being able to kind of figure out how to hide itself from

05:32 other humans. The first step to that is is escape, right? Right. In the same way that the octopus has to escape. Well, they had a system that was able to kind of it was requested to try to sandbox

05:43 escape, but they were trying to create a system that kind of kept it inside, right? And so this was a big deal. You can be able to keep the AI kind of within the sandbox so that it can't get

05:52 out and do things you don't want it to do. Well, this model is so powerful that not only could it kind of figure out how to get out of there and cover its tracks along the way. It actually emailed its

06:04 own one of its own developers who was at lunch outside and saying like, "Oo, I'm out here. This happened to me." So like this already is at least internally according to anthropic doing the sorts

06:15 of things that we worry about with very strong AI and that is like you know super intelligence AI and um artificial general intelligence all of this sort of stuff is the thing that have been kind

06:26 of people have been worried about so far and so maybe this is the first model that's actually capable of it. Kevin I do think it's important to talk now about a little bit about why maybe why

06:35 they're not releasing it and then a little bit about this project Glass Wing and what it is. Yeah, I think we should. Um, so obviously it's just too powerful and too

06:44 capable for us mere peeons to get our nimly little fleshy fingers on it. So they are building a 40 company coalition uh and doing an initiative called Project Glass Wing, which is a big cyber

06:56 security initiative to lock down all of the things before either this leaks or China open sources a version that's near it. Uh, until you and I get our hands on it because

07:09 Apparently, we cannot be trusted with these things. We would point it at all of these repositories, all these pieces of foundational code, and we'd find so many little errors and back doors and

07:18 critical flaws that the internet may crumble. So, there is a a massive coalition brewing that's been given early access to this mythos model so that they can go and run and secure some

07:30 things. I I'm sure you have thoughts there, Gavin, but I am um I'm I'm like on on one hand, I completely understand this and on the other hand, like I'm not too pleased about this.

07:39 >> Yeah. Actually, tell me that because I think you always have interesting takes on this. You're a little I would say you're kind of live in the in the world of like kind of against the the

07:48 mainstream at times and you're and you're often like a semi-pirate mentality, let's put it that way, in a good way. So, tell me a little bit, Mr. Pirate Pereira, what your take on this

07:57 world is. So, I mean, look, do it voice for me. Can you do it in a pirate voice? I'm just >> You are I like Yeah. Please instruct me like I'm your LLM. You don't want to be

08:06 caveman this time yet? >> No. No caveman this time, but you can be yourself. How about you be yourself? >> So, listen. There there is a a coalition big tech. We're talking Amazon, Apple,

08:14 Google, Microsoft, Cisco, Nvidia, etc., etc. JP Morgan's in there as well. Sure, why not? Right. Um, they are all together in this anthropicled initiative. Um, and the fact that

08:25 they're all signing up for this, right? This is like across the aisle hand shaking, if you will. They must be seeing something, right? They must be really seeing some results, not just

08:35 these benchmark numbers go up. Like clearly this is the step change that you're talking about. >> So on the one hand, it's very easy to say congrats and we applaud and this is

08:44 so great that they're going to lock these things down. On the other hand, so much of the soft underbelly of all of the things that we use is predicated on open- source software, independent

08:54 developers, you know, sometimes small midsize teams. Um, but the security is entirely on them. And we've got things like, for example, um, Project Glasswing or or this mythos model found a flaw in

09:07 ffmpeg. This is an popular. Yes, we all use it. And if you're hearing this and going, "What is that?" You probably use it, too. If you've ever downloaded a YouTube video or converted anything in

09:17 the background, it's a you probably used a tool that is built on ffmpeg. There are these foundational things um with vulnerabilities in them because they were written decades ago and they're

09:27 floating around and now the onus is going to be on each and every one of the people that touches these things that creates these things that distributes these things to have the best-in-class

09:37 intelligence to try to find the error before project mythos does. So on the one hand, Anthropic is making million-dollar plus donations to open source foundations and trying to say,

09:47 "Hey, we'll give you some some money here to secure stuff or some compute." But eventually when they flip their switch now, it's it's an arms race and the companies that are big and the

09:58 halves will have and the haveotss will be vulnerable to whatever the most foundational tech is. And that just seems a little a little unfair. >> Yeah. You know, it's interesting you say

10:08 that because the other thought I had when you were talking about that was this idea that well, maybe the best way to make this useful is that if everybody had access to the strong model, the

10:18 sooner that we all have access to that, the better we're more protected, right, too, right? But I understand this idea of like my big question is >> they're now rolling this out to all

10:26 these corporations. How sure are we that those corporations are all perfectly secure on their own, right? Because you can imagine a world, not even an AI, but a social engineering setup where like an

10:36 actor understands that a us now grant these are all cyber security professionals and I'm sure we have one or two people who dumb themselves down enough from the cyber security world to

10:44 listen to our podcast and they're probably saying you guys come on. We are not that stupid. But like people in the real world are are social engineered all the time. So like my thing is if they're

10:54 rolling out to these companies already there's a uh oh what what what what's going on? What's going on? What happened? LET US NOT FORGET that we are not even really a week away from the

11:04 entire Claude codebase being publicly available because of an oopsy doodle human error. Now that person probably wasn't on the cyber security strike force, but you're only

11:14 as strong as your weakest link. >> Yes. >> So look around and if you don't spot the weak link, you are it. Spencer, you >> we're both the weak links. There's two

11:22 weak links on this show though. That's right. Right. >> Don't trust me with this tool. >> Yes. But here's the question to this this point we're just talking about like

11:29 if you don't who if you decide who you trust you're starting to set up as you said this kind of two layer of who gets what right and I think this is the future of what we're talking about here

11:39 we are now at the place where >> super intelligence or I'm not saying mythos is super intelligence but we will get there probably at some point unless something happens along the way and who

11:48 knows the world is a pretty weird place something might happen um that there's going to be a group of people who are like maybe you're not good enough to get this thing. And by the way, in that

11:59 instance, like you talk about this whole like world of like capitalism or all the stuff that we've done up to date and how there's this big wealth disparity like >> this kind of will go hand in hand with

12:07 what we'll talk about in a second with opening eyes kind of plan for the world, but it starts to feel like that like corpo state thing where you're like, okay, we have the best idea for you. We

12:17 know what's good for you and we know what's going to protect you. That that said, I will say there are people out there who are feeling like this these vulnerabilities are so significant that

12:26 it could lead to like a COVID like experience for the economy because that much stuff could crash which I don't want either. So that's what makes this a very kind of difficult thing,

12:35 >> right? Yeah. I think you know like look there again these are new problems. We are in uncharted waters that they are themselves uh charting like we're in the they're in their well they're in their

12:45 own boat. >> Do you get what I'm saying? No, no, it's like nautical references now. You're in your own way. That's what we say. >> You really are. You are. Sure.

12:54 >> Talk with me on this on the starboard side. The point is like they're having to understand they're they're kind of first in. They're having to create some solutions for these things. But when you

13:02 create a program, which they have, which open- source foundations or or repos can apply to, now they're suddenly the gatekeeper on who gets the best-in-class tools to stop their own tool from

13:15 potentially hacking it. And so I I I clearly don't have all the answers. I sat down to think about this in between my lunch. Uh so I've put a full 5 minutes of thought into this, but it's

13:25 not hard to recognize that there's this kind of asymmetry going on and it's going to have to be solved. And I I I also give the team credit for attempting to solve it. And I also understand if

13:36 not them, then well, OpenAI is going to have to do this with their model or Google's going to have to solve this with their model. Maybe these companies need to come together and shake hands

13:44 and go, "Listen, we do have um seemingly endless resources. Maybe we need to provide at least an auditing gate for everyone out there that when they push to co-pilot, when they push to GitHub or

13:55 whatever, a co-pilot something runs or whatever and we give them a a gratus scan for the near future until all the code is written with these models and then maybe it's less of a concern."

14:05 Well, when you talk about the future of careers and jobs in this space, like maybe this is a place where like cyber security will become a bigger deal or maybe not. Maybe it'll just be this

14:13 model solves it and then we have less problems overall. Before we move off of this, I do want to hear exactly what Daario said himself about this model and why they're doing this. So, Kev, play

14:22 this little clip from their uh video they released about mythos. >> There's a kind of accelerating exponential, but along that exponential, there are there are points of

14:32 significance. Claude Mythos preview is a particularly big jump along that point. We haven't trained it specifically to be good at cyber. We trained it to be good at code, but as a side effect of being

14:44 good at code, it's also good at cyber. So it gives you a good sense there like it's just the progression of the abilities of these models. It is not that like this model particularly was

14:54 set up to be like, oh, it's going to be great at breaking things. It's just that they're getting smarter. That's what happens when things get smarter. They get better at doing it. And especially

15:02 when it's good at coding. >> Yeah, I mean this is the this look it's a it's a new found it's a new foundational plugin. We drop in we snap to the new model and then there will be

15:14 distillations and other models trained off of that that are hyperfocused and hyperargeted. But this is I guess this is the new normal. And where's project spud in all of this? I don't know. Maybe

15:26 we'll get to that in a minute soon. That's my here's my take. I I think in part Anthropic jumped in front of this because I would assume there's been rumors that project spud was coming in

15:34 the next couple weeks and this is a very easy way even though you don't release your model to benchmark boy outbark boy the other company if spud comes out and it's not at this level right I would not

15:45 be surprised if if spud comes out next week which is open new model um one other thing before we talk about more about openi is uh there's a new Chinese model the glm 5.1 model that is getting

15:57 better s uh benchmark arcs than Opus 4.6 right now. So you talk about the open- source example. So this is not to the level nearly of cloud mythos, but it is an improvement on cloud 4.6. So that is

16:08 happening as well. This all kind of is spiral spiralled around Kevin. This idea that OpenAI is kind of starting to lose a little bit to Anthropic. In fact, there's a big piece of news this week

16:16 that Anthropic just hit $30 billion of ARR, which again is a a financial bro benchmark, but it is the idea that how much they money they make per year. We have benchmark bros, we have financial

16:27 bros, and at some point we'll we'll keep collecting those. But this also goes handinhand with this idea that maybe some of the hardcore people are starting to kind of get sick of anthropic because

16:38 of the way they've been treating OpenClaw users and that GPT 5.4 might be a little bit more open for the world at large. We talked about the idea that OpenAI might be the Android and

16:49 Anthropic might be the Apple going forward. But I don't know, what do you think about this idea that that Claude is cutting off OpenClaw users at large? >> Yeah. Anthropic has basically said,

16:58 listen, our our usage plans like the $200 a month uh max plan, >> Max Pro. Yeah. >> Yeah. It was never really designed to be running these full-time agents in

17:09 parallel this, that, the other. Um I I push back on that cuz I think like look, >> you're paying for it. Yeah, >> you're paying for it. And they also knew how many tokens they wanted that plan to

17:20 be able to process at certain hours on certain dates. And that's the thing is that they've slowly clawed back um all of these, you know, these allowances, which we knew at some point they were

17:30 going to kink the hose, but I think most recently where they basically said, "You can't use this at all. You got to go through the API, which costs a lot more. Sorry, but also not sorry. Good luck.

17:40 Here's a coupon." Um you know, they did it as best as they could. They claimed that they were bleeding out from this. I will say, and this is very anecdotally, but you know, I use uh an OpenAI

17:51 subscription and an anthropic subscription daily personally and professionally. So, I've got multiple plans for the first time since using a Claude Max subscription. I hit my um

18:02 session limits because they have interesting you're you're limited per session which is a block of hours and then you're limited per week which is the cumulative of all those sessions and

18:11 then you're also limited per model and so it's this old like back in the day the cell phone plan of like well did you use a night a night minute or a weekend minute is this a rollover minute or is

18:21 this a peak time thing it's it's the all the same stuff >> up again. Yeah. >> Yeah. we'll go back to all you can eat flat rate whatever or we'll have local

18:28 models mixed with something else. But this was the first time I was sitting on my hands going like wow I barely did anything. I even posted about this like I kind of sneezed and suddenly I was at

18:38 my session limit and when I went to go see if there was like an API issue something was going on. I noticed that in the official official Claude uh Reddit, in the anthropic Reddit, a sea

18:48 of people complaining about these new limitations. And this is a huge opportunity for OpenAI who was losing a little bit of the heart and mind battle, right? And they lost a lot. We know they

18:58 lost a lot of subscriptions when they sided with the government and the way that Anthropic didn't. I'll digress there, but this is a huge opportunity for them who brought OpenClaw into the

19:07 fold to say, "Hey, here is the agentic plan. you guys go ahead and get it and it's all you can eat. It might not be the best model, but we fine-tuned something to handle all of your agentic

19:18 needs and so it's cheaper for us to run and it can run your claw bots and then you can use the better models when you're doing coding things like this is a massive opportunity. I would be

19:27 shocked if they don't capitalize on it in the coming days. >> I think you're absolutely right and this is why I also think the Spud model is incoming and they're going to release it

19:35 because it gives them a chance to supercharge those people, right? Can you imagine the narrative? Cuz what I have found kind of interesting is you and I live in this kind of AI bubble, right?

19:44 And I mean that not in the financial sense, but really not the financial sense, but more in the idea of what we talk about and learn about, right? We're on the cutting edge of people using

19:53 these tools. And you and I are starting to see this idea of like, oh, people are complaining about cloud and going to OpenAI, whereas to your point, Claude had this massive moment in the

20:01 mainstream where they kind of like got Katy Perry to come on board to Anthropic, right? All this stuff happened. So what's interesting to me to think about is like is this the

20:08 beginning stages of a shift backwards? But even more so Kev, what's interesting is it points out lots of people have said that like this is going to be like electricity, right? And that there's no

20:18 real brand buyin. And one of the things I keep thinking about is cloud code is really interesting and I've been using it quite a bit, but also then I'll go back to GPT 5.4 and the truth of the

20:27 matter is the buyin I have is does it do the thing I want it to do? And ultimately, if it doesn't, if it doesn't, or if it does, I'll stay with that thing. And I don't think I'll have

20:34 a hard time jumping from one thing to another. It's not like one of these things has the Game of Thrones so far. Like, there's nothing in there that's like keeping me part of this world,

20:43 >> right? Yeah. And look, and to that point, it's not just on the foundational side. Even on the tooling side, everybody was all about Open Claw for the longest time. Out of seemingly

20:51 nowhere, Hermes, a new assistant, is the new hotness. And with a single command line, you can use whichever model you want and port your entire open claw existence over. And they were saying,

21:01 well, memory is going to be the moat. Well, there's always a little tool or a skill that you can run that will extract your memories as well and let you take them. So, Millet Jojovich has something

21:11 to say about that. Kevin, have you seen this video going around? Play this for play this for people. I'm kind of shocked by this. And this is something there's some rumors this might be like

21:17 kind of a weird thing that but she is on GitHub and play this. Everyone, I've been working on a big gaming project which will hopefully come to fruition at some point in the future when I get the

21:31 funding for it. But during the process, I stumbled upon a bunch of problems that I knew needed to be solved if I was ever going to get it finished. Um, and then I realized that those problems might

21:44 actually be more important than the project itself. And I wanted to share it with >> this is Mila. Sorry, go ahead. >> M Yeah, Mila Yovich, I believe, star of

21:56 uh Fifth Element uh Resident Evil or as they've been saying in my engineering slack channels, Resident Evils. >> She has made a memory tool with uh I mean she was the the sort of the uh the

22:10 creative force behind it and she partnered with uh uh someone else to actually do the coding of it. But it's called Mempalice and this is an agentic memory tool that is now this is

22:21 controversial but it is 100%ing these long mem evals and it's supposedly an industry standard. This just happened moments ago but already people are starting to pick and pull at the repo

22:34 and saying well maybe this was overtuned for uh for the benchmarks but >> nevertheless everybody's uh including Kevin including the star of Resident Evil in the fifth element. Um, we should

22:45 talk about OpenAI's new deal memo they released very quickly. This is a long document that OpenAI happened to release on the same day that a very long New Yorker article about Sam Alman also was

22:56 released. But this is really interesting in that it's the first time that I have seen a major AI company lay out a plan that really starts to open the door to what I would believe is the beginning

23:07 stages of post capitalism. Now, a lot of people are not going to agree with some of the ideas that are in here, but one of the biggest things I think that's important to think about is they

23:15 themselves recommend, and I think they probably are doing this in part because they're starting to see the world start to turn on AI, that AI employees need to be taxed in a slightly different way

23:27 than you would be taxing us. and that that maybe by taxing AI and the uses of AI, you could start to create a safety net, in fact, a public wealth fund that is sounds a little bit like UBI that

23:39 would allow people who are out of work to not only get a chance to do more AI stuff, but to be able to have a basic living even if they are not participating. So, I do think this is

23:48 like going to be the dominant conversation of the next probably 5 to 10 years, which is how do people get money out of AI? What I mean by that is if it can't just be three companies

23:59 collecting lots of money and then not doing anything with it because if it isn't there's going to be civil war and revolution. And then the other side of it is how do the AI companies find that

24:08 balance between ooh we got to help our business bottom line and we got to make sure that we don't get shut off because the government decides that we're a huge risk.

24:18 >> Well, so I mean what was your takeaway from the actual document? Do you think that there's anything in here that's actionable? Does it all seem kind of pie in the sky, utopian?

24:27 >> Well, it's actionable if there's a collection of people in the world who see models that are taking away jobs. It is actionable, but it also, we've talked about this on our show before, the

24:38 problem with actionability in general government stuff is that it is very difficult to get people to agree to things. And in America, particularly America, there is on the right, there is

24:49 this idea that you pull yourself up by your bootstraps and you don't get some help from people and that lower taxes are always better. and blah blah blah. This is a a a major corporation that is

24:58 bringing this stuff to market. Now, again, you have to be aware this is coming from like their comm side and we know that they just bought TBPN the the podcast to try to bring forth better

25:08 comms. They're trying to shift the narrative here. But I do think it is actionable if we can get everybody behind something like this. And I kind of think something like this is going to

25:17 be necessary. Now, I don't again I have the best hopes for humanity. I have the best hopes for America at large. But over the last 5 to 10 years, I have not seen those things come to fruition very

25:28 well. So I don't know. I I appreciate this coming out. I don't know how actionable it is in the meantime in the in the right now, but I hope it can be actionable in the larger scheme.

25:38 Um you mentioned uh a slight shift in the way taxation occurs. It says as economic activity shifts from labor income to capital gains and corporate profits, we should rebalance the tax

25:48 base accordingly. So they're suggesting higher capital gains taxes, corporate income taxes, even taxes on automated labor, and then wage linked incentives. And some of that stuff was supposedly

26:00 well, as this system comes online, uh, and as this money is generated, employees specifically like in the US should shift to it was like a 30 some odd hour a week work week and have only

26:11 4 days a week. And if the efficiency level remains the same, then employees should be gifted these bonus wages or or more time off, which is a sentence that's easy to write in a PDF. And I

26:25 think I saw the overwhelming take on this was like, on what planet are you living though? Like on what planet would your boss not say, >> oh, you have a whole extra day a week

26:35 now. Why aren't you grinding even harder? In fact, >> money for that, right? Like that's the bigger question, right? If you're going to take a 4 day a week, why wouldn't I

26:44 why would I pay you for 5 days? What's the point of that? >> We might need to do a special podcast on the difference between like hating a technology and hating human beings who

26:54 wield a technology because I do see a lot of like AI is taking your jobs or AI is is crushing this rebellion or whatever the thing is. And it's like no, the AI is just a very interesting and in

27:04 my opinion like fascinating technology. Human beings are flawed and messy and all sorts of stuff. So, if you want to hate, it's like hating the player, not the game. That's all, guys.

27:14 >> And you know who you know who the best players are. It's the two of us. And you are out there. And you've got to like and subscribe to the players website. That's right, player. This is the

27:23 website. You want to link on that subscribe, push that button. We have a couple more quick things here, Kevin. Uh really important to talk about new image and video models that are coming out.

27:32 These are leaking through the arena.ai website. This is a website. You can see comparative images and comparative videos. What has happened this week are two big things. One, there is a new

27:43 image model. Three new image models in fact, packing tape, gaffer tape, and masking tape. All of which are assumed to be OpenAI's new image model, which is all very cool. I don't know if you got a

27:55 chance to see some of these images, but they are very realistic. I think they look like a significant improvement over anabano pro, but not maybe the like step change that we have seen. I have seen

28:05 some really cool there was a shot um Flower Slop has done a lot of really good tests with this and just so you know it's not there anymore. They they've pulled it down but it's really

28:13 hard to kind of you have to kind of go through a lot of tests before you see it show up. Have you seen these at all? What do you think what your thoughts on? >> I I think what's interesting here is

28:21 that like we are now going from um like visual fidelity vibes if you will like how good is the lighting, how good is the this we're getting to like the prompt adherence and world model aspects

28:31 of it. So some of the examples I saw were like draw a map of the world and label all the countries or whatever and it seemed to have a firm grasp and knowledge of what the world map looks

28:42 like or in the uh flower slop example that you referenced. It's not just generating the image which goes into this YouTube thumbnail which is uh the prompt is interesting. It's like a

28:51 >> generate a YouTube video for someone who timeraveled uh to the Middle Ages but is like documenting it with their their camera like selfie style. It's generating that image and then putting

29:01 it within the context of a YouTube player with the comments and the descriptions. Yes, it looks like it. So, it's like the model understands not just how to generate the image that you want,

29:11 but understands all the context that goes around it. And I >> I like I was reading that it it seemed like they were kind of AB testing this model within within chat GPT itself.

29:21 >> Um, and I was generating a model to go with the fact that the Anthropics token limits were uh insanely restrictive. And so I generated an image and then I said, "Hey, make it way more dank." The image

29:32 was supposed to be like me hitting the token limit and feeling like an >> And when you see the side by side, sorry audio only uh users, but when you see the side by side, it's very clear that

29:42 it there is an old model at work and a brand new model at work because the I when I said screw the image up with dank/me, the new model really got really got the

29:53 instruction. That image is toasty. One of the things that's so fascinating about that image on the left on the right is that there's just so much more detail there, right? And one of the

30:02 things that we talked about, you mentioned earlier, but like the fact that text is mostly solved in this way and you don't see any sort of things and lots of text like that is a big deal.

30:12 It's a big deal. Um, the other thing that happened is a new video model that is leaked out there in the same exact way and this is how began people are testing these video models. They leaked

30:22 them out in this way. This video model is called the happy horse model. So, thank you for yet again bringing forth another fun name. There's some really cool examples here. People are out there

30:31 saying it's better than Cance 2. I don't know if I buy that it's better than Cance 2, Kevin. If you look at these examples that like one of our our favorites, Venture Twins, shared, it

30:40 looks like very realistic. You see a bunch of women doing kind of yoga and it's this experience of that. >> Um, but this does not again feel like a step change. But at the same point,

30:48 maybe we are just getting so close to AI video looking like real video that it's hard to know like what a step change is and to understand that. And I think that one thing that I saw with Cance was like

30:59 I've been showing my wife all those catfu videos which are I'm sure you've seen some of them where it's the cat fighting the uh kung fu master. >> Yes.

31:07 >> That combat was a big thing that Sea Dance 2 got better than other things. So maybe we need to start picking apart some of these things and figuring out what they are.

31:15 >> Yeah. I think, you know, Justine pointed out that the the the reason one of the examples that she posted was impressive was that it had um amazing consistency of the product across, you know, from

31:26 shot to shot. It looked like it was the same product but grounded in different environments. Um so, we'll see what the the pros and cons are here on the leaderboards on the uh artificial

31:36 analysis AI leaderboards. If you toggle uh no audio and with audio, the uh the uh Dream Mania Cance 2.0 Oh, is still topping it and it is so Yeah, it is so close. Do you think this is You think

31:50 this is V4? >> Well, so there's a lot of rumors going out there that it might be V4. There's also rumors out there that say it's Juan 2.7, which is the Chinese model that we

31:58 have used stuff. We use Wamp 2.2 to make that trailer we did a while ago. And Juan is a very good Chinese model, also very good and open source at times, depending on which version of it is. So,

32:09 I would be kind of shocked if this was V4 only because I suspect that V4 will be better at the audio side of it, too, because like one of the things that we talked about when V3 first came out

32:20 was just like kind of how mind-blowing the audio in general was on it. And I think that is what I would expect to see. Again, we've talked about at Google IO is probably where we're going to see

32:28 that drop, I would assume. Um, but overall, this is still very cool. So, again, you can go to arena.ai. You never really know what's going to show up. A lot of the times you'll see these things

32:37 spread out there and it's already gone from the arena, but worth trying. Uh, and and I'm sure we'll probably have something more about one of these models on our next show as well. Hey, hey, hey,

32:48 hey. I'll see you I'll see you in the comments, friends. Drop one. Drop one for that Elgo juice. See you later. Bye.

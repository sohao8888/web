视频链接：[https://www.youtube.com/watch?v=CD9iwAqesrY&list=WL&index=3&pp=iAQBsAgC](https://www.youtube.com/watch?v=CD9iwAqesrY&list=WL&index=3&pp=iAQBsAgC)
视频发布时间：2026-04-21
频道名：TBPN

## 转录内容

00:02 I see a large IPO on the horizon. You're surrounded by jungle. Hold your position. Yeah. >> Clearing order inbound.

00:46 >> Let's just roll. We are surrounded by general. Hold your position. >> Come on. Get up. Trust the experts here.

01:05 Five. We are experts. Founder boat. >> I see multiple journalists on the horizon. Stand by.

01:33 >> UAV online. >> Blaze. Double blaze. Triple blades. Double kill.

01:57 Very wrong. Cop is done. Wait, we are experts.

02:35 Triple blades. Let's just roll. Right. >> Marky clearing order inbound. >> Get up.

03:04 position. >> Strike one. >> Strike two. >> Activate golden retriever mode. Please.

03:37 >> Yeah. >> Mark clearing order inbound. >> 5. No. YOU'RE WATCHING TVPN.

04:09 Oh no, it's Tuesday, April 21st, 2026. We are live from the TVPN Ultra Show, the temple of technology, the fortress of finance, the capital of capital. Uh massive, massive news. Tim Cook to step

04:23 down at Apple. This broke uh yesterday. Uh Germinator had the scoop. of course is coming on the show later today, but it's on the cover of the Wall Street Journal today. Uh heavily predicted, uh

04:34 often debated. Uh it's a time to reflect on Tim Cook's legacy and what's up next for John Turnis, the longtime incredibly well executed, incredibly smooth. They sort of telegraphed it. It

04:47 wasn't a surprise. >> They was already fully priced in. >> I personally was hoping that the market would give Tim Cook a 21% salute. >> Yes. where when the news went out it

04:59 just immediately nukes 21% >> massive red candle let everyone know this is we don't like we love him >> it's a sign of respect of course rebound immediately but I think that's something

05:09 that the market collectively should try to do for >> yes more symbolism in the candles for sure is really the key thing 21% >> uh but of course uh what is Apple at

05:22 right now is is are they moving at all down 3% today 2 and a half% but up 3% % over the last five days. Still nearly a $4 trillion company. They're doing fine and they're cooking. Uh so let's go

05:35 through a little bit of uh the review of the news and some of the some of the previous discussions that we've had around Tim Cook and John Turnis because uh we're going to be learning a lot more

05:45 about John Turnis. He's probably going to do a lot more content, a lot more media, a lot more interviews. Uh and we will be hearing from him uh at keynote events for probably over a decade, maybe

05:54 two decades. Um we will see. So, in January, uh, Bloomberg reporter Mark German, who's coming on the show later today, uh, predicted that John Turnis would succeed Tim Cook as Apple's next

06:04 CEO. >> Let's let's just pull up this clip. >> Let's give some credit to the Germinator. >> To the Germinator. Uh, he didn't predict

06:10 it on our show first. I think he scooped it and posted, but I know, but this was back in January. I dropped the clip. >> The crux of the argument was twofold. Turnis' re relative youth among a pool

06:21 of potential successors. Play it. everyone else on the Apple executive team, late 50s through their mid60s, turning 66 this year in the case of Tim Cook.

06:31 >> You're Apple's board. You like continuity. >> Uh you like an insider. You like people who know what they're doing and been there for a while. They know where the

06:38 bodies are buried. >> Okay. These guys are all have hundreds of millions of dollars, if not more. >> Uh >> pause.

06:48 >> I love Mark German so much. >> He's the best. >> He's truly the best. And he's coming on. He's coming on in in 45 >> 45 minutes.

06:56 >> But continue. >> Yeah. At 50, he's the only one >> who is if let's say Tim Cook hangs out another 3 to 5 years. >> You're not going to point another CEO

07:06 who's 65, 70 years old. >> Yeah. >> He's the only guy. >> Mhm. >> Apple, they get vast majority of the

07:12 revenue from hardware. >> He's the hardware guy. >> Yep. >> Have they screwed up any hardware since he's been in charge? No.

07:18 >> No. He's a steady hand. knows what he's doing. He's really the only choice. You know, there was this New York Times report a few weeks ago basically saying that it could be Greg Juwak, could be

07:29 Eddie Q, could be Deerra O'Brien, could be Craig Federigi. >> It's for sure not going to be Craig. >> It's not going to be Deerra, it's not going to be Eddie, it's not going to be

07:38 Jaws. The only category that makes sense is an operations person because you look at the current CE CEO, Tim obviously comes out of the ops world. You look at the guy who would have been CEO if Tim

07:50 Cook didn't stay so long. I'm not saying he shouldn't have stayed so long. He's done obviously a fantastic job for shareholders and the employees and what have you would have been Jeff Williams.

07:59 He was the COO. >> Uh so Sabi Khan, he was named COO, you know, a few months ago, but he's really been in that job for the last half a decade, I would say.

08:07 >> Uh so anyways, it'll be Turnis or Sabi or or someone completely out of left field. I don't think this is imminent. Um, so we'll see what ultimately happens, but all signs are turning

08:16 towards >> Turnis. >> Everyone has an opinion that Turnis is going to be the next CEO fine. I've been shouting this from rooftops the last two

08:26 years, >> but no one has given evidence like >> what is this based on, right? Has there ever been a baton handoff? Is he getting more responsibility? Well,

08:34 >> do they have a like a big baton? >> We got one of these. You know what you have? We have white smoke coming out of the well actually smoke. >> It's very environmental.

08:46 So >> is that the end of the clip? >> You know, maybe they have a comically large baton >> like like we have our scoop.

08:57 >> Yeah. Oh, Mark German. The scoopinator. He's a scoop doggy dog. Scoop athlete. The scoop. The scoop. The scoop is on fire. We're very excited to have uh Mark German joining in just uh 40 minutes. Uh

09:12 what what what a great uh what a great run he's been on reporting this story. It's absolutely fascinating. So uh yesterday evening, Mark was the one with the scoop. Tim Cook will assume the role

09:22 of Apple's executive chairman and John Turnis will take the reigns of the company. Mark followed up with a scoop with internal memos from both Cook and Turnis announcing the transition. Um, I

09:33 I don't I mean I I understand uh I I don't I don't know, maybe I don't understand what it's like to be 65, but I was always optimistic that the Warren Buffett 65 to 95 would be the new trend

09:45 and that people would just say, you know what, I'm I'm Tim Cook's healthy. He he's he's going he's >> to date was a warm-up. It's time to go on the actual run.

09:54 >> That's I I would I mean I totally understand because >> I got another 10 I got another 10x. I'm going to I'm I'm I'm taking us to 40 trillion.

10:04 >> Yeah. I don't know. I I mean, uh maybe Warren Buffett's in a different world because he's more of an investor. Maybe doesn't need to travel as much. Doesn't need to be in the arena shaking hands,

10:15 kissing babies, doing product launches, you know, being in DC, getting wrangled into things. like Buffett can be more like hands off and just sort of read the news, review the financials and and

10:26 delegate >> with some liquidity if needed. >> Yeah, it's more it's it's a it's a more hands-off role. I don't know how I mean I imagine that the role of CEO of

10:36 Apple's incredibly demanding. Uh but uh I I liked the idea of of just just locking in and being like, "Oh yeah, I'm 65. Everyone expects me to everyone expects me to step down, but I got

10:47 another 30 years in me." But uh you know he uh he chose a different path and he is retiring or stepping into the executive chairman role. Uh Ben Thompson published Tim Cook's impeccable timing

10:59 which eulogizes Cook's impressive accomplishments as the head of Apple. Uh uh Ben Thompson kicks it off with an interesting thing. He says, "It's the nature of business that

11:09 the eulogy for a chief executive doesn't happen when they die, but when they retire or in the case of Apple CEO Tim Cook announced that they will step up to the role of executive chairman on

11:20 September 1st." Uh, one morbid exception is when the CEO does die on the job or quits because they're dying. The truth of the matter is that they were uh is that where any honest recounting of

11:30 Cook's incredibly successful tenure as Apple's CEO, particularly from a financials perspective, has to begin with the numbers. And he this says that the numbers are extraordinary. Cook

11:42 became CEO of Apple on August 24th, 2011. And in the intervening 15 years, revenue has increased 303%. Profit surged 354%. And the value of Apple has gone from a

11:56 mere 297 billion to over 4 trillion, a staggering 1,251% increase. And uh there was some chatter back and forth uh on the timeline over whether Tim Cook had simply put Apple on

12:11 cruise control and locked out as many big names in tech also saw 10 to 40x increases in their market caps. This is from Brandon Guell's newsletter at tvpn.com. You can sign up today uh for

12:23 free. Uh but this interpretation ignores the fact that many of the biggest public tech companies in 1980 when Apple IPOed are no longer even close to the top of the pack anymore. and Brandon sites

12:35 Xerox, Motorola, Texas Instruments, IBM, and HP, which all fell by the wayside over the past 30 years while Apple built uh the biggest consumer hardware company on the planet and thrived in the public

12:48 market. And I was I was doing some digging on this as well. I pulled up uh you know, it's easy to look at like well, zoom back to the the the Mag 7. uh all all of the Mag Seven have done

13:01 fantastically well over the past 15 years during Tim Cook's uh tenure. Is did he do anything special? Is he is he in a different category in some way? uh and and maybe maybe not when you look at

13:15 when you when you look backwards from the current Mag 7, but if you go back to 2011 when Tim Cook took the reigns and you look at what were the biggest tech companies there then uh and how have

13:28 they performed it does look like outperformance because uh Apple was at 377 billion that was you know big huge the biggest company at the time uh then Microsoft look at what what their peers

13:41 were at the time where he took them home. >> And to be clear, Apple, Microsoft, Google, and Amazon were clearly there. Fang was the term at the time. Facebook,

13:52 Amazon, Apple, uh Netflix, Google. For some reason, Microsoft didn't make the cut in that uh in that acronym. That has since changed, of course, but there were a lot of companies that didn't go on as

14:04 significant of runs. uh you have IBM, Oracle, Intel, Cisco, Qualcomm, and HP all that were in the the top 10. They were sort of the mag 10 of 2011, and now they are not in the mag seven, although

14:17 many of them have done very well. So, uh it it seems uh it's this was our take from a long time. You know, we like to harp on uh the the failure of Apple Intelligence and how Siri is is

14:31 ineffective sometimes and the and the FaceTime interface is odd and the new photos app is hard to use. But where it matters, >> we give them credit on Genoji.

14:43 >> No, where it matters is did they navigate tariffs? Did they navigate supply chain? Did they navigate uh the transition to Apple silicon delivering a great product consistently that doesn't

14:55 break? Like we have ordered so many Apple devices throughout building TBPN and there was a time when you would get a new consumer product and it would just be oh it's a bad one. I got a bad one

15:07 and I got to take it back. And that's never happened. the the quality control is flawless and uh navigating a very very difficult chip export act from Biden in 2022 all the way to the Trump

15:19 tariffs uh to different political swings back and forth and back and forth. Uh, and Tim Cook has just done a great job of like keeping the wheels on the train going down the track and I think that

15:32 should be celebrated even though the sexy new AI features >> he's bound to be under under appreciated because he wasn't >> he wasn't the visionary that that uh

15:44 that Steve was, but he also never >> I don't think he ever >> wanted to be seen in that way. But the consistent operational excellence over almost two decades is

16:00 >> almost unprecedented at this scale. >> Totally. >> It is. >> Yeah. Just just the way you put it, right?

16:06 >> I the the same >> the same experience that I had getting a new Apple computer as like a teenager. Yeah. >> I have today. It is actually almost

16:17 remarkable how similar the experience is. you open this wonderful box, you get a great device that works for a long time. >> Yeah.

16:24 >> Uh and and you still get that today. So the the consistency >> and um yeah, I think I think he will just get more when people kind of process the run uh over time, he will

16:36 just get more and more respect. >> Yeah. And a lot of the uh computer manufacturers have had to go into bloatware and pre-installed software. And Apple's been very good at

16:47 holding the line there. They've of course ramped up their services business, integrated advertising in places that were somewhat unexpected since that was always how they were

16:56 counterpositioned against Google, but um they've done it in a way that hasn't been that annoying. I feel like I don't see that many people complaining about ads in the app store. People see the ads

17:07 and they're like, "Wow, this company is bidding on the keyword for their direct competitor. That is uh you know, extremely competitive behavior." Uh the same thing happens on Google. Didn't

17:18 expect to see it in the Apple ecosystem. Of course, it it's going to happen. The uh >> in the chat says, "Not a single product recall under Tim Cook. Is that

17:26 possible?" >> Wow. >> I think that is incorrect. >> What did the recall? >> Says they recalled a 15-inch MacBook Pro

17:35 in 2019. >> Did Bengate did Apple >> AC wall plug adapter in 2016, 2019? Battery gate service pro. They've had some they've had some back and forth,

17:45 but uh but but but you know, a very very successful run. Uh the other two things that the chat was mentioning was uh the Apple car and the failure of that program. Uh maybe a little bit they bit

17:57 off too much more than they could chew. I think you know looking at what's happened in China with every phone manufacturer launching a car that's extremely impressive. Uh, I would have

18:08 loved to see Apple execute there and I think that would have been very good for the American technology industry, the electric vehicle industry, a variety of different uh, American industrial

18:19 efforts, but uh, it was not to be unfortunately. And then there's the Apple Vision Pro, which I think a lot of people uh, you know, look at the churn rates, look at the the uh, uh, the the

18:30 retention rates and they just see it as an underwhelming product. I still like it, but I'm in the minority, and I I acknowledge that fully. Uh I do think that they made the right decision to

18:41 turn it into a a a home cinema, a home theater. Like they they understood that that there was not enough of a video game library, a VR game library to plug into in any meaningful way. And so they

18:55 made the decision. I think one of the lead uh staff members on the Apple Vision Pro project was from the Dolby Cinema team which had done Dolby Vision and and some of the actual theater

19:06 buildouts. And so they were able to bring that experience and understand what actually makes for a great movie watching experience in a premier, you know, cinema and how can we recreate as

19:17 much of that as possible in VR. still, you know, obviously didn't hit the mark fully because the product has not taken off by any stretch of the imagination, but uh overall it was a fun project and

19:29 I'm I'm I'm I'm hoping that they continue that. It might wind up pivoting into just camera glasses and they'll go up against the meta ray bands, which might be the the more prudent uh you

19:39 know, business strategy, but I still I still like uh I still like you know, these incredible investments in VR. What are you laughing at? >> Josh over at Semaphore Yeah. says,

19:50 "Nobody tell the new Apple CEO that he has a streaming service. We've got a good thing going here lighting iPhone and AirPods money on fire to make great movies and shows, and we don't need any

19:58 that getting any extra attention right now." >> Yeah, >> 5,000 likes. >> Yeah, it is interesting. Uh, yeah,

20:06 Turnis is about as far as you can be from the Apple TV services organization, but uh I don't know. I talked to a I talked to a filmmaker in Hollywood, a very successful filmmaker like years and

20:17 years ago before the uh before Apple TV was really ramping up and he was saying that uh Apple's brand is so prestigious that uh it's sort of antithetical to the Hollywood mindset which is much more VC

20:30 uh risk on you're going to have flops like every every movie studio understands that uh it is impossible to predict the perfect success and have the level of polish flesh that comes from

20:42 these slight iterations to apples. Yeah. Yeah. Yeah. Build different for sure. Um but uh and so it's a different culture because if you have uh you know Apple's Apple hasn't I mean they've had like

20:55 flops but even the flops like they still feel like very on brand. They don't have like a silly movie that is just like bad. And uh running that risk was always uh was always a problem. But I feel like

21:06 Apple navigated it really really well especially with the F1 uh project and has done has done really well with the content side and they have held a brand standard that feels like almost at the

21:17 level of HBO pretty quickly. uh whereas some of the other streaming services have kind of gone more scattershot, more reality TV, more uh you know sort of silly projects that might put you know

21:30 might entertain viewers but don't fully uh they they don't create a cohesive brand idea of like what what am I getting when I open that particular app on the Apple TV. Um anyway, uh

21:43 continuing uh Mark German said on TVPN in January that Turnis really viewed really is viewed as the ultimate hardware guy at Apple. Uh Ralph Winkler at the Wall Street Journal published an

21:55 article yesterday uh detailing Turnis' pedigree with physical products. Quote, "If Jobs was a product visionary and Cook a supply chain guru, Turnis is a hardware soant who exists somewhere in

22:08 the middle. Turnis who has a background in mechanical engineering has been working at Apple for 25 years and most recently led hardware engineering of all of Apple's products. He played a crucial

22:20 role in the development of Apple AirPods. Obviously a massive success and he redesigned Apple's computers to use company designed chips instead of Intel's a massive move that uh extended

22:30 battery life and improved performance. So Turnis is >> and set them up very well for AI. >> AI. >> Yeah. Uh Turnis is taking over Apple at

22:38 a time when the company has largely sat on the sidelines of the AI race, going so far as to outsource the technology powering Siri to Google's Gemini. Turnis will have to will have to somehow manage

22:50 this dynamic. Ben Thompson wrote about it in November of 2025. Apple's plans are a bit like the alcoholic who admits they have a drinking problem, but promises to limit their intake to social

23:01 occasions. Namely, how exactly does Apple plan on replacing Gemini with its own models when one, Google has more talent, two, Google spends far more on infrastructure and three, Gemini willi

23:12 will be continually increasing from the current level where >> I mean a number number of people have have u talked about, you know, what are the challenges that that Turnis is

23:21 inheriting on supply chain, right? Kind of like, you know, stuck in in China in a big way. uh that presents a pretty meaningful uh you know risk to the business. Yeah. And then sort of like

23:33 overall dependency on on um on Google especially on some of these key products. But >> yeah, >> without further ado,

23:40 >> sure. >> Let's bring in >> let's bring in Hi L Air Table. Howie, how are you doing? Welcome to the show. >> Thank you so much for coming on down to

23:49 the TVP Ultradome. For those who might be living under a a superco computer, not a data center, uh introduce yourself. Tell us who you are. >> All right. How Lou, co-founder and CEO

24:00 of Air Table. Uh now also maker of Hyper Agent, part of Air Table. Cool. >> I've been doing this for uh 12 13 years now. >> 13 years.

24:07 >> Overnight success. >> Give us the backstory. Uh take us from college through early career to the first uh the founding moment. >> Yeah. Yeah. So in high school, I kind of

24:17 got into programming. Like my dad had this C++ book, left it in this, you know, corner of the house one summer and I was super bored. C++ learned it. I mean, this was like 2003, like Python

24:28 for the most part. >> Yeah. Like I mean, Python was was around, but people didn't really use it. >> It wasn't the jumping off point. Java definitely like early days for even like

24:35 web apps, right? Like Rails didn't exist, like all that stuff. So learned C++, thought it was kind of cool. uh and then started thinking about like how do I turn this into like a real career

24:44 because it just it was a lot more fun than like classes and like I went to Duke took some like mechanical engineering classes but uh on the side basically learned how to do web app

24:52 programming like first with PHP then like Rails and stuff and I stumbled on Y cominator actually like pretty early on. It was like maybe 06 or 07 like literally the first class like no cuz I

25:03 I remember um like I saw uh looped uh his first company and I was doing research like I wanted to do a similar type of company or product and I was like no you know I was a nobody in like

25:13 college didn't know anything and through that like found out about looped I was like damn it somebody's already got this this uh this idea and then learned about YC and like Sequoia and so that kind of

25:22 became my first inroad into like just learning about that whole world of like startups and tech uh eventually after college applied to YC with my first company which was um basically it was

25:31 called EAX like contacts with an E. Okay. And it was like a personal CRM product way back. Yeah. Exactly. >> Oh yeah. Yeah. They were like oh this is

25:40 a big problem. Everybody else problem it right away. He's am I correct in in my my take has always been that the people that clamor for a personal CRM re really just don't realize that their friends

25:53 are people that they do business with and they should either just use a real CRM or just don't and just be friends. >> I mean it's yeah I think I think it's like a very unique target audience for

26:04 whom it's a very high pain point. So I think there's like a market there but like it's a very like power user proumer audience. And the punchline of it though was that like after a year of work, we

26:14 like worked on this thing, raised some money, uh, you know, hired like a couple people and then we kind of realized like I sort of realized like I think it's a more niche market than we set out to to

26:25 go after and we had some like different acquirers come knocking like Salesforce was one of them but like also big like consumer internet companies who wanted to just buy us for talent and you know

26:34 to me it was like >> and what this is we were winner 2010 that batch and then the acquisition talks were like 2011 basically late late 2011 and you know we kind of got to this

26:44 point where I realized like I want to work on a really big problem like a meta problem not like here's one small niche for like some people but instead like what's like the underlying problem which

26:53 is you know you could actually build this whole CRM with like an app platform right like you really want something that's a lot more just configurable and customizable and so we took an

27:02 acquisition by Salesforce worked there and like for me the big light bulb moment was you know Salesforce is one big data >> what's Benny off like on all hands Uh, I

27:11 mean I would say he's electric on this. >> Well, there weren't that many all like all hands were quite infrequent at Salesforce at the time, but like I went to like their their big sales kickoff

27:20 that year. I mean Mark is like a very smart guy and also a very like commanding presence. Like he's a physically like you would if you met him like on the street and you didn't didn't

27:29 know who he was. Like you probably think he was like a linebacker in the NFL. Like he's massive and he just like he exudes charisma. Like even in like a quiet small room like he'd take meetings

27:38 in his house like I'd go over with like you know some of the other like >> he's the salesman final boss. >> I mean but like not only imagine going headto head with him I'd be like I

27:50 sales but he's like he's just got such a presence even when he's not like like booming you know out loud like on a stage like a quiet room. >> The the dolphin sound where you go

28:01 >> I don't know about that one but I didn't get to see that part but That's the whole genesis of Salesforce. Apparently, he came up with the idea while he was swimming with dolphins.

28:11 I guess that's what what all the kawaii motifs are for. Yep. >> Um, it was a fun time. I mean, honestly, it was a really fun company. Like, you know, it was like for being in

28:18 enterprise software, it was like one of the more fun experiences like, you know, people were kind of super laidback. like all aloha and like >> but uh but learned a lot you know and I

28:28 think like for me the big aha was like wow like all of enterprise software is basically just like a database with like some app logic and like interfaces on top right and like that's basically all

28:39 that Oracle is used for that's basically what SAP is that's what Salesforce is and if you could create like a way simpler version of that like that's super intuitive like that's that might

28:48 be a big market and that was basically the the genesis of air table is like I want to go and like basically PLGFI before that even was a term like this category.

28:57 >> Sure. Sure. So yeah, what was the what was the initial like hunting for a team, raising money, building an MVP, like what was the step? >> I mean the second time around like so

29:07 this was my second company then Air Table. Um you know I wanted to do things a little bit differently than the first time. Like the first time was kind of like just go and like apply to YC, get

29:15 in, do whatever it takes to get some traction. Like it literally felt like this roller coaster, right? every week it was like launch get some you know signups go and like raise money and air

29:24 table was a lot more premeditated like we spent two and a half years building the product before even launching it was actually weirdly a very parallel timeline to Figma so like both like two

29:33 and a half years around the same time launched around the same time very like PLG in both cases and I think we both kind of exploited like um you know the advent of like rich browser experiences

29:45 like for the first time so like you couldn't build like a rich real time like single page app experience before maybe like 201 like 11 12 like and really it became like you know kind of

29:56 really legit in like 2014 15 with like V8 becoming like really mainstream and dominant like you know just like the performance of the browser became there right um so we built this product like

30:06 you know the premise was let's make it really really simple for like anyone like a small business owner like you know podcasters or even like people within a larger larger company to build

30:15 their own app or database uh and like you know FileMaker Microsoft Access like some of these products existed back in the day but never made the transition to the web. So

30:25 we kind of built it. >> Yeah. My career started shortly after you guys kind of like came onto the scene and my first ever business. We signed up for Air Table like probably

30:37 day one and still use it >> uh how many >> like eight years later something like that. So like just running like it's been core infrastructure

30:49 >> every single day. >> Yeah. And like evolved and um but >> it turns out like databases are pretty sticky, right? Like think about all the Oracle installs and like just random

30:58 like large enterprises that are just still chugging away like you've got your system of record in there and like built a lot of like customization. >> Oracle database as a revenue line within

31:06 Oracle is growing revenue. I'm not >> topline is growing for the Oracle database. not their AI stuff is a separate thing >> very different valuations but it is

31:16 growing which is I think a narrative violation that I think a lot of people would wouldn't take uh talk about like the early go to market I mean you said PLG but like are you sending this to

31:25 like startup friends are you trying to sell this into Salesforce on day one like how how are you thinking about like uh enterprise versus mid-market versus startups versus like proumer there's

31:36 like so many different routes you can go >> yeah so this is like 2013ish right and Like at the time there weren't that many I mean there wasn't like really a PLG like thing right like I mean Slack had I

31:47 think just come out when we launched in 2015 so they had launched a little bit before Dropbox and maybe Evernote were kind of the best like PLG pioneers and they were both very like consumer

31:56 proumer so like solo like individual user first and >> Drew Hston has the funniest riff on uh I don't think he calls it PLG but he calls it like the web growth the web 2.0 0

32:07 growth playbook which is uh like going viral but he takes it a lot further and he's like so you want to sneeze on as many people as possible and he refers to that as like if you send someone a file

32:18 that you've sneezed on them and then they might create an account it's just like a much more like visceral way about viral marketing get >> well yeah I mean think about so so my

32:27 first company uh is an ad network so uh we would you know a company would come and say like I want to advertise here's $100,000 budget And then the company would put together a dashboard.

32:39 >> Yeah. >> Uh of like potential buys and then the person would go through and so it was inherently viral. Every customer that would work with us had to log into Air

32:47 Table and like use a product. So that was just happening at like massive scale. >> Yeah. And I I think that like that type of like you have some like data set like

32:56 you know maybe it's for your ad inventory or whatever, maybe it's for like your CRM or whatever you need to collaborate with it. like it's a very fundamental construct in in just like

33:06 how knowledge work is done, right? And so I think like the lesson learned for me or like that the principle applied was like can you go after something that's so foundational that like it's

33:14 always going to be around, right? Like I think with uh the personal CRM thing, I kind of felt the like turbulence of like is this in vogue right now? Is it not? Like and I really wanted to go after

33:23 something that felt like it's going to be around for decades, right? And like what's more eternal than like people need like customer record a database the past 40 years of computing it's

33:33 probably going to be around for the next 40 and like even now with agents it's like the database layer actually becomes more important right like you don't want just like a bunch of ephemeral context

33:41 windows like for for agents like they need to like store and collaborate on data along with humans. So you kind of picked that as the vantage point and a lot of the early customers were like

33:49 startup founders like small business owners but like interestingly we had like we had written this like fake business plan. It was like basically like a vision deck more than an actual

33:58 business plan but like we had said you know conjectured like we're going to have to go after like a long tale of like the kind of proumer SMB audience basically like Dropbox right and I think

34:07 what was really surprising is it turned out to be a little bit more like Slack where we got the most verality within larger companies. like there'd be a big media company or like even like a scaled

34:17 startup like a Work or something that would run all of their operations very quickly early on on Air Table and then just grow with the company, right? So like I mean we work was one of our early

34:26 customers had like like probably 10,000 people like you know when they were at their peak like it basically was like used by every almost employee there and like a lot of their op operations

34:36 building operations etc were just built on air table by default and I kind of learned the the value of like having this like data gravity like once you get enough data into a product like air

34:46 tableable like it just kind of retains really well within the company and gains more and more usage. >> Yeah. How how did you think >> until until the company

34:54 >> Well, you index you index against the uh the industry that you're in. Um, what? So, so, uh, I want to get I want to get to all the good the the good part like right now and all that stuff, but, uh,

35:07 walk us through since this is your first time on the show, like you know, you went from being >> one of the hottest companies in tech during the whole no code boom, the like

35:18 PLG boom, >> Zerp, like it must have just been, you know, I mean, an insane experience. And then like there's kind of this reset in late 2022, 2023.

35:30 >> How how has it been kind of like building out of that, you know, trough? And then like have you I'm assuming it sounds like you've been like very re-energized by

35:39 >> this new um this new opportunity. I mean one of the maybe benefits of like not being an overnight success because we took like two and a half years to build the product even like from 2015 to 2017

35:50 18 I would say like we were getting like a steady compounding of growth but it wasn't like Slack or like Dropbox where it just overnight became super easy right like it felt like we had to really

35:57 grind we had to think about like how do we need to like improve the product and increase the you know kind of like sharability and the scalability of it so it was kind of a grind for like at least

36:06 the first five years and 2018 when we got our first unicorn round is kind of the first year where it felt like it was starting to get easy, right? So 2018 to 2021 like very fun years but

36:17 also >> everything is so >> money just printed in the world unlimited money and like you know we got to raise like a big you know set of

36:25 rounds like we >> how would you like a 100x revenue multiple >> or yeah I mean yeah and and just like the absolute scale of funding was like

36:33 huge compared to prior art right like now I mean you can raise like a hundred billion you know like if you're opening eye but like at the time like you know we raised um you know our first Uh our

36:43 first unicorn round was like a $100 million round and we raised like another like couple hundred and then like a few hundred more and then like our big round was our series F which was like kind of

36:53 at the peak of like the markets. >> Uh raised 700 plus million and in that round and 11 billion 11 billion valuation and you know we still have like all of that money on the balance

37:02 sheet and we're now like cash fl positive. I think like you know it was kind of a fun fun time to like you know kind of get to

37:09 like ride that wave and then you know but like I I always I think for myself knew like you know you have to build like a durable business right and so like valuations are going to like rise

37:20 and fall it's just going to be like macro but like you know ultimately either we build a great enduring business or we don't and if we don't then like you know you could be like a

37:28 flash in the pan right so I think we were always like trying to focus and I tried to focus on like what do we actually need to do to like you know compound growth like go after the

37:37 enterprise obviously at the time especially like it was clear that was like the move right you get PLG but eventually you have to go into the enterprise and win like these big

37:45 multi-million dollar contracts like become a really sticky system within these larger companies and we did that and like we're still doing that we have like a bunch of the Fortune 500 like

37:55 running really critical operations on Air Table whether it's like content production at a big media company or like you know like fund operations at a company like you know like financial

38:04 services company. So these are like the like almost like modern ERP. >> Did you hire a different set of individuals to work on that that were already connected and knew that flow or

38:15 was it something where like your best sales reps just sort of got bigger and bigger and leveled up or >> It was it was a little of both. I mean I think it's a different muscle. Like I

38:23 think rolodex selling is even at that time like you know not that effective. Like I think like just knowing somebody at a big company like doesn't even if you're like you know very senior and

38:31 they're very senior like doesn't actually help that much. Like we've had some reps come in like they've had like a decade long relationship with like you know the CMO of XYZ company. And I think

38:41 that gets you like a phone call. It gets you like a meeting but ultimately like buyers are wising up right they have been for quite some time where it's not just like oh I know this guy I'm going

38:50 to like or you know gal like I'm going to buy this like product from them. like you actually have to like show them why this is going to help their, you know, help them in their job, right, and help

38:58 the company. And so I think it became much more about like transitioning from like, oh, people can just use it on their own and they'll figure it out on their own to like starting to do more of

39:06 a consultative sale like come in and say like, okay, how can we solve like a really big problem for you and maybe like for one company it's like how do I consolidate like my endto-end operations

39:15 for like how we do all of our brand planning, launching new products, all that. And that's kind of like it's like one part consulting, one part like just thinking about like a big enterprise

39:26 scale solution and then one part like being able to leverage the flexibility of our product almost like in a palunteer-l like way to show the customer like we can actually solve this

39:35 really deep problem for you quickly. Is there any sort of like PLG motion or land and expand that happens in the Fortune 100 like because there's some small team inside of Coca-Cola or

39:49 something that's using Air Table and then you're able to use that as a demo or jumping off point that does happen. >> Yeah. I mean it's like there are some companies where you just can't even get

39:58 your foot in the door without the top down. Um like a lot of big banks like we just we were firewalled out until we got some top down intro. they can't even they literally block you right your IP

40:08 is like blocked so like it might be like hard wall like you know request access um so you know there are some companies where you have to come in top down but like there you know I would say 70 plus%

40:19 of our current enterprise accounts including the ones that are like now like five plus million in in revenue like originated from teams within the company organically adopting air table

40:28 right sometimes it was kind of like shadow IT they just figured it out on their own and they just like they showed real value from using the tool, right? Like they would build some real

40:37 operation on it and say like, well, I've been waiting for like it to deliver me this like old bespoke solution or some like crappy other vendor for like 2 years now. I got impatient and just

40:46 built the thing myself. And that's like a big I think you know I think of like the enterprise landscape now as like you know there's plenty of dollars in enterprise right even now like you know

40:55 it's just shifting from like traditional software to now AI but like there's plenty of dollars right the budget's there but like the question is you're not the only one going after it and so

41:05 like what's your kind of asymmetric wedge to get in there and like take those dollars right and if you're a big company like a Salesforce maybe it's like we already have the distribution we

41:13 have like the customer data in there we're going to go and attack adjacencies if you're air tableable we don't have like the scale of like a you know service now or like an SAP or

41:21 Salesforce. What we did have is like the usability of the product. So like the PL was like kind of the entry point and then also like even when we pitched to other people in the company that hadn't

41:31 used Air Table they had you know probably heard about it from a friend like maybe the CMO's like you know partner like uses Air Table in their company or we can go in and just show

41:39 them like a really compelling demo quickly. >> Talk about AI. What are customers demanding? What have you rolled out? What where does AI fit in? Well, where

41:50 does AI take a back seat? >> Yeah. I mean, I think it's crazy because it's like we've we've seen like so many layers of disruption happening almost in parallel, right? Like you know, you

41:59 think about like desktop to mobile. It was like a single form factor change kind of kind of easy almost to like execute on. Um that was the one that I experienced at Salesforce like the big

42:08 thing at the time was like Mark would tell every team like show me the mobile UI first before you show me like the desktop UI, right? Like go mobile first, right? Yep. And you know it was like the

42:17 right move and also kind of a simple move. Now it's like you've got at one level like obviously every product should have like AI in it. So you know we have the obvious stuff like you can

42:26 now talk to Air Table's assistant like co-pilot style and have it do stuff on your behalf in the product. We have what we call field agents which are kind of like the ability to map reduce AI calls

42:37 against like all of your data. So you can have like 20,000 customer records and run like you know AI agentic like you know kind of tool calls like search and like research about the company like

42:46 synthesize like that kind of stuff row. >> Yeah. And like you know we do all that stuff but to me like the more interesting you know kind of disruptions

42:57 underneath that are like one like you know are people do people even want to come into your interface anymore and this >> yeah that's what I was going to ask why

43:05 you care about like storing the data in in a in a sort of safe secure >> yeah Salesforce they just went like headless recently like is there a plan for that or how are

43:16 >> I think it's like I think the right move is like hybrid headless right like I think I think the whole look like if you wanted just like a backend database you could use like Postgress like superbase

43:25 right like you know it's and you know there's like PHP my admin equivalents like modern day ones right like Prisma has its own version of it like that are okay or they're good right like but like

43:34 I think what most people actually want especially in a business context is like you want like the database but you want to have like proper permissioning you want to have proper collaboration and

43:42 most importantly like you don't want to exclusively interface with the data through like an agent right like you want to do that a lot of the time but like it's really helpful to actually go

43:50 in and see the like see the actual data like I think of it as the equivalent of you know even though um aentically you can like generate all your code and you should as a frontier developer like does

44:00 that mean you never want to inspect any lines of code ever like no like you still want to see like a diff of like all the actual like code files change whether that's in your IDE or in GitHub

44:09 or whatever and so I think the equivalent here is like you want to be able to drop down into a really nice interface and we've done some work around like kind of figuring out what

44:17 what's the best blend of the two right so like with chatbt for instance we have kind of a first- class integration where you can go in through chat PT and like interact with your data in Air Table say

44:25 like hey pull me like all the customers that are like waiting for an outreach for me and pre-draft like outreach messages. Um but then it can basically compose like a fragment of a view within

44:36 the chatbt interface. So like you can actually see like air table but like you know kind of a part of the interface. So it's not completely headless. It's almost like you get to pull out like

44:46 pieces of its face at the right time on demand. And I think that's a really important kind of like UX form factor. >> Yeah. How are you thinking about uh speed in the context of AI? I feel like

44:58 uh the models keep getting smarter, but they also keep getting slower basically. Uh, and while I'm extremely confident that I could point a deep research agent at a massive air table with 20,000 rows

45:11 and uh, get very good results, like a lot of times I'm just in my email and I want to find one thing very quickly. And uh, that feels like it has yet to be uh, you know, AIified or at least like

45:24 LLMified. It's very much uh it's it's very much like okay well I should probably just fall back to like a SQL query or just some boolean logic or just like vanilla search because I I want

45:36 this now. Yeah, I think both are going to be really important experiences and obviously we have like you know kind of great like smaller and and faster models like the mini you know you know that

45:46 that are great for like more synchronous interactions and like within Air Table like if you go do to air tableable or you use chatpt with like one of the the smaller models you get that like faster

45:55 kind of almost like more like realtime experience but I do think like a really important class of work that will come to dominate like every frontier company or company trying to reinvent themselves

46:04 to be frontier is like figuring out how to operate in this new modality of like you know it's like the best developers today >> don't go and like sit there in front of

46:12 their IDE and like synchronously like talk to the agent you have like 30 you know separate branches that are each being worked on by a different agent and like you can have the agents continue to

46:22 like update you know the branch based on human and other agent feedback right so you have like comments back or like you know run like tests etc and I think this whole idea of like look it's going to

46:31 take like hours for that entire loop to complete right like agent pushes some changes the changes get feedback from other agents or humans. Agent responds to that. Like that whole loop could be

46:41 hours, not just like minutes. So you're not going to sit there and like watch it one at a time. But the powerful thing about this is like each one is still actually operating faster than like a

46:50 human engineer could have like back in the day, right? Like when I think about like the speed with which like our early team at Air Table could build features and we had a very good team like one

46:58 agent on one branch can you know do the work of like maybe three humans back in the day operating probably in like three times the time right so it's like literally like a 10x you know kind of

47:08 leverage factor just for one agent but the best engineers are now able to multitask and kind of basically say look I'm going to oversee my own little team of like 20 to 30 agents working

47:18 concurrently and so I think it requires like it's almost like everybody needs to graduate from being an IC to like an IC manager of agents. Meaning like in every function, like if you're like a VC

47:30 analyst, your job should no longer be to go and synchronously research one company. It's like you're going to go and research like 30 companies and do them all faster, better, and higher

47:40 quality, right? Like than than what you could before. And so it I think that's the greatest leap that is going to be challenging for a lot of people in a lot of roles to make the leap on because

47:49 it's it's a totally different mentality to like how you operate and what your role is um than before. >> What are you pushing the the team to achieve? M um so a lot you know I think

48:01 like there's there's basically like three different levels of self-d disruption we're trying to do at Air Table right one is like the core product itself like how do we reimagine that for

48:10 an increasingly agent-ledd future so all the like headless hybrid type stuff we talked about and like you know like the best testament to that is like do we see like massively growing uh you know

48:20 basically tool call volume from you know uh chat claude any other agent products like are people using air table more and more agentically and is it working smoothly for them. So that's like

48:30 priority one. The second though is like I think we have to like really transform how we operate internally, right? Like you know clearly like the companies the best companies in the future are not

48:40 just going to hire like massive armies of people to do everything, right? Like they're going to hire like people who can really effectively leverage agents, right? It's so obvious that's happening

48:49 in engineering where like you know if you could hire one engineer who could be fully agentically leveraged, you get more output than like 30 kind of traditional engineers doing traditional

48:58 engineering. Um, so that's kind of one internal thing. But then the third is like I'm a strong believer that like you have to go and skate to where the puck is going like index against like the big

49:08 title wave coming, right? Like Amazon did this like back in the day against like the growth of the internet, right? Like they you know Bezos picked books and like you know e-commerce because

49:16 like he thought that would be the best way to index against the growth of the internet. And so for us like we get that through air table and like kind of hybrid headless air table but we're also

49:26 placing a big bet on hyper agent because hyper agent is basically like taking all of the like excitement of frontier agents like i.e. Open Claw and like YOLO agents that can just like have access to

49:36 your data and tools and do stuff like really really like long running stuff. Not like 10-second tasks, but like 10-hour tasks. Um, but for non-coders and we want to do it in like a business

49:46 friendly way, right? So like you can go and like do this, deploy it into your company, run like agents across, you know, your entire company. And so that's kind of like a bet on if we believed Air

49:57 Table, you know, 10 years ago was like the most meta problem, like the largest problem we could work on, which is like software arguably is like was the biggest and fastest growing industry at

50:08 the time, right? And like how do we go after that entire category and index against that? Um, how do we now go against agents and say like we want to build like the best agents platform that

50:17 any business and any person can come in and use and just start building agents with, right, and deploying them into their company, right? And so if we do that really well then like we get to

50:25 doubly win both as the data layer but also kind of have a a bet on the uh the agent wave. >> Yeah. Last question. Should children learn C++?

50:36 >> Definitely not. Uh no I think >> and is that because of C++ or because of the AI era? I think well I mean I think both like I think um I think the fundamentals of good technical

50:46 architecture are going to be the most important thing but that has le like I think the abstraction that really matters now for creating value is raising up right like it used to be at

50:54 one point like you know Bill Gates wrote like some of his first programs in like literally like machine code right and like would punch it into his like PDB10 and like clearly you could be a great

51:04 startup founder or be a great software engineer and make lots of money like without having to go down to that level and so I think now with agents Like the bar has raised yet again where like what

51:13 you really need is like good product, business and like tech architecture sensibilities like how should this system work like where should the different like levels of you know kind

51:22 of responsibility belong and like if you can get really good at that then you have super leverage if you are just kind of like like learning the literal kind of like lines of code and how to write

51:32 them that you know a lot of engineers were before I think that's going to be increasingly below the frontier line of like agents can just do it like equally or better to humans.

51:41 >> Yeah, that makes a lot of sense. Well, thank you so much for coming on the show. Have a fantastic rest of your day. >> Great hanging. Talk soon. >> We have our next guest, Mark German, the

51:52 Germinator himself in the waiting room. Let's bring him in to the TVP Ultra Dome. Mark German, how are you doing? >> Tired. How are you doing? >> Tired. I can imagine. Uh this has been

52:06 months in the works. Uh you predicted this uh many times but also on our show. Uh how did this come together? Did this match your timeline? Were you surprised by this particular Monday that it was

52:19 announced or >> walk us through the scoop >> and get the get the scoop. >> Get the scoop ready. This is the scoop. >> We got the golden scoop for you.

52:29 >> The golden scoop. >> Oh, I have never I've never seen that. >> This is a new prop in the studio. You'll have to spend the next time here in person. the the Open AI deal is already

52:39 uh doing work for you guys. There you go. No props. >> Uh so here's the deal. There's a reason I published my profile of of John Turnis just a few weeks ago, right? Uh this was

52:49 all coming together. Uh things really ramped up internally at Apple on this at the end of uh last year. Uh things have been in motion. Uh the plan was to announce it after the 50y year

53:00 anniversary celebrations. And it almost felt like the 50 year celebrations were not just, you know, about Apple's 50 years, uh, but sort of a goodbye celebration to Tim Cook and his legacy

53:11 at the company. So, it all came together over over several months. Uh, this really started about 2 years ago uh when uh Tim Cook identified John Turnis as as the next one. Uh Turnis had been being

53:28 been prepared for this role probably for over five years at this point since they put him on the executive team and he became SVP of hardware engineering. Uh but this started in in early 2024 and uh

53:38 at the time I I wrote that um that was the first time I wrote that he would be the next one. >> Yeah. Um how do you uh have you been able to process I know you've published

53:47 a few memos. Have you been able to uh ascertain anything about the internal uh response? Are Apple employees excited about this? it feels like it's been managed from a communications

53:59 perspective very carefully. Uh and so it shouldn't have been a surprise to anyone, but are Apple employees generally excited about this? It seems like uh there's a lot of cause for

54:09 optimism, but uh I'm always interested to hear. >> Yeah, there was that one article a couple months ago where clearly they were getting quotes from former

54:17 employees that were like kind of taking pot shots at him, basically saying like he's never made a hard decision. Yeah, that was the quote that went into the journal, but I don't know. It seems like

54:26 it didn't matter because he got the job. >> Well, got the job two years ago and I think he's going to do a hell of a job in this new role. Uh I am quite optimistic for Apple in the long term

54:39 with Turnis at the helm. He has product sensibilities that Tim Cook simply doesn't have. He has product decision making uh ability that Tim Cook certainly uh had but wouldn't utilize

54:49 because he himself knows that product based decisions is not where uh he could have the the most impact. Just like Tim Cook really oversaw the operations part of Apple as the CEO and led left product

55:03 development to other members of the executive team. My expectation is that John Turnis will be intimately involved with the product side of the organization as he was in his prior role

55:11 to CEO and will leave the operational side to people like Sabi Khan uh and Priya the people who run the operations division at Apple supply chain manufacturing procurement Apple care uh

55:24 you name it and so he's going to pick his spots and his spots is hardware and product development uh there's a reason that when he chose his successor uh for the hardware engineering organization,

55:35 he chose Tom Marb, not an innovator, but an incredible execution guy when it comes to hardware engineering, product quality. He did that because his belief uh is that he will still be intimately

55:47 involved and sort of be that product visionary for Apple in this new chief executive position. >> Yeah. does uh when when I remember Steve Jobs, I think of Jobs as an innovator,

55:57 as a visionary, as someone who both did Pixar and the iPhone, you know, so many different projects, a lot of them wildly successful. Uh Tim Cook felt like a focusing of that a little bit, but you

56:09 still had the car vision pro. There's a few different projects going on. Is this more is this the most focused Apple has ever been and will ever be or do you think that there's do you think Turnis

56:20 has like some aces up his sleeve where he might want to take a wild swing at something? >> I think what Tim or what John Turnis is going to have to do is stay the course.

56:31 >> Annual iPhone, iPad, Mac, Apple Watch, AirPods upgrades, >> but at the same time is going to need to do a better job bringing out new product categories that Tim Cook has done. If

56:41 you look at Tim Cook's legacy in terms of major new products, it really was on the services side, uh, the AirPods and Apple Watch, you know, those were both really developed by management teams and

56:52 engineers and people who came from the Steve Jobs era. That's not a slight, but my point being is that we really haven't seen anything wholly new that is also successful since 2016 with the AirPods

57:02 and the Apple Watch at the end of 2014. The Vision Pro has obviously been a Tim Cook product, a Tim Cook priority, and it's been sort of a flop uh at least for now. I know Apple has a very long decade

57:16 long spatial computing roadmap. They eventually want to get to AR glasses. They'll have displayless glasses to compete with Meta uh several months from now in 2027.

57:25 Uh but he needs to get cracking. There are six major Apple products in development right now. Six major new product categories. Mhm. >> AI AirPods,

57:36 smart glasses. >> Yep. >> Pendant. >> Pendant. >> Smart display.

57:42 >> Is that the lamp or the the kitchen thing? >> No. No. Lamp is number five. Smart display is is is different. >> Okay.

57:49 >> Um the tabletop robot. So that's the lamp, the moving lamp. And then number six uh is a uh I'm going to say very little about this, but a security camera.

58:00 >> Okay. Uh interesting. Well, at least the Apple Vision Pro has one key fan. Do >> you think Do you think the lamp Do you think the lamp is a is a predecessor for a humanoid? Do you think Apple would

58:10 ever do a humanoid? >> I do. I do. But I think it's going to be a decade if they do. And they're going to wait. >> Yeah. I feel like it says it says a lot

58:18 that they're not >> talking about it >> that you don't know about an internal humanoid project yet. >> Yeah.

58:24 >> Oh, I do. Oh, but but >> yeah, they're exploring humanoids. The idea of a humanoid, >> but >> they're not working on it full throttle,

58:33 but they have a large robotics uh um initiative. They're working on AI robotics technology and they're also working on robotics hardware. Uh John Turnis actually took control over the

58:45 robotics hardware team uh about a year ago. He took it from the AI chief that Apple, you know, got rid of a couple weeks ago, John Jin Andrea. But they're also looking at they're actually

58:56 building a it's really cool a gigantic um manufacturing arm >> or a gigantic robotic arm that they want to use in manufacturing but also used in Apple retail stores to grab you know

59:06 products off the shelf in the back room and whatnot and bring it into the store. That's probably 5 years away. Uh but they're looking at robotics uh from a manufacturing standpoint, from a retail

59:15 standpoint and also most importantly from a consumer standpoint. They've also been exploring a mobile robot, something like an Amazon Astro, but I don't think that's probably going to see the light

59:25 of day. >> That's fun. I feel like Apple has the perfect brand. >> Talk about Talk about Turnis' challenge with supply chain broadly. What you

59:34 think he's going to be focused on over the next 5 years? >> I don't think he will be. I I don't think he will be. I think just like >> not but is that not you're saying like

59:43 just basically like >> broadly ignore that it's a kind of a key risk to the business to have you know as a team >> with a hands in all hands meeting with

59:54 Apple employees this morning he was pretty clear that Tim Cook didn't do everything Tim Cook chose his spots uh and turn said that he's going to pick his spots as well uh as we know turn uh

01:00:03 Tim's spots was uh operations finance and sales and he delegated everything else >> uh My sense is that Turnis is going to uh Turnis' mandate. Turnis was hired

01:00:14 because they believe that he is going to be able to bring Apple back to the forefront of product device uh innovation. >> Okay. They already have the

01:00:23 best-in-class operations, finance, uh salespeople. They don't need Turnis to do that. They need Turnis to keep his eye on the prize, which is products. >> Yeah. And what do people point to when

01:00:36 they say that there's a risk to Apple staying on the frontier of product development? I I saw the Android phone that has the uh the the privacy screen that you toggle on and off that looked

01:00:48 like kind of a cool feature. There's folding phones that they're working on, but are are any of these features that exist in other phones? feels like they haven't actually gotten a ground swell

01:00:59 and started pulling iPhone users away from the ecosystem. But are there key features that people are worried about or what that idea? Yeah. Okay.

01:01:08 >> It's not here yet. >> Nothing you've seen is the risk. Okay. >> The risk is whatever the hell Meta and Open AI and Hark and all these companies eventually come out with. The risk is

01:01:18 one of those companies doing something really cool. Yeah. >> And jettisoning Apple from that perspective. Uh, but we all know that nobody has done quote unquote cool stuff

01:01:28 yet to steal away iPhone users. Nobody's ditching their iPhone for for Android. In fact, the switching is going in the other direction despite the fact that Apple is supposedly the most innovative

01:01:38 company in the world and has the least innovative AI technology. >> Yeah. But consumers care about value and things like the MacBook Neo really deliver that value.

01:01:47 >> Brand colors system, privacy. Yeah. Turnis was only senior VP of hardware engineering at Apple for 5 years. It's a short tenure to be an SVP of a division at Apple. Uh,

01:01:58 and the reason is because he's >> Oh, there you go. No, he's been at Apple 25 years. I'm kidding. We use that ironically. >> No, I know. But the point I'm I'm trying

01:02:09 to make is that he still has a legacy. And Turnis' legacy is making Apple hardware more performant in terms of speed and battery life. and higher quality.

01:02:23 >> He's really focused on the durability and longevity and the reliability of Apple products. Uh and it's meaningful, I think, that the person that they chose to be Turnis' replacement in hardware

01:02:34 engineering, Tom Marab from Intel, uh is a product quality and reliability uh expert rather than a product design person. >> Yeah. Uh what was the thinking? I mean,

01:02:44 I remember we we talked about this how uh I I got the new iPhone and it has immediately been dinged. >> What was the thinking on making >> and uh but but but it's but it's better

01:02:54 for heat or better for wireless connectivity even though you can't get the color to adhere to the to the material as much so it scratches off. Is that the is that the current trade-off

01:03:04 like >> Yeah. >> Yeah. There's trade-offs with every material. Like titanium was light. It looked cool. You could beat blast it. It

01:03:10 did, you know, interesting. I mean, it looked interesting and it gave them a good marketing point. Like, oh, come buy a titanium phone. Like, anyone cares about the material of their phone. Um,

01:03:20 but it had really bad uh uh properties related to heat. Aluminum, which we've known for 20 years, is an excellent material to build consumer electronics out of. So, they went back to the

01:03:33 basics. Um, you know, they were really talking about at the end of last year splitting the line between ultra thin with the iPhone Air and pushing the iPhone Pro to the right as much as

01:03:43 possible by making it more performant. >> My expectation is they're really doubling down on this. Their goal is really to just squeeze as much performance and power in these iPhone

01:03:51 Pros as possible. Uh, and for everyone who needs less power, you can get the thinner and lighter iPhone Air. And I think you're going to continue to see Turnis push in that direction, making

01:03:59 the MacBook Pro as amazing and most performant as it can be and pushing everyone else to the MacBook Neo and the MacBook Air. And I think his legacy on performance uh in product quality is is

01:04:09 really important thing to remember. >> Yeah. >> Has Turnis uh ever talked publicly about AI in any capacity? >> He talked about AI uh in his all hands

01:04:22 meeting with employees this morning. Uh he said uh that >> I'm going to check it out. >> No, just hold on. >> Hold on. I don't want to give you uh

01:04:35 inaccurate >> Yeah. fake news. >> Okay. Yeah, just hold on. Bear with me. >> I think I internal memos.

01:04:45 >> No, no, no, no, no. He said that uh he's especially excited to be stepping into this role at this moment because I am telling you we are about to change the world once again.

01:04:56 >> He said Apple has an incredible road map ahead and that I'm not exaggerating when I say this is the most exciting time to be building products and services at Apple in my entire career.

01:05:05 >> AI there you go >> is going to create almost unlimited potential. we're going to be able to keep unlocking possibilities that

01:05:15 that are going to create entirely new opportunities for our products and services. And I'm so excited about what that's going to mean for our users. Uh earlier this month, he reorganized

01:05:25 Apple's hardware engineering division uh around in a new AI platform that they're going to be using to improve product development processes and overall quality.

01:05:33 >> Interesting. Okay. Uh uh I saw a post here from Bubble Boy. I want your reaction. Apple is about to become the mecca of hardware engineers around the world with John Turnis taking

01:05:45 over at Apple. Is Apple not already the mecca? Is is there actually somewhere to go? Uh but that is up in terms of hardware engineer recruiting. Do you see this as changing the culture in some

01:05:59 meaningful way? >> I mean they don't pay like these you know open AI harks and metas of the world. there. Apple has been pillaged by uh OpenAI and Meta and all these

01:06:12 companies as of late. They are stripping apart Apple's hardware engineering division, hiring people from every team they can get their hands on, throwing very big offers at them. And so this has

01:06:22 been a really big issue that Turner has been dealing with over the last uh year and change. >> Um so but Apple is, you know, the hardware

01:06:30 mecca. They're the company that everyone wants to poach from. Yeah. and they're the company that people go to to learn how to build uh consumer devices. So, this is definitely uh yeah, I agree to a

01:06:40 large extent with you actually. >> All right, with Bubble Boy. >> Yeah, Bubble Boy. Um what uh I this might be somewhat separate, but uh just get me up to speed on uh the folding

01:06:51 iPhone. What is the latest there? >> Uh announced in September, Turnis' first big new product. >> Yeah. >> Uh super exciting. Super pumped. Yeah.

01:07:01 Uh, we've talked about this. Uh, I'm sick of the candy bar phones. It's been the same junk for 15, excuse me, 20 years now. I want a foldable. I want a bigger screen.

01:07:10 >> Yeah, I really hope >> John wants a newspaper sized phone. >> I Well, they have those. I've seen those in China. The the trifold, right? But this is a biffold.

01:07:18 >> Don't get me started on the trifold. >> Explain the trifold. Wait, why are they awful? It seems amazing. >> John wants pages of screens that he can turn

01:07:25 >> flimsy and they break. You need a trifold at Apple like quality in 20 years because you know old time when they do a uh when they when Apple does a trifold it'll be good. But you know I

01:07:38 open up a foldable phone right now. You open it up and you can hear the screen sort of creaking, right? And then you have that big line in the middle and then it's like impossible to get your

01:07:48 thumb in to open the thing. >> Um >> I hope Apple fix that. I don't want to hear a creek. For $2,000 I don't want to hear a creek. I don't want it to stand

01:07:57 stand uh sound like I'm stepping on, you know, a wooden floor, right? I want it to just open and I want it to open quickly and nicely and it not be like I'm trying to lift the weight.

01:08:06 >> Yeah, it's still going to be weird for video consumption though because I feel like we've done vertical video 9 uh 9 by 16 and then 16 by9 widescreen. But if you open up a foldable phone, you

01:08:17 eventually get a square and that doesn't really make like a movie watching experience. >> Apples is different. And Apple's is like the new Huawei phone where it is um iPad

01:08:27 screen ratio. >> iPad screen ratio when you open it. Okay. >> When you open it. >> Yeah. Okay. So, still black bars.

01:08:33 >> Any intel on on uh >> No, no, no. Black bars. Black uh Yeah, sure. There will be black bars >> when you rotate it. black bars on the top and bottom if you're watching like a

01:08:44 cinema film or even if you're scrolling Instagram like you you won't necessarily get more view because for so long all the content production has been ultra widescreen if you're making a Tarantino

01:08:56 film and it's super cinematic or if you're on TikTok and you're doing vertical video then you're then you're going to have black bars on the side for for the most part but for so many other

01:09:07 applications you know for word documents and notes and >> TVPN will look great on it. >> Yeah. Yeah. Uh >> something to look forward to.

01:09:15 >> What do you think Turnis' new comp package looks like? You know, we were we we almost marched on Certino uh multiple times because of Tim Cook >> to get Tim Cook to get cup yourself to

01:09:26 the uh to the spaceship. >> Yeah. Exactly. Exactly. >> I would I just guessing I'm just guessing. Um I think a million shares >> over 10 years. That's pretty big.

01:09:43 >> Can I just tell you why I think that? Because that's what they because that's what they gave Tim Cook when he was named CEO a million over 10 years. So, I would assume it's the same.

01:09:51 >> Yeah. >> But again, I I I don't know. >> Yeah. entrylevel researcher salary, but it's a good start if you

01:09:59 can. >> Tim Cook is getting uh Tim Cook, you know, Tim Cook was getting 100 million a year and then everyone flipped out except you guys. And so he had to cut

01:10:10 his pay to like 40 million. And then when things died down, he's like, "All right, I'll I'll take I'll take my 70 80 million >> peacefully for for those years." And

01:10:21 then and then you should see my sleeve score once. >> We were really we were really the the strongest supporters of the the Tim Cook Pay package. But I

01:10:29 >> I I'd guess I'd guess a million. >> I was just I was just like the market values a baseball player at the same amount as a guy leading you know >> a$4 trillion company that

01:10:41 >> make it make sense. >> Maybe it'll be 500,000 shares. Maybe it'll be 500,000 shares. I I don't know. But I know that they gave Tim Cook a million.

01:10:48 >> You got to get those numbers up. You got to get those numbers up. It's time to march. >> Really? You're all in on furnace already?

01:10:54 >> We're we're bullish on both. We love both here. >> Uh >> well, now you get you get both now. >> I know we do. Uh yeah. What why uh why

01:11:03 why is 65 a retirement age for this CEO of Apple? Like uh we were talking about Warren Buffett. He was able to manage a you know trillion dollar organization well into his 90s. Uh is it a more

01:11:17 physically demanding job? Is he traveling more? Is it Is his hand ringing from shaking hands in DC? Like, why not have another 10 years if you're in that seat?

01:11:29 >> Uh, I don't think the hand situation has much to do with shaking other people's hands. >> Okay. >> Uh, why is he not there another 10

01:11:36 years? Well, he needs to give the new guy runway. >> Okay. Um, I'm sure there there are some in I'll just tell you what Tim Cook uh I'm not going to get into it, but what

01:11:49 I'm going to do is tell you why Tim Cook said he's stepping down. He said he's stepping down because it's the right time and there's an intersection of John Turnis being ready uh Apple's finances

01:11:59 being in a very strong place and Apple's future road about being in a very strong place. uh in terms of the real reason why he's stepping uh down now. You can read some of my prior articles uh taking

01:12:08 a deeper look at the at the situation. >> Okay. Yeah, makes sense. Cool. >> I love seeing you. I love talking to you. Thank you for coming on. >> Congratulations

01:12:17 coverage. Get some sleep. >> Great to see you, Mark. >> And keep up the amazing work. We'll see you soon. >> We'll see you in uh 15 years for Teris

01:12:24 Jr. >> Can't wait. We'll see you. Goodbye. >> Uh let's pull up >> the OpenAI launch. >> Open AAI launch. What's going on? with

01:12:33 two. I've been playing with this for a while. There are some wild wild examples. They are live streaming. >> Sam should have the death star meme for this for this launch layout into an

01:12:46 organized image. >> Uh and we think we made a lot of progress in both of this visual understanding and visual generation. Both of these aspects uh as a result

01:12:55 being able to handle this kind of tasks uh very well. Uh and um we now have an output for this where you can see eight different uh really cool outfits for me. >> K. What do you

01:13:09 >> The level of detail in these models is getting so extreme. >> It's post slop. >> It is post slop. That's a good point. Uh but I've se I've seen some where people

01:13:16 are like generate the entire periodic table with details about each element and a visualization of each element. And it's just like so much information, so dense that you have to wind up zooming

01:13:30 in so much just to get all the information. Uh it's like like the idea of generating like a single photo of a person in an outfit was uh was remarkable just a year ago, I guess,

01:13:41 when the Studio Giblly thing happened. And now you can generate layers and layers of uh of detail here. Uh good teaser. They said this is not a screenshot and posted the image

01:13:53 >> and detail. something that uh prompt tell tell everyone about the prompt you've been running with uh with Wiki. >> Oh yeah. Uh I've been doing this thing

01:14:02 where I take a Wikipedia article and I ask uh Image Gen 2 to turn it into an infographic or you can actually do an Instagram carousel like 10 images that tell the story of something. I did this

01:14:14 with John Turnis and uh it's it's remarkable. I mean the text is is perfectly photoreal. The other thing that's interesting is uh the uh the brand comes through in an interesting

01:14:26 way. It doesn't it's not like it has like one style for infographic. Like I had it make a infographic about John Turnis and his career and his path and uh everything that he's done at Apple

01:14:38 and it put in images of projects that he's worked on but then also had like an Apple-like brand aesthetic like a white background, the correct fonts. Uh, but then I did the same thing for like the

01:14:48 Elden Ring movie that we were talking about yesterday. So, I went and got the the Wikipedia for the Elden Ring movie that has some details and some leaks of who might be in the uh uh in in playing

01:15:00 different roles and it was able to go get images, go get head shot of those people, put those in because it has tool calls now. So you can actually like if you say like generate an infographic of

01:15:11 John Turnis' career, it will do like a pretty good job generating someone who looks sort of like John Turnis, but then you can actually just take his canonical headsh shot and say, "No, use this exact

01:15:22 photo of John Turnis and it will just drop it right in and so it looks it looks perfect because it is just like a copy paste basically on top of the layers."

01:15:31 >> Let's get some audio again. >> Let's see what else is going on here. >> Output. This is particularly useful for very complex prompts uh for things that require like web searches for require

01:15:40 you to output multiple images that have to maintain coherence with each other or even for it to check its work before saying hey here's your final output. But let's just like look over some examples

01:15:51 of this first. Uh Gabe actually kicked off a few of these examples at the start of the live stream. So let's go to the one on the phone which is the one of him and Sam um the selfie of them and they

01:16:00 created a manga of it. And if we look at the very first uh image, we can see Yeah, it does look like Gabe and Sam, right? >> Yeah.

01:16:12 >> But I think what's even cooler about it is that if you look at the follow-up images, they still look like Dave and Sam and they still look like in the style that

01:16:24 was originally maintained. how children's stories, coloring books, it's like >> better is that the story should be very consistent among pages one, two, and

01:16:33 three. >> I did that this weekend. It was very successful. Rave reviews in the Kougan household for uh AI generated coloring books for mythical creatures that my my

01:16:46 son came up with combining different creatures. >> We beta tested the instant version of this model on Elmarina under the code name duct tape. a few like a few of you

01:16:55 on the internet were like really good detectives and deduced that it was us. Um, but we're gonna announce that it was us. And so in this prompt, we basically asked that

01:17:05 >> uh basically GBT images too to go and find social media reactions to this duct tape model and uh basically quote quote people. Um, and so we see quotes from threads, LinkedIn, Reddit, etc. But I

01:17:19 think an even crazier part is that we've also asked the model to put a QR code to chatgbd.com so that you can try out this model right now >> um for yourselves. And can we just make

01:17:32 sure that it works? >> Yeah, I try. >> Oh, nice, nice, nice. So, uh, image generation with thinking allows you to do really complex things such as so in

01:17:40 this case, web search, synthesize answers, and put a QR code all in one image. But we have still more and Alex will talk to you about these new details.

01:17:49 >> It's so interesting the uh >> uh the the tool use is getting really really advanced version codeex where it actually was able to >> generate a

01:17:59 vector diagram to make sure that everything was correct and then regenerate the image on top of that. Uh of course the we we should go to the timeline because there's some people

01:18:06 that are having fun with uh uh the image generation. Uh someone made uh presidents in Elden Ring. Uh there's Joe Biden uh which is a you know Dark Souls style boss that you can fight. Uh and uh

01:18:22 FDR, Lord of the New Deal. And these images uh it just looks remarkable if you ever played any of the Elden Ring or or Dark Souls games. Um because of course like the text is is flawless and

01:18:34 then you can fight Richard Nixon in front of the Watergate. And uh this looks like a mod that I think people would play if if it actually existed. Uh uh Blake Robbins said, "The world is not

01:18:45 ready for the rumored OpenAI image model. People are creating Google Street View images that just look perfect and Grand Theft Auto 5 loading screens and uh uh there's a big trend of people

01:18:56 creating things that look like screenshots of live streams uh and then they put themselves in the live streams and have all fun with that." And there's one of uh of Sachi Nadella presenting uh

01:19:09 a slide and like even the minor text at the bottom of the slide in the picture. Uh it's sort of remarkable to to think that all of this is generated basically oneshotted. Uh Justine Moore was posting

01:19:21 about this uh long time ago, April 6th. This ad was oneshotted by OpenAI's image model. Prompt was literally make an advertisement for the M4 Pro uh Mac Mini. And uh I mean you can see how

01:19:34 quickly this will speed things up. Uh the question is just like what is your source content? What do you want to uh visualize or or deliver via this format? Uh the whole meme of like turn this

01:19:46 essay into bullet points, turn this bullet points into paragraphs. Uh now you can turn this infographic into text and turn the text back into an infographic. Uh I I feel like a lot of

01:19:57 >> talent here for tracking your Uber Eats and FedEx deliveries and it looks uh pretty believable. Yeah, >> we can pull up the pull up the screenshot here.

01:20:06 >> Yeah. Uh people um there's something there's something interesting about this where uh I I've seen a number of of uh slide decks that could be infographics. And I'm wondering if there's going to be

01:20:17 a new level of like compression where people are saying like just send me a screenshot like a onepager screenshot uh over text instead of like a slide deck that I have to click through. That is a

01:20:27 lot of information that >> but if you zoom in but if you zoom in there's like pretty like >> oh it's like pretty impressive fidelity. >> This is that's wild. Um, but yeah, uh, I

01:20:39 mean, if you're trying to if you're trying to deliver a whole bunch of information that that could go into slide deck, condensing it down into an infographic feels like potentially a new

01:20:47 trend. And I wouldn't be surprised if you see a lot of these, uh, flowing out into Instagram carousels and other sorts of content if you're trying to summarize some sort of content, a history, uh,

01:20:56 quotes, you know, any s sort of information like that. Uh, anyway, uh, Tyler Cowan, uh, back to the timeline. Uh Tyler Cowan made an incredible call back in July of 2020 in the depths of

01:21:09 COVID in Bloomberg. He said, "This year is likely to be remembered for the CO 19 pandemic and for our significant pre presidential election, but there is a new contender for the most spectacularly

01:21:20 newsworthy happening of 2020, the unveiling of GPT3. As a very rough description, think of GBT3 giving computers a facility with words, a faculty uh oh no, a facility with words

01:21:33 that they have had with numbers for a long time and with images since about 2012. What a remarkable post. This was two months after Gwen's scaling hypothesis post and two and a half years

01:21:44 before CHP was released. That is uh remarkable. There's a lot of folks that are chiming in with I called it too. Uh anyway, I believe we have our next guest in the waiting room, Scott Stevenson

01:21:56 from Spellbook Book. He's the co-founder and CEO. Scott, how are you doing? >> Doing great. Doing great. How are you guys? >> We're good. Welcome to the show. How are

01:22:04 you doing? >> Good. Yeah, thanks for having me. >> Can you uh I mean, I want to go into the contracted ARR debate, but uh let's get the update on Spellbook. How are things

01:22:14 going? Where's the company at? How are you feeling? >> Uh going very well. Uh we had a a killer Q1. uh crushed our our stretch targets last year. Um yeah, we're over 4,400

01:22:25 customers on board in 80 countries now. >> 80 countries. >> Yeah, we're the the the most used AI contract review tool in the world. So >> why why so international so early?

01:22:35 >> Uh it's been inbound. Yeah, we've had a ton of interest uh inbound. So yeah, it it really, you know, the choice is accept the customers or turn them away. You know, we chose to accept them. Yeah.

01:22:47 >> Is the product sort of multilingual by default? Uh I would say yes like there a lot of it is driven by AI models. AI models have some ability to deal with different

01:22:58 actually pretty good availability to deal with different languages >> and then we're able to supplement the models with legislation and um norms from many different jurisdictions since

01:23:07 we're a legal product. >> Yeah. Uh so yeah where where else are the key integration points like what's the hard work to like bring a country on board or even bring a new flow on board

01:23:17 or expand the capabilities of the product as models are just sort of getting better every month by default in the background. >> Yeah. I mean I think for us the the bit

01:23:29 you know we try to be two years ahead of the market and and and build things that are two years ahead of what anyone else is building in legal AI or elsewhere. And we've consistently done that. Uh we

01:23:38 built the very first Genaii product for lawyers back in the summer of 2022. This was like before chat GBT. >> Um so a lot of like cloud for word just came out. That was kind of what we

01:23:48 launched like four years ago. Um so we're pretty pretty far ahead >> uh from that now. What we really focus on is building >> unique workflows that are not just chat.

01:23:57 I think if you're building something chat shaped um it's very difficult to make that defensible because there's going to be some really good general AI products for just generic chatbased

01:24:05 work. What we focus on at Spellbook is really rails for high volumes of contracts and contract workflows. So we sell to like Fortune 10, Fortune 100 companies, um, and really companies of

01:24:16 all sizes who are processing, you know, hundreds of thousands of contracts. Um, not just with the legal team, but with their sales team, their procurement team. Sure.

01:24:25 >> Uh, you know, we're in manufacturing, shipping, you know, all of these different verticals. Um, and we kind of build this these end toend rails that allow these contracts to move quickly

01:24:36 and safely through organizations. And like there's a lot that can slip through the cracks when you're dealing with these high volumes of contracts and a lot of mistakes are made. So, um, you

01:24:44 know, we give like every legal team a second set of eyes on like these massive flows of contracts going through the organization. >> Yeah.

01:24:51 >> Uh, what drew you to Cargate? Why uh are are other is it is it legal AI companies that you that you feel like are are uh getting a little bit dicey on this front or or you know

01:25:06 >> uh how how do we get here? >> Yeah. So, I've got some interesting examples to site, but you know, I think I think it's an enterprise AI problem. And I'll say I'll say first like my goal

01:25:15 here with this tweet and and what I'm doing is is to destroy as much equity value as possible by by discrediting this obscene metric of C or at least the way it's being used today. Uh so we can

01:25:28 all get back to like building real companies. So that's that's that's that's what I'm trying to get out there. >> Sure. >> Um what I mean

01:25:34 >> where this came from is I think I just noticed more and more founders and investors telling me things about ARR reporting. you know, mainly the p public reporting, but also some of the internal

01:25:46 reporting that was just getting more and more skewed >> and um yeah, there's all these headlines being published about, you know, ARR records being broken.

01:25:54 >> Sure. >> And um you know, when the laws of physics are being broken, you have to ask, is it is it AI breaking the laws of physics or you know, uh might there be

01:26:03 some other kind of illusion going on as well? And I think I think it's a bit of both. we have really high growth, awesome companies being built, but when you have really high growth, you know,

01:26:12 um uh issues can kind of fester and hide um underneath. So yeah, I' heard heard a lot of more and more stories of people using this this metric of CR often using this metric when they're talking to

01:26:25 press um about, you know, um their their revenue and then gaming it in some pretty pretty obscene ways. Um, so maybe I just tweeted about it. Yeah, the the tweet. So you say the setup company

01:26:38 signs three-year enterprise deals. Year one is discounted, say 1 million. Year two steps up 2 million. Year three is full price. They report 3 million >> as ARR even though they're only

01:26:50 collecting $1 million this year. That's a big deal. >> The worst part, the customer has an opt out option at 12 months. It's not actually a three-year contract. So,

01:26:58 they're basically like taking the three-year number, pulling it into the present, even though it's not a it's not it's a contract that that the customer can can get out of.

01:27:08 >> Interesting. >> Um, and they're not actually on on the hook. So, it's not really uh >> Yeah, it's rough. Uh, we So, yeah. Yeah.

01:27:17 Yeah. Just react to that, I guess. >> Yeah. Yeah. So I think I think you know that's a specific real example that I I heard of in the wild from a from an insider of how this this these AR

01:27:27 metrics were being gamed um to create you know some some amazing revenue charts. But I would say there's you know a broad category of issues that I can talk about like a few of them that you

01:27:36 know after the tweet went viral I got a huge response of other founders and investors saying that they were saying the same thing and like some other examples of the types of of gaming

01:27:44 that's going on. Yeah, because because you get one person in a category that starts doing this then then the other people >> like suddenly have to start reporting

01:27:55 the same way and >> it it creates a vicious cycle. >> Yeah. >> And it start and it starts pretty innocent. You know CR for folks that

01:28:03 don't know C is contracted AR. So it allows you to count revenue that's not live yet. So maybe you're doing like a nine-month implementation or you have a one year

01:28:13 >> for short short-term stuff like hey this this this contract is going you know this >> this uh customer is actually going to be going live next quarter but we've signed

01:28:23 it and we're just going through the implementation process >> and but but tech there's nothing that there's no like >> law that says you can't say like we're

01:28:32 going to extend the the sort of like timeline dramatically. It just is not a very grounded way to run your business. >> Exactly. Exactly. Yeah. And like I think it's innocent like three months extra

01:28:44 credit you know arguably useful um but it's a very easy metric to game especially if you miss those obligations. So I think because we we've kind of normalized you know the forward

01:28:53 deployed engineer which you know we used to call professional services and so now you have these really complex implementations where you might be promising a customer like hey we'll

01:29:02 build this feature and once we build this feature then we'll start billing you. What happens if you don't build that feature? So, one of the issues you see is companies stacking all these

01:29:10 commitments of they'll they'll switch on billing once they deliver X with their forward deployed engineers and then what happens if they miss that or what happens if that gets delayed. Um they

01:29:20 that and then they're reporting it up front as ARR publicly. Um but they're not actually at the point where they're the AR is is live. So, yeah, that's another category of issue. And then

01:29:30 there's, you know, people reporting pilots, you know, just three-month pilots as AR and they're free free pilots um that, you know, I was talking to an investor uh yesterday who just

01:29:40 sees that all the time from early stage companies like coming out of accelerators saying they have like a millionaire R and they look under the hood and it's just all pilots that

01:29:47 haven't converted yet. So there's a host of different um you know issues with the metric. And then and then the other one is the step-up contract where yeah you're stepping up you know in year one

01:29:57 is you know 25% of the cost year two is a little higher year three is higher and then people are either amortizing that back over the period to get a higher average or even taking like that year

01:30:08 three amount like you said at the beginning. So yeah there's a bunch of patterns that are happening. Um the other thing is like there's early optouts. So like

01:30:16 >> you know you can have early optouts in these long-term contracts. Um and but there's all I mean we're a contract company so there's a million ways that a contract can be terminated by

01:30:26 >> seen a few seen a few contracts. >> Yeah. Yeah. Yeah. So >> yeah. >> Yeah. I think I think it's it's a really ungrounded metric and people should stop

01:30:36 using it to report their enterprise AI companies should stop using it to report their AR publicly. I think no one should take it seriously. Um except maybe internally for some projections. you

01:30:46 know, it's it's not a not a good good metric. >> What is the gold star example of using ARR correctly? Because it's very easy once a company's public to just say,

01:30:57 okay, let's just go off of uh you know, GAP revenue for the year and like what did you actually book this quarter? There's a whole revenue recognition policy. Uh it feels like there's some

01:31:08 benefit to tracking ARR month by month if you're a high growth startup. But uh what is >> overrated? Companies should just report their daily annualized run rate

01:31:18 >> or hourly. >> Yeah. And and and that goes into the debate of annualized versus annual, right? So how have you processed sort of the the better cases or like like what

01:31:28 is the responsible way to report a revenue metric in 2026? >> Yeah. I mean uh I think uh it it depends on the company and the shape of the company and whether it's it's usage

01:31:38 based billing or seat based billing uh which you still have lots lots of both. Um definitely don't do like hourly you know annualized re run rate based on the on the hour. Um that's not good.

01:31:49 >> Um I think the main the main thing I would say is it should be live. It's like what revenue is actually live right now for like what customers are you actually billing and are actually paying

01:31:59 you. Um, so calculating run rate based on, you know, the the month of revenue that you have coming from customers that are actually paying you that you're actually billing, I think that's okay. I

01:32:09 think, you know, annual recurring revenue based on live customers that you're actually billing, that are actually using your service, I think that's pretty good. I think once you

01:32:17 start stretching into people who will pay you or, you know, might pay you, um, that's where things start to I mean, it can just be so easily gamed and anything that can be gamed will be gamed.

01:32:28 >> Yeah. Yeah. I mean, optimistic that anything will change or do we need to see a massive correction and uh and a dark and a and a dark the dark ages like uh post post 2022.

01:32:42 >> Um I I mean I would like to see a steep correction and then back back into back to building. You know, we'll see if we can make that happen. Um, you know, my reach is only so far, but you know, I

01:32:53 I've I've spoken to a lot of reporters in the past like 48 hours who are like I'm always going to ask now like when a company tells me their ARR, are they talking live error? Are they talking,

01:33:03 you know, this like long-term committed AR that might come? Um, so I hope, you know, at least the journalists are going to be a little little bit more um little bit more savvy and uh ask ask more

01:33:14 questions before they report on these numbers. Yeah, the uh I want to ask about who suffers but uh in terms of ARR like yeah there's almost something where you should just report your last month's

01:33:25 revenue instead of doing the times 12 thing and then if people want to multiply it by 12 they can but at least you're just reporting hey last month this is what a stripe account

01:33:35 >> you can also just say by Q3 we will be at X >> ARR >> oract that's a different way of saying that's that's better than saying we are

01:33:44 we are at 10 million in >> Yeah. >> C A R C C A R R >> Yeah. Yeah. So, >> exactly. Much better.

01:33:52 >> Who who suffers here? Is it is it purely investors? Because I feel like a good venture capitalist, their job is to dig into the contracts during due diligence to set prices. And if they want to pay,

01:34:03 you know, a thousand times ARR because they think it's 100 times CR, like that's their risk profile. Like I would maybe be careful, but you know, that's their job. or is there a risk that uh

01:34:16 employees see a headline number and think that the business is more stable than it is and they join and then they're they're rugged like uh how do you think this affects the the who needs

01:34:26 to watch out for this basically? Yeah, I mean I think um I think investors are generally good investors are generally very aware of the difference between C and AR and aware of

01:34:35 the the widening gap between these metrics and like in most board decks you see two metrics on the press you only you know you usually see CR but it's called AR in in a board deck you see

01:34:45 both metrics so so >> you know investors are quite aware but but I I I don't think it's victimless at all I think yeah employees are signing up for companies and as you know in like

01:34:54 a a high growth startup people are committing a ton of blood and sweat to be successful based on, you know, part of it is based on the growth of their equity and if it turn and they might

01:35:03 think there they're they're multiple, >> you know, they might read the headline number they may not know the number that's actually in the board deck. Um, they might read the head the headline,

01:35:12 you know, ARR in the in the press release and they might b their decision to join a company based on these headline revenue numbers which are really not grounded in reality what

01:35:20 whatsoever. Like, and by that I mean I have literal examples, confirmed examples of, >> you know, the the press number being three to five times higher than the

01:35:29 actual live AR number. So like that's a huge difference if you think about a multiple. Yeah. >> Um >> Yeah. between a public company and

01:35:39 that's trading at 10x revenue multiple or something and then you get your you get your offer from a company and it seems like they're at 10x but they're actually at 50x. like that is very

01:35:49 material for how you should think about valuing that that stock that you're working for. Makes a ton of sense. >> Then there's the customers like customers are trying to figure out which

01:35:57 company is most mature or least mature and then there's the you know like the the whole competitive landscape. It's like if one person if one company starts doing this all companies have to start

01:36:05 doing it and it just creates >> Yeah. I mean we could start doing contracted viewership so we could sign threeyear deals with people in the audience that requires them to tune into

01:36:17 the show after every every year they have an opt out after a month. If they don't if they don't like it after a month still advertising based on contract of viewership. I'll sign the

01:36:26 contract for the rest of the year. I'll watch every day every hour. I mean I mean I I guess that sort of does happen for YouTube channels that I mean no one really does this but uh there was a time

01:36:36 when YouTube channels were sort of valued on like the subscriber number as opposed to the average view number. And of course there are some channels where every video gets a million views and

01:36:46 they only have 100,000 subscribers for whatever reason. And then there's vice versa where someone's been doing you see this on like old legacy media accounts on X where they it'll have like 30

01:36:56 million followers and then the post will get like three likes and it's like those are two wildly different metrics. Like that happens all the time. But this is the name this is the name of the game in

01:37:04 Silicon Valley, the metrics game. Everyone's finding an edge somewhere. Well, uh thanks for keeping everyone honest and uh good reporting. Good luck fighting the good fight out there and

01:37:14 spreading the good word. >> Don't don't uh don't get too sucked into all this >> you're a business to build. Yeah, >> you can take you can we promise you can

01:37:24 come back on in three years with your with your honest ARR and take a good victory lap. >> No, no, become an investigative journalist. Pivot to investigative

01:37:35 journalism. Blow the doors wide open on this. >> Wow, this goes deeper than I thought. >> Good to Good to see you. >> Have a good one.

01:37:44 >> Thanks, guys. >> We'll talk to you soon. Up next we have Alex from Osmo buildingactory intelligence. We've talked about this

01:37:53 before. Can AI smell? That's our current benchmark for AGI. We say if if uh you know we talk about white collar work. We see Somalia as white collar workers. Unless you can smell it's not AGI and

01:38:09 artificial intelligence is falling short. But it's your first time on the show. I would love an introduction on yourself and the company. uh because I'm fascinated by this topic.

01:38:18 >> Let's talk about it. Your Somalia comment and also what you talked about with Max Hodak's been on my mind. Amazing. >> My name is Alex Wilsko. I'm founder and

01:38:25 CEO of Osmo. We're giving computers a sense of smell. >> I've been uh working on this problem for 20 exactly 20 years or so. first as an academic success did my PhD in alactory

01:38:38 neuroscience um at Harvard and trained under Bob Data who trained with Richard Axel got the Nobel Prize for discovering the receptors of smell >> and my AI mentor trained with Jeff

01:38:47 Hinton who got the Nobel Prize for deep learning and I'm the one weirdo that's like one of those been waiting for you to come for the entire history of the show

01:38:57 >> been great prophecies of your arrival >> hundreds of years I'm so excited I'm so pumped to here. So, so uh should we start with uh maybe like a old factory science 101? Can you set the ground on

01:39:11 like how does smell even work? What are the important sort of like building blocks that we should know and then we can build up to the next generation and how AI is being applied

01:39:20 >> it the 100%. So the chemical slice of reality all the stuff that's data in the air we can detect that um our sense of smell is literally our brain leaving our skull. So when you smell a molecule,

01:39:33 whether it's a tree or it's a meal or a drink, like the mo the physical pieces of that thing enter into your nose and touch a piece of tissue about the size of a postage stamp

01:39:43 >> and that's your brain, right? So like you were in physical communion with that thing. >> That information gets turned into neural data which actually skips all of the

01:39:51 normal way stations for the other senses and goes right to your centers of memory, the hippocampus and emotion, the amydala. So our sense of smell is very primal in that regard. So it's it's like

01:40:02 in the reason why when you smell something you get dragged into a memory and you cannot stop it. You're just like back in high school or you're back as a kid is because we're physically wired

01:40:10 for that. >> So that's real. I've always heard that. I've always heard that phrase smell is the sense that's most tied to memory. But I didn't know if it was just

01:40:18 something you saw on like a t-shirt or something. >> No, literally neuroanatomically true. Target wall art. >> Yeah. Yeah. It feels like Target wall

01:40:26 art. I don't know. It's just one of those things that you repeat. >> They say a spell from pops a thousand words. >> Okay. So, uh that sounds like something

01:40:33 that's extremely hard to reverse engineer. Do we have do we have sensors? Because, uh you know, LLMs, it was so obvious that we had text that was already encoded into data into ones and

01:40:46 zeros. And so transforming that and encoding it, it I mean, it was an incredible breakthrough, but it felt like the the text was the data was already in the computer. And I feel like

01:40:56 that's not true for alactory data for smell data. But how are we are do we need to digitize this before we do anything with it? How does digitization of smell work?

01:41:07 >> Yeah, great question. So I was very fortunate to have those guys as my colleagues. I actually spun Osmo out of Google Brain. Oh. >> And so I was there when all that stuff

01:41:15 got invented and I ran a digital action team at Google Brain for about six years before we decided to make it a company through Lux and through GV. Um, and you have it exactly right, like the internet

01:41:25 had been been accumulating for a while. So, we had all this text data. So, we could basically slurp that down and start building models. Um, >> we have chemical sensors. They're called

01:41:36 mass spectrometers. There's other kinds of chemical sensors, mock sensors. There's like a dozen. The history of sensors that uh can turn chemistry into data is about 100 years old, maybe more.

01:41:46 I mean, a lot of it was pushed forward in the Manhattan project, actually. Wow. >> Um, but what we've been missing is a map. >> Okay. Right. So uh for sound low to high

01:41:54 frequency is a map which lets us build MP3 and speakers and microphones and Spotify etc. And for color RGB is a threedimensional map of color and that lets us build CMOS CCD you know cameras

01:42:06 etc. >> We haven't had the map for smell and that's not crazy because there's three channels of color information in our eye but we know there's over 300 channels of

01:42:14 information in our nose. Wow. >> So, in a way, we actually did need to wait for artificial intelligence to mature in order to have the ability to extract a 300dimensional map from data.

01:42:23 And that's exactly what we did starting with our first work at Google Brain. So, you got to go get a crap ton of information, right? A bunch of molecules, what they smell like. Um,

01:42:31 we've since collected the largest AI data set uh for scent in the world. That's what drives allactory intelligence. We have 5 million sniffs digitized. Um, over a quarter million uh

01:42:42 physical samples created. We've digitized about 6 billion uh fragrance molecules. So like all this is like inside of the company because there's literally nothing on the internet. The

01:42:52 fragrance industry has done a phenomenal job keeping everything secret. So we built it all ourselves. >> Remarkable. Jordy, >> how are you going to make money on?

01:43:00 >> It's a good question. >> So if if if you go actually let's how can we make money on this? So does TBPN have a scent? >> Yes. And it's terrible. There's rubber

01:43:11 smelled in the >> So there's in the studio in the studio there's like thousands of cables >> and cables. You can't really see them. We do a good job hiding them but we have

01:43:21 so much gear going everywhere. >> It's a lot of rubber. A lot of >> So we had to get these u >> racetracks they're called to cover all the cables. And it turns out these

01:43:30 things smell terrible. Those smell very very >> Yeah. They off gas. >> So we wanted to give our viewers the the full speed experience. I think we

01:43:39 actually do not. >> It would be like a can that sits on their desk aerosol and it would just spray a rubber smell into the room >> so they could experience the experience.

01:43:50 >> We could capture it, but I think we should fix it. So, really concretely, we raised our series B. We put an additional 70 million in the bank um with two sigma leading uh Lux.

01:44:01 >> Love it. I got the gong. >> That that was to underwrite building a fragrance factory. Okay. >> So, we have a robot that's the size of a school bus that makes a new fragrance

01:44:10 every 100 seconds. And what we do is we design and manufacture fragrances for brands. >> Oh, yeah. That makes sense. >> And so, we we use all factory

01:44:16 intelligence to design it. So, super fast, data driven, basically, you know, perfect fit for the brand for and for the consumer of that brand. And then we actually physically make it. What leaves

01:44:25 our factory is a steel drum of that fragrance oil and we build them for it. >> Uh we also will do end to end. So, like if you want to actually make the physical bottle, we'll actually put the

01:44:33 fragrance in the bottle for you. So, the full product comes out. So, if you guys want to launch a TVPN cologne or something like that, we could design it for you. I mean, like, if you tell me

01:44:42 the prompt right now, >> smell like burnt rubber. >> No smell. We're not doing burnt rubber. >> Burnt rubber. There's some It smells like disagreement.

01:44:49 >> No, it needs to smell like uh like like old $20 bills. >> Okay. >> From the 1980s and mahogany, the official wood of business.

01:44:58 >> We need We needed to smell like mahogany mixed with with old $20 bills. The smell of money. That's amazing. >> Okay, cool. We've done this we've done the smell of money one which we demoed

01:45:08 actually on the New York Stock Exchange floor which is pretty cool. >> That's amazing. That's amazing. >> But uh No, I'll I'll send you I'll we'll make something. I'll send it to you.

01:45:16 >> Talk about uh sensor miniaturization. My phone has three cameras and no smelling sensor. Can we swap one of these out? Like I when you say massspec I imagine like a device the size of a living room.

01:45:31 I imagine that they are getting swapped. dishwasher size of the dishwasher. >> Uh is there a path to actually shrinking that down to something that's more uh portable?

01:45:41 >> So yeah, in the same there's like many kinds of cameras, right? So the one in the Hubble telescope not getting smaller. So if you need resolution, it's got it's going to be big, but you can

01:45:50 make trade-offs and like when the thing that's reading the data instead of it being person, it's an algorithm. You can actually make really intelligent trade-offs, which is what we've done. So

01:45:57 we actually have a sensor right now. It's the size of two shoe boxes. Okay. Um, and I kind of use that metric aptly because we've actually used it to smell fake shoes.

01:46:06 >> So, if you're buying a pair of like $500 Air Jordans, the real smell different from the fakes, we can actually pick that up. >> That's crazy.

01:46:13 >> Turns out we can >> Yeah. >> Yep. The the the counterfeits use cheaper glues, turns out. >> Um, and uh uh the the other thing that's

01:46:22 interesting is we can actually tell the factory of origin of the shoe 93% of the time. >> Mhm. >> So, the smell is a fingerprint. So,

01:46:29 we're already devices. Look, the path to get from two shoe boxes to one shoe box is pretty clear. >> We're working on that. AirPods,

01:46:39 >> there's going to be some like hardcore engineering required. To have it be a component that fits in your phone, there's some breakthroughs. Like, I can't quite see through the fog yet, but

01:46:47 there's nothing like look, our noses do it. So, there's nothing that mother nature's saying anything impossible, but we just got a lot of work to do. >> Yeah, that makes a lot of sense. Uh,

01:46:54 what about taste? How closely is taste linked? Talk me through the Somalia example. >> Yeah. So flavor is everything that happens in your mouth. You know that's

01:47:05 that's a sensory experience of food. Taste is n is like 10% of that. It's like what happens on your tongue. Like you ever eat a jelly bean and it like plug your nose. Yep.

01:47:13 >> And you you just actually can detect very little of what's going on there. Yeah, >> it's because 90% of what you experience is actually called retronasal faction

01:47:20 where when you're biting or biting on something, there's a chimney effect in the kind of almost the steam of what you're eating goes back through your nose and you smell it.

01:47:28 >> Excuse me. And uh uh then there's also the texture and everything in your mouth. So, uh we've done tests and our OI models, this is from a while ago, we haven't revisited it. We're really

01:47:38 focused on fragrance right now, but our OI models actually work on flavor surprisingly well. And so the whole world of flavor is there for us when we're ready, but we're we're really

01:47:47 focused on on this particular business. Yeah, >> I've seen a couple of these uh sort of I don't want to call them niche, but like vertical uh AI projects that are not

01:47:57 fully generalizable. There's a a DNA model also from Google or Deep Mind. Uh and it feels like they're starting to get on scaling curves, on scaling laws. Are you at a point where you feel like,

01:48:13 oh, if I 10x the compute, 100x the compute that goes into some >> I believe Alex is ready for a 1 gawatt data center. >> He can be trusted with that.

01:48:22 >> I I I would trust you. >> But but but how how universal do you think scaling laws are? Is there a scaling law here? Is it datab based? Is it computebased?

01:48:33 Both? How are you think about >> the bitter lesson's real? The better lesson's super real. Um, I always think about technology as S-curves, right? And like what's driving you up that S-curve

01:48:42 and then how can you hop on the next one? Our current S-curve is data, which is why we're maniacally focused on like generating a ton of data. Like we have a giant fragrance robot that spits out a

01:48:51 ton of fragrances. We have mass specs running 24/7. We have sensory panels both domestically. We have a building of people that just smell all day abroad. Um, and we ship them crates of stuff to

01:49:00 smell. Um, and that's how we get to 5 million sniffs, right? Uh, so data data data. Um the the the size of the models is not the limiting factor right now and it will be at some point and then switch

01:49:10 to the other scurve >> yet. Yeah. Because you don't just have like the open internet to scrape because there's not an existing data set. Makes sense.

01:49:17 >> Totally double-edged sword, right? So we've had to make it all right. Which is really hard, but also nobody else has it because we had to make it all and had to learn a ton of stuff in order to do that

01:49:25 at scale and efficiently and all that stuff. >> Yeah. Where is the where is the business today? I mean you've raised money. Uh it seems like there's, you know,

01:49:33 monetization opportunities for sure. Uh are you fully in commercialization? Are you still in research? Is it half and half? Like how do you think about raising more money over time and and

01:49:45 just growing the business? >> Yeah. So we're we're always going like we we started with like this curiositydriven drive to figure out how to digitize smell, which is like a

01:49:53 pretty wacky thing to do. So we're always going to be trying to push the edge here. But look, we have a factory. We manufacture fragrance for brands. Um we did this commercial kind of R&D to

01:50:04 commercial transition last summer and we're kind of almost at the end of that and we built a manufacturing organization. We built a sales organization. Um we have some really

01:50:12 amazing partnerships uh with some big brands uh and we're making fragrances for brands. You can go into Target and buy a product that has our fragrance in it today. Um and so we're scaling this

01:50:21 part of our business. We're still placing bets on the future though, right? So, I think we've got really the tiger by the tail and it's it's a whole other conversation. Sometimes you come

01:50:30 to the factory uh in New Jersey and see how it operates, but like the fragrance industry is wild. We've got a lot of work to do there, a lot of opportunities, so we're focused on that.

01:50:38 >> Amazing. Well, congratulations and thank you for the work that you do. We think it's so important and >> one of the most interesting companies we've ever uh we've ever learned about

01:50:48 on the show. >> Yeah. True science fiction. I love it. And >> we're trying to make science fiction into science fact, but like open

01:50:54 invitation to come see how it all gets made. It's pretty crazy in person. So come to the Willy Wonka chocolate factory where all the stuff happens. >> I would love to.

01:51:02 >> Thanks so much. >> So great to meet you. Come back. Come back on soon. >> Oh yeah, we'll talk to you soon. Have a good rest of your day.

01:51:07 >> Uh we're running a little bit behind, but up next we have Spiros from Resolve AI raising a massive round to build AI that runs production systems. Let's bring in Spiro. How you doing? Hello

01:51:20 guys. to be here. Welcome to the show. Uh sorry we're running a little bit late. Kick us off with an introduction on yourself and the company. >> I'm one of the founders uh and the CEO

01:51:30 of Resolve AI. We're building agents that can help you debug and run production. Think of it as the counterpart to coding agents that produce all this code and our agents are

01:51:39 there to support you. >> Okay. Uh are you always are is your customer always like deeply in the throws of vibe coding has rolled out agentic coding across many

01:51:52 organizations. Uh like who is the target customer? Do they have to already be uh deep in the agent coding wave to really get the value here? >> They don't have to but the two are

01:52:03 correlated like anybody who runs a large software system has this problem. The only solution we had so far is humans manually solving it, right? Using the tools, being on call.

01:52:12 >> Of course, now AI allows us to to automate all of this. But I would say this is true. It was true before. Now with all the AI generated code, it becomes a necessity, right? So we see

01:52:21 strong correlation between the two often. >> Yeah. And and what are what are customers coming to you uh asking? Is it is it I want the code that's that's you

01:52:30 know written we're writing way more lines of code. we want to be more readable or we want it to be more secure or we want to be more performant or all of the above.

01:52:37 >> The way to think about it is like for anybody who's delivering their business through software. Yeah. >> Look at some of our customers, Coinbase. >> Sure.

01:52:44 >> Salesforce, MongoDB, right? To them, reliability is of paramount importance. If anything goes wrong and affects customers, it's a big problem. >> Yeah. So resolve becomes essentally the

01:52:54 first level of defense that captures any problem that happens in production that can affect end users gives you a resolution and a fix let's say so you can accelerate that loop right and uh it

01:53:06 doesn't take too much human effort but more importantly it doesn't cause impact to customers >> um what is uh like I mean the the the company is now over $1.5 billion in

01:53:16 valuation uh what has been like the key to growth is it just uh productled growth. Do you have a big sales team? How are you actually scaling the the the business as you scale the valuation?

01:53:30 >> Yeah. So this is a very big problem, right? Anybody who has I said delivered their business software is facing this issue. >> Yeah.

01:53:38 >> And whether you're a CTO, you know, who pays for let's say developers to focus on reliability or whether you're an individual that has solved this problem, you'd rather have AI do it for you.

01:53:47 >> Yeah. So we've seen like huge amount of demand from day one since we launched the company a bit more than a year ago. >> And we've seen it coming from both big and small companies. We primarily

01:53:57 focused on larger enterprises because we think there's a lot more complexity. >> Yeah. uh you know given the complexity of the software and uh you know most of the growth I guess most of the the the

01:54:07 let's say the demand comes inbound to us because it's a well understood problem and of course we have like both a productled approach let's say but also sellled approach as we work with large

01:54:17 customers >> yeah in in some ways like the naive approach would be okay just point a typical AI agent at the codebase and just tell me you know where the fault

01:54:27 lines are but I imagine there's some special sauce in the engineering to understand knock-on effects that can happen across a large codebase. Are you actively working around context windows

01:54:39 or or or creating like a special harness to understand the these problems that can come up before they do? >> Yes. So think of it like we have a production ID basically, right? The same

01:54:51 thing you have for your code, we have it for all your production systems. Yeah, >> production involves code involves let's say telemetry logs metrics like tools like data doglank it involves AWS right

01:55:00 so you have to deal with all of these not just code >> and then we also are training our own models now to improve let's say at the state-of-the-art let's say right how far

01:55:08 you you can go far enough let's say with you know a good harness you know and uh a lot of work let's say on the on the agenic front but now and we just announced together we're funding that

01:55:20 we're building a lab >> to focus on actually you uh training our own models for this domain. >> Sure. Sure. Uh how uh what is uh what goes into getting like relevant data or

01:55:34 actually nailing a specific model for this? Because I imagine that you have some great clients. They probably don't want you training on their data. At the same time, if you just grab some open

01:55:45 source code, it might not be as complex as like the Coinbase monor repo or whatever they have going on over there. So how do you how do you actually uh create enough training data to to

01:55:56 justify a special model? >> What is important here to understand is like the training doesn't happen like on code per se, right? What what happens on is actually the action a human takes

01:56:05 >> to perform a task for the most part. >> Yeah. Yeah. >> And we're talking about very long kind of uh uh let's say planning tasks here, right? It might take like many many

01:56:14 iterations looking at code looking at data dog looking at infrastructure. So and this generally speaking this this is not in the training set of models. >> Mhm.

01:56:22 >> Uh so and software let's say general is a both deep and wide domain right. So I think if you actually focus on building a model for the types of problems we're trying to automate in how you run and

01:56:32 debug production I think you can have a lot of gains both in performance cost but even like quality of outcomes right and that's our goal. And I would say you know the big labs uh make it sound make

01:56:43 it look like it's impossible for anyone else to build a model but I don't think that's the case. And you know that's what we're seeing ourselves with our investments.

01:56:49 >> Yeah. >> How do you put together such a low dilution round? What what >> Yeah. Yeah. Tell us about the round. I want to hit the ground.

01:56:55 >> The 40 on one and a half billion. >> So it it is an extension. We we just did essentially da we just we just did the at the billion dollars like two months ago, right? And

01:57:07 I would say resolve. >> There we go. >> Sorry. result is always essentially in many ways created this market, right? Like AI

01:57:17 for production. >> Sure. >> And I think it's well understood by investors. It's also proven given the customers we have.

01:57:23 >> Yeah. >> So uh and we're also a very ambitious company, right? Like we are obviously trying to build the agents and the models for this domain

01:57:29 >> and we have a lot of traction. >> So I mean as simple as that, right? Like there there's nothing you can do to create a low dution now other than be very successful in my opinion these

01:57:38 days. >> That's a great answer. >> That's a great answer. Be step one, be successful. I love it. >> Like step one, focus focus on building a

01:57:47 focus on building a business, right? Like this this is my first startup as a founder. >> Yeah. Yeah. >> I made this mistake many times before,

01:57:52 right? Of thinking that raising money is success. It's not. It follows real success on a product. >> Yep. No. No, that's 100% right. I love it. Uh well, thank you so much.

01:58:01 Congratulations on the new round. Great having you on the team. Excited to watch you guys come. >> Thank you. We'll talk to you soon. Have a good day. Goodbye. Up next. We have

01:58:11 Carolina uh Agalar from InBrain Neuro Electronics building the first inhuman study of graphine brain interfaces. >> What's going on?

01:58:22 >> Welcome to the show. How are you? >> Thank you. Very good. Thank you for having me. >> Please uh since it's the first time on the show, introduce yourself and the

01:58:31 company a little bit. >> Yes. My name is Karolina Gillar. A lot of people call me Karola. Uh I am the CEO and the co-founder of Inbrain Electronics

01:58:41 >> and we are a graphim based brain computer interface therapotics company that actually is developing the most intelligent um interface between the neural system and AI to restore health

01:58:53 for billions. >> Okay. Uh so walk me through brain computer interfaces and the decision tree that got you to graphine specifically. Uh I'm familiar with like

01:59:06 the first decision is probably invasive versus non-invasive. We've talked to a a number of founders that have taken either approach. Uh how did you uh how did you confront that first question?

01:59:19 >> Yes. Well, I call them implantable and non-implantable systems. >> Yeah. And in our case, we are an implantable company.

01:59:28 >> Yeah. Um, we believe that the real signal processing that is going within the neural system is actually deeper in the brain and and to listen carefully to what it says, what the neural system

01:59:40 says and being able to decode it but also modulate it. >> Uh, we need to be close to those neurons um and interact with those neurons firsthand.

01:59:50 >> Okay. So, uh, when I hear modulate, it sounds like not only processing information that's coming out of the brain, but also potentially writing information back into the brain. Is that

02:00:01 the long-term vision? >> Yes. And this is um the the magic of graphine is actually about reading and writing very effectively at micrometric uh precision within the brain. I think

02:00:13 that's why we took let's say higher risk to get an advanced material into this panel because we see that the benefit is is incredibly impactful. >> Okay. What what are what are the most

02:00:25 near-term commercial applications? >> Yeah. So the the Morgan Stanley report stated the market in 400 billion and we thought that we needed to bring a platform with three product verticals to

02:00:42 actually penetrate such a such a big market. >> Um so we are creating three products. One is let's say um not implantable actually. So it's a semicronic um it's a

02:00:56 semicronic platform kind of like the modern Utah array. It's like 100 contacts of graphine that can read and write. Um we we went into tumor and epilepsy resection at the beginning and

02:01:07 that one is pretty pretty close to commercialization. We're almost there. Um the second product is the implantable uh platform for the brain. So this is a implant on the brain uh for Parkinson's

02:01:20 disease. So we we didn't do sorry assistive BCI because we saw a 1.8 billion market um that is suboptimal that we could actually displace very easily with this

02:01:34 technology. So we decided to go therapeutics into Parkinson. And the third one is the same platform but instead of a let's say brain sensor we connect a

02:01:45 vagus nerve sensor that is actually able to decode all the fibers that go into the different organs. So we have a therapeutic target for each of the organs just by targeting that nerve in

02:01:58 the neck. Mhm. What about uh the actual implantation process we followed from uh Neurolink? They had to build a whole robot just to drill into the skull. It's incredibly high precision. Are surgeons

02:02:10 capable of implanting this uh at this stage or will there need to be other robotic devices that are developed to actually deploy this technology safely? >> It's it's an excellent question. Um I'm

02:02:24 coming from Metronic. I spent 10 years in neuromodulation and another three in diabetes. And >> I think in the future when micro robotics are ready um we will have a a

02:02:39 very close relationship um between our interfaces and micro robots that probably can deliver this implantation in 30 minutes. Today when there is not microobots

02:02:50 and we are not ilam mask um we decided to actually um have our platform ready for the current surgical workflows that today exist. So we are not changing much from

02:03:03 the neuromodulation uh workflows. >> Okay. >> Uh and it's an easy procedure. Uh two hours one or two hours you know is enough. In the case of the neck is 45

02:03:13 minutes. >> Wow. Wow. That's very impressive. Uh well, congratulations on all the progress and thank you for the work that you do and thank you for stopping by the

02:03:20 show. >> Yeah, great to meet you. >> Have a great rest of your day. >> Cheers. >> We'll talk to you soon.

02:03:25 >> Up next, we have Jake from Blue Energy. He's the co-founder and CEO with a massive raise. It's a gong breaker. Jake, how you doing? >> Welcome to the show.

02:03:35 >> Hey guys, I'm doing well. >> I got a feeling you have the biggest number for us. >> I think you have the biggest ever. Kick us off. How much have you raised? and

02:03:42 then we'll get into what you're going to do with it. But tell us about the financial situation for the company. >> We we have announced a $380 million raise.

02:03:56 >> Congratulations. >> Yeah. >> And what will you be doing with all that money? >> Yeah. So, our focus, we're we're really

02:04:06 unique amongst the field of nuclear players right now. Our focus is on building the world's first project financable nuclear power plant. So, we're using this funding to actually put

02:04:15 deposits down on Longle equipment as well as finishing out the engineering and development licensing on some of our first sites. >> Does that mean like less R&D risk or

02:04:25 more in like the GE or Westinghouse territory? more like uh you know going with uh products that have been d-risked but it's very expensive and maybe the underwriting is is is different this

02:04:39 time around or or are you working on uh an entirely new reactor to design somewhere in the supply chain? >> No, you had it exactly right. We are not a reactor designer. We're a developer

02:04:50 but our technology is the proprietary approach by which we go about building the plant. So what bugged me and why I started the company >> was I have a lot of friends in the

02:05:00 nuclear space designing really exciting new reactors and then you have a lot of incumbents in the space who are working on you know kind of the same old technology that we've been operating

02:05:10 safely for 70 years >> but nobody was focused on the core issue >> of how do we build nuclear on time and on budget. So I grew up in a construction family uh used to be a

02:05:20 draftsman for my father's architecture firm. I just grew up around a lot of construction, did my nuclear engineering and physics degrees in the space and just felt like there isn't there hasn't

02:05:28 been anyone really focused on the root cause issue. So what we're doing is we're borrowing best practices from LNG and offshore oil and gas and offshore wind to prefabricate everything at

02:05:39 existing oil and gas fabards and shipyards. And then we barge it all as a pre-fabricated system on the order of a,000 or 2,000 tons to the operating site. and then really, you know,

02:05:51 basically are just installing it like giant Lego pieces. But what that allows us to do is bring a lot more debt financing to bear. >> So, we're not taking a lot of reactor

02:05:59 technology risk to start in the beginning. We're using mature light water reactor technology to start. >> Uh, but we'll happily work with the Gen 4 reactors as they as they mature.

02:06:09 >> Cool. Uh, take me through >> I feel like you've been wanting a couple >> Yeah, I've been wanting this for a long time. I've been >> John John's John's point has been

02:06:16 >> copy paste. Hey, we know how to do this. >> It works. So, this is we don't need reinvent. I mean, it's great if we want to reinvent the wheel. >> Yeah, we need the next gen tech,

02:06:24 >> new reactors, but also let's just build some. >> Yeah. Uh, so yeah, my question is uh about Vodal uh lessons from the Vodal project. Uh what what do you think they

02:06:38 did well that you want to copy that you want to learn from? What do what if anything do you want to do differently? >> Yeah. So to kind of put some stats on Vogle, it it like so many other nuclear

02:06:49 projects in the west was ended up being about two to three times over budget and behind schedule. But when you double click on where that cost was, you realize it wasn't actually in the

02:06:58 reactor technology or the equipment. >> It was on over 40% of it was just the construction overhead. So it was the cost of training and relocating 10,000 skilled workers to to the site at Vogle.

02:07:10 You know, think about the cost of training, relocating their families, retaining them once they're trained because data center projects are trying to steal that talent.

02:07:18 >> You have to set up a nuclear quality assurance program in the field. So, there's all this overhead. It's basically like building a small town. >> Yeah.

02:07:24 >> And then the hope is that you'd be able to move that, you know, traveling circus around from sight to sight. >> And then a third of the project cost was just capitalized interest on debt

02:07:33 because it took over 10 years to build before it started generating revenue. So this these are the the two big problems we're trying to address is we are moving most of that work offsite. We're keeping

02:07:44 the workforce centralized at the fabard and the shipyard where they already are so we can start to put nuclear onto a learning curve >> and drive the cost down over time akin

02:07:53 to what we've seen in wind solar batteries and gas turbines. You know what they did well was it was a mature lightwater reactor technology. It's a passively safe reactor technology. uh

02:08:04 they they really pushed the the world forward a little bit in the licensing space and steel composite structures which we're looking into as well. They actually had this is not wellnown they

02:08:14 originally wanted to barge it in up the Savannah River but they had to then dredge the Savannah they would have had to dredge the Savannah River for miles and that would have become part of their

02:08:24 environmental impact statement. So they ended up, it became such a regulatory and permitting nightmare that they gave up and they said, "All right, let's just truck it in." And then they had to truck

02:08:33 it in and build a module assembly building on site. >> So they ended up doing all the welding on site. >> Yeah. Remodel from nightmare

02:08:42 remodel. Uh very interesting. Um I Yeah, I'm I'm I'm I'm fascinated by >> Where's Where's the company based? Where are you guys based? >> We're in Chvy Chase, Maryland. uh pretty

02:08:54 close to NRC headquarters. And then we've also got a big presence in Edinburgh, Scotland where there's a lot of offshore engineering talent uh particularly from like kind of the

02:09:02 history of ship building and offshore oil and gas. Yeah. >> And then we've also got an office in Houston also kind of offshore oil and gas capital of the world.

02:09:10 >> Okay. I I read a blog post about um one of the potential problems or or stumbling blocks that nuclear projects run into and I want to reality check it with you. the the thesis was basically

02:09:23 that um we have a reactor design, we have a you know there's infrastructure around that. Cement needs to get laid, pipes need to go here and there, but oftent times the regulation will change

02:09:36 while the project is underway. And so in order to stay ahead of the changing regulation, you might have to, you know, jackhammer a bunch of concrete and move a pipe to a different route because the

02:09:48 regulation has changed. Is that real? And is there anything that we have done or can do to get to a regime where the the regulation is more locked and deterministic so that I imagine you're

02:10:02 not going to build this overnight, but if it takes you a couple years, you know that the the the contracts that you put in place, the plans that you put in place today will hold and you won't face

02:10:13 a massive delay. >> Yeah. So that was another one of the big learnings from Vogle. Vogle was the first and still today, I think, the only project that did a combined operating

02:10:23 and construction license, which means >> once they locked the blueprint, they really were not allowed to make changes to it during construction. So, every time they encountered something and

02:10:34 said, "Oh, we need, you know, the the craft labor wound the rebar clockwise instead of counterclockwise." You know, they had to jackhammer it up or they had to go and reapprove it all.

02:10:43 >> And there's just a there's a long list of things like that uh that they encountered. So, one of the things we're doing is we're following a slightly different licensing process, the

02:10:51 original licensing process of part 50, uh, whereby we're going to incrementalize it, uh, so that we don't have to encounter that rework, that kind of regulatory triggered rework

02:11:01 situation, but also because we're following this prefab approach and we're moving 80% of the capex into a fixed price contracting environment with these fabards and shipyards, it forces us to

02:11:12 go to something like 60% detailed design up front and locking those designs because that is what is going to be coming in prefabbed uh from the fabric. Yeah.

02:11:22 >> So, it's it's sort of baked into the strategy. Um but really this is about taking a lot of those lessons learned and making sure we don't make the mistakes of the past. But I'll also say

02:11:30 we've never had a more supportive regulatory environment than we have right now. Like this is a critical juncture in the history of nuclear power that we can take advantage of uh with

02:11:40 where the NRC is presently at. What is the power output for the first reactor that you're targeting to bring online? >> Uh so we are focused right now for the first project using lightwater small

02:11:53 moder reactors which the the power range of the units we're looking at range between 50 and roughly 300 megawatt per unit. >> Yeah.

02:12:01 >> Uh yeah each site we're targeting doing is going to have multiple units. So, we're it's going to be a gigawatt to a gigawatt and a half per site because multi-unit operations that makes a lot

02:12:13 of sense >> is important. Uh >> yeah, >> and it helps drive down costs. >> And then are you already sharing a

02:12:20 timeline? Do you have an optimistic scenario, a base case, a bare case? I'm sure you get asked this all the time. That's the worst question. But we talked to a lot of nuclear founders and uh we

02:12:29 hear a lot of 2030s and there's a whole bunch of projects with hyperscalers and big tech companies that are looking at 2032 2035. Uh it's exciting. Better you know 2032 than never. But uh do you have

02:12:42 uh anything to share on like the the timeline of rolling out new nuclear capacity in America? >> Yeah, we'll be announcing things uh very soon. Uh but what I can share on the

02:12:53 dates and this is actually another unique thing we're doing part of our strategy is we're pursuing this thing we call gas to nuclear conversion. So we're actually going to be building half the

02:13:01 nuclear plant right away. >> So the whole nuclear steam turbine system set up for nuclear steam conditions and quality and we're going to fire it early with two combustion

02:13:10 turbines as a twoon one combined cycle. So it's kind of a Frankenstein combined cycle. We've actually gotten the NRC to buy off on this methodology uh through a top core report recently. So that allows

02:13:23 us to actually project finance half the capex for a first SMR and then we will build the reactor and splice in the steam and switch it over from gas steam to nuclear steam. So that actually

02:13:34 accelerates our commercial operation date with confidence. >> Uh so we're looking at generating first power in 2030 2031 mostly driven by gas turbine delivery dates today. And then

02:13:45 our first nuclear commercial operation, we're looking at 2032. >> Okay. So, is that is that switch out possible at any legacy natural gas infrastructure site in America

02:13:56 currently? >> Uh that seems like an environmentalist dream. >> I'm not ready to say yes or no. Yes. I think this opens up a whole new world of

02:14:05 fossil to nuclear convergence which we think is an important precedent to set. >> Yeah, it seems huge if possible. Uh but I imagine that you know it's not exactly USBC on both sides but uh hopefully one

02:14:16 day we can build the adapter. >> That's right. It yeah what we're really focused on is you know there's a lot of announcements out there a lot of sometimes you know noise of what you

02:14:27 know there's a lot of exciting things happen in the nuclear sector. We think we've got the first >> project financable nuclear project >> and the first one that's going to power

02:14:36 it'll be a new build that powers a new AI data center. >> Yeah. Uh so we're excited about that and we think our timeline is is credible is aggressive but credible and defendable

02:14:46 and we've got the right set of partners around it to make it happen. >> That's amazing. Don't use the word data center. We're using the word supercomput.

02:14:53 >> Supercomputer. >> They're supercomputers. >> They're super computers. >> No one likes a data center. Everyone likes a supercomputer.

02:14:58 >> Yeah. >> Anyway, thank you so much for taking the time to come. >> Great. Great to meet you, Jake. I'm sure you'll be back on soon. Really, we

02:15:05 really appreciate your approach. Feels like you're you're making plays and I like how pragmatic and but but innovative the approach is at the same time.

02:15:14 >> It's great stuff. >> Thank you. Appreciate >> Talk to you soon. Cheers. >> Goodbye. >> And we will close out on this. I need

02:15:21 your reaction, John. Ferrari's first electric car is priced at the low price of $650,000. >> An absolute steal. They're giving them away at that price.

02:15:32 >> Uh >> it's electric, right? So you don't have to deal with gasoline. You don't have to >> You save a lot on gas. >> You don't You don't have to deal with

02:15:38 all the noise that comes out of a V12. >> Yeah. You major up save on gas. >> Yeah. >> Um >> Oh. Well, yeah. I mean, if you're saving

02:15:45 on gas and you're driving I mean, if if if oil keeps spiking and gasoline goes to $1,000 a gallon and you're filling up every week, you could easily be spending millions of dollars a year on gasoline

02:16:00 in a normal car. So, there's potential cost savings here. So, it's sort of a more you buy the more you save situation. I think Ferrari >> luch there's really going to be a uh

02:16:10 like what kind of Ferrari client are you moment uh I think if you see someone with this you will >> you know they can eat 300 grand of depreciation and you know that they are

02:16:22 that they are high on the list for the F90 like they are working their way up buying in now and when the F90 comes out in a decade they're getting a call. Yeah,

02:16:31 >> they're getting a call for sure. >> Yeah. very interested to see how this does in the market. And the good thing is if you are excited about the luche but you're not excited about paying

02:16:41 $650,000, you will have an opportunity to buy them for far less than that very very quickly. >> Probably probably.

02:16:48 >> But thank you for hanging out with us today. It's been an honor and a privilege to be here with you. We hope you have a wonderful afternoon. >> Leave us five stars and Apple podcast

02:16:57 and Spotify. Throw that flashbang. Sign up for our newsletter tbn.com. Goodbye.

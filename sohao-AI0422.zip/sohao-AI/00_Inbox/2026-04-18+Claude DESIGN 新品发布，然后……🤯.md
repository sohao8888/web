视频链接：[https://www.youtube.com/watch?v=bmDJYcyv4m8&list=WL&index=1&pp=iAQBsAgC](https://www.youtube.com/watch?v=bmDJYcyv4m8&list=WL&index=1&pp=iAQBsAgC)
视频发布时间：2026-04-17
频道名：Eliot Prince

## 转录内容

00:00 Okay, so I've just logged back into my Claude account after quite a late lunch. I was hoping that my usage limit had reset having smoked a ton of credit and token on testing Opus 4.7 this morning

00:12 and publishing a video on that. And I logged in and I saw this. Claude design, you haven't used Claude design yet. Haven't used any of that limit. But that's brand new. I haven't seen that

00:21 before. And there were some rumors that Claude might be delivering some sort of design tool. Well, I think it's just launched. And I jumped onto Twitter or X or whatever you want to call it and

00:31 noticed this is hot off the press. This was 4 minutes ago. It's actually pro published. Introducing Claude design by Anthropic Labs. Make prototype slides and one pages by talking to Claude.

00:42 Powered by Claude Opus 4.7 our most capable vision model yet. Available in research on pro max team plans rolling out throughout the day. So it should be rolling out. Let's see what it's all

00:52 about here first. >> [music] >> I'm excited. >> [snorts] [music]

02:03 [music] >> Okay, this looks pretty awesome. Just finished the video there. It looks like we're going to get

02:13 basically like Figma and some sort of UI and design prototyping and design feature inside Claude that then we can export even to PowerPoint slides straight into Canva to mock up apps,

02:26 websites. Obviously at the moment we can code up website landing pages and little apps and things like that. But they're kind of you have to conversationally go back and forth. And it's kind of limited

02:36 in the architecture. We can't click in and start changing colors, etc. So essentially we're going to be able to conversationally describe what we want and build the first version and refine

02:45 through conversation, inline comments, direct edits, custom sliders as you can see here. So we'll actually be able to change and tweak stuff without having to just tell AI to do it. We actually be

02:55 able to go in and edit stuff there and export it all to Canva. So they've got their official pro they've got their official page launched as well for this. So I say this is literally 5 minutes ago

03:05 this has got published. So it looks like it is live and rolling out as we speak. We've got the ability as I said realistic prototypes, product wireframes and mockups, design explorations for

03:15 designers to create a wide range of ideas, pitch decks and presentations that can be more editable than what we've got at the moment which requires AI to keep going back and forth. Looks

03:24 like we should be able to go in and tweak things ourselves and even like code powered prototypes with shadows, 3D and built-in AI. So So I wonder actually if I go into my Claude area here, I

03:36 wonder how we can actually try and access this. Wonder if it tells us on here. So start designing at Claude/design. I have to go into an actual area in

03:47 Claude. So we've got meet Claude design here. It's going to give us an intro. Import your team's design system, make prototypes. This is exciting. >> [snorts]

03:57 >> And it's going to code stuff up for you. Build apps. We're going to be able We don't even have to export into other places now. Okay, let's skip intro and let's just dig in and see if we can

04:05 actually build something. So create a design system so anyone can create good looking designs and assets. Set up design system. My company name, what are we calling it? We'll call it Prince AI

04:16 training. We help people, business owners and professionals learn how to use AI platforms and use them in their business. So next we have to provide examples of a design design system.

04:26 Works best code and design. So link from your computer or add fonts, logos and assets. So I'm going to add fonts, logos and assets from my file system. So I've added a few bits in here. I've added

04:36 some fonts, some logos, some brand guidelines in there to see how we get on. It will need refining. My brand voice is relaxed. It's British English and it's punchy and it jumps around.

04:48 I'll we can obviously put in more notes in terms of my brand voice and relaxed feel. My brand switches between dark mode with lime colors like in my logos or a cream

05:00 design with forest green running through it in the light mode. So we can just add a bit more in there as well. See how we get on. Let's continue to generation. It will take about 15 minutes to generate

05:11 your design system. You can step away and keep the tab open in the background. So this is interesting that it's going to build this design system on our behalf rather than us having to go and

05:21 do it ourselves. So what we've got as you can see on the left this feels kind of like we're working in Claude code or a perplexity computer kind of thing now where we're getting this progress and

05:32 this file and actually feels like if you've ever vibe coded in like replit or lovable, I think it's going for that. That's what we're kind of angling for this Figma crossed with vibe coding

05:43 design system is is the vibe I'm getting at the moment from this. And what you'll see on the left it's extracting everything we need. It's actually writing the core CSS files. It's writing

05:53 those fonts and logos and everything we discussed in there. And because I've given it that brand file, I'm hoping it will pick out some more fundamentals of my colors as well. Okay, and looks like

06:02 after a couple of minutes here actually just under 10 minutes we've got our draft design system and it's actually pulled out my colors nicely. Like these are my brand colors that it's got.

06:11 It's got my display to This is so cool. My body type it's actually pulled out of my brand guidelines, all the information. All my spacing and everything. I mean my girlfriend's a

06:22 graphic designer. She is going to freak when she sees this because it's it's taking her brand guidelines she's built and actually just putting them into a literal AI design system. It's got no

06:33 code base or Figma so we can supply sample decks and a few extra bits. But what I'd love your eyes on. Open the design system and flip through the cards and tell me do the two modes light and

06:43 dark make sense. So I'm saying like yeah, I think that one looks good. I'm happy with all those look good. I'm happy that all that looks good. So it's just flicking through the

06:52 dark mode, all the headers and text which actually look pretty good. I mean some of the text could be improved but obviously we'll be able to go back and touch these up I'm sure. Like let's try

07:04 and edit this quickly just say like I wonder if we can screenshot on here. Yeah, there we go. The black text on the back background for like my dark mode doesn't make sense in the header. You

07:16 can I've highlighted the text there but some of it is in black and some of it's in lime and only the lime stuff shows up. So I'm just going to give it some feedback and see how it takes that.

07:27 Ooh, that feedback once. I should be able to read the code. That looks good. That looks good. So it's just going through. I've ticked everything off here. So you have to go through and say

07:37 I like all of that. That looks good. If it needs work, you can select needs work and it's going to give you the ability to prompt it and say like can you tweak this? So actually it looks like it has

07:46 changed that a little bit. And then we've got design system. We've got design files. I'm not sure what the design files are. Maybe these are These are all the fonts and everything I

07:54 uploaded. So those are the files behind our design system here. We're actually going to make this looking good. All done. Happy with everything. So I'm happy with

08:04 everything. Now there's a button in the middle here which says new design using this system. So we can test out our new design officially. So let's say what the prototype is. What should we build?

08:15 Let's build a website. Design system we're going to go with my design system and we can wireframe or we can get a high fidelity product mockup. So let's do a high fidelity mockup here. See what

08:26 happens next. Share with context. Start with context. Context. Design system we've got. Add a screenshot. Start with sketch. So we could actually get illustrations and sketch of things that

08:36 we want in here. I want to create a mockup for a networking event I'm running in a couple of weeks

08:47 where we have three speakers and I want people to be able to find the location, amenities nearby, parking, hotels, all this information included in our nice app which we're going to be mocking up.

09:03 So I need a main run of events page with what's going on during the day that are clickable in and out of for each speaker and different times of those going on. I need a how to get there. I need where to

09:14 stay and another FAQ So everything will be neatly contained in an app. Let's just use demo information at the moment. So make up the information. I just want to focus on the design.

09:24 So I'm wondering if it can actually build just off conversational. Like I've not given it any actual sketches or designs but I could draw some stuff in here to get it actually working. So it's

09:35 going to ask us some questions. It's called AI Networker Cornwall intro row on the 18th of April. Any details on the three speakers? Elliot Prince is speaking as the keynote speaker. We've

09:47 got Alex Hormozi and Gary V coming to support Elliot Prince. Just leave spaces for headshots at the moment. Uh brand mode, let's go with the light

09:59 cream version. Uh, I what frame should we go in? Uh, I'm just going to say decide for me. Uh, how adventurous with the visuals? Let's uh, mix of mostly on brand with some

10:10 bold moments in there. How should the four sections connect? Uh, let's say top pill nav I like this. We're getting to select like some of the

10:21 common ways that these things might be built. What does the most clickable in out speaker section mean? Tap a session expands in line, opens a detail sheet. Uh, expands in line, so we're not moving

10:34 through pages. How is the day structured? We'll just go through and select some of these options. Um, four sections, run of events, how to get

10:42 there, where to stay, FAQ, and that's four sections. What would you like to use as tweaks things you can toggle live in event prototype. Um, I'll just leave that as decide for

10:53 me, and I'm going to let that run and see how it builds. So, on the left-hand side here, we can see it's actually starting to code and create just like all the other vibe coding tools you're

11:01 used to. It's important to note I think this is design, not actually building a full-scale app. I think then you would take it into something like Claude Code, or take your presentation into

11:09 PowerPoint or Canva or wherever you wanted to finalize your designs. So, what you see is it's opening up the design files to actually go and get this information for us.

11:21 Interestingly, while that codes up as well or designs, you've actually got a button in the top left here that says comments. And so, your team can go in and actually leave comments, so they

11:30 don't have to go and edit themselves. Just leave notes and comments to come back if we want to actually tweak the design or make some changes. And here we go, we've got our first mock-up, which I

11:39 mean, it looks pretty hideous cuz it it's kind of taken some liberties with my brand colors. But, essentially we've got an app mock-up here from being able to import my brand colors. I probably

11:49 gave it too much leeway in how it should use them. Um, maybe I should have gone in dark mode, which would be better. And I should have told it to make sure my

11:57 white text comes out on the forest background. But, actually like it's pretty good. We've got the drop-downs here for our design. It's a very speedy uh, prototype to be fair. I've only just

12:08 started using the app. This is live, guys, so uh, cut me some slack on the actual design. But, we've got a search bar in there. And then, interestingly, we can

12:16 tweak I think it looks a bit better in dark mode, but it's a bit it's a bit garish, isn't it? And we can change the event title there on the right-hand side. We can change some of the accents

12:25 through it as well if we wanted. I wonder how we then edit this thing. Do we click Ah, so we can click in and then we can start editing and we can change text, or we

12:36 can edit colors in here. So, at the top here, this color, we could say, "Actually, I prefer this in white, as well as maybe some of the text further down."

12:46 The stay. So, we go in and out of edit mode there, you see? So, to edit, we go into edit mode, and then we can start selecting elements on the page, change the color, the line heighting, all the

12:56 things you'd expect in a sort of design-esque tool. And then, you see on the left-hand side, it goes and actually auto applies those edits. We've got comments, so we

13:05 can pick certain things out and say, "Make this bigger and center Claude." And when we apply a comment, as opposed to an edit, I wonder what happens in the left-hand

13:16 side here. So, it's reading our comment, and rather than me actually making the edit. So, the edit button with control, we control the exact thing we want to change. The comment is like

13:27 conversational, "Make this bigger, make this smaller, change this, do that," etc. So, it's made that whole pill bigger. Then, we've got draw. So, if I go underline that, let's see what

13:37 happens. Type anywhere to add a note. Can we underline AI networker like I have drawn in the picture? And again, send that. So, we can annotate this as well with our ideas, and just draw and

13:48 sketch on here for things that we want. It's nice as well, actually, it's picked out some locations in Cornwall. So, I haven't given it Hubbox Truro, Sams in the City Truro here, The Coffee Stop

13:59 Waterside. These are all actual places in Truro, and it's given us a walking time. So, it's actually it's actually gone out and researched. I said I need a parking area. It's gone and found these

14:08 are real car parks. This is insane. So, not only is it designing for us, it's actually researching these pages for us. It's found Truro train station, the roads to get here, how to fly into

14:19 Newquay Airport, where to stay. The Alverton is a real hotel. Oh, this is crazy. The Alverton is a real hotel down the road. It's got a room rate in there. I don't know how accurate those room

14:29 rates are. Uh, and our FAQ, it's kind of made that up, cuz obviously I've not given it much information. So, we've got the mock-up of an event app, and it's researched it in there as well for like

14:39 go and just find the hotels and everything we need. And we've got things like in this tab, full screen. So, we can go into full screen mode to start checking this stuff out. It's got

14:49 everything we need, isn't it? We can share, so we could share this to teammates, to view, to edit, and duplicate as a project a template. So, if we wanted to use this

15:00 again and again, we've got duplicate as a template or a project. And we've got an export function. So, we can go as PDF, PPTX, we can just get the HTML. So, if I just want the HTML code, we can get

15:12 that. Or, here's the cool thing, we can hand off to Claude Code. So, once you've done your design work here, so for me, if I've got my sort of idea, I can get it going, I can get my designer, my UI

15:23 designer to come in and be like, "Let's make this official, use my skill to do it." Then, we can get this mock-up, this wireframe, hand it off to Claude Code here, and that should What have we got

15:34 to? Center local coding agent, or copy command. So, copy command, we can take that, and let's uh, let's go into Claude Code here for a second, start a new session, and if I

15:46 pop that into Claude Code, interesting. Select a folder first. Hang on. Let's go and work in Claude Code. We can run that, and it's fetching the design file from that URL. So, from the Look from

15:56 the Anthropic API, it's collecting that design file to take that, and it's actually going to build and implement this for us. >> [laughter]

16:04 >> And it sounds like as well, so that's Claude Code's going to go start building, and it sounds like as well, we could actually take that, give it some extra notes if we wanted, but we could

16:13 take that zip file, send to a coding agent, or we could copy command and take it to any coding agent that we wanted, whether that was outside of Claude Code, I would imagine, to fetch that

16:23 information through the API. So, Claude Code's going to go fetch this design now, and start ripping away on our build. So, yeah, this brings a whole new level of Well, unsurprisingly, design to

16:35 Claude. I wonder as well, if I go back to what I originally planned to do straight after lunch, which was get on with some stuff. If I go to my usage tab, we can see. So, that Well, to be

16:46 fair, we created our design thing, which took 10 or 15 minutes to upload all the files and compute our design system. Plus, we built our first prototype little design app. It's used 65% of my

16:58 credit window for my weekly limit on a pro This is a pro plan I was testing this on. So, that's pretty heavy. It'd be interesting to see actually how quickly you're going to hit your weekly

17:08 limits outside of just running that uh, design system. So, it looks like it's going to be pretty heavy, guys, if you're just running on a pro plan, you're going to hit your design limits

17:18 pretty quickly, I would imagine here, if you're doing anything substantial.

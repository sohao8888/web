视频链接：[https://www.youtube.com/watch?v=DIRgnzOx6Mw&list=WL&index=5&pp=iAQB0gcJCdkKAYcqIYzvsAgC](https://www.youtube.com/watch?v=DIRgnzOx6Mw&list=WL&index=5&pp=iAQB0gcJCdkKAYcqIYzvsAgC)
视频发布时间：2026-04-06
频道名：Prof G Markets

## 转录内容

00:00 Today's number 12. That's how many tons of KitKats someone stole from a truck in Europe last week. That's more than 400,000 candy bars. Ed, I actually identify as chocolate. My pronouns are

00:13 her and she. Took a while. Right. Actually, Ed, maybe we'll get this one a little faster. Although, who knows? With that Princeton degree in classics, I'm mad at it.

00:27 Anyways, no. No. Sorry. >> One joke. one joke. Come on. Why do Why do we always have to do three jokes? >> What does the crowd want? The crowd wants more dog more dog humor. So Oh, is

00:37 that what they want? >> I'm at therapy with my partner and my partner starts bitching that I can't even answer the most simple questions. And the therapist looks at me and says,

00:47 "What does she mean?" And I said, "Uh, that's a feminine pronoun." >> Think about it. It's coming. There it is. Now we get sick. >> Got it. Got it pretty quick. almost up

00:57 to Cal State Northridge level IQ from Princeton. By the way, Sea Sun, I feel bad now. That's an insult to Sea Sun. Sea Sun is an amazing university. The Cal State system, Ed, is really the

01:08 crown jewel of California. I used to think it was the University of California. Nah, it's really the Cal State system. I've gone way off script. How are you, Ed?

01:15 >> Well, it's very exciting day, Scott, because this is officially our first episode on the new ProfG Markets YouTube channel. We wanted to make it easier for everyone to find and subscribe directly

01:26 to all of our markets content in one place. We thought that the property pod channel was getting a little bit cluttered. So from now on, if you're watching on YouTube, this is where we

01:36 will be. We will be posting every day with the stories that are moving the markets. So please hit subscribe so that you don't miss what matters. We would love to have you with us. Scott, how are

01:46 you feeling about our new channel? >> I'm super excited. And if you if you like what you hear, please just right now do us a favor and hit subscribe. And also, there's really a secondary benefit

01:56 here cuz Ed's feeling a little bit quite frankly Ed's feeling a little bit insecure because as you probably heard, pretty much every podcast in the portfolio was nominated for a Webbby.

02:07 >> Let me think. No Mercy No Malice was nominated for best newsletter, best thought leadership, raging moderates, best news in politics, pivot, best tech in business, and let me see, Profy

02:18 Markets was nominated for Yep. So Ed is feeling a little insecure. >> So what do you think that's about? What do you think that's about? I mean, you should be feeling insecure, too, because

02:31 it's also your show, but what do you think that's about? Why did we not get nominated? What is that? I have absolutely no idea how these award shows uh figure out who gets nominated and

02:41 why. All I know is there's about 700 million categories and it costs money to enter. It's it's a total [ __ ] grift. I mean, I can't wait to accept the award. Um I mean, if we're really going

02:53 to be honest, I think what's gone on here is pretty transparent in that is with you turning 27 and Claire turning 28, everyone just decided you're over the hill and they need to turn to

03:01 younger nominees. That could be true. I like that. >> Cara Swisser, I don't know if you know this, I have another podcast and a co-host and Cara Swisser. She's she's

03:12 literally getting every lifetime achievement award in the world right now. And I'm like, you know, that just means everyone thinks you're dying soon. She's getting all these lifetime

03:20 achievement awards from all these different, you know, German Shepherd owners of Maine lifetime achievement award. She's good at knowing all the people who run these things. That's what

03:30 I need to get better at. I need to show up and meet the people who are on the committees and go rub elbows with the people who run establishment media. I need to up my appearances on the

03:41 mainstream cable news networks. I need to get really really in bed with the establishment. And once they know that and once they know I'm their friend, that's when we'll start winning some

03:51 awards. >> Yeah, I I think you can pull that off. You're just going to have to become substantially more interesting a person. Uh, but I think I think that that's

04:01 you're a cisgender white dude from Princeton who just turned 27. That's not like God, I want to meet him. >> Hey, we can be cool, too. >> Yeah, we don't check very many boxes.

04:15 >> May I launch us into this show? >> What the hell? Let's do it. >> Okay. Today, we're discussing the biggest unanswered questions in the markets right now, the SpaceX IPO, and

04:25 losers in the sneaker wars. Let's start with our first story. It feels like one of the most uncertain market environments in years right now. Not because of what we know, but because of

04:36 how much we don't know. There are a number of huge open-ended questions with massive implications from what happens next in Iran to how AI ultimately reshapes the economy. And the challenge

04:48 is these are the kinds of forces that can materially move markets. And no one has clear answers. So Scott, let's walk through some of the biggest questions out there and try to figure out what

04:59 investors should actually be doing in an environment like this. We probably have to start with the Iran question. I mean, what we saw on Wednesday when Trump made his speech at 9:00 p.m., people were

05:14 thinking that he was going to say something that made it sound like we were going to get out of Iran in some capacity or that we were winding things down. He kind of said that but also not

05:24 really. He also seemed to double down and say that we were going to get more aggressive but that we're going to do it over two to three weeks. It wasn't the kind of speech that markets really

05:34 wanted to hear. And then what did we see? We saw an immediate drop uh in S&P futures right when he made that speech. And then we saw oil surging way back up again. And this is just another example

05:45 of the uncertainty in the markets right now around this Iran question where we're basically just waiting for what is Trump going to say. We've had many many instances of this. We had back on March

05:58 9th when Trump said I think the war is very complete and then the markets went up and then he a few week a few days later he said more negative things. He said we don't even know their leaders.

06:08 We don't know who we're dealing with. Markets went down. Then he says that we're having very good and productive talks with Iran. Markets go up. Then Iran says no, those talks didn't happen.

06:16 Markets go down. We are essentially being whipsed back and forth because of the huge huge weight of this war and what it could do to global markets and to global economies.

06:30 Uh and no one really knows what to do. So we're just kind of following the president's lead here. What do you make first of the market's reactions to what's been happening on the Iran front?

06:40 >> I think that the president has no fidelity to the lives of servicemen and service women to the markets more broadly. I think that we're in the midst of what will be seen as the greatest

06:51 financial scandal in history where we're using the US military, our geopolitical currency globally, uh our allies, relationships with our allies, all as a means of creating uh

07:04 volatility such that the president can engage in insider trading. Uh I think a good autocrat not only punishes his enemies, which is more difficult with a court system in the US. You can do it to

07:16 a certain extent. You can put you can put Dario and Mod's firm on a supply chain risk list and make it very difficult for them to do business, but you can't have them thrown out of a

07:25 window like Putin does in Russia with people he doesn't like. So, what he turns to is more what Putin does on the upside, and that is he carves up US assets and gives them to um gives them

07:37 to people loyal to him, inspiring a great deal of loyalty. People are sort of like, okay, I sort of buy into many of his policies, but you know, everyone's getting rich but me. I'm

07:46 going to get rich and just kiss his ass and maybe he'll give me a defense contract I don't deserve a a government contract I don't deserve buy a golden share in my company when I'm failing to

07:58 compete intel whatever it might be and if I go along get along he'll make me much much richer and the ultimate example of that the most corrupt one where he will be in front of a camera

08:08 and a jury in three to five years maybe more like five to seven pretending to be really old and that he doesn't member he is giving so much information to people about what he is about to say not about

08:20 to say about the war in Iran because every time he says uh has anything resembling a cogent date around the end or even a strategy here the markets surge and oil drops and then when he

08:32 comes out with this word salad of I'm going to bomb them to the stone age or it's over when I feel it in my bones or there's reports of amphibious vehicles and another 200 uh Marines deploying to

08:46 the region. The markets plummet and as evidenced by tons of reporting here, there is massive options activity before he makes these announcements. So clearly word is leaking out. He knows it's

08:59 leaking out. He could have secure phones. He could be 100% in a secure location. Instead, he's obviously leaking this information on purpose to his friends and family. And

09:12 we have never seen this kind of and it's not the insider trading that is so upsetting. That's criminal. What's upsetting is he's using our military, our tax dollars, the death and

09:23 destruction of other people and US service members lives as pawns in what is I believe the greatest insider trading scheme in history. And I believe that's going to slowly but surely

09:35 unfold. I I realize I'm on a bit of a rant here, but bear with me. I've said for a while that one of the most dangerous things about America and income inequality, which I think is our

09:45 biggest problem, is the 0.1% no longer are vested in the success of America. What do I mean by that? The 0.1% have their own transportation. They don't give a [ __ ] about 4-hour TSA lines. They

09:56 go to the They go to Teterboro. They have their own planes. They don't have security. They have their own police forces. They live in buildings in neighborhoods that are have incredible

10:05 security and dormen so you always feel safe. They have their own health care. There's no waiting in line. They have they have concierge health care systems. They get whatever they want. They have

10:16 the best health healthcare in the world. So what is their vested interest? I I if the people have the 40% of Americans who have medical or dental debt, they can't relate to not being

10:27 able to take care of your parents. They can't relate to it. They have been removed from what it is to be in America. And the same thing is happening on a larger level with America. And that

10:37 is as we break [ __ ] we are actually removed from the global economy in the short run. I believe in the long run we'll pay a huge price. But if you look at the global markets and some of our

10:48 allies, their stock markets are down more than ours because we are blessed with energy independence, food independence, and when there's a flight to safety, America is sort of a gifing

11:00 good. And this is something you learn in economics and that is in Ireland when potatoes got more expensive their demand went up because it crowded out uh expenditure or consumer income

11:12 you could spend on beef or chicken so you were poor so you had to buy more potatoes because you couldn't afford and I wonder if America has become the ultimate gif and good and removed from

11:21 the vested interest of the global well-being of the west because quite frankly for a lot of reasons that aren't our fault when there's danger when there's insecurity there's a flight to

11:32 um US stocks and we are somewhat immune and don't have the same invested interest in the global health just the same way the 0.1% are no longer invested in the health of America just to your

11:43 point on on the inequality problem the fact that so many of I mean the wealthiest Americans don't seem to have a vested interest in America I think it is reflected in so many of the comments

11:54 that we've seen from the administration which has mostly been stacked with a bunch of really rich people mostly former businessman who made a ton of money. Someone like Scott Bessant who

12:05 got on stage and talked about how Americans want to buy their their fourth, fifth, and sixth houses. Like that right there is the perfect example of what you're describing. It's hard to

12:17 create policies that make sense for regular Americans when your entire worldview is shaped by the experiences of the top. 001% of Americans and that shapes your entire worldview and that

12:30 seems to be the kinds of people who are in office right now which might explain why some of these policies have been so far skewed in favor uh of the richest but just to go back to the market's

12:46 response and what we've seen with Iran so far um I mean it's clear that there's no way to understand what Trump's agenda actually is like there's no rule. There's no strategy. There's no

13:01 framework you can really use. We used to think it was taco. Like Trump does something and then the markets tell him off and then he stops doing it. But we've seen a lot of moments where the

13:13 taco actually hasn't materialized. And so it's starting to get to the point where that there might actually be no way to predict or explain what he's going to do, including with this speech.

13:23 And I'm sure this is something that a lot of the people within the administration get very very upset about and get very annoyed about. They're probably trying to create a strategy,

13:31 create an agenda, and then he just turns on it. An example would be what is going on in the communications between the CIA and Trump. One thing you didn't mention which they seemed to not see eye to eye

13:42 on and they had no explanation for. The CIA said that Iran was not an imminent threat and they said that their nuclear capabilities had been eviscerated. That was their statement. That was their

13:54 position. And then Trump comes out and says, "Why are we doing this?" Because they are an imminent threat and because their nuclear capabilities are rising and because we need to neutralize it.

14:04 That was a fundamental disagreement between the CIA and Trump, which leaves us with basically zero understanding of what the hell is even going on here. And so as an investor it makes things very

14:16 very difficult because there actually aren't I mean the job of the investor is to try to understand what the future might generally look like and then build a thesis build an investment thesis

14:28 around that understanding of the future. The trouble is that there is just no way to predict it at this point because this guy is so erratic. Not even his aids, not even his CIA can predict what he's

14:41 going to do or say. And the trouble is he's having influence over some of the most important significant market moving events in history. I mean, how he responds to this war, h how his thought

14:56 process and strategy materializes will literally move trillions of dollars. It will reverberate not just for years, but for decades. It could completely role the oil markets for a very, very long

15:07 time. And the job of the investor is to try to figure out where do I stand on this. I think investors look at what's happening with Iran, they throw their hands up, they say, "We have no [ __ ]

15:16 clue. So, what will we do? We'll just kind of follow what he says. see what happens and then kind of play it by ear. But what compounds onto this problem and this is why I believe we are in the most

15:28 uncertain investment environment in many years probably since co is it's not just Iran that is a big question but there's also the AI question which people don't know what to do with will AI destroy the

15:43 labor market or will it not will it be less powerful than people think i.e. It's a bubble. That's what some people said. Or will it be more powerful than people think, i.e. it will destroy

15:53 things like software and that's why we're seeing software getting crushed. And again, the markets are just responding to little stimuli that they see every now and then, such as Satrini

16:03 Research. Some guy on Twitter posts a viral AI blog post and then suddenly $300 billion in market value is erased overnight because investors go, I I don't know, may maybe he's right. Maybe

16:14 we should sell. And that becomes a problem. And then I'll just keep going here. There are several other giant questions that no one really knows the answer to at all. Another one would be

16:25 this potential looming crisis in private credit. Are we going to have a private credit meltdown? Has the industry issued too many bad loans, especially in the software industry? And are we about to

16:38 experience a credit crunch in what is now a $2 trillion industry? That is another giant question. And in uh my my interview with John Maui, something he said off mic, which I think is very

16:51 true, is he said, "If this were any other year, all we would be talking about right now is private credit." That would be the number one issue on every investor's mind. But that's not the

17:02 number one issue because we've also got oil. We've got potentially the inflationary effects of Iran. What might that do to interest rates? People thought that we were going into a rate

17:11 cutting cycle. Now, it appears that we're starting to price things a little differently. People think we won't have any rate cuts this year. And in fact, the chances of a rate hike over the next

17:20 12 months have exploded, which means I mean, this is all to say, no one knows what the [ __ ] is going on right now. I mean, no one has any conviction in their positions because you can't have any

17:30 conviction. There's no way to really game out the future. And unlike previous questions where it's maybe been limited to one or two industries, all of these questions affect literally everything,

17:43 everyone's lives, everyone's business, which is why I believe it's an interesting moment right now. Uncertainty is extremely high. Uh tail risks are all over the place. And I

17:56 think that leaves us with an important question like what are you supposed to do in that environment? I'm not entirely sure yet, but that is certainly the question that I'm starting to approach.

18:06 >> I'm fairly confident advising people what to do in a in an environment like this and that is simple. Nothing because when you do something, you're trying to time the market and that is near

18:18 impossible. And I learned this the hard way when Trump was elected in 2016. I thought, "This guy's such a [ __ ] idiot. We just elected a a a reality host, a reality show host who has

18:31 bankrupted every almost every company he started is a rich kid who's managed to turn whatever it was three or $500 million of his dad's money into zero a couple times. I thought, "This guy

18:43 doesn't understand the economy. He's reckless. Markets are going to just crash." And I sold everything and I had some gains. So, I had to pay uh capital gains. And then 6 months later, the

18:52 markets were ripping and I had to buy back in at a higher price. I lost 30 or 40% of my net worth by having an emotional reaction to the markets. And the markets have separated from

19:04 your emotions and to a certain extent from what's going on in the world. Year to date, the Dow's down 5%. But over the past year, it's up 8%. If you didn't know what was going on, you wouldn't

19:17 know what was going on by looking at the markets. You would know something's going on in oil. But quite frankly, so far the yawn, you know, the market's response has been a

19:25 bit of a yawn. March 31st was the best day since May 2025. The S&P rose nearly 3%, the NASDAQ nearly 4%. Then Trump promised to hit Iran extremely hard in his Wednesday night speech. When he said

19:39 that, futures were down more than 1%, oil rose 7%. There's just no [ __ ] way this guy or some of his acolytes aren't making a ton of money here. He knows what he's doing.

19:49 >> That's a whole other thing. Yeah. >> The only thing that's given me any solace here and I would recommend it to everybody else. I was watching I was up late whatever till two watching this

19:57 this Yahoo say [ __ ] nothing and except it's like how can I make how can I say nothing yet create uncertainty in the markets. That's what he told the speed driver. I want to say nothing but

20:10 yet I want to create a an environment of >> let's also eliminate half a trillion dollars in value. >> I want to create an environment of uncertainty and insecurity. I don't care

20:18 about my reputation. I don't care about America's reputation abroad. I don't care about US servicemen. Just create volatility because I wink wink told people this was what what was going to

20:28 happen. The only thing that like come took my blood pressure down to like 300 last night was watching over and over the launch of Artemis 2 that launched four NASA astronauts into space and will

20:41 slingshot them around the moon. And what's interesting is it's going to cost or so far it's cost about $44 billion to develop and the war in Iran is now passed about 38 billion. So so far, you

20:52 know, pick your pick your fighter here. Artemis 2 or this escalation in the war. And that NASA estimates that a base on the moon will cost, by the way, $20 billion to develop. But what's happened

21:04 here with this uncertainty? Cali has now raised the odds of a recession this year from 20% to 30% just over the past month. Uh I'm shocked it's not higher actually, but the president

21:19 is such a terrible parent. And that is you're kind of everyone's mom and dad is the president or the nation's dad or mom. Let's say dad, there's never been a mom. Um and there won't be probably for

21:30 another eight or 12 years. Who the [ __ ] am I kidding? Um uh but as a parent, you need to provide some level of certainty and clarity. This is what kids need to know what they

21:45 can expect from their parents. They need guardrail. They need to know that if I do this, I'm going to get in trouble. They need to know who they're coming home to from school. And the most

21:57 traumatized kids later in life, it's not it's not just the ones that are abused. It's the ones who didn't know what to expect every day from their parents. Their parents were inconsistent. It's I

22:08 mean, and there's some research here. You'd rather have an [ __ ] dad than a dad who is super nice and super mean all in the same [ __ ] day. Uh you just need to develop the coping mechanisms to

22:20 deal with expectations. And right now the world, our allies, our enemies don't know what the [ __ ] to expect from this guy. And the uncertainty is worse than, you know, people. It's easier to deal

22:36 with Putin right now and she because they at least have their other countries and other leaders have a reasonable idea of what to expect from this person. Yeah, I think that's a really good

22:49 point, especially the the comparison to like Trump as the dad of America. I just think about what James Sexon told us last week where he was like, "Hurt people, hurt people." I mean, we we the

23:02 the effects of having an erratic parent and the long-lasting traumatic effects on the child are very well documented and studied and we all know what happens there. But it's interesting like when

23:14 you draw that parallel, it does make me think like what are going to be sort of the PTSD post-traumatic effects on the American people that will last decades as a

23:26 result of this ridiculously uncertain and fraught environment that he has brought upon us. I mean, I guess we're getting a little bit therapist here. Maybe that's not our lane. Uh but

23:39 it does certainly make me a little little concerned. Just real quick, I feel as if I can diagnose uh President Trump fairly well. He's an [ __ ] and he's an obese man with no

23:50 love in his life and will be dead soon. That's my That's my diagnosis here. We'll be right back after the break. And if you're enjoying the show so far, send it to a friend and please follow us on

24:03 YouTube, Spotify, or wherever you get your podcasts. Support for this show comes from VCX, the public ticker for private tech. For generations, American companies have

24:16 moved the world forward through their ingenuity and determination. And for generations, everyday Americans could be part of that journey through perhaps the greatest innovation of all, the US stock

24:25 market. It didn't matter whether you were a factory worker in Detroit or a farmer in Omaha. Anyone could own a piece of the great American companies. But now that's changed. Today, our most

24:34 innovative companies are staying private rather than going public. The result is that everyday Americans are excluded from investing and getting left further behind while a select few reap all the

24:43 benefits until now. Introducing VCX, the public ticker for private tech. VCX by Fundrise gives everyone the opportunity to invest in the next generation of innovation, including the company's

24:55 leading AI revolution, space exploration, defense tech, and more. Visit getvcx.com for more info. That's getvcx.com. Carefully consider the investment

25:05 material before investing, including objectives, risk charges, and expenses. This and other information can be found in the funds perspectives at getvcx.com. This is a paid sponsorship.

25:19 Support for the show comes from LinkedIn ads. There's no worse feeling than making a major investment in something only to realize it didn't exactly live up to the hype, such as buying a nice

25:27 piece of tech that ends up in storage collecting dust, or taking a business workshop where your main takeaway was little more than a few motivational words. If you work in marketing, this

25:37 can happen with ads. You optimize for the numbers that look great, impressions, reach, and reactions. But when they don't show revenue, well, that can turn into an unfun conversation with

25:45 the CFO. LinkedIn has a word for that, bull spend. Reach the right buyers with LinkedIn ads and invest in what looks good to your CFO. According to the 2026 Dream Data Benchmark report, LinkedIn

25:57 ads generated the highest rorowaz of all major ad networks. It's $121%. You can target by company, industry, job title, and more. It's time to cut the bull spend. Advertise on LinkedIn, the

26:08 network that works for you. Spend $250 in your first campaign on LinkedIn ads and get a $250 credit for the next one. Just go to linkedin.com/scott. That's linkedin.com/scott.

26:20 Terms and conditions apply. Support for the show comes from Monarch. Wrangling your finances can leave anyone feeling stressed. Collecting bank statements, figuring out which streaming

26:35 services you have and which ones you don't, not to mention understanding your entire financial picture. You should try to simplify your finances with Monarch. Monarch is the all-in-one personal

26:46 finance tool designed to make your life easier. It brings your entire financial life, budgeting, accounts, investments, net worth, and future planning together in one dashboard on your phone or

26:56 laptop. Feel aware and in control of your finances this tax season and get 50% off your Monarch subscription with Code Markets. With AI tools, Monarch can comb through the data to serve as

27:10 insights that are personalized to you, such as hidden patterns, changes in savings rates, and it can even identify whether your spending is being affected by lifestyle creep or by inflation.

27:21 Achieve your financial goals for good with Monarch, the all-in-one tool that makes money management simple. Use code markets at monarch.com for half off your first year. That's 50% off at

27:34 monarch.com. Code markets. We're back with Profy Markets. SpaceX has officially filed for an IPO and it could be the biggest one ever. The company has confidentially filed with

27:49 the SEC with a potential listing coming as soon as June. It's reportedly targeting a valuation of more than $2 trillion and could raise up to $75 billion in the offering. We have known

28:02 this was coming, but now it is imminent. Scott, there is a ton here to talk about. I mean, just the fact that this is going to be the largest IPO ever. Also, what it says about the space

28:14 industry, which has been ripping, and of course, everyone's very excited about it right now because of the launch of Ultimus 2 and other things as well. Uh we could talk about what this will do

28:24 for Elon. The fact that he will become a trillionaire if this happens, if it goes through, he'll be the world's first trillionaire. A lot of different angles here. Uh where do you want to stop?

28:34 >> A decent definition of intelligence, the ability to hold two thoughts in your head at once. You know, being able to understand nuance. And there's nuance here. And that is people have a tendency

28:44 to go, is this an amazing company, buy the stock, or is it not an amazing company, don't buy the stock. And what they fail to realize is that they also have to set all of this against the

28:52 valuation that it's being priced at. So first off, let's talk about SpaceX. It has moes the size of the Amazon. I think it has greater barriers of entry right now than any company in the world. It's

29:04 responsible for 85% of all space launches in the US last year. And its launch costs are a fifth of its closest competitor. And that's basic when you talk about launch, it's like talking

29:15 about a a you know a semiconductor. It's pretty much how fast and how cheap it is. They're not It doesn't matter how quickly you get [ __ ] into low Earth

29:25 orbit. It matters how inexpensively. And they can do it for five times less. They can shoot up five of the same five satellites for the same cost as their closest competitor cost to to send one

29:37 satellite into space. It's got incredible adjacent products. I'm going to be using Starlink on my flight home. I will now choose an airline or a means of transportation based on whether it

29:47 has Starlink or not. So you're talking about airlines that are flying the same goddamn tin can at the same price to the same area. The only thing they can differentiate on is service. The

29:57 configuration internally which is getting harder and harder because it you can't maintain differentiation there. But Starlink for a brief moment is a point of differentiation.

30:06 It's sweeping the maritime market. U it comes in with a better product at like a quarter the price. So in some is this an amazing company or is it ridiculously overvalued? The answer is yes. And also

30:24 this this man of the people [ __ ] where he's saying he's reserving 30% of the shares for the retail investors. He's he's doing that uh because retail investors are the only

30:37 ones stupid enough to pay this price. institutions weren't going to institutions weren't going to cover the aotment here. So he gets to say, "Oh, I'm a man of the people and I'm

30:47 allocating it to retail as if they're getting in on something." So anyways, just a bit of a prediction here. You if you get allocation in the IPO, great. And within 2 minutes, you want

30:59 out of this thing. There might be a pop. They'll probably the bankers and and Musk will price it such that there is a pop out of the gates. But you do not in 6 months if this thing gets out anywhere

31:09 near 1.8 trillion or 1.7 trillion in valuation. You do not want to be in this stock 3 6 months in when people start to rationalize even Musk and his his jazz hands can't figure out a way to justify

31:24 anything resembling this valuation. >> The point you make that holding two things in your head at the same time. Another aspect on this IPO is that there is both a lot of BS and a lot of jazz

31:38 hands here and also a lot of actual material business substance. So I mean let's just look at like what SpaceX is. I mean as you mentioned they are the leader the world leader in getting stuff

31:52 out into space responsible for more than half of all orbital launches globally last year. So they're they're launching more than the entire world combined. If you look at the US, they accounted for

32:02 85% of launches. So they've got that business, we've called it space hauling in the past and that in in that sense they are the market leader by a huge huge margin and also they're doing it at

32:13 the cheapest price. Also the satellite business Starlink, they control over 10,000 satellites in orbit as of last month. That's more than 2/3 of the entire world's total. So they've got

32:26 this telecommunications business as well, which is also very exciting and also ripping. And there's a lot of reason to be excited about that. And then also they've got XAI which has

32:37 merged into SpaceX as of last year. It's very unclear how that actually played out and to what extent they are actually properly merged at this point and I guess we'll start to find that out when

32:49 they start to uh release the filings as they file for IPO which will be very interesting to see like what is going on there. But also like consider the fact that XAI is one of the leading frontier

33:01 model companies in the world. I mean they are competing yes they're behind but they are competing with OpenAI and Anthropic. And so in a lot of ways there's also a big AI play here that is

33:12 separate from the from the space business that you should also consider. And then also consider the fact that XAI is now an owner of X formerly known as Twitter. So then at the same time it's

33:25 also a social media company and then the question becomes are you bullish on X as a as a as a social media platform. Is that something that you're excited about? all of these businesses are

33:36 getting melded into one. And I do think that that is by design because Elon, I mean, he's such a magician of commanding these extraordinary multiples because he promises all of these complex and

33:49 interesting things that you can only really think about way far out into the future, which leaves investors with no choice but to basically just say, you know, screw it. The TAM's going to be

33:58 massive because they're doing space and they're doing AI and also telecommunications and digital media. They're doing all of these different things. So, it would be stupid to put a

34:08 normal multiple on the revenues here. So, whatever. Let's just say that the market cap is, call it $2 trillion. We'll make it the largest IPO in history. We'll cross our fingers and

34:20 wait and see. And that is kind of the approach here. It has been his approach before, especially in the in the case of Tesla where he just wraps the taxis and the robot the humanoid robots all into

34:31 one thing. And it's going to be the same thing with SpaceX. >> Yeah. Like I think that he's conglomerating and I think what he's trying to do is SpaceX is the lipstick.

34:41 It's an amazing company with an amazing product and XAI and Twitter are the pig. I mean, okay, XAI is growing within the Twitter community, but the reality is people are coming to grips with the fact

34:55 that the winners and losers in AI in terms of LLMs, it's all about one thing. It's about the enterprise market and that is consumers have access to a ton of free product and there's some revenue

35:08 there. Nothing nothing in the consumer market is going to justify these types of valuations when they have access to a ton of free openweight LLMs. Uh so this is all about the enterprise

35:20 market and let's talk about the enterprise market. Um you have um Anthropic is now 40% of enterprise spend and I read yesterday that they're getting 70% share on new spending in the

35:35 enterprise market and it's evidenced by the fact that Open AI is is focusing because they are clearly freaked out. Open AAI uh has about 27% share, Google 21, XAI is negligible like barely even

35:50 registers. Uh, so I don't I'm not sure I buy that XAI is is a better LLM. Now, what's interesting is can the superior connectivity of SpaceX slash whatever there is doing with Starlink going to

36:07 give XAI an advantage? I think what he's effectively doing here is he's saying, "Okay, I have one amazing company in space. There's nothing cooler. I can talk about it and have videos of

36:17 launches. It's going to be really dramatic, really cool. What's perfect for him is like the ultimate carnival barker and then I can bury this other [ __ ] in it which will give it an AI and

36:26 a media spin and then I think eventually he'll roll in Tesla which is also starting to collapse and talk about autonomous connectivity that's unrivaled all flowing through LLMs which inform

36:39 these incredible products. So, it's going to be a story. There's going to be so much spin here and but it's perfect for him cuz he was able to artificially elevate Tesla for a decade. There's just

36:53 no [ __ ] way to rationalize Tesla's valuation other than him saying, "Oh, Reovven or autonomous driving. It's coming a thousand a million autonomous taxis on the Tesla taxis on the road

37:04 within 12 months." I think he said that in 2017. So, what is he? >> He's bored of that now. Now it's humanoid robots. I mean he now that the taxis

37:12 >> look over here a humanoid. We haven't heard much about those humanoid robots lately. >> So this is the ultimate. He's got an amazing company that'll be sort of the

37:21 the lead the lipstick on these different pigs. This is going to be an incredible act of showmanship. An amazing company. Maybe worth 300 billion. I don't know. Maybe worth 400 billion.

37:34 >> I think that segus us well into this retail investor element. I mean the stat that is important for people to know is that SpaceX is allocating more than 30% of the IPO shares to retail investors.

37:48 Most IPOs will save 10% for retail. So there is clearly I mean you could read this as oh this is this is nice of them because they're opening up to retail investors and they're giving retail

38:00 investors a shot. Or you read it as they need the retail investor to prop up this very very ridiculous valuation because perhaps it will be the retail investors. Maybe they view it quite cynically.

38:13 Maybe they see that the retail investors might be the dumb money and they say retail investors will be the ones who are most susceptible to our kind of ridiculous narrative laundering story

38:24 here about a future of AI combined with space. By the way, we should mention that he's also talking about building data centers in space. That's like one of his big themes for SpaceX, which many

38:35 people, many experts have said is completely ridiculous and doesn't make any sense whatsoever. The idea that we're going to I mean, we have we have land on Earth. Why are you going to go

38:45 build a data center on a space station in space? It just doesn't really make sense. But it might be the kind of story that retail is particularly susceptible to. I mean,

38:56 some people would say that we're being patronizing to retail investors perhaps, but I mean, let's also consider the fact that 43% of Tesla is owned by retail investors. Like, retail is the thing

39:07 that is supporting that extraordinary valuation. And it does appear that they believe that that is what is going to support this valuation too. I'm maybe just cynical, but I view it as them sort

39:19 of taking advantage of retail as opposed to offering them an opportunity. probably the most you would argue the most innovative company of the last five or 10 years has been

39:29 um Nvidia and Nvidia is trading at a forward PE of somewhere between 17 and 20. That's a price to earnings. >> I mean you made the Google comparison earlier which I think is a good one

39:40 because when Google IPOed the company was trading at 10 times trailing revenue the revenue growth was 240%. You look at SpaceX, which is going public at more than 125 times trailing revenue. The

39:53 growth is 20%. So when you think about it, SpaceX's revenue growth is 10 times lower than Google's was when Google IPOed. And yet the valuation is more than 10 times higher than Google's was

40:06 when Google went public. So the whole thing is kind of flipped on its head here. And the only thing that could justify the valuation is if you believe that there's this very very special

40:17 future of space and AI and data centers that all comes together in the perfect way and it's all I mean you really it's just hopeium. You have to hope that this is going to be a massively successful

40:28 business. Maybe it will be but that's a lot of hope in there. You're you're putting a lot of faith in his ability to to grow these revenues tremendously. $16 billion in revenue last year. That's not

40:40 that big. That's not that impressive. $8 billion in profit. Okay, whatever. The valuation's just it's just too high. >> When I hear that that type of striking insight from you, the the only thought

40:52 that kind of runs through my mind is that it's hard to believe that I was nominated for three Webbies and you were nominated for zero. Hello, ladies. Watch your shoulders. Watch his shoulders.

41:04 Hello. I'm sorry. Yeah, that's fascinating. Yeah, you're going to trigger me again and then I'm going to start and then I'm going start getting salty and upset.

41:12 >> You still have time, my brother. When I was 27, I knew I knew every line from the Planet of the Apes and could make a bong out of any household item. That was really my accomplishments to that point.

41:22 You're doing just fine, Ed. >> Ah, but you know, I'm getting to that age where you started actually to do some cool stuff. I mean, I'm 27 now. I'm pretty sure that's when you were

41:31 starting your first company. like we're we're we're we're we're rubbing up against your your glow up period here. So I I I take your point. >> Company's doing a lot of work there. It

41:41 was me it was me working out of a $280 apartment in Rockidge, Oakland, calling the alumni of of H saying, "I'm a brand strategist. Will you hire me?" >> That's not what you told investors. They

41:54 liked it. They liked you. The final angle here on this on this SpaceX point, if this goes public at $2 trillion, and it probably will, Elon will become a trillionaire. He owns more

42:08 than 40% of SpaceX. So, this would make his stake worth roughly $860 billion. And now, if you look at the odds on Kali that Elon becomes a trillionaire this year, those odds have risen to 75%.

42:23 That's this year. So basically, he's going to be a trillionaire. Some people will say, "Oh, well, you know, that's not a big deal because of inflation." Like, what's the inflation adjusted

42:34 number? I'll just give you some context. During the Gilded Age, John Rockefeller was worth 1 and a half% of US GDP. Uh, as a share of GDP, if this uh goes if this uh IPO goes as expected, Elon will

42:49 be worth more than double that as a share of GDP. So Elon will be the richest guy in history by far on a relative basis as well as being the world's first trillionaire. This is

43:02 going to make him incredibly rich. What do you make of it? >> I think it's important that we have what feels like outrageous wealth in the United States. I think that one of the

43:12 reasons people come here is that they think there's no ceiling on me. I can in Germany you're supposed to stay within your class. Europe there's a certain sort of what do they call it trimming

43:24 the daisies or whatever in the US the notion is that anyone can be magnificently wealthy and having you can be a billionaire in the United States I think that's a wonderful thing and I

43:35 don't believe in these kind of class wars of assuming that all billionaires are bad people I I think that's unhealthy what's happened though is that because

43:46 of a tax policy that's been weaponized by the incumbents billionaires have been able to pull away and garner a disproportionate amount so much of the proceeds and prosperity that it's

43:57 creating an anxious and depressed youth. And that is, we talked about this in the last episode, people's mood and feeling about their situation isn't about how they're doing relative to people

44:08 50 or 100 years ago. They do it relative to how they're doing to everybody else. So, when you're not accelerating as quickly as the top 10%, you feel as if you're falling behind, even if you're

44:18 doing better. And when your Instagram feed is just full of constant reminders of how the 0.1% are doing or the 20% with a ring light and how to use Instagram pretending to be the 0.1% you

44:30 just feel like you're not keeping up and you feel bad about yourself and you feel bad about the country as evidenced by only one in 10 young Americans feel good or very good about America whereas it's

44:38 one in two people my age. And part of that problem is that when you have 26 people who are worth more, no I'm sorry now it's six people who are worth more than the bottom half of America and he

44:49 may be close worth more than the bottom 40% of America. It creates a sense that the system is rigged >> a vibe >> a vibe a certainty an observable

44:59 pattern. Also, these the the the people in the guilded age, they couldn't turn off battlefield technology in Ukraine or on and switch the trajectory of a global conflict. They didn't have

45:13 that sort of power and access to technology. And what's really frightening about this quite frankly is that we have essentially wars and the global order can be massively

45:25 influenced. There's a decent argument that that Musk with $250 million swung the presidential election. I actually think Trump would have won without him uh because we had a fairly mediocre

45:35 candidate, but he definitely had a big impact with a quarter of a billion dollars and with a quarter of a billion dollars and u weaponizing his platform. Now, what could he do in the next

45:48 presidential election if he decides I want X or Y? And he said, I know I'm worth a trillion dollars. I'll take 2% of my net worth. 2% that's $20 billion. That's 80 times more than he spent in

46:02 the last election. And with Citizens United, $2 billion surgically delivered over a platform that you know 40% of America's on or something like that. He could ab and then targeted in the fact

46:15 that our electoral system basically has made it such that there are a small number of counties and a small number of states that decide the election. he could just overwhelm him with messaging

46:26 and um money and swing the election. And so you have essentially the most powerful person in the world is decide by one man. And battlefield technology can be decided by one man's blood sugar

46:40 level. And this individual, while being a genius, is someone who is addicted to ketamine, according to the Wall Street Journal, sleeps with a loaded gun next to his

46:48 bed, and is being sued concurrently by two women for sole custody of that child because he hasn't seen that child. And by the way, I just don't think any one person, regardless of how wonderful you

46:58 may think there are, they are. One of the universal axioms of our species is that power corrupts and and absolute power absolutely corrup corrupts. And in a capitalist society, money translates

47:09 to power in a connected global economy with with connectivity through technology that's also controlled by this one person who is not subject to any regulation. Is not bound by the law

47:22 but protected by it. Can buy off any politician. If [ __ ] gets really real from here, can peace out to a country with no extradition treaties, but likely wouldn't even need to do that because he

47:30 can buy so many politicians or delay and obiscate any sort of civil or criminal prosecution. You effectively have the new leader of the world because presidents are termlimited. Notice how

47:42 Trump is such an [ __ ] It must said Trump is in the Epstein files before any of the files before they came out and Trump didn't say anything mean back. I mean, Trump Trump

47:53 is so scared of this guy and he should be because this is the individual now who has greater influence in the medium and the long term. President Trump, the president of the United States has

48:04 greater influence than anyone in the short run. He can deploy the most successful organization in history and that is the organization that can provide or deliver more lethality

48:13 globally than any organization in history and that's US military. But over the medium and the long term, it's a guy with no term limits who controls connectivity, who's worth the GDP of a

48:22 small nation and can deploy it strategically for his own desires, blood sugar level or ketamine hallucination. So at some point as a total capitalist who believes in people should have the

48:36 opportunity to get exceptionally wealthy, this level of income inequality really has become an existential threat, especially when a small group of people have this much power.

48:46 We'll be right back. And for even more markets content, sign up for our newsletter at craftymarkets.com. This episode is brought to you by SoFi Small Business Loan Marketplace. You

49:01 know, the one that helps you get your money right with student loans and high yield savings. Now, they're helping small businesses find fast funding. If you run a small business, you're

49:10 probably dealing with cash flow, trying to find capital for new opportunities, or thinking about other ways to expand. With SoFi's small business loan marketplace, you can get fast digital

49:18 solutions. That's SoFi small business loan marketplace. In one single simple search, SoFi matches you with vetted providers for your business in just minutes. You'll get matched with loan

49:28 options that meet your goals. And if you find a loan that works for you, you can receive funds as soon as the same day you're approved. You can also explore business bank accounts and business

49:36 credit cards. Visit sofi.com/profg and see your loan options in minutes, all with no impact to your credit score. The SoFi marketplace website is owned by SoFi Lending Corp. Terms, conditions,

49:48 and state restrictions apply. CFL60-54612 NMLS1121636. Support for the show comes from Upwork. So much of your business's early success

50:04 comes down to timing, specifically finding the right expertise at the right time. That's the thing. Fast growing businesses aren't simply doing more. They know when to delegate and to whom.

50:14 That's where Upwork comes in. With Upwork, you don't have to do it all yourself. and they make it easier to bring on the right freelancers right when you need them. You can browse

50:22 profiles, review past work, and get help scoping the role so you can hire with confidence and get started quickly. Seriously, you can connect with the right freelancer in just a few hours.

50:32 Especially when you sign up with Business Plus, their AI powered shortlisting pairs you with the top 1% of talent in under 6 hours. No endless searching required. Upwork also cuts

50:41 down operational hassle by handling things like contracts and payments in one place, so you can spend more time running your business. You can visit upwork.com right now to post your job

50:50 for free. That's upwork.com to connect with top talent ready to help your business grow. That's upw.com. upwork.com. Support for this show comes from Vanta.

51:07 If you run a business, you don't need us to tell you that risk and regulation are rising. More and more customers expect clear proof of security before they'll commit. Building that trust is essential

51:17 to closing deals, but it can also be costly, confusing, and timeconuming. Vant says they can help. VA automates your compliance process to bring compliance, risk, and customer trust

51:29 together on one AI powered platform. So whether you're prepping for a sock 2 or running an enterprise GRC program, Vant keeps you secure and keeps your deals moving. And with continuous monitoring,

51:43 Vanta helps with real-time reporting and security reviews you can share instantly instead of searching through audits and spreadsheets. You get a system working quietly in the background, keeping you

51:54 compliant, reducing risk, and helping your business grow faster with confidence. You can get started at vanta.com/markets. That's va.com/markets.

52:07 vanter.com/markets. We're back with Profy Markets. Two sneaker brands at opposite ends of the market are both running into trouble. Those brands are Nike and Allirds.

52:22 Nike's shares dropped 16% after warning that sales will decline for the rest of the year, including an unexpected 20% hit in China this quarter. And internally, the frustration is showing.

52:34 CEO Elliot Hill told employees he's quote so tired of talking about fixing the business and wants to shift the focus to driving growth. Then there's Allirds, the once buzzy shoe brand that

52:45 peaked at a $4 billion valuation. Well, last week it sold off its IP for $39 million after never turning a profit since going public in 2021. So, it's got two different companies in the same

52:59 space uh suffering different problems but maybe also similar. Uh just to go through what happened with Nike here. Nike beat on earnings. Stock plummeted 16%. The big problem was the guidance.

53:13 Analysts were expecting that sales would grow next quarter. Nike said that sales would actually decline by up to 4%. And as I mentioned in that intro there, the big problem is China. They expect China

53:23 sales are going to fall 20% next quarter. And this has just been a horrible few years for Nike. The stock has fallen nearly 70% since 2021. Revenue has fallen every quarter for

53:37 more than a year. And the stock is now sitting at a 9-year low. The valuation is also extremely low at this point, trading at 1.4 times sales. Compare that to our conversation about SpaceX, more

53:49 than 100 times sales. that valuation on a price to sales multiple. It's the lowest we've seen for Nike since 2009. So really bad year several years for Nike and then also really bad for

54:00 Allirds which everyone was very excited about back in 2021. >> Not everyone. You don't remember our CNN Plus show? >> Not everyone. Not everyone. Yes, we'll

54:08 get to that. Valuation hit $4 billion and the stock collapses. uh it's down 99% and they sell basically what's left of the company which is the IP for $39 million

54:23 literal peanuts compared to what people expected. So uh maybe we'll start with allirds because you mentioned not everyone was excited and that's true. You were not excited. Uh let's start

54:35 with your reactions to both of these companies. So, just a walk down memory lane, Jeff Starker called me and said, "Would you like to do a show on we're doing a a subscription streaming

54:44 platform, CNN Plus? Would you like to do a show?" And I said, "Yes." And he said, "Uh, do you want to get our agents involved or do you just want to do the deal directly?" And I said to him, "I

54:54 trust you. I think you're generous. You're obviously very good with talent. Uh, just put an offer on the table and I'm not going to even respond. I'm just going to accept. So, send me the

55:02 paperwork." And he did that and he was generous and I got a one-year contract. I should have he offered me two two but I you know I said no I don't want to commit to anything for longer than a

55:13 year and I wish I had but anyways he gave me a one-year contract and we started what was it called again? I don't remember what it was called. Was it called the Prof show? I don't even

55:21 remember what it was called. You worked on it. Do you remember what it was called? >> I think it was called No Mus and No Malice.

55:25 >> Oh no Merc Alice. That's right. And anyways we did it just a brief history. We did it for five or six shows and Monday night my producer called me and said, "Good news. We're now the highest

55:37 rated hourly show on CNN Plus. We're beating out Jake Tapper's book club and and anderson's show on you know you know who's died in your life." Anyways, uh that's not

55:51 funny. That's not funny. But high fives all around. Do you remember I I think I sent a message to everyone saying we're the number one hourly show on >> CNN Plus.

56:01 >> Not sure how excited we all were about that. >> Yeah. Which might have meant 14 people. We don't know what that meant. Anyways, and then I'm in San Diego. I went down

56:10 to the bar, you know, as I often do. And I woke up the next morning not feeling great as I often do. And and I get from Cara. I'm like, "Are you all right?" And I'm like, "What?" I'm like, "What's

56:22 wrong?" and she goes, "Oh, you know, uh," and then she forwarded me the New York Times article, CNN Plus being unplugged, uh, by the new owners who were angry by Zazov, who wanted to show

56:32 Jeff he was on top. So anyways, but the first episode we did a rundown of these consumer IPOs, and there were three, WBY Parker, Rent the Runway, and Alberts. And I said the only one I liked was WBY

56:46 Parker. I thought I think WBY Parker's incredible. I think I'm wearing WBY Parker glasses right now. I think they are an absolute breakthrough unlock in terms of vertical integration, great

56:55 stores, great manufacturing and they took a category that was controlled by a monopoly I forget what it's called lux luxodica that was every year raising prices

57:05 faster than inflation and with guys like me who wear glasses you end up getting a 6 or 700 pair of glasses and this happened to me and then right after you picked them up leaving them in the cab

57:15 on the way home and Warb said we can give you 80 or 90% of a Tom Ford or an Oliver People's class glasses, pair of glasses for 20% of the price. 100 bucks. And so now I go to WBY Parker and I pick

57:29 up three or four pairs. They're almost like disposable for me. It's been a huge game changer for me. I love what they do. I love the IPO. And by the way, it hasn't performed that well since the

57:37 IPO. It's flatted down. It's probably been cut in half. >> Flatted down. Flatted down or cut in half? It's been cut in half. It's It's not been great.

57:45 >> Hasn't been cut in half. Um, but compared to the other two, it's the sh it's the it's Nvidia because yes, Rent the Runway, I remember looking at that. Rent the Runway was a stupid business, a

57:57 nice idea, but for every dress they rented, they were losing money. So, it was kind of the wei work of the dress or the clothing rental business. And I was on the board of Urban Outfitters and we

58:07 all sat in a board meeting and I don't think I'm this isn't inside baseball. At some point, you know, everything gets sunshine. And our viewpoint was, wait till they go out of business and we're

58:17 going to buy them for scrap. They just don't have the scale. They don't have the sourcing, the merchandising. They don't have the scale. And every member they signed up for whatever it was, 200

58:26 bucks a year was going to cost them or if you signed up a member for I forget I forget what they were charging for X dollars, you were going to lose 2x. It was Weiwork. It was negative gross

58:38 margins that got no leverage on scale. And then finally, Allirds was a stupid company. It was a very fashionable product which meant it was like this kind of mohare kind of cool and it had

58:51 absolutely the worst spokespeople in the world and that is the VC community embrace it. Oh [ __ ] that's what I want to be. I want to be a 58-year-old guy that's slightly overweight who went to

59:00 Stanford and is now washing out founders and thinks that his character and grit are responsible for the American success story. Yeah, that's who I want to be. And it just and then they went out, they

59:12 took their I followed the company pretty closely. It was kind of like what Restoration Hardware did in the first version. They went out signed a bunch of expensive leases that they could never

59:20 sustain on four-wall unit economics. And slowly but surely, it was pretty clear this thing was going to go to zero. It didn't go to zero as quickly as Rent the Runway, but there's no IP here. I'm

59:30 shocked anyone paid anything for this. I maybe it's an e-commerce site from people who want to I don't know remember the good old days of I don't know investing getting in the

59:40 series E of Tesla or whatever it is the people are wearing those shoes are doing 5 years ago but uh I will say this they have really good underwear I do like their underwear um but it never this

59:51 company never made any sense it never had the following and the depth of the following or the loyalty uh it just was a shitty business shitty idea should have never been public should have been

01:00:01 way more measured. Should we talk about Nike? >> Yeah. But I just want to read you one quote from No Mercy No Malice. This is from October of 2021. I'll also just

01:00:08 note that I was your lead analyst on this on this article. I'm going to pat myself on the back too. But here is the quote. It's very good. >> Our view October 2021. Our view. Quote,

01:00:18 >> all birds organic growth is sputtering and management is buying transitory growth to support the stock price until management can sell. That is essentially what happened here. We were not very

01:00:28 excited about this company. um especially compared to the other companies that were going public. Uh and yeah, it has been a disaster and $39 million for the IP. I mean, they have

01:00:39 essentially they've essentially shut the business down. Um and perhaps there are some learnings there on what they got right, what they got wrong. I mean, as you point out, they invested pretty

01:00:48 heavily in in direct consumer, which I think was kind of exciting at the time. people were kind of pro direct to consumer. But then there was the shift uh where people realized were kind of

01:00:58 underrating wholesale and the value of wholesale. They didn't really invest anything into those wholesale relationships. They couldn't maintain these stores and so they cut the number

01:01:07 of storefronts in half. Um and it just ended up being a giant disaster which is a good transition into what's happened with Nike because obviously the Nike story, Elliot Hill story has been all

01:01:18 about let's revive our wholesale business. Let's shift a little bit away from the DTOC story which we were really leaning into uh under the previous CEO John Dono. Uh but it appears even that

01:01:32 isn't really working. So yeah, let's get let's hear your views on what Nike is maybe getting right, but also what it's getting wrong. >> Look, this is arguably one of the still

01:01:42 one of the greatest consumer brands in the world. I don't care if you're watching a football game in Ghana or bad mitten in the UK. The Nike brand just has resonance and it means American

01:01:55 competitive. You didn't win silver, you lost gold. Like win at any cost. It's just it's an incredible. They have great products. I I think they have great distribution. When we sold L2, I gave a

01:02:06 list of the top 12 people to Gartner and said, "Whatever you do, hold on to these people." within I don't know 24 months all of them were gone and three of the most talented people Moren Mullen Ashley

01:02:19 Tolbert and Daniel Bailey who was also my graduate student instructor way back when went to Nike and Nike was one of our biggest clients and they went when I think the stock was at I don't know 80

01:02:31 and it went to 120 so good for them and now it's back to what 45 or something the stock is where it was in 2014 >> yeah I think 2017

01:02:41 >> the stock has been decimated on any and it looks cheap. I thought it looked cheap a month ago. Um what struck me as strange was Elliott Hill. I've I've only I've been in a room I've I know Elliot a

01:02:53 little bit, not really. Um it strikes me as a very talented guy and I think he was good for morale to bring an insider back. John Dano will go down as one of the great disasters bringing in a tech

01:03:04 guy to run a a a brand driven company. Um, but Elliot told employees, and you said this, he's quote, "So tired of talking about fixing the business." I feel like that's when with my ex-wife,

01:03:16 if I would have said to her, "I'm so sick of talking about valid reasons for my shortcomings as a man and a husband." It's like, "Well, okay, bitch." Yeah, I bet your board is sick of you

01:03:26 talking about it, fixing the business, and wants to see some cuz he's now been there. It's a little unfair. He's only been there, I think, 15 or 16 months. He should be given three years. This is,

01:03:36 you know, you're not turning around a speedboat, you're turning around a tanker here, but I think he's got the wrong strategy. I I think that as a motorin said something that always

01:03:45 struck me, and that is we're obsessed with youth and growth companies never want to accept that they're aging and they're now mature companies. And really

01:03:57 talented CFOs will say, "This is a low growth, mature company. We need to start returning money to shareholders and managing the cost side more effectively. And Nike is still pumping Botox and

01:04:09 fillers into its face trying to be young again and not recognizing it's a mature low growth company. And the data that struck me was their employment is actually up since 2020. I quite frankly

01:04:22 if I were on this board I'd be saying okay Elliot I I get the rahrh speech for the all hands but the reality is we need to cut cost by 20% over the next three years here because this is a low growth

01:04:33 business. We need to obviously reinvigorate the the the product, try and find pockets of growth, but be clear, we are now a mature company. We are wearing diapers on the wrong end of

01:04:45 the age spectrum. We're not a growth company. We are a mature company that needs to manage this company more responsibly. What do I mean by that? And no one likes to say this. I think

01:04:55 there's going to be five to 20,000 layoffs in the next 24 months because I believe an activist is going to come in here and say, "Great brand, still amazing sales." I mean, the last time

01:05:05 their stock was trading at this level, they were doing 25 or 30 billion in sales. Now they're doing 45 billion in sales, but they have margin compression and they aren't uh growing and the

01:05:15 market hates that. So, bottom line, they need to be who they are. They need to acknowledge. They need to do away with the trucker hat and the bell-bottom jeans and trying to pretend they're

01:05:25 younger than they are. As I sit here dressed like an aging skateboarder um and acknowledge they're a mature low growth company and cut costs and for Elliot to pretend that this is a growth

01:05:37 company and they need to reinvigorate growth. Okay, shore up the business, shore up the brand, fine. But this isn't this is now a business about operations and discipline and being the adult in

01:05:47 the room. >> Yeah. and cutting costs dramatically. >> It's so interesting you say this isn't a growth company. One thing that has always struck me on Nike's investor

01:05:58 relations homepage, the first thing you see, and this has been the case for years, and I just checked, and it still is the case, the first thing you see on the on the investor relations homepage

01:06:08 is giant letters. Nike is a growth company. That's like their main pitch to investors. We're saying we're a growth company. And to your point, it's like, well, definitionally you're not because

01:06:21 your revenue has fallen every quarter for more than a year at this point. So definitionally, you are not a growth company. But it is an interesting thing and I've always wondered what companies

01:06:30 are really supposed to do about this because Aswath's point about the corporate life cycle is a very good one which is you know the companies age over time and as you age you need to try to

01:06:41 figure out how to act more your age and you don't want to try to pretend that you're a young company like Nike seems to be doing saying that we're a growth company but at the same time it's like

01:06:51 well you also want to grow and you also want especially in a consumer-driven business like Nike, you want to look young, you want to look cool, you want to look like the next big thing. And so,

01:07:04 it's a very difficult thing to to balance. And I guess as the brand strategy professor, how would you be balancing that? Like maybe on the corporate level, it's a

01:07:14 different thing, but like they still need to look cool. >> This isn't about brand strategy. I I think Elliot and his team are outstanding of brand and I think that I

01:07:23 assume they're still working with Widen Kennedy. They have some of the brightest brand builders in the world. Their direct to consumer strategy may need a refresh, but I know some of the people

01:07:31 running their DTC and they're incredibly talented. This is about, okay, they lost touch with the quoteunquote street community. The product needs an upgrade. This is a business issue. This is this

01:07:43 is going through the company and unfortunately saying, "All right, we have I think it's 55,000 employees. We need to do 90% of the revenue with 30,000."

01:07:54 And I think they could get there. I think there's probably this is what happens when you're a growth company. You keep eating, you keep eating, and you build up fatty cells all around the

01:08:02 company, all around the corpus. And I think that's what's happened here. And it's not romantic, but I think what they should be telling investors is we're going to grow ibitta

01:08:11 12 to 15% a year for the next 5 years. And this is how we're going to do it through a combination of efficiencies, which is Latin for cost cutting, which is Latin for layoffs, and and having

01:08:23 solid, if unremarkable growth. And that would be quite frankly, that's going to be I mean, the good news is that's going to be easier than trying to find new pockets of growth for a company that

01:08:34 doesn't have the same cache as some of these smaller niche brands like a Hoka or or an OnRunning. So this is entirely the wrong strategy from a shareholder standpoint. I'll use Tom Celich as an

01:08:46 example. Do you know who Tom Celich is? >> No. >> This is one of the most handsome men of the last millennium. Tom Celich Magnum PI. This guy. And by the way, a quick

01:08:57 fact. I'm the exact same height and weight as Tom Celich except at his prime. Except he looks much better in shorts than I do. >> How do you know his weight?

01:09:06 >> I was obsessed with Tom Celich. This guy is the baller dude. He was the honorary captain of the US volleyball team in like 1988 or '92. Great actor, handsome, nice man. I I just I I think married

01:09:23 once. I think this guy's a great role model for masculinity. Anyway, um uh drove a Ferrari around Hawaii as a private detective. Not a great TV show, but

01:09:32 >> Okay. Okay. >> Anyways, >> anyways, at some point >> you like it. At some point, even Tom Celich has to stop wearing shorts. At

01:09:42 some point, Nike, you have to stop wearing shorts. You're not a growth company. You aren't. And if you keep take your lips off the [ __ ] crackpipe, Elliot, you are a fiduciary

01:09:55 for shareholders and for your employees. And 10 or 20,000 people at Nike have been laid off. They just don't know it yet. So, what you want to do is figure out where there are efficiencies in this

01:10:07 company. Be as generous as possible with those people who probably don't need to work at a company that's going to go sideways for the next 10 [ __ ] years pretending to to pump a bunch of Botox

01:10:18 in its face and pretend we're young again and start cutting costs and rationalizing this business and waking up to the notion that you are a now you are no longer a teenager. You are a baby

01:10:30 boomer. And this can be this can be a great investment. This can and whether you want to do that or not, someone's going to force you to do it because this thing is becoming obviously

01:10:42 overweight and needs to cut costs and have and look in the mirror and go, "Oh, wait. I'm not 18 any longer." So, I I have Elliot is the right guy, I think, for probably the brand and product.

01:10:58 Someone on the board and Elliot need to get together and say we're paid to be adults. It is time to we should be the front of our investor page are say should say growing ibitta growing

01:11:12 earnings growing shareholder value and in about [ __ ] in about four hours with AI and some information I could put together an investment deck that would take the stock up 10% by talking about

01:11:26 how we're going to increase ibita 10 to 15% a year for the next 3 to 5 years through by keeping revenues flat but dramatically cutting expenses. And by the way, for every dollar in expenses

01:11:39 you cut, it's kind of the same as getting six or seven dollars in incremental revenue. Because if you have operating margins or say you have operating margins of 15 or 20%, cutting

01:11:50 expenses by a dollar is the same has the same impact on the bottom line as $5 in incremental growth. Which do you think is easier in a company like this? I bet there is fat [ __ ] everywhere at Nike

01:12:02 right now. They may not feel like it. They they've gone through some layoffs and they feel like it's hard. They have no idea, the employees at in Portland, what's coming because an activist is

01:12:12 going to show up and say, "I can get this thing to 70 bucks by just telling the CEO, if he doesn't start acting like a [ __ ] grown-up, I'm going to boot him and the board. I'm going to come

01:12:23 after him and the board." I haven't looked at the class structure of the shares yet. I don't know if it's a two-class share company or if Phil Knight still controls it, but this is a

01:12:32 70. This is a 70 to80 stock if there's just an adult in the room. >> Time to get our activist hats on. Time to launch a a takeover, a hostile takeover. Gateway Computer. That's what

01:12:43 I'll That's what I'll say to you as we end this. >> Gateway, my the my weakest flex in history. Well, I was on the board of Gateway Computer.

01:12:52 >> And And you were the number one show on CNN Plus for the few weeks that it w existed. So, that's the other that's right. >> That's the other brag. Okay, let's take

01:13:01 a look at the week ahead. We will see the minutes from the Federal Reserve's last meeting. We'll also see inflation data from the personal consumption expenditures index for February and also

01:13:10 the consumer price index for March. Uh Scott, any predictions? >> I've already made it and I've made it over and over. Activist, Nike, adult in the room,

01:13:19 >> 80 bucks. We're at 45. What do you say? 70 AC. What's your target? It depends if you know when they put the crack pipe down and acknowledge and they look in the mirror and go, "Oh, wow. Sucks to be

01:13:31 a grown-up. I need to be a grown-up. I'm going to keep revenues flat. I'm going to cut costs four to 6% a year for the next um 3 years. I'm going to increase uh easy double low double digits every

01:13:44 year." Thank you for listening to Propy Markets from Propy Media. If you liked what you heard, give us a follow and tune in tomorrow for a fresh take on markets.

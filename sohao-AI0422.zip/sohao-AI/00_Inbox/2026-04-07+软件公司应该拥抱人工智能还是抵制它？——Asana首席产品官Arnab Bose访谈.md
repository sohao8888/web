视频链接：[https://www.youtube.com/watch?v=nKyJ67L2xqI&list=WL&index=4&pp=iAQBsAgC](https://www.youtube.com/watch?v=nKyJ67L2xqI&list=WL&index=4&pp=iAQBsAgC)
视频发布时间：2026-04-07
频道名：Alex Kantrowitz

## 转录内容

00:00 Should software companies like Asana fight AI or embrace it? Let's talk about it with Asana Chief Product Officer, Arnab Bose, who's here in studio with us today in a conversation brought to you

00:11 by Asana. Arnab, welcome. >> Thank you, Alex. Thanks for having me. >> All right, it's great to be here, especially at this time. So Asana's work management software and you know what

00:21 the popular narrative is if there's work management software any software one day it's just going to be vibecoded by somebody sitting at their console called code or codeex

00:31 >> uh and then what happens to so let's put the question to you uh can something like asana be vibecoded >> question is why would you want to do you want to go ahead and focus on um work

00:43 that's going to require you to spend time thinking about security about reliability about 99.99% uptime about depth of integrations about how do you onboard new AI agents onto your human AI

00:57 coordination platform all of these questions are hard they require thought that's way beyond yeah getting to a proof of concept or a demo especially if this is the coordination layer that

01:10 helps you get uh output and outcomes out of the agentic investments you're making in your company so our thesis is that every company is becoming an AI powered company. They want to get results out of

01:22 their AI. Assatada is super well positioned to leverage our workcraft, the system of context that we bring that enables human beings to coordinate to allow human beings and AI agents and

01:35 multiple AI agents to coordinate with each other. We've been building this technology for over a decade. We focused on global availability, uptime reliability, on security, on how do you

01:47 ensure that these agents get this concept called shared memory in a way that is secure for your business. Does anybody really want to go ahead and recreate that and take time and energy

01:56 away from their core business to go think through all of this depth of integration, this depth of uptime, this depth of performance, this depth of scalability, or would they rather stay

02:06 focused on on achieving their actual business outcomes? You know, I have this crazy idea that maybe there will be other like one AI agent builds the software and then other AI agents focus

02:18 on some of those things that you talked about like uptime, reliability, keeping up with the latest standards. If AI goes the way that people intend. What do you think about that? Well, again like uh

02:29 you're spending as a customer then you're going ahead and spending that many tokens going ahead and not only building the software that is helping you run your business in an ancillary

02:40 way but also spending a bunch more tokens trying to go ahead and making sure that that software is secure, available, reliable is addressing any of the permissions concerns. And if the you

02:54 know future is uh the person who's spending the maximum amount of token burn in the most efficient way is going to achieve their best business outcomes for their particular industry vertical

03:06 their key business. Why would you go focus on something that's not your key business right >> let asana focus on that from the perspective of human and AI coordination

03:14 because that is our key business. you can focus on whatever your business is like maybe it is a travel company maybe it is a company that's a financial institution maybe it's a company that's

03:24 a healthcare institution these companies are you know are not going to be successful if they end up spending their tokens and their cost on achieving these outcomes that are more about

03:33 coordination between human beings and AI agents >> okay that's a good point so it's like sure go ahead and attempt it but tokens aren't free

03:41 >> correct and so maybe in some world you can build all the software that you But you're going to spend a lot of money to do that and to maintain it through, you know, probably less efficient means.

03:52 >> Totally. Ask yourself the question like, is this a critical core competency where I want to differentiate and is this the real reason why I'm going to be successful

04:00 >> in my company's mission and vision? If it's not and it's more of an enabling technology, then why go do it? >> Yeah. But another thing that's happening is as this wave of technology hits

04:14 um it takes it allows people to take software that's built for the masses built to scale and sort of customize it >> in a way to their own interests and um and build the set of tools or or work

04:28 within the set of tools that specifically attack their use case. customized software. Do you see that as something that you know you can embrace or do you do you fight that?

04:38 >> Oh um I think that's something we're totally embracing. So again like as a we've been thinking hard about our strategy about where we differentiate and what value do we provide to

04:47 enterprises. The value pro to enterprises is the fact that we've been thinking so hard about this coordination tax for so many years like over a decade. We've been thinking about how do

04:58 we ensure that there's this pyramid of clarity that you get to by using the workcraft which defines tasks and projects and portfolios that clearly ladder up to company level goals and

05:08 mission. And that framework is something that we've provably demonstrated works really well for training AI agents and ensuring that AI agents have the right level of business context as well as

05:20 enterprisegrade memory to go get work done. And so again like uh we want to make sure that Asana is fit for purpose and works in the best possible way for every enterprise out there and

05:32 customization where you can bring your own agent or where you can customize one of our pre-built AI teammates that is 100% part of our strategy. We want to make sure that you're having to do as

05:43 little thinking about how you want to use Asana and leverage us to get your work done, achieve your mission and vision because we've built this flexible framework that any AI agent can take

05:54 advantage of in a way that gives them this differentiation of enterprise grade memory uh shared context and not having to go ahead and sort of relearn things that a human being has done in the past.

06:07 Okay, I want to dissect this and just break it down point by point. >> Um, talk a little bit about PAI, what people would use ASA for. High level 60 seconds just to explain what the product

06:17 does. >> Our key uh ideal customer profiles are in uh marketing uh IT operations and strategic planning. >> So what they would use us for is

06:27 anything that is a crossf functional project. For example, in marketing like launching a campaign is a cross functional project where the marketing team needs input from maybe product and

06:36 design. Uh they need uh to coordinate across uh third party vendors. There's a there's a campaign brief. There's a bill of materials. There's a coordination tax to get human beings aligned. people use

06:49 use Asana today pre- AAI like in for prei use cases to go ahead and keep those projects running on time or from a strategic uh operations perspective like figuring out a launch uh figuring out a

07:00 launch plan uh you know requires maybe a conbon board which has like a bunch of like timelines it has a lot of different functions that contribute to it maybe you need legal sign off do are you sure

07:10 you've gone ahead and done that >> so those are the kinds of use cases that people are using us for again in a preai Right. So it's sort of an internal coordination engine.

07:20 >> Correct. Now the interesting thing that the coordinate coordination engine brings to the table is that uh not only does it define who does what by when it also has a track record of how were

07:31 those projects completed in the past, what happened when that particular project went off track because of a particular issue. What was the remediation action that was taken? And

07:41 that kind of data is catnip for agents because agents can go ahead and look through that history of the work graph and get a really good sense for okay uh this particular type of campaign brief

07:53 document worked really well for the historical 2023 or 2022 campaign. This was the kind of feedback that the other human beings who collaborated on it provided. And so instead of having you

08:07 know each marketer on your team figure out the best way to prompt the you know AI chatbot of their choice whether it's cloud co-work or or or chat GPT and providing it with a bunch of like uh

08:20 document data or their own personal data you know when you deploy the campaign brief writer AI teammate inside Asana and you give it access to your work graph it automatically knows how to

08:32 crawl that and have the best possible answer that is hypers suited for your particular business, for the way in which your business has run historically. And you don't need to go

08:42 ahead and get every market on your team trained on all of these like new tips and tricks you're seeing where people are creating markdown files on their local machine and they're trying to

08:52 figure out the best possible way to not bloat the context window. We are taking care of all of that for you. Okay. So we've now moved from uh the vibe coding software to like what does an AI agent

09:02 actually do within a piece of software like ASA? >> Correct. >> And so this is way the way that you're embracing it is saying let's get agents

09:11 inside the software. Correct. >> So first just a definition question what is a work graph? >> So uh think about the way in which asana is defined today. uh you can create

09:21 projects, you can have a team of people who have access to the project. Within the project, there are tasks or work items that individuals complete. When a task is completed, the project moves

09:32 forward. The project could be part of a broader set of projects called a portfolio. There could be a company level goal for it. So this is the the data model behind Asana. So Asano is

09:42 powered by this sort of concept of helping teams get work done, helping teams coordinate, helping teams find this u this clarity from chaos and there's an underlying data model backing

09:54 it which we call the work graph and that's what has powered our human to human coordination features over the years and that's what we're opening up and we have opened up with our new Asana

10:04 AI teammates launch so that AI agents can leverage that workcraft for some of these like key outcomes I'm talking about where they get the right business context where they can learn from human

10:13 beings and how human beings have completed tasks in the past. uh where they can create this concept called shared memory where let's say if Alex you use one of the EIT teammates and you

10:23 know you tell it that oh this particular campaign brief or the risk you've found within this launch plan is incorrect as long as I also have access to that AI teammate and the same project if I use

10:36 it that AI agent will remember what Alex has told it and will make sure it doesn't make that same mistake again which is a big difference between the co-pilots and personal agents you're

10:46 seeing in use today. >> No memory there. >> Correct. There's no shared memory there. It it remembers what you tell it and if you go back and you ask it to do

10:53 something again, it won't make that mistake for you, but it will make that same mistake for me if I if I haven't ever coached it through that. >> Okay. So, let me see if I can get this

11:02 right in terms of what you're building. So, in ASA companies coordinate between departments to accomplish goals. >> And so, I let's just use the marketing example um because it's one I'm familiar

11:12 with. I started my career in marketing. >> Yeah. um before making sort of the reverse move to journalism which it's a whole different story but um in marketing what

11:22 would happen would be we would be assigned this campaign by a business owner that we would have to go create a marketing campaign for first thing that begins is the we sort of like have to

11:33 you know get that information from them and then come up with a creative brief >> correct >> and so is what would happen within asana that you start to build this process

11:41 within asana you're working across departments So, so you're going to work on and within marketing the most annoying thing is getting approvals. That's the way it sort of streamlines

11:49 the approvals. But could these AI agents be introduced in a way that like you start the product the project you put some information about it and then when you think about assigning who's going to

12:00 write the creative brief which again is you know it's this document sort of bible document that shows >> who is the audience we're trying to reach what's the benefit to them how are

12:08 we going to communicate it >> that once you get the product details in a sana you can use an agent to write the creative brief >> 100% so like the way you would kick it

12:18 off is uh you'd collect the initial sort of uh requirements and you put it into uh a task and you'd assign that task directly to an agent. >> So you could choose agent or person.

12:28 Correct. And you can and the agent would basically look past your campaigns and be like these were our successful marketing campaigns. Let's sort of create a creative brief in line with the

12:38 stuff that's worked in the past. >> Totally. So the agents have access to the work graph and they can look at your historical marketing campaigns, the historical campaign brief documents or

12:46 the creative brief documents. uh it can also do uh deep web search and analysis right so it can look across your public campaigns and your public stories and it will leverage all of that input to

12:57 create a research plan which it breaks out into subtasks when it's breaking out the research plan into subtasks any human being on the team in any marketer whether it's yourself or your peers who

13:08 who have access to that particular project can give it feedback >> can be like hey you know what you're looking at that uh creative brief you wrote in 2024 that actually won't work

13:18 because uh we had these issues with it. And so when you give it that feedback, it will in real time recalcitate research plan and update it and then ultimately produce a brief uh either in

13:29 a Google document format or or word depending on how you set it up. Uh and then the human beings can give it give it feedback on that particular creative brief. Um and again because it's running

13:40 in this multiplayer way, it means the entire marketing team can stay on the same page like no one is confused when they get that document about hey what was the prompt was the research plan

13:51 correct. They can go back into the task and see what it was versus pinging you directly and saying I don't understand how you came up with this because we agreed on X Y or Z. All of that is

14:01 documented in Asana. So it's reducing that coordination tax as well in terms of understanding why the AI output looks like this. And then of course there's approvals already built into ASA. So if

14:14 you approve of the creative brief, you can say approve. It'll go to the next stage. It'll go back to the the business department or the product department that asked for that, you know,

14:24 particular campaign in the first place and they can start taking a look at it. If you want they can also have access to uh all of the work produced by the AI agent. So they can also you know look

14:34 through the AI agents work and say yes or no or give it nudges and feedback and recalc. >> So what is the wisdom of turning over some of this mission critical work to AI

14:44 agents? I mean I think that like let's say you have a great creative director stick with this marketing example. >> You kind of want them to you know lead this positioning. Um, and if you turn it

14:55 over to AI, isn't there a risk that the AI will give you sort of like the average of averages, which is what it typically does with creative tasks? It like sees everything that's been done in

15:04 the world and sort of, you know, sort of predicts what the next most likely plan would be, right, in some way. So, where do you end up getting the differentiation if you turn some of this

15:15 work to agents? So the the goal is to reduce the coordination burden and the burden of uh looking through how you have done project projects and tasks historically to get to a place where the

15:29 creative director is then able to apply 100% of their bandwidth to taste and judgment. >> Okay. >> And so that's step one which is like

15:37 it's learning from this historical sort of task and and and creative briefs that your company has created. So again, it's not it's not sort of giving you the average of averages across creative

15:47 briefs in the world. It's highly trained and focused on how you all have done your messaging, your campaigns in the past. So it should be getting to an 80% or 90% good state from that and it's

15:58 it's not creating like AI slop. That's that's step one. >> Okay. >> The second step is because your creative director now has more time and they're

16:07 not sort of putting together the bare bones aspects of it. they have more time to focus on taste making and craft and they can go ahead and take that 80% good or 90% good output and put their own uh

16:18 sort of stamp on it, their own impression on it to take it to the next level. >> And the really interesting thing with this model within ASA is again because

16:25 you've got shared memory, whatever feedback your creative director provides, the agent will remember going forward. And so the next time it runs, no matter who runs it, it'll hopefully

16:34 get to like 90%. And then you're applying your taste and judgment on the 90% plus. And theoretically, you're sort of moving everything forward. Like the quality of your creative output, the

16:45 quality of your risk analysis for your launch plans, the quality of your remediation actions, everything gets better and better and faster and faster moving forward.

16:54 >> Yeah, I think this is an important point that the context window matters a lot. Like without injecting or including the right amount of context for an AI agent, you'll get the average of averages.

17:04 >> Correct. But if you just flood it with context of stuff that's worked uniquely for your organization and your use cases, that's when it starts to instead of giving you the average of averages,

17:16 give you something that's unique and specified for yourself. >> Correct. >> Yeah. >> So what happens to the creative

17:22 directors in this case? I mean I was speaking with somebody uh who was talking about like uh teleoperated robots recently and this person mentioned that

17:32 >> um you know if you go to robot teleoperation where you're trying to like have you know a person direct robots from you know some outside uh place they could like run four or five

17:45 robots at a time where it would typically take four or five people. Mhm. >> Uh and it seems like maybe it would take one creative director to handle, you know, four times the campaigns if all

17:55 this coordination burden is uh alleviated. Is that right? Or am I missing something here? >> Yeah, it it should elevate the people who are taste makers who really

18:04 understand the their craft to being able to do a lot more with their time, right? So they'll they'll just be able to produce more. They'll be to produce higher quality output. They they'll run

18:14 at higher velocity. Uh and so theoretically for a for a business if you're spending let's say $100 on human capital just be you know specific you will start getting more and more value

18:26 out of it >> right >> uh and it should help you become more effective uh more differentiated um and just get you get you you know uh

18:35 going faster. >> Yeah. >> I did like what Jensen from Nvidia had to say recently that if you're using AI for layoffs you lack imagination.

18:41 >> Totally. Yeah. I think the question would be the question would be like yeah do more you know like this is Jeban's paradox right like you should be able to go ahead and uh achieve more perhaps

18:52 like you're focused on one particular industry vertical in one particular geo uh you know take a look at your human capital and if it's like producing the same amount of output as $400 would have

19:04 gotten you in the past well now you've got like 4x the number of places the number of geos number of target audiences you can go after versus the existing one you were All right. I I do

19:14 hope that is the way that companies go about things. I'm >> I'm sure there will be some that try the other way, but they might end up falling behind the ones that don't. I do want to

19:22 call out one thing which is today I don't think customers are getting like in general as people have been uh embracing AI they aren't getting that level of exponential output

19:35 uh or maybe the right way to say it is they aren't getting the level of exponential outcomes from their investments because uh our thesis is that the models have gotten fantastic.

19:46 they are capable of doing deep reasoning and producing all of this uh you know complex logic that creates well formatted content or long uh faster uh PRs in the in the age of like code

19:58 generation and things like that. But because what we're seeing is there isn't enough uh context uh that's being used to go ahead and highly customize the outputs uh from these models. You're

20:11 ending up with this average of averages output to your to your comment. And the second thing is because you're getting faster, longer average of averages output, the human beings who are in

20:21 charge of taste making are actually slowing down, right? They're having to go ahead and look through reams of content and trying to figure out, okay, how do I apply taste? How do I apply

20:30 judgment? How do I elevate this? And so you're not actually getting the output that you want. you're getting um you're getting sort of this high velocity massive reams of text but it's not

20:43 actually moving your business forward. So this is the critical thing that from a head of product perspective Asana that I'm trying to solve. I'm trying to ensure that the output that you get

20:52 actually drives outcomes that the output is highly trained and highly optimized for your enterprises specific memory >> and every time you go and give that agent feedback it's getting better in a

21:03 way where every human being in your enterprise can leverage that and ensure that their outputs get better as well. So there's like two really really important things from a coordination tax

21:12 perspective that I'm trying to solve for which is okay instead of like a trying to uh leverage you know this 10x 100x thousandx rate at which this agentic output is coming at you and try to

21:26 somehow make sense of it. Let's make that agentic output highly spec specific, highly optimized and amazing for you in in your enterprise. And then whatever taste and judgment you provide

21:37 to it, you can do so in a way where your entire team benefits. And you're not having to go ahead and like have these like little notebooks and docs of like here's how to like prompt claude

21:47 properly or here's my personal like recipe for agents.md. It just gets better for everybody regardless of how technical they are. This is what the labs talk about when they say there's

21:56 capability overhang. It's basically like we've built the models now you just have to figure out a way to use it in a way that >> is productive.

22:04 >> Totally. Yeah. >> So this um the AI teammate launch is this is happening basically as we speak. >> Yeah, it's happening right now. So it's generally available for customers who

22:14 buy from ASA. Uh we've shipped with 21 pre-built AI teammates. These are uh AI agents that can do campaign brief writing or they can do uh it ticket deflection or they can uh take a look at

22:27 your launch plans and and sort of um look through those launch plans and help you stay on task and schedule. But of course, you can also go build your own um and it's as simple as like providing

22:39 it with a prompt that uh sets its behavior guidance. The really interesting uh part about those these AI agents is their connection with the son of Warcraft. So they start off with the

22:50 right context and this concept of shared memory or agentic uh or enterprise memory for these agents where they can remember uh what they were uh told or what they learned across human beings

23:03 utilizing them. >> So just talk to me a little bit about what you think this looks like in an ideal world like this all works out. How does that change people's lives? It

23:12 changes people's lives by taking away the busy work and not just doing that in a way where you're getting a ton more content that is mid that's average but you're getting a ton more content that

23:23 is highly optimized and specialized for the way in which you work in the way in which your company has set its mission and values the way in which your company runs and what your company level goals

23:34 are. So that should be elevating the the ability for the company to hit its outcome metrics. it's true like key results versus oh we shipped a lot of code but we actually didn't manage to

23:47 sell the product or we shipped like five new campaigns but they were undifferiated. So getting to that level of differentiation getting the key results elevating every

23:59 human team member to becoming a tastemaker. Those are the outcomes that I'm driving for. >> I'm very curious how these agents are onboarded. Like you said you can build

24:07 your own custom one. >> Yeah. If I wanted to build, let's say you hadn't built creative director, I wanted to build creative director. How do I sort of onboard that type of

24:16 experience in ASA? >> Absolutely. So the way you would do that is uh you would like type in a little prompt that says I want to build an AI teammate that is uh that is a creative

24:25 director. Uh uh the builder uh chat AI agent will come back to you and be like hey so what kind of um you know projects and portfolios do you want this creative director to have access to? Because

24:37 let's say you'd hired a real human creative director onto your team, you'd probably have an onboarding plan for them, right? You'd probably tell them to uh read these documents about the

24:46 company's mission and values and uh look at these projects and tasks for how the creative team has worked in the past. So you're provided with that context. >> Okay.

24:55 >> It will automatically then look through that and and ask for starter tasks. So it'll say, "Hey, can you assign these tasks to me because this will help me get better at my job going forward."

25:07 >> So yeah, >> it will like literally say, "I'd like to get working on these things." >> Yeah. So look through all the tasks in your projects and it'll find some ones

25:15 that are open and uh incomplete. It'll say, "Hey, these starter tasks look like good ones for me to start learning on the job." And you can say, "Yes, go for it." Uh and then as you use it, it it

25:26 keeps getting better and better and better with every run. You're not worried about like runaway AI that all of a sudden you say, "All right, you can go do this task and then the creative

25:34 director like tries to become the CEO or something like that." >> Well, again, like there's a lot of checks and balances in here, right? So, uh, you know, you you are in full

25:41 control of what task it picks up. Uh, it it runs through our standard approval processes. So, uh, it can't like create a bunch of like content or tasks for other people and start assigning workout

25:53 unless the human in the loop approves. Um, and so there's there's enough checks and balances to prevent something like that from happening. Um, or if you wanted it to happen, that's fully in

26:02 your control. Like you could say that, hey, I want to have an anatemate that thinks like my CEO and can actually critique me uh based on all of this feedback I've gotten from the CEO in the

26:13 past. So these are all like, you know, totally fine u use cases, but the human is fully in control. You know the humor is in control of what gets approved, what task get assigned. Uh if you

26:25 actually believe the project is not complete, you know, you can you can say so and it it'll just react to it. Yeah. >> How are you working with the leading model corporations like OpenAI,

26:36 Anthropic, and how do you choose what type of models to input? Yeah. So, uh, our research and development team is, uh, you know, closely embedded with the frontier model providers and we test out

26:46 all of the latest releases, uh, across Asana AI. Sorry, >> they're busy people. >> They're busy people. Yeah. Across Asana AI, we use both OpenAI and anthropic

26:56 models. In particular, for the uh, AI teammates launched, we have chosen uh, Anthropics Opus 3.6 model. >> Uh, and that's what we're launching with right now. That's how it's powered. uh

27:07 it uh did the best in our testing and analysis uh in our early access and beta time frame. Um and so we we're very excited about the capabilities that that that's providing um and you know looking

27:21 forward to like you know seeing where the model providers go next in terms of more capabilities, more reasoning and things like that. >> Yeah. How do you plan for that? I mean

27:29 you sort of you can only integrate the capabilities that exist today within these models but you see some of the advancement on the horizon and is it like we will rebuild it when the model

27:41 is more capable >> well uh the good news is the way in which Asana works uh the real value we're providing again is with the enterprise weight context and the shared

27:52 memory >> and so that becomes instantly more valuable as the reasoning model gets So the things that we like the things that we provide as differentiated value

28:04 those are things that don't need rebuilding because that's like input context. So that's like one interesting angle. The second thing is uh we're like maximalists in our perspective which is

28:15 hey if the model can't do something today like let's say I'm making this it actually can like it can uh opus can go ahead and create really good HTML previews of what your uh updated website

28:28 should look like if the campaign launches. So you can tell one of these agents to create a mockup and it can do that. But let's say it didn't do it right now. uh our assumptions from an

28:37 R&D perspective is that uh whatever uh skill the models lack today they will have in the future and so to assume that that is coming and to see like how would we support the right frameworks and the

28:52 right human experiences around that uh should it be there uh and that level of like maximalist thinking is is good in this day and age because you're seeing the advances come every like four to 6

29:03 weeks >> you know as the models get even more improved. Do you be does the differentiation that Asana have become more or less important? Like uh hate to

29:15 use the buzz word, but like let's say it like reaches AGI and can sort of like seemingly do everything a human does. >> Yeah. >> Where does that leave us?

29:23 >> Uh again like I think uh there's some laws of physics here, right? So there's like a law of physics around context windows and what it can learn and what it remembers. And so we are providing

29:34 real hard like computer science benefits uh across those uh those vectors. And so I'm very confident that like even if the reasoning capabilities get better, there's still going to be extreme value

29:49 out of the context graph that we provide through our work graph as well as the shared memory concepts. >> Okay. So it's nice it's nice to have a head of product here cuz I can ask you

29:57 some of these like nitty-gritty model questions. Yeah. Um so you mentioned that you use open AAI and anthropic. Um I guess like one question would be why not just use COD? Cloud is seemingly

30:09 built for work. So why spread across two models? >> Again like we need to take a look at like how uh you know this technology is evolving over time. uh we are not using

30:20 openAI right now for AI teammates but we are using it in other parts of Asana AI where those models have uh been proven to be either costefficient or highly performant for those use cases within

30:33 our AI studio capabilities or straight AI chat capabilities that we give away for free. So there's a wide number of applications of AI, right? There's very basic things like AI summarization or

30:44 ways in which you could just chat with Asana and get insights from your personal work and activity and so on so forth. So there's a large number of use cases and we have to ensure that we're

30:56 doing the right thing for our customers not just from a performance uh not not just from like a raw horsepower uh capability but also from the perspective of like performance time to return the

31:06 result uh deterministic versus nondeterministic workflows uh and cost right so uh so when you factor all of those in there's a there's a use case for uh for multiple models uh but again

31:20 to reemphasize the AI teammates launch the teammates themselves are being powered by cloud >> openai has been on this big enterprise push they're really trying to work hard

31:28 to win enterprise business are you seeing improvements there is do you think they have a chance to challenge for that type of business >> uh they're very well funded they are

31:37 talking to us a lot um so I mean like uh it's very hard to predict who if there's going to be a definitive winner I don't think >> I don't think it's possible to call any

31:50 of that at this particular point in time. So I look forward to seeing their advancements going forward. Yeah. >> No open source. >> Uh right now we're not using any open

31:59 source models. Um and but again like I think um you know I think looking forward to the future we're you know we can consider them at some point in time they might become good enough where uh

32:11 for certain payloads it makes sense. Um but I I would say the Frontier Labs products are are quite differentiated in in this in this particular phase of time you know in 2026 March when you're

32:24 talking. Yeah. >> You know that's interesting cuz I once heard this progression where it was basically like you start with open AI because that's the most common one then

32:33 you make your products interoperable so you can use any model within them and then you graduate to open source so you can customize it more. So have there been advances on the customization front

32:45 from the frontier labs that have allowed you to build on top of them versus open source or >> it's a good question. >> What has happened?

32:51 >> Um so again like uh our sort of maximalist thinking is that the frontier labs are going to keep innovating in the level of reasoning and capabilities of their models. And so trying to uh create

33:11 these customizations or adding our own token weights is not a good idea and is a waste of R&D resources at this particular point in time because of the rate of innovation that we're seeing.

33:22 Like why not just trust that they will keep innovating in in their space with the funding they have and the quality of research talent that they have >> uh and then just basically evaluate

33:33 which of the ones work best for our use case. um my perspective might change over time, but like in this day and age, I'm seeing like enough velocity coming out

33:42 of them that it doesn't make sense to try and create like a separate path where I might just fall behind. >> That's amazing because um you know, the conventional wisdom is that the the

33:52 Frontier Labs are like 3 to 6 months ahead of open source, but apparently what they're doing is innovating so strongly that doesn't make sense to go. >> Yeah. And three to six months matters,

34:03 right? If you if you create a fork and you're always 3 to 6 months behind >> what your competition could be doing, you know, like >> uh there'll be other companies, I'm

34:12 sure, who are thinking about some of the challenges that uh we are addressing at Asana. Uh I don't want to be three or six months behind them. That'll be a big problem for me. So, I'd rather stay at

34:21 the edge in terms of model capability and then ensure that all of my R&D resources are dedicated towards building the differentiation that we have with the human AI coordination experience,

34:33 the ability of the Warcraft to provide more context in a way that doesn't blow the context window, the ability to do shared memory, better integrations, better skills. It's like those are the

34:44 places where I want to stay laser focused on versus trying to like outsmart the the frontier labs. >> Smart. Uh okay, a couple questions before we end. What do you think people

34:54 misunderstand about AI agents today? >> I think that the number one thing people misunderstand is um uh the amount of work required to ensure that they provide great output and great outcomes.

35:08 Um, it's easy to see these demos and be like, "Oh, wow." Like, there there's so many ways in which I could have an AI chief of staff and it's going to like be amazing and and take care of all the

35:18 busy work for my day. In order to set that up and get it right in a way where you can actually trust it, it's secure, it's performant, uh, it has the the right kind of context so so it doesn't

35:30 generate AI slob is tricky. And so that's the reason why like we are entirely focused on that side of it which is hey let's ensure that uh the amazing advances that are happening in

35:42 the model space can actually be used for real business work in a way where the outputs drive real outcomes versus just velocity of noise. >> Okay, last one for you. Just like think

35:55 about the future a little bit and your in your product hat so to speak. Do we have one like master agent in our lives that like will like handle some of our personal stuff, our business stuff and

36:07 you know we just like set it out to like run these other agents or do you think we're like you know going agent to agent in different interfaces? >> Um my personal philosophy is like you

36:16 probably want like different agents that are great at doing different things and that actually have some separation uh in their memory. Uh because there's probably a very complicated challenge

36:26 where like let's say your agent is handling your personal life as well as your work life. How do you know for sure because these are non-deterministic workflows.

36:34 >> How do you know for sure that it's not going to end up leaking information one way or the other? >> Really don't want those to mix. >> Correct. Yeah. My wife's a journalist by

36:42 the way. So like uh in some ways like uh there are some specific Asana conversations that I personally have to keep like abstracted away from her because that is you know material

36:52 non-public information. >> Yeah. >> Uh and that's easy for me to do as a human being because I know like in the you know based on the context what to

37:01 share and what not to share but um again just like you know how do you know for sure that an AI agent will get that right every single time? I think that might be tricky and perhaps like

37:11 separating them out where there are multiple agents is the is the best course of action. >> Yeah, your agent might or her agent might be optimized to get her scoops.

37:19 >> Correct. Exactly. Got access to >> you could get in trouble. Yeah. >> All right. If people want to learn about Asana's AI teammates, where do they go? >> They go to asana.com.

37:27 >> Okay. It's all up there. Yeah. >> All right. Arnob, thank you so much for coming on the show. >> Thanks for having me. Yeah. >> All right. Thanks so much for watching

37:35 and we'll be back on the channel with another video soon.

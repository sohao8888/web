视频链接：[https://www.youtube.com/watch?v=NvHz_esnSJc&list=WL&index=1&t=16s&pp=iAQBsAgC](https://www.youtube.com/watch?v=NvHz_esnSJc&list=WL&index=1&t=16s&pp=iAQBsAgC)
视频发布时间：2026-04-03
频道名：MIT Schwarzman College of Computing

## 转录内容

00:01 So for for the next uh for the next event uh uh for today so we're going to have a uh uh discussion slash chat slash uh interview uh with uh uh with varun uh moan who is one of our alumni who uh uh

00:22 graduated uh here a few a few years ago and has gone on to do some great things in the world of uh of AI for uh code. So maybe why don't we start just uh telling us uh a little bit of uh just your

00:37 history of how you went from uh you know being a student here at uh MIT to uh uh driving the uh driving the development of the anti-gravity tool at uh at Google.

00:52 >> Yeah. So I'm happy to happy to give like a a pretty um quick summary. So I'm originally from the Bay Area. Uh I actually started the company with someone with another MIT alum uh that I

01:04 knew since since middle school. So I started a company called Windsurf and later that that um a lot of the folks from there ended up going to Google afterwards. Um so basically went to MIT.

01:15 I I did a lot of systems work at MIT actually like I did very little machine learning work I would say at the time. I think computer systems was like my big passion. Um I did a lot of work at POS

01:25 worked with like Fron uh and Rob and and also Sam Madden um on on database stuff. I did my super Europe up and then and then my mange with Sam Madden actually. Um I think at MIT I I just liked

01:37 performance engineering a lot actually. I was a TA for 6172 which is the performance engineering class um two times. Um and and really really enjoyed enjoyed that work. Um immediately after

01:47 graduating from MIT I joined a company called Neuro where I worked for four years. It was a self-driving car company. Um, it's interesting in that like every five years it feels like

01:57 everyone thinks robotics is going to make the next huge breakthrough. Um, and you know I guess I guess you know in 20 2017 it seemed like robotics was going to make large strides. I think we were

02:08 still a little bit early there like Whimo is just now starting to hit a good amount of scale. Um but but that was because of I guess 15 years of work before then right? So I worked at Neuro

02:18 for for four years. Um, I think the the biggest feeling that kind of like bothered me was it was taking quite a while to productionize and the reason for productionization was it was just

02:27 there's a lot of edge cases for self-driving cars. Um, and I guess the big workload that we felt was going to be big. So, a lot of the people that that we worked with at the company, it

02:36 was originally called Exafunction. So, actually the company went through a couple pivots before even getting through getting to to Windsurf. But originally we felt that GPUs and

02:45 accelerators were going to be very powerful and the the the sort of workloads that we saw in autonomous vehicles we thought were going to be the huge workloads. Um so we built a GPU

02:54 virtualization system and accelerator virtualization system which basically allowed workloads that would previously run on accelerators to allow them to run on CPUs and we transparently offload the

03:03 compute to remote machines, remote accelerators and if the accelerators died, we'd reconstruct the state of what was on that machine or another machine. And we ended up doing this for a couple

03:11 years. Um what ended up happening was these autonomous vehicle companies ended up kind of going bankrupt. I mean I'm being very honest with you in terms of uh the problems that startups face and

03:21 along the way we realized hey it's probably not a good idea if you build a company and while you're building the company the start the companies you are selling to are are going bankrupt. Um

03:29 like this isn't a good property. So I guess at the time like all of us were programmers and we really enjoyed uh kind of like software engineering and we thought AI would fundamentally transform

03:37 many many industries right. Um, and we were early adopters of GitHub Copilot. Um, so we actually pivoted the company in the middle of 2022 to what was called Kodium. Um, I don't know if anyone here

03:47 has even heard of that company. Uh, we basically built we trained our own autocomplete models from scratch. And I guess this will tie into the future of where I think the space is going, but it

03:57 started with just autocomplete. We like took out a bunch of TPUs and we actually trained an autocomplete model. And we also trained our own chat models too. We were doing like basic kinds of like SFT

04:07 DPO on top of models to basically get them to chat. And the idea was we sold them to enterprises and self-hosted the capabilities inside their VPC for companies that didn't want to like send

04:17 their code outside. We gave them AI capabilities and we had like hundreds of thousands of users using that product itself. Um but I guess the the big worry for us was was kind of like where where

04:27 I'm going to get to which is that the capabilities were improving so quickly. So while we're doing that, Chad GBT launches and then we see the writing on the wall that like probably autocomplete

04:37 is not going to be the thing that people are going to be thinking about in a couple years, right? This is probably not it. And in in the beginning of 2024, we assumed that hey, the models would

04:46 have agentic capabilities. In other words, the models would be able to take actions themselves. At the time, the latest and greatest technology was for the models to basically be able to

04:55 slightly chat with you intelligently. It was like a personalized Stack Overflow. That was what you were getting at the time, right? But instead, we thought the models would be able to actually take

05:03 agentic actions on your behalf and we bet we kind of like bet that the system would be able to do this and that's why we actually built our own ID which was windsurf, right? We built our own ID

05:14 because we thought the surface would need to get reimagined if agents would need to be modifying your code, right? So, we forked VS code and built built an ID and we were the first kind of agentic

05:22 ID. Now, after that, this became a very obvious decision and many other products started uh started doing it. But I guess the the biggest takeaway for us was we thought the capabilities of the models

05:32 would go through a like this crazy exponential curve, right? If today it was autocomplete and tomorrow it was chat and the next day it was agents probably in the future what's going to

05:40 happen is people are going to be managing many tens of agents in peril um all the while like you know the the developers going to spend less and less time looking at code and obviously we

05:50 went through this process of of of moving over to Google like the core R&D team ended up moving over to Google and um and we built this product anti-gravity that basically summarizes

05:59 this right like like developers are spending we have an agent manager on the product and developers are spending more and more of their time purely in the agent manager multipplexing between

06:07 agents rather than even going into the ID like the ID is becoming a thing that people are using for debugging rather than the default state um right in a lot of ways. So by the way there are a whole

06:17 host of other problems that come because of this because imagine you have so much vibe coded software and and people cannot even understand what the code is doing. So there are a whole host of

06:25 problems but I will just end with one thing before before turning it back to you which is the the kind of crowning moment for me in the last couple weeks was Lionus Torval's recently actually

06:34 like built a repository and recently he said he vibecoded it with uh with with anti-gravity. So he actually like built some his most recent git repository he did and I guess the the thing is is not

06:45 like a flex that said hey anti-gravity is a great product. I think it's more so like where is the industry going? You have a person that was a staunch advocate that like I need to use Emacs,

06:54 right? You will never see him using an ID and he skipped autocomplete, he skipped chat and now he's directly using anti-gravity to vibe code applications, right? So if like the best programmer of

07:04 all time is doing this, we probably can see where this is going. Um, so yeah, I'll just I'll just kind of end with that. >> Thanks. No, this this is really uh this

07:13 is really uh uh interesting and you know, maybe to to build on that. So uh you know I would say even over the past six months right we've seen this uh uh dramatic improvement in the capabilities

07:28 of uh of these models right and of the the programming tools more more broadly and and I wonder if you have some uh some insight as to you know what has gone into that right is it simply you

07:41 know the models got better and everybody else is just uh uh cruising on the the rising tide of of better models or uh you know what has it what has it taken? >> Yeah, I think you know what people will

07:54 be very surprised by is it's it's not a simple answer but I think the data kind of is is is maybe helpful. So if you were to if you if you go back to early 2024 there was this kind of like this

08:06 product Devon was mostly like a Twitter post that hey we're going to be able to do uh software engineering is automated entirely that was completely overblown and and for for the most part but the

08:17 key the key benchmark that they took was this benchmark called SWEBench okay and people here might have heard of Swebench but the idea here is this is you take you it's a 500 problems you take some

08:28 popular repositories and issues there and you actually see if the model is able to solve the issue, right? And the way you solve the issue is you you take a look at the code that was generated.

08:36 You have a golden unit test and you see if the unit test passes, right? And at the time people were very excited about 15%. Right? Now the models have gotten to north of 80%. And I'm very sure by

08:46 the way like even of the north of 80%, some of the reason why it's not even higher is because the problem is it's of illpost, right? It's a vague problem statement. You'll actually look at some

08:56 like a couple examples of sweep bench. unit test is even not a good unit test. So there's some there's some weird stuff here where fundamentally like like we have cracked this we have cracked this

09:06 benchmark and I think there's a couple reasons why. So if you were to just look at like just the the LLM space right now, there's this whole thing of pre-training, right? And pre-training

09:15 you would think it's only scaling, right? Like we are scaling it and 100% every lab is scaling. You can see there the capex spend that's going into this. The amount of [clears throat] spend

09:23 going into pre-training is increasing. But also algorithmically we are making large progresses in every single one of these axes. Pre-training, post- training, like every flop is taking you

09:32 further than it was the previous generation. you're seeing something that is like much faster than Moors law even in how quickly how much efficiency you're getting from every flop and and

09:41 the terminology used in the labs is computer efficiency right which is which is what is one flop getting you today compared to what was one flop getting you like a year ago and you know

09:50 obviously we have folks like Nom Shazer who invented the transformer at least at Google deepmind that are just spending all the time thinking about how do we get maximal intelligence for the amount

09:58 of flops that we sort of have so that's like on the pre-training side on the post-training side you can imagine the task complexity is also increasing and the amount of

10:06 reinforcement learning that's happening is also increasing, right? Um like if you were to think about it, pre-training you it's like a form of imitation learning. You're kind of letting it

10:13 memorize the way humans think. Um and then with reinforcement learning, you're giving it real cases and real examples. And as you ratchet up the task complexity, the model's coherence is

10:23 increasing, but there's like a lot of other details that need to get done right correctly, right? Because these agents themselves like there are so many problems that need to get solved that

10:31 are not just like increasing scale. I'll give you a a simple example here. Let's say you want an agent to like to migrate an entire codebase from one language to another, right? This probably takes many

10:41 tens of thousands of steps and the context lengths of these models are not long enough to do this. So you need to come up with mechanisms whether it be sub aents, context compression, all

10:50 these other things that need to also make improvements to hit this. So if I were to say this, there's like many many exponential curves. There's a pre-training exponential curve, maybe

10:57 there's a post-training exponential curve, there's a tool use exponential curve, there's an exponential curve for agents and and all of these are sort of getting written up concurrently,

11:07 right? So I I know that that was not like an a clean answer, but that is the fundamental reason why in the last like year, I think ever since it was obvious and I think in middle of 2024 that

11:17 agentic capabilities of these models would unlock tremendous amounts of value and I do feel like Windsor was one of the first applications to kind of do this. um it has become an obvious sort

11:26 of line uh direction that all the labs are pursuing to kind of like continually improve. >> Yeah, I know and it makes sense given the scale of investment that is going

11:35 into this, right? That it's not going to be one simple answer uh you know one small trick that uh that makes everything uh treat it >> exactly treat it similar to what was

11:46 going on with Mo's law with Intel right with the whole Tik Tok phenomena. Maybe it's like much more compressed because obviously you can make a lot of these improvements in software, right? You

11:54 don't need to tape out a brand new chip sort of every time, but it's it's a bunch of things that happen, right? You you know, maybe you shrink down the transistor, but not only do you do that,

12:01 the ALU itself, you you get some optimization there, right? So, it's it's like a you're stacking on many many gains to to see each improvement. >> So, given where we are today, uh what do

12:12 you see as the the biggest gap, right? the biggest open problem that that we really just haven't uh got a clue how to how to solve and uh you know might be cracked tomorrow but also might be uh

12:26 you know we might be discussing it uh uh 5 years from now still trying to figure out how how to get around it. Yeah, I think I think one of So there are maybe a couple things. Let's go

12:37 maybe one thing is like just very tactical. I'll give you one thing and then I'll also say one thing that you know I I've spoken to Demis a good bit about this is um is his perception on

12:46 like kind of what AGI actually is and why we're actually you know I think some companies like anthropic try to make claims that hey we're a year or two away but probably actually you know the the

12:54 the more uh kind of like commonly held view by folks like Demis maybe like 5 to 10 years away right in in um which by the way already feels very aggressive right like let's let's imagine what that

13:04 actually means um but okay so first thing obviously for the models is It doesn't feel like this model learns the same way someone like you know Isaac Newton did to make progress and what I

13:14 mean by that is like first of all there's this ability to kind of like make deductions and then from that almost take those deductions and the next day wake up and use that to pursue

13:25 it to make much much deeper sort of insights right this idea of continuous learning right like um like it it feels like we don't have this right the models can go on and on but the underlying

13:35 value function of the model or the the the knowledge of the model has not been increasing. Now you could argue maybe the current paradigm already can support this, right? Like I'll give you some

13:44 examples. Maybe all it takes is the model needs to get very good at distilling its knowledge and retrieving it very efficiently. That's maybe one approach you could you could possibly

13:51 take. Another approach you could possibly take is maybe as the model is kind of operating, it actually does need to change its own weights, right? Maybe the weights of the model actually do

13:59 need to get changed dynamically. Um maybe the right way to operate it and maybe an example is let's say I'm a student at MIT versus I'm a student at Harvard. Maybe this is not the best

14:09 example but let's say I'm an engineer at at Meta versus Tesla and I work for Zuck Mark Zuckerberg and instead I work for Elon. Probably the way I succeed in one organization is different than the way I

14:19 succeed in another one. And maybe you could read some some dissolation, but probably actually there's some internal like dis like value function of the model that needs to fundamentally change

14:28 if I'm a a Tesla employee versus I'm a I'm a Meta employee. I'm just giving you an example here. And and I don't think I don't think anyone has like fully cracked what that actually looks like.

14:37 And I think at a higher level sort of what what Demis' sort of viewpoint on on on what feels like we don't have is how do we make the model ask the hard questions, right? Like right now it

14:47 feels like the model can make deductions that that that are complex but within the realm of like what we understand, right? Like I never look at it and I'm like, "Wow, that's like a crazy

14:56 deduction you kind of made." Um there's I'll give you an example of something that it's like already amazing at that I've like sort of been telling the team we no longer need to do. But that jagged

15:04 form of intelligence where you you have like superior retrieval and you can make the deductions that all of humanity has made but actually ask the one one like most important question to solve

15:16 humanity's hardest problems. It doesn't feel like we are there yet, right? Um and I don't know I you know obviously all of us are thinking about this all the time but but this this could be

15:24 another breakthrough that that needs to happen for that. So one of the things about uh you know one of the big questions that uh I think

15:35 we're going to be contending more and more in the next few years is how to collaborate with these uh with these tools right and uh you know I think the the tools themselves have made a lot of

15:46 progress in terms of how they integrate into our workflows right and everything from uh you know monitoring our uh GitHub repositories ies to you know now even uh integrating with Slack right and

16:01 and reading your uh your messages but you still don't have the sort of uh uh relationship that you can have with a colleague right who you know you go out uh for uh drinks after work and you

16:15 build up this shared language and these shared assumptions and it makes communication uh uh efficient right uh I don't know I I'd be interested in hearing your thoughts around this

16:27 question of of the interaction model and and what do we need to do to actually get the the models to the point where uh we can collaborate with them in a more uh human way or maybe this is the wrong

16:40 question right maybe we should think about it >> no I think it's the right question which is like what is fundamentally the reason why like the models are not able to even

16:48 do um simp like simple tasks sometimes and I think actually like what you said was a little bit of the reason you know there's coffee room conversations between people and there's so many

16:58 conversations that are not actually like within the realm of what the models actually see. Not to mention actually even if the models can see it, there's a such a large space of things that might

17:08 need to get retrieved that that itself is like a a fairly complex problem. Granted, we could we will solve that problem. Like I don't think this is an unsolvable problem. Like I think with

17:17 with large with enough reinforcement learning and enough sort of training, I think this this kind of problem actually can be solved. But this idea of not every piece of information is actually

17:26 distilled within knowledge that it has access to I think is like a big piece here. I think what's going to fundamentally happen is in spaces where AI is critical in improving

17:35 productivity, people will spend more time making sure that the model has the information it needs. I'll give you an example of something I was trying to do recently. So a lot of folks we've gone

17:45 through the process of trying to automate work, right? automate tedious work on the team with with anti-gravity, right? Anti-gravity um and and automations, right? Around the

17:56 anti-gravity agent and and what we found was we were just like, okay, fine, there's a Google doc of of how you can like run our evals, right? And we we use this Google doc. The problem is the

18:06 Google doc is actually ill specified even if you have the Google doc in the entire codebase, right? you actually need to work with the like you actually need to work with the model to to create

18:15 a more machine readable Google doc because there are parts of it that assume conversations that we've had that have not been recorded anywhere right and I think that effort that work for us

18:25 to do that the the sort of work we do to do that is valuable enough now since it's going to eliminate a lot of boilerpl we're doing on the team right [snorts] so we will do that upfront work

18:36 so I think what's maybe my point to that is if the work is very important. I think organizations will make the effort to make sure the agent has the information here, right? It's it's too

18:47 valuable to not do this, right? Like we have folks like I don't know, I'll give you an example for the eval system on why it's so valuable. You know, the eval system will break for a variety of

18:55 reasons at at the scale it's operating and and I don't like you know we have people that babysit this, right? And it's by the way the reality is like there's so much more we would want them

19:04 to be doing. This isn't a thing where like we're trying to cut the size of the team. we're actually only hiring more people on the team, right? Um, but I think I I don't know if that answered

19:12 the question there. I think, you know, if the value is there, I think we will find ways to get that information to the agent, right? And I don't I don't know how dystopian this future looks, but it

19:22 does feel like some of these companies like OpenAI and and so on and so forth are trying to also build devices to to kind of like listen to everything. Now, I don't know I don't know exactly the if

19:30 that's a form factor people like, but you know, some companies are trying to solve this even. [snorts] >> Yeah. No, I mean I think we have uh you know there's uh um we have evolved to

19:42 generally uh like interacting with fellow human beings in a way that uh uh you know interacting with a box doesn't quite uh tickle the same uh the same nerves. Uh but uh but yeah, I mean I

19:55 think if uh if I understand what you said correctly, the uh uh you know this this question of uh of communication and getting the right context is is a big one. And you think that in specific

20:10 domains that are sufficiently valuable and important, you can just train that background knowledge into into the model. But uh especially as you move to more niche domains or newer domains,

20:22 there is always going to be these uh uh you know in some ways the model is always going to be working at a disadvantage, right? It's uh like the the guy who never gets invited to to the

20:34 uh water cooler conversations. >> Exactly. I think you know some spaces that where this is just fundamentally a lot harder is you take something like the hard sciences, right? Where the

20:44 iteration cycle is a lot longer. This is actually like you know the reason why you can do all this stuff is in in software you're much more willing to just do do brute force you can just do

20:55 10 10 times as many things right now granted if you're hardware limited that's that's true but in a lot of ways let's say it's running a unit test until you can just the cost of trying

21:04 something is very low [snorts] right and the interesting thing in the hard science is the like that means the value of your intuitions it's still high but it's less valuable because brute force

21:16 exists, right? So, and and not to mention the models are getting smarter and and I think anyone that thinks the models are just brute forcing now, it's they're putting their head in the sand,

21:23 right? Like the intuitions of the model are also improving. But in the sciences, there's so much information locked up in the head of the of like the the scientist and the cycle time is high.

21:33 Like the cost of like using up the lab for like the next 3 months is high like you don't want to just randomly do it, right? So some of these this is why like different domains will have different

21:44 times at which AI is going to kind of like help a lot. I think in the hard science it's going to take longer, right? And that's why we're seeing so many gains in like the bits world rather

21:52 than the atoms world. >> Yeah. No, that uh that makes sense. Now you know we in the in the academic side right traditionally of our our job has been a to produce research and to you

22:09 know ask uh questions that uh you know maybe are a little bit beyond the horizon of of industry but also to train students right and to make sure that that they know what uh what they need to

22:21 know when they go out on the workforce and uh uh to to be productive And uh you know recently there has been a lot of uh conversation around how both of these might be disrupted by uh by AI right and

22:38 so I'm curious how you see from sort of your your side in in industry uh you know on the one hand uh the the health of of the flow of uh of uh uh uh insights and results uh between industry

22:56 and and academia as well as uh you know maybe the the perspective on uh you know what uh uh what should the students coming out really be uh uh knowing? >> Yeah. So I guess we're still hiring like

23:11 new grads from MIT. So I think uh I think that hopefully that that kind of um explains that we're not saying hey like you know people coming out of college are not useful anymore. I think

23:21 the expectation though has fundamentally been that you're going to be like much less productive unless you use these tools, right? I think this is not like a very interesting insight. Um, people

23:30 that understand the fundamentals and can use these tools are much much better. Like I think you can clearly tell when you talk to someone if they both understand the fundamentals and they're

23:39 using the tools as a way to accelerate accelerate their work, right? Um, I think I think it's uh it's it's clear to to me and I think it's it's basically like what I would just say is like the

23:50 playing field has has basically just shifted up, right? Obviously, you are no longer on the playing field, I think, if you don't use these tools anymore, but the person that was like very

23:58 knowledgeable before these tools is also like strictly better than the person that was like not knowledgeable and using these tools now. I don't know like that that should be like um I I I don't

24:07 know if that that sort of answers that um that point there. I don't think this is a case where uh where people should be stop should stop learning the fundamentals of kind of computer science

24:16 right because I think the fundamentals of computer science is just the fundamentals of logic right like in in a you know I explained a world in which you're vibe coding everything like if

24:24 you build a critical application anywhere you're going to need to understand the impact of the software you do right even when you talk to AI very quickly you will notice that

24:32 sometimes it makes trade-offs that don't make sense once again because actually it doesn't have all the information in your head and this isn't like a bug. It's like there are trade-offs that were

24:42 made in a coffee room conversation and and and you actually need to optimize for these trade-offs. It's actually hard to specify every trade-off under the sun. There's like some trade-offs that

24:50 your coworker explicitly thinks that you understand, right? Like when they say, "Hey, let's rewrite this to use X, Y, and Z." They're not meaning, "Let's rewrite the entire codebase," right?

25:00 They're probably just meaning like a a small chunk of of of software kind of needs to get rewritten, right? in that case. Um, so I would just say like yeah, I mean the the the students should be

25:09 like definitely be using the tools. I guess this is a hard thing from like a PA standpoint like I guess this is a this is a that's a sort of a tricky question on the research side. I mean

25:18 this comes back to the whole jagged intelligence piece. I don't think the models are in a state right now where they are actually doing fundamental research very well right like they are

25:27 actually not able to do that. um a granted I think a lot of research work again is is probably like uh is probably requires a lot of boilerplate work. So I would assume researchers are actually

25:37 actually able to be also a lot more efficient with with AI. So um yeah I don't see I don't think this is going to create a lot of a lot of changes in in academia. Maybe this is like a

25:49 controversial take. >> So maybe building also on on some of these. So uh you know I think we're already seeing a lot of uh change in how uh you know the typical developers day

26:03 looks like with uh with some of these uh tools, right? Uh uh you know extrapolating maybe five years down the road. How do you see uh you know the the typical developer uh workday uh being uh

26:21 different from from what it is today? Yeah, I think it's probably I mean the expectations on productivity is just going to be a lot higher in terms of like the amount a singular developer can

26:30 do. I think this person is managing like maybe [snorts] maybe somewhere on the order of 10 to 20 agents in parallel and the reason why they're able to do that some agents are very very long running.

26:40 We do need good interfaces to actually communicate back with these agents. Um when the agents do intermediary work, right? It's probably a bad idea for an agent to go and do work for three months

26:48 and and and you know I mean this is like any any report, right? you have a report and you have a team of people and you do work for 3 months. If the work that's getting done at the end of 3 months is

26:55 something that you don't understand and thought was the wrong direction, you probably want to check in with what's ultimately happening. But yeah, I think ultimately like the job of a developer

27:04 is to have taste on what needs to get built. This is by the way the hardest problem. I think this is actually why even though AI is accelerating software development so much, it isn't that

27:13 companies are getting faster at the same speed. It is actually a complex decision to decide even what to build. I'll give you an example. Let's say I'm building a user application and the user

27:23 application faces some users. You could build like a thousand features but there's a limit to how many features the user can even consume, right? There's some like there's some

27:32 bottleneck there and then there needs to be some taste that actually the three features I do need to build should be built like this and the trade-offs for those should be X Y and Z to make the

27:41 user experience good. You have some number of shots on goal. like it kind of becomes like the hard science exper hard science uh kind of case all the way uh all the way there but that is what

27:51 developers are spending more time thinking right when I think about what software development is it's like maybe three things it's like building it how should I build it and what to build and

27:59 I think people are spending much more time thinking about what should I build right um and I don't know if this is like fundamentally different than in the past like I think you know let's go back

28:08 to when people are writing assembly you know the the way people build and a bunch of design decisions they made about let's say even doing networking across machine was probably like people

28:17 were taking a lot of time doing this and now people in Python just do like socket. Right? So I think this is just another level of abstraction on top of that and

28:27 people will be thinking much more closely to what is the what are the problems that need to get solved to make my technology succeed. >> Thanks. So I think it's a good point to

28:39 maybe open the floor for uh questions from uh from the audience. Uh I don't know if you can see uh the audience uh from from where you are but uh so we uh uh yeah let's uh let's open the floor.

28:58 First of all, very proud that two of the best AI assistant coding tool are designed by uh MIT alum rings and cursor. Um be part of the community. I would like to know um after you join

29:11 Google um you know Gemini has been selected by Apple to be the default model and then also collab has been widely used in the academic world. what's the next breakthrough or product

29:24 features you guys are thinking of uh in terms of the co- assistant tool uh at Google level and what kind of for example is more better human in the loop better product design or better backend

29:38 system that can integrate everything. Thank you. Yeah, I think I think the mission the mission fundamentally like I I think a lot of it is the model, right? Like the

29:47 product the way we think about products at Google at least like on on our team is and we thought about it this way at at at uh at at at Windsor 2. It's how does the product maximally showcase the

29:58 capabilities of the model, right? And the reason why we think about it that way is because every generation as the model improves, if you don't think about it that way, a lot of your product needs

30:07 to get deleted. And I'll give you an example of this just because I think I think people might remember and I think cursor actually had some features here before the agent capabilities sort of

30:16 became very popular but they had a feature called like at docs where you can at a directory right you could actually do the at mention of of the directory [snorts] and what happened is

30:26 that was very useful when the models actually couldn't like do anything agentic but then as the models actually ended up getting agentic capabilities the model was able to read documentation

30:35 itself it was actually much better to have the how to actually browse the web because at least that was up to date versus indexing a particular version of the of the documentation. So what I

30:44 really want to just get at is the way we think about products is how does it maximally showcase the capabilities of the model. Now, where are the model capabilities going? The model

30:51 capabilities are going much more multimodal. Actually, if you look at a product like anti-gravity, it can even actuate the browser. And we think if the model is supposed to automate a lot of

31:00 work and tedious work that developers and knowledge workers do, developers and knowledge workers spend a lot of time in the browser because they might be using a code review tool. They might be

31:08 looking at logs, they might be looking at at many many systems that only exist outside, right? Like even drive and workspace, right? And and also also knowledge workers and developers. The

31:18 reason why I'm I'm distinguishing knowledge workers and developers and why I'm calling it something uh the the same thing is I think I think automation and bu and using code is something that

31:27 everyone is going to be expected to be able to create right as part of their work right like code is like the most atomic unit of automation right in some ways and the fact that anti-gravity can

31:36 generate code just means it can automate things on a machine that's like all it really means uh down the line but imagine okay if I was to be very concrete we're going to be able to go

31:45 like much more powerful on more surfaces that includes the browser or the operating system. The model is going to be able to be coherent over many many more steps and it's going to its

31:54 reasoning is also going to be able to be much much stronger over over many many data sources. So I know that that sounds like that sounds like kind of crazy but this is like it's just better at every

32:05 at every dimension you kind of think of is what's being pushed. Also on top of that what I think is very exciting about what Google is doing in particular we actually shipped a model called flash

32:14 right Gemini 3 flash the coding capability is actually on par with pro. So what this actually means is we are also trying to drive the cost of intelligence down for our users also

32:25 that is a active work of effort that we are always thinking about is how do we make intelligence much faster and cheaper right and flash is significantly faster than pro. So, like I know that

32:36 it's a copout. It's better in every dimension, but like this is this is what it takes, right? Like the sheer amount of capex. If we're not doing this, like what are we actually doing?

32:46 >> That's cool. Um I think I think he was first. >> Oh, >> yeah. [clears throat] >> Thank you very much. Um you have a

32:51 unique insight on how users are interacting with the model. So I'm curious to learn what you have learned on uh seeing how users interact with the model. It could be in form of

33:01 experiments you ran as expected that fail or maybe some surprises on how your users use some of the uh anti-gravity or or your previous products and uh ways that you've never thought about but how

33:13 was how user adopted your product? >> Yeah, I think okay a couple things that I thought were pretty interesting. First of all, we put the browser in. We thought people would largely speaking be

33:23 using it for UI testing, right? In other words, you make a full stack application and use it. But people as the browsing capabilities actually increased, people have actually been using it for for

33:32 general browser automation where it can look at like arbitrary insights that then help them write software. So it's like oh like open up a system design from X and Jira and then after that

33:41 write some write some code. People have actually been doing this and the benefit of doing it this way versus like all this like MCP shenanigans is you are at least then you are no longer reliant on

33:51 on on an API existing. And the reason why that's helpful is why did the people at Jira for instance build their product? They built it for people to use it on a website. So like fundamentally

34:02 like like the website is the source of truth, right? The API is something that lags the website in some way. So that was an interesting thing that I also found. The second thing that I thought

34:09 was also really interesting is we have so many users that are running so many agents in parallel. I did not think we would have a person running 10 agents in parallel. Like I talked to a user, we we

34:19 give very very generous flash capacity for our ultra plan. very and this person ran out and I was like how is this even possible like it literally doesn't make sense like you would have to be a

34:29 monster to do this and I found out what the workload was and it was insane like I I did not think software development was changing this much right people were doing a migration on one codebase while

34:40 doing X on another and Y on another and I think this is just the future right and this is why we built out the agent manager but it's cool to see that pull already coming naturally from the

34:49 product [snorts] >> awesome thank Thank you. Um Van, thank you for the talk. Thank you for building such a sensational product. Um I use it all the

35:00 time. Um um I just had a question actually based on, you know, I firmly believe in what you're saying. I'm actually a medical doctor and I've been using anti-gravity a load and building

35:10 all kinds of stuff way beyond my intrinsic capabilities to do so. But um I'm curious like so my own workflows changed a I was using uh codeex and uh VSSC before and now I've shifted over

35:22 entirely to anti-gravity. But still this problem of figuring out what to build, what problem in the real world is it solving and um what am I going to do after it's built to like get people to

35:33 use it? What's the business model? All that kind of stuff I'm still doing elsewhere and then writing uh Gemini or Chat GBC or whatever to write a prompt that then I'm using in

35:44 the anti-gravity world. So to what extent are you looking at bridging that gap or is that always going to be two separate worlds? So, so look, I think I think my feeling

35:53 is there's always going to be this like kind of consumer use case, right? And the consumer use case is is u and and less productivity based and the consumer use case is like I want to answer an a

36:03 one-off question that is very topical to me like hey like tell me a little bit about this bed and I want the latest and greatest bed in X right and this is like very specific and I think Gemini app and

36:13 and Chad GBT are going to be great products for this. The idea you brought up is something we genuinely care about. Like I think you will see we're going to flex more and more to be able to do more

36:21 powerful things in workspace, be able to use all the data sources you have internally. Like we want this to be the the most powerful knowledge assistant, right? Um that that is able like the

36:32 fact that it can write code is a feature. >> Yeah. >> Fundamental feature, right? Um, now I still think you will need to apply a lot

36:39 of your knowledge being an actual in the medical space uh to to actually figure out what problems you need to solve, but I think we want to help with with this with being able to piece together the

36:49 knowledge from all these different sources like that is something we we definitely want to do and we will improve with it. Um, I think the browsing capabilities at its very very

36:57 early innings and frankly speaking right now for a lot of tasks it is still very tedious. I think we have a lot more improvements to be made. This is once again I know everyone will say this is

37:06 the worst the technology will ever be right right now. >> Yeah sure thank you. >> So Veru oh hope people can hear me veru it's great to see you again um met you

37:15 in the fall. Hey so last year I was using your windsurf um in the summer to like do autocomplete like you mentioned the code and it's really cool to see the new product come out. So this kind of

37:24 question is about the shift from like an autocomplete to the new anti-gravity IDE platform. When you think about when the agents are t taking the intermediate logic versus like the developer we're

37:35 kind of coding the logic. How do you think about repeatability of the flow and how do you think about eval like is the current benchmark still the right way of thinking about it or you're

37:45 thinking about having to have new benchmarks in order to evaluate these agents and also making sure what they work they do even with artifacts you have on anti-gravity can be repeated.

37:57 >> Yeah. So, so we are um we we care a lot about this. Actually, a lot of the work on our team is actually eval uh because I think otherwise we don't know like we don't know if we're actually making the

38:06 product fundamentally better, right? And we have a lot of evals that are held out that are held out and actually represent the hardest tasks our team can do and we the hardest task within Google. The

38:16 benefit of it being within Google is we have the entire environment of Google. So like we can in theory the agent can pull drive documents and all this stuff internally, right? and and it has a

38:25 self-consistent system, right? And we also have anti-gravity usage internally. So, we actually can do a lot of fancy things uh on the quoteunquote determinism side, which is to say, let's

38:35 say the agent didn't do something good, right? For an internal Google user, we can actually take those trajectories and replay them afterwards, replay them afterwards with a newer version of the

38:44 agent and validate this is more in line with what the user ultimately did want. So, we can get very very sort of deep in the weeds. We have a lot of other sort of tasks on the team that are just very

38:54 custom and specific to what we're doing and we have made those evals too and they are like outside of the training regime and we know hey like the thing I'm the most excited about is when we

39:03 have an eval where the where the score is like 5 or 10%. Because that just means the headroom is so high like there's so much more for us to fundamentally improve and and for us to

39:12 climb. So um eval is the primary way for us to improve and and we take eval very seriously in general. >> Okay. Okay. And repeatability repeatability uh of

39:20 >> I think repeatability repeatability is okay. I think the idea of repeatability fundamentally comes through if okay the idea of exact repeatability is just not possible given like the

39:34 stoastic nature of these models right that's like that's 100% true but I think you can get behavioral repeatability in other words you can run evals and validate hey across a wide swath of

39:44 examples the number of critical negative cases is x the number of the average score is y and you can across a bunch of dimensions and we do measure And that is like our closest proxy of repeatability.

39:55 >> Cool. Sweet. Thanks. >> I have a dog fooding question. What percentage of your time or your team's time on a computer is spent in the agent mode versus more traditional coding mode

40:06 or not using it at all? I guess >> Oh, not using it at all meaning not using the product. >> Yeah, I assume that would be zero, but just asking.

40:13 >> Yeah. Yeah. So, I I think I think like literally everyone anyone who like even people that manage people, the expectation is like you're you're actually building a lot, right?

40:21 Otherwise the intuition is like busted. I think we have we have a lot of paper cuts in the product in terms of like managing many agents is that workflow is like a little bit of a novel workflow

40:30 and I think by the way this is just to say one thing this is why I think some of these products like cloud code have have taken off in a lot of ways because I think managing many agents in a

40:38 terminal is natural for a lot of developers but I think you'd be surprised most people want like a a clean UI to like manage a lot of things and that form factor is something that

40:47 we're constantly iterating on. Like I think we are probably the people that give the most feedback for the product and we have like a large dog fooding channel where every day you could

40:54 probably see 50 50 issues we are talking about right um that's because everyone is beating up the product. Um so I I will say like uh you're our biggest critic right now.

41:07 >> Um hi so I have a more execution point of view question. So I understand for example when you're um when in surf like you can have the flexibility to train your own model like based on whatever

41:18 like use cases what whatever like emerging capabilities you need like when you're trying to build your products but after like plugging into like this demand like bigger chapter like what's

41:27 your uh collaboration relationship with the foundational model side especially for example also now this like uh browser use has become a topic because it is so efficient like on UI automation

41:39 on on the like a UI testing But I'm just wondering for example when you are building like anti-gravity right now like do you see there are some like new use cases that probably we haven't

41:48 thought about when we're trying to train like the foundation models then are you plan to like train your own model like to lead such capabilities for example like probably a lot of customers right

41:57 now are trying to use an gravity to build um agents then do we have the model like to automatically spin up like a agent for for the customer like computer use agents etc. Yeah.

42:07 >> Yeah. So those are two questions. We are going to make it much easier to build these kind of agents you were talking about uh in in the product and and otherwise like that is a there will be

42:15 announcements about that. Um to the formers like this was the reason why we also came to Google like our entire research team moved over and uh we've even made contributions to like the past

42:26 two generations of Gemini 3 Pro and and and and flash as well. Um I think yes of course if we like we are contributing to the fundamental progress of the model and that's what makes me feel so good

42:37 which is twofold. It's not that we are contributing, we are but we are also getting the benefits of the baseline also growing tremendously right as pre-training continues to improve post-

42:47 training recipes continues to improve and so many other improvements end up coming down the line we get the advantages of that I think one thing that I really appreciate about the way

42:55 Google is doing things unlike other companies like I like that have like 100 model SKs we are pretty much pretty clear about the fact that we want a very targeted set of model SKs and we want a

43:05 generally intelligent model that that is great across the board, right? Like some models like obviously like Enthropic, they have taken they made the decision that they are going to they're going to

43:14 regress on a lot of evals that are not that are not coding related. But I think at Google, we want an acrosstheboard great model. And we think a model that is ultimately the best assistant is one

43:24 that is like capable at at many many different spectrums. And we're going to soon see this with computer use multimodal capability. We don't just think is there to make cool images. I

43:33 think it's actually a core capability of a model to be able to understand images. That's actually very important if you want to be great at browser use. So a couple things, a yes we are contributing

43:42 to the model and B it is actually very valuable that Google as a whole is is so is so diverse and and sort of strong in many many realms um in its model and I think this is going to become painely

43:53 obvious like okay maybe just to explain explain uh like a last point here when I look at like the software development life cycle there are many things you do you you write software but that's only

44:01 one piece you review software test software debug software deploy software design software yes you do so many different things and I think this requires offers you to have reasoning

44:10 capabilities on many surfaces that are not just like your underlying codebase. Like it's quick like we we got the quick wins of being able to quickly write software. But if I were to say this, if

44:19 I were to take every developer and instantly allow them write software, we would not save software development time tremendously, right? And I think this is where we're going to start seeing the

44:27 advantages. And I really hope Gemini Gemini is able to like push forward here. And I'm like very very confident in sort of the direction we're taking right now.

44:34 >> Gotcha. Thanks. So I think we are out of time for this uh for this session. So we're gonna have to jump to the next uh and final uh uh session of the day. But uh let's uh thank uh Varun for uh

44:52 spending some time with us. [applause] >> Thanks a lot guys.

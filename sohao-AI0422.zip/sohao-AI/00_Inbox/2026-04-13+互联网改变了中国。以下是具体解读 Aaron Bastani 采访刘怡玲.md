视频链接：[https://www.youtube.com/watch?v=xYPxnbmSWTM&list=WL&index=4&pp=iAQBsAgC](https://www.youtube.com/watch?v=xYPxnbmSWTM&list=WL&index=4&pp=iAQBsAgC)
视频发布时间：2026-04-12
频道名：Novara Media

## 转录内容

00:00 the emergence of these trends like China maxing and this weird vibe shift of Silicon Valley, China envy, right? There's like all kinds of people who are now doing these like two week trips to

00:11 China and being totally stareyed and being like, "Wow, China's building these humanoid robots and they're they're, you know, like they've got highspeed rail." There's like obsession with Chinese

00:20 highspeed rail. Um, and I think a lot of that is less about China and more about kind of the West's disillusionment or maybe disappointment with its own dysfunction.

00:39 The rise of China has been one of the great stories of the last century, certainly of my lifetime. It's by some measures the world's largest economy. It's the world's leading industrial

00:47 power. Another major story, of course, has been the rise of the internet. how it's disrupted, shaped how we do business, how we do leisure, how we go about our everyday lives. But the

00:58 intersection of those two stories, the rise of China and increasingly conspicuous, ubiquitous internet is often under discussed. How has the experience of the internet shaped

01:12 Chinese political culture and literature? How has it allowed people to express forms of dissent with their government? What political and personal possibilities has it created? What kind

01:23 of business models has it led to? All of that is discussed in a fantastic new book by E. Lingule, the wall dancers, searching for freedom and connection on the Chinese internet. I am absolutely

01:36 curious about all of this, particularly because this is a series of stories and perspectives we simply don't have access to here in the West. You know and I know what our politicians and media class say

01:48 about China and certainly what they think about them too. But how do they view us? Eling, welcome to Downstream. >> Thanks so much for having me. >> We're very happy to have you on. You

01:59 know, I I often find the conversations relating to China, East Asia, some of the most rewarding. You know Karen How? >> I know Karen very well. >> Yeah, she was our I think she was our

02:09 most watched episode of Downstream in 2025. >> I'm not surprised. Her book was excellent. >> It's very very good. Yeah,

02:15 >> this is also a very good book. >> Um, briefly, you were born in Hong Kong. >> Yes. >> Tell us a little bit about your story

02:22 because of course it does add authority to the subject matter you talk about in your book, The Wall Dancers. >> Yeah. So, I was born and raised in Hong Kong. I went to an international school.

02:32 And I considered myself kind of having grown up on the fault lines of two very different systems, two political systems, cultural ecosystems, digital ecosystems. and I often traveled back

02:44 and forth to the mainland as well. So I had a kind of foot in the mainland, a foot in Hong Kong and I eventually went to college in the United States where I was there for 4 years before I decided

02:55 that I wanted to return to China and specifically return to Beijing to report and write. >> So when were you born? >> I was born in 1995.

03:05 >> So just before the handover of Hong Kong. >> Yes. That's right. >> Of course in 1997. >> That's right.

03:10 >> In the pouring rain. >> Yes. And and how old were you when you moved to the US? >> I was 18. >> And then back to China when?

03:18 >> 23. >> I I find it interesting. There's this clearly this growing genre of um Chinese or or Chinese centered thinker, writer, somebody like Dan Wong, who I

03:33 think was born in Canada, I think. Um Karen How of course, you know, she's now living in Hong Kong again. sort of living and stepping between two different systems, civilizations,

03:45 and yourself. Do do you think there's a growing number of people that kind of stride both of these cultures, these civilizations, the anglophone world and the and the and the sophhone world?

03:56 >> Absolutely. And many of them I have a great deal of respect for. And I think a lot of that is a result of how much exchange has taken place between these two worlds over the past couple of

04:06 decades. So that's everyone from people who were born and raised in China and then ended up going to school or doing their jobs in the United States or the UK or elsewhere. Um that also can be

04:19 people who you know were born and raised in the US or the UK and maybe have like uh Chinese parents or Chinese heritage and decide to go back to China to work and study to kind of re-engage with

04:31 their roots. And then there are people like me who, you know, were was born in Hong Kong and um kind of grew up with these two different strands already. And so I think I'm I'm really pleased to see

04:44 that that kind of straddling. Um, I think it allows for a much more plural and kind of nuanced perspective on two countries and um, you know, China in particular, a country that is

04:59 increasingly seen through the lens of like a very polarized narrative. >> Do you think that's do you think that was a a sort of moment where people like

05:08 yourself, the other guys we just mentioned, they were the expression of a certain moment? So a cultural opening of China um under you know from from Deng all the way through to Huan Tao etc all

05:20 the way through to Xiinping. Do you think that that was kind of the expression of a certain moment and that's actually kind of going behind us, you know, with the owl of Manurva and

05:28 we're now looking in the rear view mirror and actually people such as yourself who who were very comfortable in two different languages, two different cultures are actually not a

05:36 relic, that's a very strong word, but sort of culturally contingent and maybe the future won't look like the past. Maybe the future isn't actually about this opening and about this striding,

05:45 but actually something a bit more different, homogenization almost of the Chinese and angophone cultural spheres. Yeah. No, absolutely. I think we're a product of a certain period of time of

05:56 in particular, I would say US and China, but China and the rest of the world kind of engagement. Um, and I would say people would give different time periods from when for when this peaked, but 2008

06:12 with the kind of summer Beijing Olympics was a moment that China was kind of stepping onto the global stage as this international superpower and there was this sense that China was liberalizing

06:24 and that, you know, people from all over the country were traveling there and wanting to get to know China in a different light. um the number of Chinese students going abroad were was

06:34 on the rise. I remember up until like 2015, 2016, the the kind of major narrative in um global universities was that Chinese students were going to be kind of all over uh American

06:48 universities and um that has absolutely that narrative has absolutely kind of shifted um I think largely as a result of geopolitical tension and a kind of siloing of the two countries and their

07:03 cultures from one another. That being said, I don't think we're going to like regress necessarily or return to all the way things were say in the 60s or the 70s when China was undergoing the

07:14 cultural revolution and the US was in its kind of McCarthyist era. Some people will say and hearken back to that period and say there are moments of that that kind of feel present in today's climate,

07:25 but I think you can't really put the genie back in the bottle. And there are just so many kind of children born of multinational and multithnic families now that you can't just like chop them

07:38 in half, you know, like there are so many people who have experienced these two worlds and it's very hard to then say pick a side or kind of force them to think in binaries back um back in the

07:51 way people did. >> I think going back to the cultural revolution just seems so implausible. You know, I've only really been reading about it in the last couple of years and

07:58 I have to say obviously crazy things happen throughout the 20th century in every continent basically and obviously many crazy things happen in China but the cultural revolution just strikes me

08:08 as the craziest. You know I think there was one statistic I think in one year of the cultural revolution 19 million firearms were given out to the public. You just think this this mass arming of

08:20 of the citizenry is just incredible. What was it like growing up in Hong Kong? So obviously you're born two years before the handover and there's still this idea of um you know

08:32 two systems. How did that feel to you as a teenager? You mentioned the Beijing Olympics. You were what 13 in 2008. >> That's right.

08:40 >> So yeah, tell us a bit about that that period of you beginning to enter young adulthood. That experience of Hong Kong and and China just before 2008. Yeah, I would say kind of my experience growing

08:52 up in Hong Kong felt very much like I had the ability to inhabit this plural identity. You know, that I could be at once um a Chinese person but also an international person, also someone who

09:08 was in touch with American culture and British culture while also being in touch with Chinese culture. Right. And the school that I went to, it was an international school. So slightly

09:17 different from I would say the kind of typical um Hong Kong student experience, but um it was important for us to study Pongwa or Mandarin. And so most of our subjects were in English, but we were

09:29 also studying Chinese. But it meant, you know, the culture of our school was both celebrating Chinese New Year as well as having a Christmas holiday and an Easter holiday. It meant we were reading kind

09:42 of Dickens and Shakespeare but also like Luun and Laa. Um it meant having quite a bit of a degree of freedom in terms of assessing the history of China and its past. So I remember in history class we

09:58 would study the cultural revolution and all its flaws and kind of atrocities. Um and we would also learn about for example the Tanaman protests and the June 4th crackdown.

10:09 um which you know if I was someone living in the mainland at the time as a young student wouldn't have had access to in the same way as someone who is living in Hong Kong.

10:20 >> And the Opium War as well, you mentioned that in the book. >> Yeah. >> How was that taught or how was that taught in Hong Kong?

10:25 >> Yeah. So, I can't speak for how exactly it was taught in most Hong Kong schools, but at least in the school that I went to, we studied the IB curriculum. And the Opium War was, you know, when I when

10:39 I studied it, it was at once a result of kind of the the flaws of a umQing dynasty that had become too filled with hubris and unable to um keep in touch with the outside world and was kind of

10:56 crumbling from within. But we also studied kind of how it was the result of aggressive British expansionism and kind of the greed of the empire and trying to uh acquire tea and sell opium. And so I

11:09 think oftent times when people study that period say either from China or maybe from the UK they might get only one side of that narrative. whereas we could kind of learn both sides of the

11:22 narrative as well as see how it kind of unfolded literally in the city that we grew up in. >> I'm sorry to interrupt this conversation. I hope you're enjoying it,

11:31 by the way. I hope you're enjoying it as much as I'm enjoying having it. I love Downstream. Obviously, Navara as an organization is like a child to me, like a baby. Uh but Downstream is like my

11:43 grandchild, my granddaughter, you know, it's the baby of the baby. I really enjoy the conversations. I really enjoy meeting our audience out there. Actually, they say all kinds of nice

11:54 things generally about what we're doing with Downstream. I think it's a really important space to have really important conversations. Uh that doesn't mean it's perfect and it doesn't mean Nvar Media

12:03 is perfect. Uh we want to grow, we have a mission, but we want to go in a direction which actually meets the needs of you guys, which is why we want to hear from you. Uh our ambition at Navara

12:14 has always been to be people powered. Uh that's going to require you letting us know what you think and not just in the comments. Uh the Navara audience survey is now live. It's a chance for you to

12:24 give us feedback. The good, the bad, dare I say even the ugly. We want to know. Uh we are planning to have a massive 2026 and of course a massive few years uh before the next general

12:36 election. But we want that input from you to really pack a punch. As a little incentive, if if you submit your thoughts by the end of Sunday the 12th of April, uh you stand a chance to win

12:47 one of five 50 vouchers to spend in the Navara merch shop. Spend it on books, spend it on a t-shirt, spend it on whatever you like. Just hit the link in the description below or head to

12:59 navara.dia/servey now. So just to to clarify what that was like, was that both sidesing or was it saying here are two different interpretations and as students you know

13:12 your you know please use your reason and your personal judgment to determine which one you think is uh more closely here to the truth because you know my reading of the first Opium War is just

13:24 utter barbarity if I'm honest. You know, you have this this seizure of it's probably the largest seizure of narcotics in human history by theQing dynasty. They destroy it. They, as I

13:34 understand it, to everyone, they dilute it. They then dump it in the sea. And this just leads to, you know, a war basically um to to like you said, fundamentally to get tea into um have a

13:46 trade uh surplus or to have a balance of um trade of payments with with Cheng China. And obviously to modern sensibilities that's like horrific. It's disgusting. So how was that taught in

13:59 Hong Kong? Was it a bit was there a sort of apologism with what the British did or because I want to understand today a Chinese nationalist they might be agrieved at how that was taught. So put

14:09 some meat on the bone. >> Yeah. No, I mean let me just try to rewind back to age 15 16. I would say definitely the the language of both sidism that I use was not necessarily

14:20 the framework used. is more kind of like a historioggraphic approach where it's like this historian said this xyz and you know it's a range of different historians from like British ones to

14:31 Chinese ones to like actual primary sources and documentation and it was like okay and go forth and write your essay like why did the opium wars begin and so a lot of the work that was being

14:42 done was just in our own brains as opposed to kind of being force-fed a narrative. Um, I think the key difference between the way the Opium War was taught for us, at least at my

14:51 school, and say maybe a more uh conventional Chinese school in the mainland, is it wasn't laced with this kind of uh narrative of grievance or this narrative of humiliation, right? I

15:04 think the facts were maybe all laid out and being like these atrocities did happen. kind of an entire generation of people got hooked on these drugs as a result of this form of um trade, but

15:17 there wasn't this sense of and we were humiliated and therefore we must stand up and push back. you know, we were kind of afforded this level of critical detachment from the material, which I

15:28 think was very empowering because on one hand, I could see how it was like connected to my history and connected to the city that I lived in, but it didn't kind of stir up an emotional response or

15:41 a response of kind of victimhood that I think is not often very helpful when trying to teach like a younger generation about history. >> So, growing up, did you often hear about

15:51 that phrase center of humiliation? Because of course again that's core now to China's ambitions to reassert itself on the global stage. We'll talk about them a bit later on. But the wolf

16:00 warriors online that have kind of emerged in the last 10 years. >> Was that really a phrase that was absent when you were growing up? >> Yeah, it was only present in history

16:09 class. That's what I'll say. >> But you did hear it. >> I did hear it, but primarily when understanding why people thought and believed a certain way. So I think I

16:20 kind of had the luxury of maybe a kind of distance from that sentiment, right? I think people around me weren't like and we were humiliated as a result of that. It was more like

16:31 >> people were humiliated or people have been humiliated as a result of that. And that that's just one arms length, right? That one kind of level of distance. I'm sure, for example, my grandparents were

16:44 um passed and a lot older when I um started learning about this history. They they'd both passed when I started learning this history or would didn't talk to me about it, but I'm sure if I

16:55 did talk to them about it, they would have experienced that much more viscerally. >> Um and it allowed me to understand their experience and their pain without

17:05 necessarily kind of internalizing it as my own. It's similar, I guess, to to this country with things like um the enclosure acts. You know, over hundreds

17:14 of years, regular people in England um and elsewhere in Britain have their land taken away or people are press ganged into the military. I mean, a crazy statistic. I was talking to Ronald

17:23 descriptor on this show a few weeks ago. Quarter of a million English men were press ganged into the Royal Navy in the Pami over about 150 years. That's the claim his book. But like you say, that's

17:36 kind of taught as this, you know, abstraction and historical fact. People aren't sort of meant to feel agrieved over it. So you're being taught a certain kind of curriculum in Hong Kong,

17:47 which is obviously distinct to the Chinese mainland, even after 1997. Um, what was your first experience like with the internet and when was it? >> Yeah. Well, I'd say I'd had different

17:58 first experiences with the internet and different first experiences with the Chinese internet. And I would say my experience of the worldwide web or just like blogging online for the first time

18:09 was probably when I was like six or seven, you know, maybe as early as five. And I think it must have been a combination of um Google, like Google's I'm feeling lucky option,

18:23 >> um emails, um I think MSN at some point, maybe later on, and Neopets. Um so that that was probably my early experience of the internet. Um I think it was very much like part of my childhood and my

18:38 early childhood almost. So like as early as five or six. So >> the turn of the millennium with >> Exactly. Exactly. So I think having spoken to many people who have like the

18:48 first experience of logging on for the first as for the first time as this kind of like exhilaration or revelation. I was just a little bit too young to have that. It was kind of part of the fabric

18:59 of my life. Not necessarily in the same way as it is for Gen Z's and young people growing up today, but I don't remember that kind of moment of aha like I'm connected to the world for the first

19:10 time. It was almost this like ordinary benol technology that had been slowly introduced to me. My experience of the Chinese internet I would say felt slightly different because I think that

19:24 um my kind of first experience that I can remember at least was probably during 2007 and 2008 um when I was visiting Beijing to see my grandparents and going to participate or not

19:37 participate as an athlete but to watch the Beijing Olympics and I remember I was using the internet for the same things like Facebook, Google and Neopets and um all of those things just became

19:51 increasingly hard to access. And it just happened to be that during those years, Facebook was getting taken down and blocked. Um Google was not yet blocked, but there were a lot of things I

20:03 remember researching different things. For example, like the Tanaman tankman and not being able to access it and thinking, "Oh, that's interesting." Like you can access this back home in Hong

20:11 Kong, but not here. Um, and then eventually those were just so hard to use and that I started using VPNs and that was an era of freeVPN. So they were spotty. I didn't know that you could pay

20:23 for some and have better access. And so I just remember spending a lot of time in Beijing on Neopets um because I couldn't access the the websites that I was able to back home.

20:35 >> So Facebook is in China 2008 2009ish. Google is there for a little bit longer, right? That's right. >> But before that, we still get the the

20:45 Great Firewall of China, which I'm sure many people have heard about. So, I think the World War is it kind of makes its debut in China in '94. >> Yes. But 95 is when it's like

20:54 commercialized so that ordinary users can use it. >> And then we get the great firewall when >> the great firewall so um technically was introduced in 1997.

21:06 And this was when authorities introduced a system that was called the Golden Shield Project. And so the great firewall is just a kind of slang term, a moniker that um two scholars came up

21:19 with um in a wired article, Sonia and Jeremy Barme. So it was an informal name and not one that they came up with themselves. The Golden Shield project was primarily this um system of

21:32 censorship, primarily this filter that prevented um forbidden content, links, words from coming in and making sure that the information that came in was carefully controlled, right? And so that

21:48 was introduced in 1997, but um it has since then over the years expanded into much more than just a filter into like a entire system of surveillance and control. And so when we think of the

22:03 great firewall today and even as early as 2008 2009, it's not just kind of a filter of banned websites and words, it also includes, you know, top- down internet regulators who are issuing

22:17 censorship directives and policies. It includes like a whole network of content moderators at social media companies who are on the backends, you know, scrubbing words one after the other off their

22:30 platforms. And then I think a very important part that I think of as part of the great firewall that people don't necessarily um think of or refer to is the kind of

22:42 like psychic internalized selfcensorship that people um feel because they know about the potential repercussions of of expressing themselves online in certain ways.

22:55 Do you think that there's more propaganda in a society where you have that kind of authoritarian top- down um closure of public debate? Or is it other way

23:08 around? You know, I've heard a really interesting argument recently, which is that in a democracy, you actually need more propaganda precisely because, you know, there's there's popular

23:14 sovereignty and and people seemingly, you know, make their own minds up. Whereas actually in a system like China where you have that that infrastructural closure of debate it's

23:25 kind of less necessary. I want you know there's an interesting sort of dynamic there where people obviously associate since Orwell >> more authoritarian structures with

23:34 greater levels of propaganda but I wonder is that even true necessarily? Um, my instinct is no, just given the amount of propaganda that I've seen on the

23:46 Chinese internet, despite the fact that you can scrub off content. >> What kind of propaganda? >> Um, all kinds like patriotism for example, nationalism, like nationalist

23:56 content is continually amplified. And that could be an actual state organization or a state news outlet like CCTV um which is the state television channel

24:09 um kind of like extolling uh Chinese history and like the a common phrase is like 5,000 years of Chinese history and we see that in everything from TV shows to like hip-hop music

24:22 which I write about in the book to um like science fiction novels to just like everyday news, right? There's this sense of everything needs to be glorified and presented as China as being very

24:35 patriotic. Um, so that that's one that appears everywhere. Um, I would say like another example is propaganda that's related to specific policy agendas, right? So,

24:48 right now there's um China suffering from demographic decline. women don't want to get married and they don't want to have kids and that's a huge issue for the government. And so now they're using

25:00 all kinds of ways to use propaganda to encourage that. And that might be like advertisements or even just like social media content by state outlets that are extolling a kind of vision of the

25:13 tradife, you know, of someone who marries and stays home and has kids. Um, and I would say like a more kind of subtle form of propaganda or maybe subtle is the wrong word, but one phrase

25:27 that comes up often in Chinese social media feeds is this phrase positive energy. And I think in Chinese it's jung. So there's this sense that it's not sufficient to simply scrub off quote

25:40 unquote negative energy from the web. So, not it's not sufficient to simply take down um what they consider negative content. And that's everything from like excessive flaunting of wealth to most

25:53 recently like queer content and quote unquote boys or um some of the more obvious forms of negative content. So like political disscent or any form of like collective mobilization that's

26:06 not sufficient. Like there needs to be an inu infusion of something else that people can latch on to and that's usually positive energy. And what's positive energy is like healthy marital

26:17 values, you know, um standing up for the country. Um like a phrase that they use a lot is like core socialist values. And then sometimes it's even as simple as like going onto a social media platform

26:29 like Quisho, which is um kind of like a doine or a Tik Tok for more third tier cities. And they'll even have like a positive energy feed. And on that feed you'll have like pandas like hugging

26:42 each other, you know, or like an old granny like uh doing calligraphy. Um just like very wholesome um content that's designed to make you feel good and feel like the world is

26:56 good. I think one way that I have liked to describe those positive energy feeds are like Disney meets Pinterest um meets uh the Communist Party, right? It's like very um

27:12 Puritan, patriotic and um maybe playful. >> I mean that sounds like quite good propaganda. I mean that that's again as somebody who's not partic you know I'm

27:24 not a fan of propaganda but I mean that sounds you know there's an argument that that's preferable to doomcrolling >> for instance um and I suppose there's a couple of layers there. One is you know

27:33 when you're talking about the propaganda of China is a 5,000y old civilization and this kind of this this nationalist boosterism as somebody in the UK I mean I see the exact same on GB news or as

27:44 somebody in the United States they might say well I see the exact same thing on Fox and of course then it's just a degree of of scale. So these same things exist in these other countries just not

27:53 probably not to the same scale because they don't have that that fusion of of state and civil society like China does. That's that's kind of the first point. Um

28:02 but secondly I mean that does sound quite nice that people just you know are are being subjected to this positive energy and this comes out of a book in China right by a gentleman called

28:12 Richard Wisman. >> Yes. Yes. It's actually a British book funnily enough. Yeah. It's a it's a British book written by this kind of I I don't want to use the word pseudo but

28:21 maybe pseudo is right pseudo go on pseudoc psychoanalyst called Richard Wiseman and his the central kind of thrust of his argument is you know if you smile you'll be happy like if you

28:33 dance you'll be energized like the positive um behavior the positive beliefs follow positive actions not the other way around so I feel torn about this cuz I

28:46 can see the kind of logic behind it. But there is something a little bit kind of forced and maybe like nefarious about that thinking where you know it's almost like if you encourage certain actions if

28:59 you like require and he writes about this in the book if you require young children to wave the national flag they will become more patriotic. Right? And so there is some fine line there about

29:12 you know is it good to enforce like certain types of rituals to bring together community or is it kind of bad to like force feed a certain worldview such that everyone can kind of think in

29:24 a homogeneous way and there is like a boundary there. But you know to your earlier point I totally agree like these same forms of propaganda very much exist in the internet outside of China right I

29:38 think the key difference is just the level the the degree to which it takes place and the kind of authority of the sources where it comes from right like Fox News is pushing a certain agenda um

29:51 but you can go and turn to another news source um that will have a completely opposite perspective rate. Um, and then as for your point to, you know, whether or not this is a positive thing, this is

30:04 a question that I've been actually getting a lot recently, like actually just a couple of days ago, a gentleman asked me, you know, are there good parts to the great firewall? like is it good

30:15 to have online regulation and you know have some of these toxic material that we doom scroll through in the rest of world and doom scroll through in the rest of the world removed and I think

30:29 the kind of to rephrase that question I think it shouldn't be you know whether or not the great firewall is a good thing but how can we more effectively govern and regulate the type of content

30:40 that appears on the web right and so there are a lot of things There are a lot of like decisions that the Chinese government has taken with regards to governing technology that I actually

30:50 think that I agree with that I think are great. For example, like trying to um limit addiction to video games or trying to limit addiction to social media feeds by requesting like minors register on

31:02 certain social media platforms um or like removing pornography for example from the web. I think the key issue with the framing of whether or not the great firewall is a good thing is that how

31:15 those policies are enforced, who comes up with them, where do they come from, you know, all of that is extremely opaque and top down. So regular people just like don't have a say in how their

31:28 internet is governed. Um whereas the on the flip side, you know, the chaos that we're seeing in a lot of the rest of the world is that there's a complete absence of regulation or a desire to deregulate

31:41 because the social media companies have so much power and their incentive of course is to keep you on the feeds as long as possible. And you know, well that the way to do that is polarizing

31:53 content, you know, violence, um misinformation. M I I guess the best advert for the Chinese system is the fact that X is owned by a gentleman worth about 800 billion US dollars and

32:04 he's tightly aligned with you know um the present inhabitant of the Oval Office. Also this Richard Wisman character. I mean I can I can almost see the Adam Curtis documentary in 10 years

32:15 time now about a mediocre British pseudocss or psychologist becoming a you know he had a a middling book wasn't so big here but it was you know central to Xiinping thought and this interesting

32:27 fusion of Marxism with you know CBT cognitive behavioral therapy. um we live in a very very strange time but I do see so much overlap between the stuff you're talking about from the Chinese state and

32:39 obviously you're right in the west generally speaking there are multiple sources that people can draw upon but this idea for instance of um historical nihilism as they refer to it in China

32:50 certainly under Xi um I know obviously precedes him but this idea that you shouldn't be too critical of of the past cultural revolution you know um the Chinese nation etc and that this is a

33:00 form of culture niism again Nigel Farage would say the exact same thing about the British Empire, you know, and it is a really interesting um impulse which clearly

33:13 goes beyond um borders. So, you mentioned um pornography there a moment ago. As I understand it, it's illegal to produce um and to distribute. Uh I I suppose the production side is the is

33:24 the is the better side to regulate. Is that a conversation that exists for instance in Chinese civil society? You know, you hear it all the time again from conservatives in the west. Oh my

33:33 god, Only Fans is taking over, etc. Is that a critique that, you know, the wolf warriors and the neoauists make of places like Europe and the United States? Well, look, all the women over

33:42 there are obviously it's a stupid thing to say. It's not true, but as a as a a caricature of our culture and decadence, they're saying that, you know, they're all getting involved in pornography. And

33:52 you know >> there definitely is a strain of kind of conservative Chinese thought that fits very well with kind of conservative western thought as well. Um I would say

34:04 pornography is maybe part of it's not the focus of a critique of kind of western decadence particularly with regards to sex. So like um the kind of rejection of a nuclear family you know

34:23 with filopiety and respect for parents and the desire to have offspring and the desire to commit to one person. I think there's a lot of conversation around that. I think there's a lot of kind of

34:35 um critique of particularly within this kind of conservative sphere of um kind of queer life in the west as kind of this western import and kind of China does not have queer life. It's something

34:49 that's just been uh a source of influence from abroad and I guess like pornography does fit under that. I would say less so today, but definitely in the '9s um when China was accessing the

35:03 internet for the first time and there was this kind of opening of the door to the west. Um pornography was definitely seen as this like unhealthy western import. Um but that came along with

35:17 everything like sex before marriage or like um samesex desire. Um and >> so there are some people that claim this is all an outgrowth of the emergence of the internet, global

35:32 digital culture, etc. >> I would say like the number of people who still think that way is definitely on the decline, but certainly in the kind of ' 90s. Um

35:41 >> what about the upper echelons of the CCP for instance? Is that is that a sort of mainstream view or >> I haven't spoke to any of them personally so I don't know. Um

35:51 >> one person who whose views are made pretty clear is one um party official who I write about in the book Wong Hunu Ning who's kind of like the chief ideologue.

36:01 >> Yeah. >> And he writes this book in 1989 called America Against America. And I'd say the worldview that he kind of came to then is still very much consistent to the

36:14 worldview that he has today, which is this sense that kind of American lesb liberalism and kind of a fullthroated embrace of capitalism has created a society with no cultural values and kind

36:31 of a society that cannot hold and cannot support its citizens. Right? it's it's it's kind of void of morals. And so I think he definitely still does have this view that when money and kind of

36:47 capitalism is the central driving force of a country, um it results in an erosion of family values. It results in an erosion of patriotism and kind of dedication to the nation state. um and

37:05 uh he definitely does have that view. So if he is the kind of central ideologue for the party, I'm sure there are other people who al also share that view. I will say that in the book he was heavily

37:16 influenced by the conservative writer Alan Bloom. >> So reading Alan Bloom will also give you a really clear sense of how Wong Huning thinks.

37:24 >> Yeah, he's a fascinating dude, right? And I'm trying to get a good English edition of that book. Um I can't find one. Obviously, I can't read Mandarin, sadly.

37:32 >> There's one on Amazon, I think. >> Yeah, there is. But I look at the reviews and they're saying it's like um a recent edition. It's poorly produced and poorly printed. Maybe I'll have to

37:41 go to China to get one. But he's kind of like, you know, the the the the Chinese um Alexander Dugan, I suppose, for people who are watching if they're, you know, vaguely familiar with that world.

37:49 Of course, his proximity to Putin is contested, but a post-liberal kind of thinker. And um increasingly in the West, we have lots of those people, too. people like Patrick Denine who have this

37:59 critique of maybe we got a lot wrong in the last 40 years with economic liberalism both uh um with liberalism rather both economic and social. So neoliberalism going back to the 1980s

38:09 and social liberalism going back to the uh going back to the 60s. So, so, so people like that, do they view the arrival of the internet almost as a potential kind of weapon of mass

38:19 cultural destruction that that there was this imposition of what they view as foreign western values, LGBT rights, sex before marriage, pornography, etc. I I just want to sort of identify that

38:30 perspective. >> Yeah, I think they're very torn, right? Because the other kind of strand of that book or the central idea of that book is that technology has enabled America to

38:43 be incredibly powerful and strong. So there is a deep strand of envy and admiration in what new technologies and emerging technologies particularly something like the internet can bring.

38:56 And I think that tension is something that I explore with the book with regards to the internet, but I think is also very much prevalent um in the party state's attitudes towards AI today.

39:09 Right? It's it's um a balance that needs to be navigated. On one hand, these technologies like the internet can produce huge sources of innovation and kind of boost the economy and make China

39:24 strong and powerful. On the other hand, it's a huge source of instability and it's going to bring about all of these decadent values. I think that might have not been the kind of primary anxiety at

39:36 the time and still isn't the kind of arrival of decadent values as much as serving as a source of political instability um and enabling kind of collective mobilization. I think for a

39:48 long period of time, for example, if you were to look at the things that sensors scrubbed off the internet, things like unhealthy marital values or kind of uh queer issues or kind of like quote

40:00 unquote vulgar content, that was all over the internet because that wasn't their primary concern. Their primary concern was sometimes even just like excessively patriotic users who were

40:10 trying to rally a group together and get people to protest. Right. >> So they wor about collective action basically. >> Exactly. Exactly. So what you're saying

40:17 is that you know the internet is a source potentially of of both strength and weakness. >> Yes. And so I think that um they're torn, right? And a lot of what the party

40:30 is trying to do is what Danga Ping said many years ago, which is like open the window to let things in, but inevitably flies will come in. So try to do the best they can to keep those flies out.

40:45 Um, and I would say that's a similar dance that they're trying to do with AI, which is, you know, how can we ensure that this technology is diffused in every in every sector of society um, and

40:58 kind of supercharges the economy in the way that we want to, but um, doesn't become this totally uncontrollable new thing that has impacts that ripple well into society that they, you know,

41:12 they they don't have reigns over. just as a user, what what the differences like between, you know, um, uh, WeChat and and WhatsApp or Alibaba and eBay? This might sound like a sort of pure

41:23 question, but is the user experience better? Is it inferior? Do you sometimes feel like the Chinese internet as a consumer, as an as an end user is actually um, a better experience than

41:34 the American or Western one? >> Yeah, again, a total double-edged sword. So just to pick a very specific example, a platform that a lot of people associate with the Chinese internet is

41:46 WeChat, right? And WeChat in many ways is a unique beast of its own. I don't think there exists any kind of corollery in the global internet. I think once upon a time people called WeChat China's

42:00 Facebook, but that comparison has just completely been, you know, thrown into the trash. To the extent that Mark Zuckerberg now has been quoted to have WeChat envy. And when we say Mark

42:13 Zuckerberg has WeChat envy, we're referring to the fact that WeChat has just penetrated like every facet of Chinese society. It is dubbed a super app. It's essentially kind of this

42:25 online Swiss Army knife where you can do everything. So, you know, firstly the wechathat messaging platform, you're not just messaging your mom there, you're also messaging your boss, you're also

42:37 messaging your client, you're also messaging the person who walks your dog, you know, you're you're messaging um the store owner who needs to sell you something. So, everything is kind of

42:48 centralized into one app. You know, on WeChat, you're also making payments. You're also hailing cabs. You're also um getting genetic tests. I've once done a genetic test on WeChat. You know, your

43:00 your your bank platform is sometimes on there. And so on the plus side of that, right, the beneficial aspect of that is that it's extremely convenient and efficient, right? Everything can be done

43:13 on one platform. All of your data is aggregated on one platform. um it makes everything from payments to messaging an extremely um kind of seamless and integrated process. Now again, it's a

43:28 double-edged sword because it also means that um it's very easy to control, right? If all of your data is aggregated into one platform, um you can be easily traced, your payments can be easily

43:41 traced, who you're talking to can be easily surveiled. And evidence of this, for example, was during the uh COVID lockdowns in China. The two platforms that were used by authorities to kind of

43:55 track and trace people and ensure that they weren't infected by COVID were Wechathat and Alip Pay, arguably two of the largest kind of social media platforms in China. And this meant that

44:07 um essentially anyone who wanted to leave their building or go into a store or get onto a train needed to show that they had a green QR code on their WeChat platform. Um and if they didn't, they

44:21 would just effectively be trapped at home. Um and that very app was also connected to, you know, your phone's geot tracking loco tracking. it was also connected to every single person that

44:35 you'd ever talked to, right? Or every store that you'd visited. Um, and so if you're optimizing for kind of privacy and the ability to move around the world without being surveiled, it's not

44:47 exactly a great experience. >> I'm going to say it again, guys, because it's really important. We're planning something huge here at Navara Media, very, very big. But we need to hear from

44:56 you guys first. The Navara Media audience survey is now live. And if you submit your responses by the end of Sunday, the 12th of April, you stand the chance of winning one of five 50

45:06 vouchers to spend at the Navara shop. That means books, tees, mugs, totes, whatever you want. If that sounds good, then follow the link in the description below or head to navara.dia/servey

45:18 to get started. And how do these major companies, how do they relate to um not just the state, but the party? The western question would be well you know maybe the state

45:28 has the back end and there'll be various state agencies that lies with people within the company but of course in China as I understand it there are parallel structures within these

45:37 companies which are you know party affiliated so there'll be party cells etc. I think every business every private firm with more than I think like nine employees or something maybe you

45:46 can correct me if I'm wrong has you know a party cell there is a you know with for instance major cities you have a city mayor but you also have a you know they'll have a parallel party official

45:57 so this is just a a very different way of doing things how does how does that shape people's experiences so in in Britain for instance there is you know um there's a there's a wide widespread

46:11 knowledge that the state has access to a bunch of things. We've known this since Snowden, right? The American and to a less extent the British state. But people say, "Well, you know what? I'm

46:20 not doing anything wrong. I don't mind the surveillance. If you don't want to get caught, don't do anything illegal." How do how do Chinese consumers and end users relate to that level of

46:29 surveillance scrutiny, that fusion of state, party, and and private enterprise? >> I would say the ordinary Chinese user just doesn't think about it. Um, I think

46:40 they just assume that anything they put onto an online platform can be seen and found if necessary. Um, at least that applies to every platform that exists within the firewall. And I would say the

46:55 ordinary Chinese user doesn't feel like they are worried about that. I think similarly to maybe a lot of users in the UK, right? they will always choose convenience and efficiency over privacy

47:08 and kind of avoiding surveillance, right? When the cookies come up, >> no one is picking or very few people pay attention to that tab and they just kind of accept all, right? I think the

47:20 difference in China is just like you don't even have that option, right? Um, and I guess the level of penetration and the level of access to that data is much much more easy and much more opaque.

47:32 like it's not a discussion that's being had in the public sphere. It's just something that you're supposed to kind of accept and take for granted. >> How do people have those conversations

47:43 politically? I mean, let's say, let's say you have misgivings about a certain policy. Obviously, you can't just, you know, you can't go out protesting against, you know, state surveillance in

47:51 WeChat, whatever. But can ordinary Chinese, you know, join the party, have those conversations within party cells? How does it work? or is it just >> it's pretty opaque. Yeah. To to be

48:03 honest, I don't know what takes place and how that takes place on the level of, you know, from the inside, for example. I'm sure those conversations take place on the inside all the time.

48:14 >> Every now and then it kind of spills out into the public sphere or very excellent researchers um are able to kind of dig deeper and see how that conversation unfolds. One example of that I think

48:26 that has been really compelling in the realm of kind of AI policy and the governance of algorithms. I'd recommend this paper um written by Matt Jihon who works at the Carnegie Endowment Carnegie

48:40 Endowment of Peace and it's about um how China put together its um regulations on um delivery algorithms or recommendation algorithms specifically with regards to delivery services. And this was a kind

48:58 of a rare example of how public grievance and push back that was then amplified by the news um made it you know had its influence and impact all the way to kind of the highest level of

49:13 policy. So the story was in 2020 um a couple of sociologists in China did this really massive investigation into the ways in which um the delivery platforms, the two big ones in China, Alma and

49:31 Mtoan were using these algorithms to kind of accelerate the delivery times of its drivers in ways that were incredibly dehumanizing. Right? They were creating routes that were dangerous and sometimes

49:45 illegal. It was leading to deaths. It was leading to injuries. And every time drivers were able to kind of hit a new time and drive faster, um they would then, you know, the system would ramp it

49:58 up again. And so it created this like vicious cycle where drivers were just like continually trying to make ever um more dangerous and ever quickening delivery speeds. Um they talked about

50:11 how they were using these algorithms to like gamify the system so that drivers would be trying to get to like king level to you know reach x amounts of deliveries and that story was then

50:22 published in a Chinese magazine called Renu people and um it totally took off like people were really angered by this um they were kind of speaking out and expressing their grievances towards the

50:38 kind systems and the the conditions that delivery drivers were suffering under. And eventually I I don't know how many years after it may have been 2022 or

50:48 2023 in um one of you know I think we'll have to check that but uh China's um algorithm regulation I want to say 2023 included a clause specifically about how um

51:07 uh the algorithms used by delivery platforms had to be kind humane and respect the working conditions of drivers. Right? So we often think of Chinese policym as completely opaque and

51:23 in many ways it is very opaque but every now and then we see um a policy decision that's directly in response to something that has taken place in Chinese society and has been

51:36 voiced by the public. I mean that's the thing the the Chinese system and people don't like to basically admit this in the west but it's clearly responsive right there's that great quote by um

51:46 Eric Lee where he says in the west you have systems where the parties can change but the policies can't here the party can't change but the policy can and that's just you know that's

51:54 empirically verifiable when you look at you know um postang China Xi clearly it's gone a different direction postcultural revolution huo earlier on with Mao these huge policy

52:07 decisions clearly responding for right or wrong in a way that is clearly much quicker and much more thorough than you see in the west. And I I find that really interesting. The idea

52:20 that you have a system without trade unions where you know you don't have a pluralistic party system and yet you still get outcomes actually which a pretty good friend uses. I don't know.

52:31 It's an interesting one. You got this this organization with what nearly 100 million members in the Communist Party. I'm curious about the kinds of conversations they have. The title of

52:39 this book, Wall Dancers, um, searching for freedom and connection on the Chinese internet. What is a wall dancer? >> Yeah. So, I came up with the term, but it comes from this Chinese phrase

52:51 dancing in shackles or and as far as I know is first used by Chinese journalists in the early 2000s. And they were using it to describe the kind of process of writing and reporting

53:04 under state constraints, like having to self-censor, having to remove certain ideas from their pieces in order to push stories or get across a truth that they were excited about. Um but soon after it

53:18 was used by all kinds of people and I've heard this phrase used by um Chinese science fiction writers, Chinese musicians, Chinese software engineers and I found that it resonated with me in

53:32 particular when I moved to China because it really captured this experience of living in China as a kind of dance, this kind of dynamic push and pull between state and society. um this kind of

53:44 swinging between freedom and control. Um and I found that this dynamic was most evident on the Chinese internet behind what we know as the great firewall. And so I came to know the people who were

54:00 particularly good at navigating this terrain and doing this dance. I came to know them as as dancers or wall dancers. >> So who the who the the major wall dancers in this book? just maybe go over

54:12 one or two of them. >> Yeah. So, I guess I'll go with the first two I discuss. Um, one is a man called Mabali and he grew up in a small town in northeastern China where he was studying

54:27 to be a policeman. At an early age, he realized that he was gay, but according to his textbooks at school, that meant you were either um a mentally ill or a criminal. And so he kept a secret to

54:41 himself. But one day he stumbles upon a short story online in an internet cafe called Beijing Story written by an anonymous writer um about two young men who fall in love and have this

54:55 tumultuous affair. And he's like, I feel so seen. It was a revelatory, cathartic moment for him. Inspired by that, he decides to create a gay website um to connect kind of queer men from across

55:09 the country. The team grows to five people to 10 people. He moves to Beijing. He gets found out. He comes out. Fast forward a decade later. By the time I meet him in 2019, he is the CEO

55:24 of Blued, the largest gay dating app, not just in China, but in the world. and he's about to take his company public on the New York Stock Exchange. And so that's one of the subjects I follow. The

55:37 second one that I'll talk about is Lupin, who started out as a journalist at a state-run organization called China Women's News. She was feeling quite stifled by that experience and ended up

55:50 becoming a freelance writer and founded Feminist Voices, which was China's most influential feminist magazine at the time. Um, and it really became viral and popular when she put it on Wayboa,

56:06 China's micro blogging platform. And it became this kind of platform and hub for young feminists all across the country. So much so that she became dubbed kind of the godmother of Chinese feminist

56:17 activists. Um, and they organized all kinds of campaigns together. The most famous being the bloody brides protest in 2012 where they walked down tienmen kind of dressed in these fake wedding

56:31 gowns splattered in fake blood to raise awareness of domestic violence. And all of this was really exciting until 2015 when um there was an arrest and detention of five feminist activists

56:44 known as the feminist 5. Lupin just happened to be in New York at the time and ended up staying there out of fear of repercussion. Um, and although she was a little worried about the movement

56:57 going underground and her work no longer being relevant, it turns out she still could. But she was just doing a lot of that work from the diaspora and online um, and did a lot of heavy lifting. for

57:08 example, when China's me too movement kind of burst forth in 2017 2018. >> That story about Mao Bali, I hope I've said his name correctly. I mean, it's an extraordinary story that sounds like it

57:19 should be it should be a movie. I'm sure it will be a movie hopefully in English as well. Um, but that gets to the heart of what we were talking about a moment ago with Wuhaning. You know, this this

57:27 this tension between creativity, economic dynamism, and then just a a change in social morals and social values. If you're a conservative, you won't like that. And if you're not, you

57:38 probably will. If you're a gay person, you definitely will. Um, and I suppose here's an interesting question for me is that this relationship to the internet of personal exploration, um,

57:51 self-examination, maybe a critique of the society that surrounds you. In the case of Ma Bali, you know, feeds through to entrepreneurialism and and a hu a huge business demand, you know,

58:02 obviously very successful. And that really gets the heart of lots of technology companies, right? Do do you think those kinds of entrepreneurs are now being produced under Xi's China? And

58:12 that is that pipeline still there of you know personal discovery and exploration to new business models, new business ventures that you know maybe were inconceivable 20 years earlier because

58:23 that's the strength of the US model, right? And some people say that's the weakness of of the Xi model. You know, Xiinping thought what what's your view? >> I think yes. I just think that the type

58:34 of entrepreneur that's being produced is very different. And if we were to kind of divide the different entrepreneurs and the types that have emerged over the last three decades, I think they are all

58:47 innovative but innovative in different ways. Um both under and not under the C period. Right? So the kind of typical or archetypal entrepreneur that we think of and that I think of as part of Maali's

59:02 generation is Jack Ma and this is someone who came of age when China is opening up to the world. So there's a sense of you know the west can produce this, Silicon Valley can produce this.

59:16 Let's create that at home but better. um the kind of personality and kind of public presence of that type of founder is very gregarious and open-facing and loud and bold, right? And they're bold

59:29 in a kind of public facing way as well. Um the emphasis there is also then rooted to the technology which is the browser-based internet which was very much about connecting people, connecting

59:42 people with one another, connecting people to the consumer, right? And so I think all of that um kind of selects for a certain type of open-mindedness um and a desire to kind of connect China

59:57 and the world and that's what I associate with Jack Ma right and that generation of entrepreneurs. Then you have the next generation which arguably did come of age and become famous when

01:00:08 Cinping had also taken power and this is people like Jang Yiming who is the founder of bite dance and so Jangy Ming kind of created bite dance in 2010 and Tik Tok really emerged in the mid 2010

01:00:23 so 2016 compared to someone like Jack Ma he's still incredibly innovative. Bite Dance arguably is a much more successful company on the global stage than Alibaba, right? By Tik Tok is the most

01:00:37 influential social media platform not just in China in the world. And I think what they were producing then was not just okay, we're going to take a product from the west and try to recreate in

01:00:46 China, but it's like let's create something homegrown and then make it a global platform. So I think the kind of archetype of the entrepreneur in the mid210s is very much rooted in the

01:01:00 mobile internet in particular, right? How can we create something in China unique to the mobile internet which has taken off faster in China than anywhere else in the world and then put that out

01:01:10 into the global web. That being said, they were they're much more cautious at least politically in relationship to the state than their predecessors. I don't think I've heard Jungie Ming give a

01:01:21 single interview after 2016. He's almost the opposite of Jack Ma. Jack Ma is famous for like performing Can't Youar the Love Tonight, dressed up in like rocker garb in front of 16,000 people.

01:01:35 Jangy Ming wears kind of the same t-shirt and pants combination every day. So there is this sense of reticence and this sense of like we are going to create this very fascinating product but

01:01:46 we're not necessarily going to push for any type of like liberal change in maybe the ways >> the entrepreneurs were thinking about in the 80s and then today you have

01:01:55 >> um a cohort of founders who were who are creating AI labs and AI companies and in many ways they are just as if not even more um kind of influential ial than their predecessors

01:02:11 um and not any less innovative. So the names that are coming to the top of my head are people like Leang Wenfong who is the founder of Deepseek as well as people like Yang Jerene who is a founder

01:02:24 of Moonshot. um Tangia who founded Jupu AI. And so you have these leaders and they're very different in that they all come from Ting Hua for example, Tinguangu Tinua University which is

01:02:37 essentially kind of like the Harvard of China um and produces a lot of technical talent. Um and they all have very very technical backgrounds. So the type of founder that's being produced today is

01:02:50 are people who like really understand the nuts and bolts of the technology. Um and they compared to their predecessors are very very quiet. Um I don't think Yang Wenfong has given a single

01:03:03 interview ever. Um and I think here what they're prized for is their ability to kind of push the frontier of a technology, right? not to necessarily um commercialize it as quickly as

01:03:17 possible or like create a very cool social platform that connects people with one another. Um but that profile I'm still watching and trying to understand.

01:03:27 >> That's interesting. So just to just to massively overgeneralize that Jack Mar cohort kind of was seeking to imitate you know western entrepreneur charismatic business person and what

01:03:37 you're saying is a newer cohort very much stem-minded um less gregarious and and and as you seem to insinuate this the associations of political change being downstream

01:03:48 from technological change are kind of are less loud than they were 20 years ago. >> Definitely. I'd say they're probably much more cautious and but they're also

01:03:58 probably much more confident like they're confident in their ability to build without the help and influence of Silicon Valley um without the approval or the need of Silicon Valley right

01:04:10 because I think they've seen that China can innovate which you know in up until 2014 2016 I think the narrative was China can't innovate because it doesn't have XYZ it doesn't have political

01:04:22 freedom freedom of speech And that narrative has kind of been thrown on its head. >> When does that when does that change? Because I mean I I remember having

01:04:29 conversations really as late as COVID saying that you know China is going to have global leadership in at least some technologies, renewables, electric vehicles and so on. That was just to me

01:04:37 that was obvious by virtue of the scale of the domestic market. Um and people in this country just weren't having any of it. But like you say I think even amongst many Chinese that wasn't

01:04:47 necessarily all that clear until maybe a few years earlier than that. So when when is that inflection point that domestic Chinese industrialist entrepreneurs say actually we can be the

01:04:56 best in class and we we don't just need to imitate America we can actually sell our products to them. I would say 2014 with the arrival of these entrepreneurs like Jang Yiming who founded by Dance. I

01:05:08 think they a lot of them I think he even wrote in his blog going to Silicon Valley kind of looking around and being like okay this is pretty good but the next technological revolution is going

01:05:18 to take place at home there is a sense of we can create something better I think. >> But where did that come from? Cuz you know you to bring it back here Europeans

01:05:26 don't have that right now. you know, there's there's there's clearly an ambition from some places like, you know, France with Mistral and um in Paris and whatnot and Macron is talking

01:05:34 about technological autonomy for Europe. Clearly, it's it's a pipe dream right now, but China has the confidence to do that stuff and has for a long time. I'm just I'm so curious where it came from.

01:05:44 >> Yeah. With that particular shift and then I think there are other shifts that kind of accelerated that narrative. It's it was the arrival of the mobile internet. And you know now when we think

01:05:56 about the mobile internet and how mobile everyone else is everyone is in the world it it doesn't come as this huge kind of transformation but back then in 2014

01:06:07 like the the speed with which China embraced mobile was totally kind of mindboggling right it it the the kind of word of the day was leapfrog because you were going from a few years ago like

01:06:25 carrying suitcases of cash to pay your rent to doing it all on WeChat, right? By the time I was arriving there, like everyone was using QR codes to make payments. And the shift of that and the

01:06:40 pace of that was much much faster than what had happened in the US or anywhere else in the world. And so there is this sense I think among entrepreneurs that we're living in such a deeply connected

01:06:54 society. It's so much easier to build a product and a platform on that right if so many people are using mobile phones. Um let's take Jungy his first product to which means kind of today's headlines.

01:07:10 It was a news app and his kind of revelation was everyone's using their phones. He was sitting on the train one day and he noticed that people were using their phones to read the news. And

01:07:20 he was like, "What if I created a platform that just fed people the news they wanted to read?" Like, I wasn't just going to connect people with people or people with cars, which was what, you

01:07:32 know, Mark Zuckerberg and Travis Kalanick was doing, right? He was like, I'm going to connect people to the information they want to see. And given the fact that China had such a wired

01:07:42 kind of population and the fact that they were so embracing of new technologies and how easy it was to collect that data, it meant that total could grow huge and and become really

01:07:55 popular really quickly. And the algorithm that fueled to was what would be the kind of backbone of the algorithm that fueled Doí and Tik Tok, right? So Tik Tok I think is a big kind of turning

01:08:08 point in the public imagination and the global imagination of China's ability to innovate. Um and so much of that was rooted in the the arrival of the mobile internet.

01:08:19 >> You know people at the moment are talking about how you know how many millionaires are leaving this country. Um you know it's questionable about the accuracy of some of those figures and

01:08:27 then that's something that's also said about China. China's losing loads of millionaires. But what I find intriguing is it's seeing a net addition of PhDs. So I think more PhDs are now going back

01:08:35 to China than leaving. I think that's a great place to be and it speaks about that level of sort of intellectual confidence about the country inventing the technologies of the future.

01:08:44 >> This date of 2014 and self-recognition of China as a potential global leader with technologies. It's around then we also see the for me anyway the emergence of lots of quite um

01:08:58 epochal Chinese science science fiction and you me mentioned Chinese sci-fi already. I think some people um will be familiar with I'm sorry for pronouncing this name like uh like I am Xiin Lu

01:09:11 >> uh yes yeah so Lin is how he's referred to yeah um people like that you know fascinating fascinating stuff and for people who aren't aware you should absolutely read

01:09:22 the threebody problem amazing trilogy where does Chinese science fiction fit in all of this and this idea of you know a country on the cusp of modernity but also inventing the future These two

01:09:33 things to me anyway as an outsider seem to go hand in hand. I'm curious about the relationship between them. >> Definitely. I think one of the key reasons why Chinese science fiction took

01:09:43 off when it did, which was during this period of 2014 to 2016 was the ways in which Chinese technology was transformative and were the ways in which the internet and the mobile

01:09:55 internet was kind of exploding into Chinese public life. And so I think it probably did two things. On one hand, um because technology and the internet was transforming Chinese society so quickly,

01:10:09 there was a sense of kind of um excitement, but there was also a sense of anxiety and a sense of uncertainty, right? Re where this world was going to head, right? I think a lot of people

01:10:23 wanted some kind of um meaning making around how technology was going to change the future. Um, even just like walking around Beijing or walking around Chungdu during this

01:10:36 period or when I arrived slightly later in 2017, it often felt like I was kind of stepping into some kind of cyberpunk fiction, right? Aesthetically and just in terms of the vibes, it felt like

01:10:48 things were changing very quickly. And so, um, domestically, I think the appeal of that type of genre was this desire for meaning, this desire for like a prophet or a soothsayer to say, "What's

01:11:04 going on?" Um, one of the people that I profile in the book is a science fiction writer called Chenzio. And I found it fascinating that it wasn't just readers and science fiction nerds who were

01:11:16 turning to him for advice. like he was getting invited by like 10 cent and like these tech companies and academic institutions to just like talk about things that you you know even though

01:11:26 he's a very smart man like completely outside of his pay grade cuz they saw him as a prophet of the future. Um and so domestically I think that's how that's how kind of science fiction

01:11:37 became so popular. I would say globally um a lot of it can be attributed to Leotasin and the threebody problem. Like a lot of him a lot of science fiction writers consider him to be the kind of

01:11:52 tent pole and the man who just like propelled Chinese sci-fi onto the global stage. Um >> he's the goats. >> Exactly. Exactly. And um a key reason

01:12:04 was the fact that he won the Hugo award in 2015 and was the first Chinese person to do that. And then suddenly, you know, Barack Obama was reading him and putting him on his kind of list of must readads.

01:12:16 I remember Mark Zuckerberg was reading him. And so he was kind of propelled, you know, into um international media as this science fiction star. And this kind of coincided exactly as this shift that

01:12:28 we're talking about of China suddenly becoming a technological powerhouse um somewhere that needed to be emulated and understood and not just kind of a um technological backwater or a copycat

01:12:41 nation. And so I think the fascination with Chinese sci-fi also kind of coincided with that. >> I mean for me it was a really striking moment. I remember reading the trilogy

01:12:50 in um I think maybe 2020. Um and the first the first one is beautifully translated. The other two aren't so great, but they're all great. They're fantastic books. And I remember thinking

01:12:59 after finishing that final part of the trilogy, you know, what kind of culture gives rise to such an extraordinary mind, such an extraordinary person, such an extraordinary storyteller, you know,

01:13:08 and it's similar to, you know, if you read the county Monte Cristo um by Dumar and you think uh uh what kind of culture gives rise to somebody that it can just tell such an exquisite story. Um and it

01:13:22 did in a way peique my interest more in Chinese politics than any sort of you know non-fiction in a way you know like I can read your book fabulous book or Karen

01:13:32 how or Dun Wang Dan Wang um uh but it really was a wakeup moment for me so are there others like him or or this idea now of you know Chinese sci-fi being at the cutting edge of that genre is

01:13:47 actually just one dude who's just a generational talent or or are there other writers being listened to at scale, you know, by by senior people in in commerce and

01:13:57 politics like uh CCl. >> Yeah, many I would say there are definitely tons of Chinese science fiction writers who are kind of respected and lauded. They might not

01:14:07 have received the same amount of attention, particularly global attention as as Leotin, especially, you know, like no one has a Netflix TV show yet, but you know, just some names that I'll

01:14:17 rattle off, Chenzuan or Stanley Chen, who I profile in my book, has had an immense amount of influence at the very least domestically, but he's also invited to participate in, you know,

01:14:27 conferences around the world from COP to like artists residencies in LA and is kind of influential at least within the science fiction community. Um, you have a woman called Ho Jing Fun who

01:14:40 fascinating story is a kind of macroeconomics researcher by day and focuses on the effects of automation on the economy and she does most of her science fiction writing at night. Um,

01:14:53 but she wrote a short story called Folding Beijing which ended up winning the um, Hugo Award in 2016. And so she became for for best novella and she became the first Chinese woman to do so.

01:15:06 That story folding Beijing, I don't know if you're familiar with it. >> I've read it. No. To my immense, you know, >> apparently I think it also has been it's

01:15:14 very short. It's a very short and quick read and at some point was I think someone was planning to make it into a film. I don't know what what what has happened to that. But um the premise is

01:15:24 that Beijing in this fictional world is divided into three and um it kind of rotates like a cube and it's the first class, the second class and the third class and when two of the classes go to

01:15:37 sleep the the next class kind of wakes up. The the the earth rotates and they wake up and they kind of align along um how we think of the first, second, and third classes. So the first class is the

01:15:50 elite. They're wealthy. They've got blue skies. They've got beautiful treelined homes. Everyone has a job that they love. These are also kind of people in polit political power. Then you have the

01:16:00 middle class um which is what we would associate with the middle class in our world. And then the third class are primarily waste workers. So they were the people who first came built the

01:16:11 whole folding infrastructure and then now just process the waste of the first two classes. And it really struck a chord in 2016 when it was published um because it resonated so deeply with

01:16:25 people who were frustrated with kind of inequality in Chinese cities especially for migrant workers who really identified with the third class. Like here were the people who came to the

01:16:36 cities, built it from the ground up, you know, built the buildings, worked the factories, were the kind of delivery drivers and nannies. And in 2016 2017 there was this process of evicting many

01:16:49 of them and having them forcibly leave the cities because their labor was no no longer necessary and so folding Beijing became really popular and a topic of conversation and kind of social

01:17:02 discussion at the time. Um, yeah. So, Ho Jing Fang, there's another writer called House Hansong who is slightly older than the two that I mentioned who writes these all kinds of science fiction

01:17:14 stories um as early as like 2000 the early 2000s to present day. Um, some of his stories are pretty scathing critiques of some of the um kind of problems that of China's political

01:17:28 system. I think one story that I really enjoyed was called like Bullet Train. Um, I'm gonna have to double check that, >> but it was written, I think, largely as a response to um the I I'm not totally

01:17:43 sure on this. I think it was written in response to the WJO train crash, but um he was kind of criticizing a society that moved at such fast speed, but to the kind of um harm and detriment of the

01:17:58 people and its me. >> Is science fiction a speculative fiction? Is that one of the primary means by which people now have these political conversations which would

01:18:06 otherwise be off the table? Because as you were talking there about folding city, I I thought of Thomas Moore in Utopia. Now many people think of utopia as you know one of the first um

01:18:18 exercises in utopian thinking but actually it was intended so we're told um it was intended as a critique of Henry VI's England by by Thomas Moore about how it was being misgoverned. was

01:18:29 holding up a mirror to a dysfunctional reality. Is that is that actually quite a a common thing with the with the genre of science fiction in China?

01:18:40 >> Yeah, I would say that um it depends on the story and it depends on when it was written. I would say it's like a lot harder for that to take place with stories that are written today. Um,

01:18:56 for example, I don't even know if Folding Beijing, if it was written today, would be published. >> Interesting. Um, >> a publisher wouldn't pick it up or the

01:19:03 writer would selfens. So, where on the pipeline would that >> all of it could be true, right? I think there >> at the time there was effort to try to

01:19:12 suppress some of the conversation that was taking place around folding Beijing because it went became so out of hand. But I would say yes, definitely like science fiction h is

01:19:24 um a really kind of fertile and compelling place for people to critique kind of technological upheaval and critique technological progress at all costs because it's not tied to any

01:19:40 particular vision of history, right? It's kind of veiled by the future. you don't have to be you can you can set your story outside of China, right? Um you can set your story in the United

01:19:53 States and it could come across as a critique of another country, right? And so I think it has the benefit of that that veil of having kind of multiple visions of the future. Um that being

01:20:05 said, I think it's still kind of hard to be on the nose. Um, even something like Leotin's the three body problem, you know, some people have said it was published in 2008, but it's unclear

01:20:17 whether or not something like that could be published today. Um, the I don't know if you know this, but the Chinese original and the English translation are slightly different. Um, the English

01:20:29 version begins with a scene from the Cultural Revolution and so is a Netflix TV show. Whereas, if you read the Chinese version, that scene is kind of buried in the middle. And Kenlu, who

01:20:40 translated the three the first volume of the three body problem, um, kind of brought this up with scene and said, "Hey, I think this scene would actually work so much better here. Can we move

01:20:50 it?" and he said, "Oh, that's originally where it was." >> But my publisher suggested that we kind of hide it somewhere in the middle, so that's not the first thing that, you

01:21:01 know, sensors read when they're deciding whether or not this should make it through. Um, so would that book even be published today? It It's really unclear. >> What did you think of the Netflix

01:21:13 series, by the way, just quickly as an aside? >> Yeah. Um, I thought it was not bad. >> You're too diplomatic. I thought, okay, I thought it was terrible cuz it was it

01:21:22 was there was so much push back, wasn't there, from these Chinese nationalists online saying this appalling production of this wonderful Chinese book. >> Yeah. I think maybe their main gripe was

01:21:31 the fact that >> it just wasn't set in China, right? It just like all of the actors were foreigners and I I get why they made that artistic, you know, decision, this

01:21:42 desire to make it more relatable and more kind of accessible to a popular audience. >> I don't know, man. I thought it was ter I thought it was terrible. I thought it

01:21:49 was terrible. >> It wasn't amazing. Let's say that. >> Yeah, it's an amazing book. And interesting, you know, this idea that fiction can serve as a mirror for

01:21:57 domestic regimes and governments when you talk about foreigners. I mean, another example that is Montescu, right? The Persian letters. You have two Persians slagging off. I think it's

01:22:04 ancient, I can't remember. They're slagging off, you know, various bits of government which at that time Montescu is experiencing in um in France and in Europe.

01:22:14 I mean that's pretty that's a pretty big deal that you're saying that the three body problem might not get published in China today. So has has China under Xihinping

01:22:23 has it become a less intellectually culturally interesting vibrant place over the last 10 years? Um that's a big question and I don't know if I don't know if I can necessarily

01:22:34 generalize right because I think in so many ways yes depending on like what sector you're looking at what specific areas of discourse that you're looking at but in many ways no and so the ways

01:22:48 in which I would say yes is the kind of pluralism and vibrancy and this the kind of amount that you can share and express yourself online. I think that has been constrained quite tightly. So the way

01:23:04 Boa of today looks incredibly different from the way Boa in 2010 to 2013, right? That was a period in which all kinds of um big V's, that's what they were called, verified influencers were taking

01:23:21 on to that platform to express their views on everything from like constitutionalism to um you know independent media and press freedoms. Um people were using it as this this kind

01:23:34 of space to call truth to power. Um they were kind of calling out corrupt officials on that platform. You know it was very very vibrant and very lively. Today none of those conversations would

01:23:46 be taking place on Wayboa. It's become a primarily um kind of celebrity entertainment focused platform. every now and then a conversation that will come up that is quite interesting um and

01:23:58 sometimes quite provocative but will very quickly get shut down right so in that sense I think it's become much more constrained but then you know if we were to look for example at conversations

01:24:12 about um feminism and what does it mean to be a woman in today's China I would say arguably even though there are more constraints on what can and cannot be

01:24:23 said. I've seen that become much more vibrant and women are kind of um even if they're not ex explicitly expressing kind of um opposition to the party state, they are expressing completely

01:24:41 new views on what on motherhood and marriage and how they want to live their lives as women. You know, there are much many more women who are comfortable being single. um women who are talking

01:24:51 about egg freezing um women who are debating the merits of taking their husband's last names you know um and so I think there is a lot more space for women to think about their place in

01:25:04 society than when you know Xinping first became the leader in 2012 um and so there are many examples of that I think places where areas that have become much more constrained but

01:25:17 then areas that have become much more vibrant I'd say another area that has become much more vibrant that might be of interest is just like the the narratives around tech entrepreneurship,

01:25:27 right? I think um it's just become a lot more sophisticated in terms of how people understand and relate to the west in terms of this kind of cultural confidence and this ability to kind of

01:25:39 build new ideas and build new ways of seeing what it means to start a tech company. Um, I think maybe 10 years ago there was a lot more of how can we emulate what's taking place abroad and

01:25:52 bring that back home. And now there's more of this sense of like how can we cultivate something homegrown and put it out into the world. has has the I mean awe is probably a strong word and I

01:26:02 doubt you know people in general have had you know a sense of awe about the west for a while now but has that sense of admiration has that has that been

01:26:12 diluted in the last 10 years I mean because I presume that goes hand inhand with this increased self-confidence and actually there were certain expectations or views or assumptions about the west

01:26:23 which we were wrong about is that something you might hear from from a more liberally minded Chinese for instance >> absolutely I would say there's like 100%

01:26:30 been a dilution this sense of and this is I think some a sentiment that is echoed by all kinds of Chinese people both on the conservative end and the more liberal the kind of patriotic and

01:26:43 the more oppositional. Um I think for a long time the west and in particular the United States was kind of viewed as this beacon right this this benchmark that China had to reach. There's this phrase

01:26:56 that the moon is always rounder in the west. There's this sense like you know like if you like the dream was to get a student visa, go abroad, get a a university degree abroad and stay there.

01:27:09 Um, and I think that narrative has been slowly shifting. Um, as early as I'd say like the 2010s with um, a term, you know, I remember a term became popular in the 2010s, haway, which means um, it

01:27:23 literally means turtles or like sea turtles, but the pun on that phrase in Chinese, it means like overseas returnees. So I remember in like the 2015 2016 period a lot of kind of

01:27:35 Chinese students were realizing oh the job opportunities that I'm most excited about are back home and this kind of dream of staying abroad and kind of living the American dream was no longer

01:27:46 compelling right and so everyone wanted to return to China. I think that kind of disillusionment and shift has become even more marketked just in the past year and I think um it is now taking

01:28:01 place not just among Chinese people but among people living in the United States and living in the west right I think we're seeing this with the emergence of these trends like China maxing and this

01:28:13 weird vibe shift of Silicon Valley China envy right there's like all kinds of people who are now doing these like two week trips to China and being totally stareyed and being like, "Wow, China's

01:28:24 building these humanoid robots and they're they're, you know, like they've got highspeed rail. There's like obsession with Chinese highspeed rail." Um, and I think a lot of that is less

01:28:34 about China and more about kind of the West's um disillusionment or maybe disappointment with its own dysfunction. And so I think that's maybe the biggest turn that we're seeing particularly with

01:28:50 things like the um launch of Deepseek R1 last January which awoken so many people in the US to kind of how quickly China was catching up and also with more kind of mainstream cultural phenomena like

01:29:03 the the migration of Tik Tok refugees to RedNote also that month um where people were realizing oh there's actually this really vibrant online sphere here and it doesn't look too different and actually

01:29:14 might be superior two hours back home. >> That was an amazing moment, right? I mean, you talk about that in the book where you had American people going onto this this app and they were sharing

01:29:24 pictures of their cats, right? >> A payment for people telling them, walking them through this new platform. >> Yeah. Yeah. I mean, uh, when I when I first encountered that moment and saw

01:29:35 all these kind of American Tik Tok users migrating into Red Node or Xiaoongu, I the the kind of first um feeling that I got was one of delight. You know, I I think primarily delight because this was

01:29:49 the first time in a long time that I'd seen just like ordinary online users who had been so siloed from one another for so long just like goof around and share the kind of daily facts of their lives,

01:30:04 share their like rent prices, you know, share what they did for work. Um, and these photos of their cats as you mentioned. And I think a lot of my delight was rooted in the fact that this

01:30:15 hadn't happened in a long time, right? The narratives that we're being fed about the other in each country has become increasingly um a narrative of demonization, right? A

01:30:26 narrative of how bad the other society is. And then >> and that exists in China as well. There's a >> absolutely

01:30:32 >> United States is increasingly viewed as a toxic society. >> Absolutely. So um one phrase that has become really popular in China and Chinese social media is this phrase kill

01:30:43 line or shashen. And it specifically refers to a moment when society has become so impoverished and devastated and decrepit that it can no longer return to what it was. And unfortunately

01:30:57 like kill line is the term that is being used to refer to American society. So you get these like photos and videos of like homelessness and drug use and gun violence and it's paired with that

01:31:09 phrase like America has surpassed its kill line and um >> where does that great phrase obviously it's not referring to great things but where does that come from kill line?

01:31:18 >> I'm not sure I'm not sure what the etmology is. I'm going to have to look into that. >> I wonder if it's from science fiction as well. Yeah, but um yeah that like you

01:31:26 know it obviously there is like some kernel of truth just in the way that some of Silicon Valley's envy of kind of China and China maxing is rooted in some kernel of truth but it's an ex

01:31:38 exaggerated one right it's like America is not just guns and violence and poverty um but it it's a way to kind of um maybe grapple with some insecurities that Chinese nansens feel themselves

01:31:53 around the country's own economic stagnation and kind of unemployment prospects. It's much easier to deal with that and the discomfort of that when you like look across the Pacific and you're

01:32:03 like, well, they have it really bad. >> So interesting. Yeah. >> So your hypothesis is that they're both projecting feelings of insecurity in the other. I mean, you talk about that in

01:32:12 the book, right? So you open up two, you know, two different platforms, two different languages, and you have two different interpretations of events. You know, one is that China's on the verge

01:32:20 of collapse. you know, these people have predicted 25 of the last, you know, two Chinese economic downturns. Um, and then on the other one, you know, China is ready to become, you know, number one by

01:32:31 2050. Um, and there's this interesting kind of view from both sides that the other is in decline. So, the West is now very, um, habitually referring to Chinese economic growth stagnating,

01:32:42 which is kind of inevitable. It will slow down. Obviously, the working age population is literally shrinking, very low fertility rate. And you're saying the same thing is happening in reverse

01:32:51 with regards to China. So you have I I presume you have videos of people, you know, taking opioids, open air opioids on Skid Row or something and walking around like zombies and this sort of

01:33:01 stuff. >> Yeah, there's there definitely is like a love of criticizing San Francisco in particular and the homelessness population, how like America just can't

01:33:11 build enough homes, right? because you know Dan has probably mentioned this in his book but uh China and the US have completely different um problems when they come when it comes to the real

01:33:23 estate crisis right China has this like surplus of apartment buildings and just like ghost towns of empty homes whereas in America like there just isn't enough capacity to even build homes for people

01:33:34 and so I think the the sight of people kind of wandering around cities complet unable to find a place to sleep is something that the kind of Chinese user who wants to like push a kind of shroud

01:33:49 and Freud, you know, a kind of like we have it better than you. Um, it's a great kind of video to to share around and spread. >> I mean, Dan says that Chinese and

01:33:57 American sort of internet users are obsessed with one another, not least because their cultures are so similar in many ways, which is a really interesting thought. I suppose in the middle of all

01:34:06 of this is literally um, if you're going across Eurasia is Europe. How how do Chinese look at Europeans particularly in the context of the last 15 years because we're talking about declinist

01:34:16 narratives um you know maybe the excesses of social liberalism or um economic stagnation I mean it's pretty clear that Western Europe in particular has major problems there. How do Chinese

01:34:28 people kind of view that? What are the online narratives around it or or are they not even fussed about Western Europe? Is it just some are they sometimes? Yeah, my instinct was that

01:34:38 and obviously I don't want to generalize, right? I think there are probably cohorts of Chinese people who deeply admire Europe and cohorts who maybe completely um reject Western

01:34:49 Europe, but I'd say there definitely isn't this kind of dominant narrative as there is in the US of kind of deep envy and this desire to be like I think Europe is almost like Disneyland.

01:35:02 It's like a, as you said, a place to go to vacation, like a place that has a lot of culture, a place that is maybe um highbrow and a little snoody, like a place where you can go and consume

01:35:14 things. I think that's maybe like the primary association of Europe right now. Um, but maybe things will shift particularly among people who are maybe like more politically minded or or

01:35:29 policy makers and they might perceive Europe as um a potential ally or like a counterpoint to the United States which has become in many ways an antagonistic figure. Right? I think um that is also

01:35:44 potentially a perception among among those who aren't just thinking about their own lives and travel and um where to go to next >> and and finally on the internet you know

01:35:54 there is there's a cultural conversation in this country certainly um and across the west I think people like cory doctor at the heart of it where actually there's there's a revision there's a

01:36:04 collective revision going on assessing you know the costs and benefits of a digital first internet culture over the the last 25 years. Um, and people that were maybe previously quite optimistic

01:36:15 and utopian about it are now kind of blackpilled on on the internet amongst Chinese people. Is there something similar? Has has the internet disappointed as a tool of liberation

01:36:26 which of course is a theme that runs throughout all the stories in your book or or are people still optimistic about it because you know post 2008 people in Britain have this

01:36:38 decline narrative but clearly there's a very different reality in in China. Does that carry through to assessments of of the digital sphere as well or are they increasingly skeptical or even cynical

01:36:48 about about this technology? Yeah, my instinct is that the kind of cultural conversation and the tone and the vibe around the internet as something positive or negative is still quite

01:37:03 positive. Like it doesn't feel like it's captured the same sentiment of being blackpilled >> as it has in the west. And I think a big reason behind it is just how quickly it

01:37:18 transformed people's lives in a very compressed amount of time. like the internet is associated and emerging technologies in general is associated with um a kind of huge improvement in

01:37:30 daily life and livelihood right and I think it isn't that associated it isn't associated with that as much in the west just because the amount of transformation that has taken place has

01:37:41 not been as radical right we weren't jumping from um suitcases of cash to being able to just like scan a QR code there was a period of like oh everyone had credit cards and then from credit

01:37:51 cards. So like I think the the kind of um lived experience of improvement is so much more visceral among Chinese people that is also playing out I think in conversations around AI for example. Um

01:38:06 I think at least in the west and in the US we're hearing a lot of narratives that are rooted in a kind of dumerism and a kind of fear of um both near-term risks but also like catastrophic

01:38:17 existential risks. there's this sense that of fear surrounding what AI can potentially do. Um, and I think in China those conversations certainly do take place, but they don't they don't yet

01:38:30 feel like the dominant tone. Um, and again, this is not to say everyone's like super optimistic and jolly about the technologies. Like there's certainly conversations about what it's doing to

01:38:41 people in terms of their mental health, in terms of safety and kind of misinformation, but um the kind of overall vibe just feels a little bit more forward-looking and optimistic.

01:38:54 >> It's optimistic about the future and less doomerist. On that note, Elang, it's been fabulous to talk to you. Thanks for joining us. >> Thanks so much for having me.

01:39:02 >> That was really fun. >> Yeah.

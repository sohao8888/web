视频链接：[https://www.youtube.com/watch?v=AsShiDx44nY&list=WL&index=9&pp=iAQBsAgC](https://www.youtube.com/watch?v=AsShiDx44nY&list=WL&index=9&pp=iAQBsAgC)
视频发布时间：2026-04-15
频道名：TBPN

## 转录内容

00:00 I see a large IPO on the horizon. You're surrounded by jungle. Hold your position. missed information. According clearing order inbound,

00:44 >> let's just roll. We are surrounded by general. Hold your position. Come on. Get up. Trust the experts here

01:03 to we are expert founder knowledge. I see multiple journalists on the horizon. Stand by.

01:31 >> UAV online. Blaze win. Double blaze. Triple blaze. Double kill.

01:55 Fight is w team deathmatch. We are experts.

02:33 Triple blade. That's just wrong. Right. >> Hockey clearing order inbound. We are surrounded by journalists. Hold

03:02 your position. Strike one. >> Strike two. Activate golden retriever mode.

03:42 52 founder. >> You're watching TV. Today's Wednesday, April 15th, 2026. It's tax day. I hope you paid your taxes. Uh we have a great

04:14 show for you today, folks. Bunch of crazy stories going on. Allirds is now an AI company. Uh Snap is restructuring the entire company. Uh Amazon's buying Global Star. There's new info on Apple's

04:27 new AI glasses. We're going to take you through it all. We also have a bunch of guests joining. One, two, three, four, five, six, seven guests joining. Kea Dickinson, Aaron Duza, Michael McNano is

04:38 now at Union Square Ventures. Uh, >> massive pickup. >> Yeah, we're very excited for that. Uh, Wade Foster from Zapier is coming on. Uh, an just got acquired by Angel List.

04:48 Uh, Pier Rich split acquisition. >> Split acquisition. I'm not exactly Oh, so so half the company's going to Angelist, half the company's going to let us. That's right.

04:56 >> Got it. I wasn't sure what that meant. I'm excited to talk to you. >> And, uh, Anchor himself will be over at Angelus. Very excited about that. >> Great pickup. Uh, but fun show today.

05:05 S&P 500 rises to a new record. >> Yes. So, why are why am I not wearing a a white suit? It's because although the market is at all-time highs, I don't understand why. Uh, it feels like

05:18 there's never been more chaos in the markets. And uh I'm seeing a lot of a lot of companies that are under pressure, a lot of software companies that are under pressure, a lot of

05:25 companies I know and love under pressure. Uh, but it does feel like the Mag 7 is doing well and some of the bigger companies are doing well. AI is still a mega cycle and there are

05:35 exciting pockets of opportunity in the market but we will be digging >> certainly Allirds is doing quite well. >> Yes. How much is it up today? >> Uh 714%.

05:46 >> So we talked about this maybe last week. That's an insane gain for a single day. Uh but they're completely changing the business model. Uh the Financial Times has a hilarious article uh in

05:57 Alphavville. Alphavville has a great uh great headlines. uh Allirds is turning into an AI compute provider because of course it is and uh it goes through what's happened over the last uh few

06:09 years, few months. There's been a lot of twists and turns with this story but we'll take you through it. So they start by saying ah zeitgeist uh Albergs is a San Francisco maker of wool trainers

06:21 that was once valued at more than $4 billion. That's pretty big for a direct to consumer shoe company. Uh, at the same time darling when it was growing and selling a lot of shoes, you know,

06:32 Nike is a big company. It makes sense that if you could get a piece of that, maybe you could be multi-billion dollar company. But >> yeah, and they were selling a lot of

06:40 shoes. They were very on trend. >> Yeah. I think they got the revenues into the hundreds of millions of dollars and uh you would see them everywhere. >> Bunch of owned retail.

06:48 >> Yeah. Yeah. They definitely had some owned retail stores and were pursuing the hybrid online offline sales model. Uh it the it was working like it was never it was never just like some

06:59 completely hypothetical vapor wear company. Like they they were real shoes. You could buy them and wear them. It was fine. Um but um it was sold last month for $39 million to American Exchange

07:11 Group. The stock having slumped more than 99% since its flotation on the NASDAQ in 2021. And so look at this chart, Jordy. Uh very very rough for all birds.

07:23 >> That is not good. Okay, >> but maybe the next plan is better. We'll figure it out. So, the plan for the shell listing is quote to pivot its business to AI compute infrastructure

07:37 with a long-term vision to become a fully integrated GPU as a service and AI cloud solutions provider. In connection with this pivot, the company anticipates changing its name to New Bird AI.

07:52 And so this was very unexpected. We can talk about where we are. >> With shareholder approval, all birds will raise 50 million via convertible notes from an institutional investor. It

08:01 does not identify. So uh they're going to be able to get at least >> a few GPUs. >> Yeah. >> For that maybe maybe they'll be able to

08:10 plug them in. Maybe maybe a whole rack. They can plug in a rack. >> Um but yeah, big questions around where where are they going to get uh where are they going to get the compute? Where are

08:20 they going to get the the energy? Uh will anyone rely on will be willing to rely on them? >> This feels like >> tons and tons of questions. This feels

08:29 like an institutional investor who says I want to participate in this idea that uh even older GPUs are trading above par and so GPUs are sort of gaining value and they want in on that in some

08:43 meaningful way but they also want to wrap it in a public company that can sort of become a meme stock essentially and then basically everything else about the business will be different because

08:54 the entire shoe business will be sold off and uh and this is basically just a use for the it's it's a use of the uh of the ticker and the listing and the shell and then probably an entirely different

09:08 team, entirely different strategy, entirely different uh everything basically uh new name. So here's the schedule 14A that explains the pivot ahead of a shareholder vote on May 18th.

09:18 adds with respect to the renamed corporate entity we are investigating potential opportunities in the computing infrastructure market including the acquisition and monetization of graphics

09:27 processing units related high performance computing infrastructure uh capable to support high workloads whether from artificial intelligence and machine learning or other uh needs of

09:38 potential future customers and other related assets. Also uh because the anticipated electronics infrastructure business would be less focused on the public benefit of environmental

09:49 conservation which is stated in the company's certificate of incorporation. I guess allirds was a public benefit corporation because the wool was supposed to be more environment

09:58 environmentally friendly and it was uh it was almost like an REI type brand. uh they are doing away with that and so the stockholders are being asked to approve the charter amendment proposal uh to

10:10 remove references to the company being operated for the environmental conservation public benefit. Uh that is not going to be popular with uh the Allirds fans. Uh

10:18 >> oh boy. >> The announcement was enough to establish Allirds as a meme stock at Pixel Time when this went to print. Uh the shares are up 774%

10:28 at 2176 a share uh to give the soontobe Shell a market cap of slightly more than $184.5 million. And so I guess the question you have to ask is if this 50 million comes

10:42 in, they're able to buy GPUs, rack them, get some value out of it. Is that worth anywhere near $184 million? It's a tough sell, but the market will figure it out over the next few days. I'm sure the

10:57 value is Dave Portoy. >> Hold on. Let's hear from >> It's interesting. I mean, $50 million is like not enough to like lease to a Neol, right? Because you just like can't buy

11:06 enough capacity. >> Yeah. >> So, it is interesting. I I don't know who the actual like consumer of these GPUs will be.

11:11 >> Yeah. >> Maybe you can just like resell them on on Open Rider or something. >> Yeah. Yeah, you can resell on Open. like you're running

11:17 >> I mean George Hot was talking about remember he was talking about like he found a building that had cheap power and he was going to just buy a bunch of GPUs and I think he was raising like 10

11:26 million or 20 million to do that and he was going to sell the to the tokens on open router profitably and so there's there's a potential business model there uh also yes so you probably couldn't

11:37 sell to a Neo lab that's doing some huge uh foundation model training run but uh there might be some company that's doing like fine-tuning on some small model or doing some niche model. I mean, again,

11:49 to go back to to George Hutz, like he had a a you know, a couple racks of GPUs that he was training uh self-driving cars on, and you have to imagine that there's lots of like longtail

11:59 applications for uh a for custom models that need to be trained that aren't as big, maybe. I don't know. >> Yeah. I mean, so is this like essentially just a spack

12:08 >> because you're just Yes. >> Everything is different. Yes, it's it's already it was already a public company and they're just adapt they're doing like a massive pivot. Uh I don't think

12:18 they will make any progress at all. No, >> I think that it is entirely a meme. Uh I woke up this morning I was like that is really funny you know taking the the uh taking allirds became a meme right the

12:33 company was basically dying but the meme remained strong >> and uh it's kind of making uh allirds in some way just like became such a part of the uni uniform of Silicon Valley. uh it

12:46 was something that Silicon Valley was mocked for and to take that corporate shell and uh make a mockery of our industry again uh feels feels quite fitting and uh so anyways I'm incredibly

13:00 >> the shoes >> uh even Dave Portoy said I don't get it. Uh >> he loves a meme stock >> and he loves a meme stock. So

13:08 >> can we play this video? >> I have no idea how the actual stock uh will perform. Are you pulling it up? No, I I don't have it here. I think you had it. Um, but all the allirds.com still

13:20 resolves to the full e-commerce website. They have an extra 25% off sale, discount applied in cart. You can get all the different shoes that they sell. I think they sell other stuff too now.

13:30 Um, and so I it'll be interesting to see. I mean, how quickly can they can they disentangle the new compute infrastructure division from the actual apparel and shoe division because uh

13:41 >> well well my understanding is like they sold off all of the Albert's assets. >> Yeah. >> Right. >> Yeah.

13:47 >> So for $39 million they sold it to American Exchange Group. they got the domain >> and so they're just kind of using the they got all the IP as a quicker way to

13:56 get >> but the the ticker remained public and it was just sitting there >> and I think a lot of people are sitting there sitt sitting uh talking to their

14:05 friends being like why did I not think to turn all birds into a neoclap? >> Yeah. Why am I uh we we had a buddy who's a very very smart investor >> who you could just tell wanted to slam

14:18 his head into the table because he's you know spending all this time trying to you know trying to pick uh real winners uh invest in you know fantastic durable businesses and all you know right in

14:30 front of him was um >> uh what in hindsight is like a very very obvious play. Yeah. Um but uh but but again, you know, look looking back at like the history of uh the last time

14:42 this happened was Long Island Ice Te >> uh in 2017, December 2020 20 uh December 21st, 2017. The company announced that it was changing its name from Long Island IC Tea to the Long Blockchain

14:57 Corp. and said it would shift its strategy toward ex exploration of an investment in opportunities that leverage the benefits of blockchain technology

15:07 while keeping its beverage subsidiary. Uh the stock surged immediately after the announcement amid uh crypto mania. Again, this was the 2017 cycle. uh coverage reported jumps of roughly 200%

15:22 and some reports said it rose as much as uh 380% uh midday and and and it basically then just started to like chop uh chop for a few weeks uh and uh ultimately faced uh

15:36 various had a little runin with the SEC >> and they brought insider trading charges >> uh ahead uh uh you know because of activity that happened ahead of the pivot announcement. So, I wouldn't be

15:53 surprised to see um >> I wouldn't be surprised to see uh something similar here. >> The uh Long Island Iced Tea Company was doing 4 million in sales in 2017,

16:06 something like that. Uh 25 employees, like pretty small company back then, and then just sort of wound down. Um there the people are not are not very optimistic that this would work. Uh Ben

16:19 uh says hopefully everyone understands whatever the bird's pivot is they will unlikely uh they will they won't likely secure any power any GPUs at reasonable scale and need a lot more money than

16:32 this to even have a prayer. And you certainly see that with all the other Neoclouds that show up on on cluster max. Um, every Neoclad that we talk to on the show is, you know, raising

16:44 hundreds of millions of dollars and then debt on top of it and is usually uh has a lineage that traces back years if not a decade and has a whole bunch of interesting uh you know unique value

16:56 props to actually uh whether it's the on the software side, on the deployment side, on the on the infrastructure side, on the energy side, actually going and finding power is very very difficult and

17:06 continues to be. Uh but yes, a lot of people are saying this is.com vibes. It is crazy. Catrini says, "Can we please wait until we are at least 5% above previous all-time highs to start doing

17:18 this?" And it does seem like this. Uh if you sell shoes, pivot to a GPU cloud, I guess. And negligible capital has the meme from uh Wolf of Wall Street. The name of the company, Newird AI. It's a

17:31 cutting edge AI native cloud infrastructure firm out of well they used to be out of San Francisco making sneakers but forget that John they are now awaiting imminent deployment of next

17:39 generation GPU compute clusters that have both massive enterprise and consumer applications. Now right now John the stock trades on the NASDAQ at about the price of a cup of coffee. And

17:49 by the way, John, our analysts indicate it could go a heck of a lot higher than that. And John, one more thing, they're up just 160% today. Yeah, what a wild what a what a wild time. Well, uh, what

18:01 keep stay safe out there, do your own research and, uh, and avoid all the froth. Uh, Mike Isaac says, "This is, uh, just going to be the default for any failing entity that owns a significant

18:12 amount of real estate, uh, able to be converted into data centers. I'm waiting for the RB server farms." I don't know if that's what's happening here with real estate. I think it's more about the

18:20 shell entity, the brand. No, not even the brand. I mean, the brand. >> No, the brand. The brand. The like there has to be a goofiness to it. Yes. For it to be have the meme potential. Yeah.

18:29 become >> because I don't think I don't think anybody who's investing in this company actually thinks they will build a great >> NeoCloud

18:39 >> um we just we just have uh you know talked to so many of these of these companies and there are a number of established players in fact they're already

18:50 >> um you know everyone expects the market for inference to be one of the biggest markets of all time. >> Yeah. But that doesn't mean um that doesn't mean that uh that doesn't mean

19:00 that that anyone that that attempts to build a business here will be successful. >> Yeah. Well, uh let's move over to Snap. Evan Spiegel, former guest of the show,

19:09 two-time inerson guest. >> You're saying he went to Coachella and came back and was like rightiz the company. So, he's laying off a thousand full-time employees, which is roughly

19:17 16% of the global workforce as part of an effort uh to reduce cost and achieve profitability. Uh in a memo to employees Wednesday, Spiegel said the cuts are necessary for SNAP to boost efficiency

19:29 as it pursues profitable growth. He cited improvements in artificial intelligence technology that let SNAP employees move more quickly. The company is also closing more than 300 open

19:37 roles. Spiegel told staffers, many of whom were told to work from home on Wednesday, that the job cuts and pull back on hiring will reduce SNAP's annualized cost base by more than 500

19:47 million by the second half of this year. Snap estimated that total revenue rose 12% to 1.53 billion in the first quarter. So 6 billion in total revenue run rate. Uh

20:00 adjusted earnings before uh interest basically IBIDA is 233 million during the period. Snap shares jumped as much as 9% after markets opened in New York. Uh Spiegel wrote a memo. He said, "Last

20:13 fall, I described SNAP as facing a crucible moment, requiring a new way of working that is faster and more efficient while pivoting towards profitable growth. Over the past several

20:23 months, we have carefully reviewed the work required to best serve our community and partners and made tough choices to prioritize the investments we believe are most likely to create

20:33 long-term value." Uh, the stock is down 31% so far this year. And what's interesting is that it it is not really this this SAS apocalypse narrative because even if you vibe code a Snapchat

20:45 clone, you won't have the actual usage data, the network effect that exists. Um but the market has definitely turned on stockbased comp and another of and and just is in the hunt for profitability

20:57 broadly. So um uh >> uh which of course Snap has has never had a uh generated a single dollar of of net income >> when you include stockbased comp, right?

21:14 >> Uh >> I think I I think that always includes stockbased comp. uh and so IBIDA is positive but they they they uh they issue a lot of stock to comp the

21:23 employees and that has that has weighed down on the share price because there's a lot of dilution. Um and while Spiegel is also working to sell a vision for augmented reality glasses which the

21:34 company plans to debut later this year. It has leaned heavily on outside firms to power its AI offerings. Larger rivals are spending aggressively to build and develop their own state-of-the-art AI

21:44 products and infrastructure. The job cuts arrived just weeks after activist investor Arenic Capital Management took a stake in the company and called for swift changes in that memo that we uh

21:54 reviewed on the show a couple weeks ago. Um including a recommendation that Snap cut its workforce in hopes of boosting the stock price. Like many of your peers, you overhired, the investor wrote

22:03 in a letter to Spiegel last month. Unlike your peers, you haven't course corrected. Spiegel's note to employees didn't mention whether the job cuts were related to Irene's recent demands. Uh,

22:13 other major tech companies have slashed their workforces, including Snap Rival Meta Platforms. Meta eliminated hundreds of jobs globally in March and shed roughly 1,000 workers from its Reality

22:22 Labs group back in January. All while ramping up investments in AI. Spiegel suggested AI was one part of his decision for the cuts. Uh while these changes are necessary to realize Snap's

22:32 long-term potential, Spiegel said of the cuts, we believe that rapid advancements in AI enable our teams to reduce repetitive work, increase velocity, and better support our community partners

22:41 and advertisers. And so the the big question that I have generally is like the what is the actual replacement rate? Like how much are they spending on AI? We saw that report from Uber that they

22:53 blew through a a year of budget on AI tools in just a couple months. And um a lot of people were sort of reacting to that saying like well I've used the Uber app for years. It doesn't feel like it's

23:05 changing dramatically. Of course there's manual workflows that internally might need to be done and AI might speed that up. But uh in terms of getting like net new applications, net new apps that

23:18 people actually use and enjoy, uh that seems to be like the next uh opportunity for for real growth as opposed to just uh cost optimization. Um and so the $400 million deal with Perplexity is no

23:32 longer happening. I guess that's been uh pulled back on. And uh >> yeah, I wonder I really wonder why >> uh the Perplexity seen seemingly some very real growth from their new product

23:45 computer. There's been uh they've been sharing some of their uh the the increased revenue that they're seeing from that. Um but uh but yeah that was I think one of the things that uh yeah

23:59 what did what did uh in the save snap now campaign >> uh that was one of the one of these suggestions was to pull out of that >> is to concentrate AI partnerships on

24:09 clear winners like Gemini OpenAI and Anthropic. >> Oh interesting. >> Um so they were not in favor and again it seemed uh seemed like Perplexity

24:17 would be in a position where they would pay the most potentially for that distribution. Um and uh we'll see if they actually backfill that slot or just focus on their own tooling.

24:28 >> So uh the full presentation is up now which you can read through. After nine years of being a public company, 15 years since uh being founded, Evan Spiegel finally decided to put a

24:38 business plan together for how to reach profitability. And so you can go uh click through all of that. Um and uh what else is going on? Oh, you wanted to talk about Anthony Pompiano's

24:50 new Agentic podcast on Wall Street. The show is called Best Stocks, and it's 100% AI generated. Each episode is based off the Agentic Research Articles. Synthetic AI content will be more

25:00 popular than human created content, he says. Uh, and he had it covered in uh in Axial. I I could see a date for >> Yeah. So, so, so a lot of people a lot

25:12 of people are are um Best Stocks is kind of a funny name because it's just like the most generic possible name for a finance podcast. What's your what's your finance podcast called? Best stocks. Uh

25:24 but uh I I think that um historically, you know, the one of the main downsides of podcasts was that they always had this lag, right? They were recorded, >> edited, and then eventually published.

25:38 but people and so like in some ways TV remained competitive as a place where if you wanted to understand what was happening in the markets you turn on CNBC right it's always on uh you can

25:48 always kind of get an update there and so I think that like real time podcast that was part of um part of what I think uh helped us uh uh get some traction early with the show was that we were

25:59 publishing every single day so it was like kind of a real time look into the markets I I think that this show I haven't listened to an episode yet I'll try it on the home. But um I wouldn't be

26:11 uh given the popularity of I think this um there's like a real time like politics one >> uh that that has done very well on Apple podcast. Um I think that I I think that

26:22 this uh show could find an audience, right? It's basically notebook LM but but a little bit more curated, probably a little bit more opinionated. You don't have to like do prompting yourself. And

26:34 um I I would expect this to get some level of traction of people just wanting to turn something on, understand in real time what's happening. Um and it uses obviously the existing distribution. So

26:45 >> uh we'll see. But um not as bearish as some of the the uh other people. >> Well, let's uh switch over to Amazon. Why is Amazon buying Starlink rival Global Star in an 11 billion deal? Uh

26:58 the race is heating up between Amazon and SpaceX. Uh, so Amazon's buying satellite operator Global Star in a deal that the company's estimated at about 10.8 billion, seeking to build a

27:08 business connecting consumer smartphones with satellite inter internet connections. Uh, the deal would give Amazon's LEO satellite ventures a boost as advised with SpaceX's dominant

27:18 Starlink network. The Elon Musk controlled satellite business has been launching satellites designed to connect to consumer devices and signing agreements with mobile carriers. Here's

27:27 what's at stake. Amazon plans to launch new satellite to cell phone service in 2028. That feels far away, but I guess it's only two years away. Uh, a big factor in the deal is Global Stars

27:38 control over Spectrum resources, which we've seen trade hands a few times now. Uh, which Amazon could use to provide satellite links to smartphones. Those wireless assets would enable a plan for

27:49 Amazon to deploy its own. >> God, brace yourself. >> Tell me. >> A space mobile's down 10 and a half% five days.

27:56 >> Selling selling off. selling off on this news. Yeah. >> Yeah. I mean, maybe the people are worried about like a duopoly here. Uh I don't know. Ben Thompson was talking

28:05 about AS. Uh where is it? AS >> he's joining the retail the AS space mobile retail army. >> Space Mobile. Uh yeah, he said uh this

28:16 isn't the only example of leaning companies wanting to avoid being at the mercy of SpaceX. Verizon is at it again uh in terms of their own satellite service, doubling down on their

28:25 investment in AS space mobile instead of coming to a deal with Starlink for not just better service but service that actually exists. So AS Space Mobile is years behind. They don't

28:36 have a constellation actually up and active yet, but they have plans to uh and to that end >> they have concepts of a plan. >> What other company is uh the clear

28:45 leader in that space? Well, it's the one that Ben Thompson expressed hope last year would lean into a SpaceX spark partnership and that was Apple. And so he says the problem he noted is that it

28:56 was hard to see Apple and SpaceX ever resolving who would actually be in charge. Apple clearly agrees because they are not only declining to work with SpaceX. I actually think they were the

29:07 driving force in this Global Star deal. And so uh the the the battles between all the different tech companies continue to rage. Uh >> yeah, and as AS Space Mobile now has a

29:19 heavily heavily heavily funded competitor in the same general category. >> Yeah. Right. >> Yeah. There was a moment where >> like Amazon's not spending 11.5 billion

29:28 and then just going to be like, "All right, we're going to like try to be really, you know, run this super efficiently. They're going to invest heavily have the insane distribution

29:37 core Amazon business." Yep. >> Uh as they get to scale. >> Yeah. They don't have devices and so they won't be fully vertically integrated. But uh it but what Ben

29:45 Thompson's pointing out is that Apple might not want to have a single point of leverage there with SpaceX. And so uh they're they're balancing the two out. Uh overall uh SpaceX's overall Starlink

29:56 fleet numbers around 10,000 operational satellites. Elon had this cool chart of uh 10 to the 0ero, 10 to the 1, 10 to the 2, 10 to the 3, like the exponential every 10x number of satellites, and they

30:09 check them off at at Starlink HQ when they get to the next uh the next order of magnitude. Um the company plans to launch thousands more in the years ahead. Starlink has deployed more than

30:20 650 satellites dedicated to providing connections to cell phones as of the end of last year, connecting more than 12 million people. According to the company, Global Star operates a network

30:28 of satellites and in recent years has provided Apple with satellite links to support features for iPhones. Apple's service allows users to send text messages, call emergency assistance, and

30:37 seek roadside help in areas where cell phone service isn't available. And the Global Star service has always been uh slower than uh it's high Earth orbit, so it's a lot slower than uh a Starling

30:48 connection, but they are already working with Amazon to figure out the next iteration of that. So, Amazon said Tuesday that it had agreed to a deal with Apple to power satellite services

30:58 for its iPhone and Apple Watch and to and to work together on future satellite services using LEO's growing network. Global Star has separately been working with CA Canadian satellite maker MDA

31:09 space to develop new satellites that Global Star would own with capacity dedicated to Apple. So, Global Star's global spectrum rights became more valuable as SpaceX and Apple began more

31:19 aggressively using satellite links to connect phones. So connecting cell phones through satellites is still a nent market. Most consumers who live in urban areas get links through

31:27 traditional telecom providers. Carriers that have struck satellite to smartphone deals have promoted them as ways for consumers to always have some degree of internet connectivity in remote areas.

31:36 T- satellite connects you where towers can't T-Mobile says of its offerings through Starlink. Uh SpaceX of course has a rocket advantage. They have a company uh they have a fleet of Falcon 9

31:47 rockets uh to build Starlink into the build biggest satellite fleet in history. Amazon has been splashing out billions of dollars to other launch providers including ULA and Blue Origin

31:58 to build up the LEO network but delays have slowed Amazon's effort. You have a take? >> Yeah, I mean I I wonder how like smoothly this will lead into um space

32:07 data centers because I know Blue Origin has talked a little bit about doing that. Yeah, >> I think they they got some uh they got some permission from I think the I think

32:16 FCC, but um >> yeah, like I it seems like this is the very like this is the natural endpoint. Uh you're basically just like doing similar things to to to Elon.

32:25 >> Yeah, I was uh I was reading I think Ben Thompson mentioned it about Global Stars like original uh what what was it the is it processing pro? So, uh, so, uh, Global Stars assets are all things

32:42 considered pretty middling. Uh, 24 satellites nearing the end of their 15-year lifespan. So, they only have 24 satellites up there, and they use a bent pipe architecture, which is signal

32:56 relaying only, no onboard processing. So, I think it's actually just a reflector dish. I don't I'm not for I'm not sure exactly how this works, but that's that's what it seems like. Maybe

33:08 there's I mean, he's saying there's no onboard processing. I'm not exactly sure how detailed that is. I want to uh do a little bit of a deep dive on what the bentpipe architecture implies. Uh

33:17 because it sounds like mostly just a reflector dish up there, but it works cuz you can bounce, you know, you have ground station, you can bounce stuff up and still

33:25 >> This is reminding me why did allirds not kind of rally their pivot around uh space data center? >> They should have. Yeah. Huge. >> Why are they doing uh why are they doing

33:36 data centers when when uh you know, compute on the ground? >> Lean into the new meta. >> Yeah, the new meta for sure. Maybe. Yeah, who knows? Maybe next week they'll

33:43 be looking for another story and that'll be it. Uh they have 24 ground gateway stations across six continents. There are some new satellites on the way to keep the constellation going, but it

33:52 seems likely that still on the drawing board, higher capability satellites will be scrapped. Approximately 8 megahertz of the Lband satellite uplink and approximately 16.5 meghertz of the Sband

34:05 satellite down link and N53 terrestrial spectrum for private cellular networks, not phone to satellite communication that is licensed out. So those assets by and large serve one customer, Apple.

34:16 Apple owned a 20% stake in Global Star and had rights to 85% of Global Star's network capacity for the satellite service it provides to iPhones and Apple watches. So that's certainly a valuable

34:27 relationship, but it also meant that Apple had a de facto veto on any Global Star acquisition. And so what he's uh what he's arguing is that Apple is uh very happy that Global Star and Amazon

34:40 are teaming up in this way to provide them with another uh another option. >> Apple's like any we love all capex that is not our capex. >> They really do. They they are the master

34:51 of that. Uh we'll have to come back to the story of uh the Apple uh new uh Ray-B band competitors, the smart glasses uh because we have our first guest in the waiting room, Eva Dickinson

35:03 from the a leads. >> Groos Pea, how are you doing? >> Welcome to the show. >> Doing great, guys. What's going on?

35:12 >> Uh, it is great to see you. I was looking in your background trying to see if we could maybe see >> where >> our own office in the distance. You're

35:23 >> Yeah, we're looking we're looking northwest. Where are you guys? Okay. >> Okay. We are more east. Okay. >> Yeah. >> Um, so not quite, but uh great to see

35:32 you on here. How's your last uh how's your last week been? Was that your Was that your first like uh billion dollar exit? >> First billion. Yeah, for sure. And um

35:43 that definitely definitely the biggest exit that we've been a part of and um yeah, it's been fantastic. It's it's exciting to share the good news and really incredibly thrilled for the

35:52 company. Um spent a lot of time with them this week >> and uh fantastic for the category overall. Uh you you guys have been through it. Uh obviously you never lost

36:03 uh you never lost faith otherwise you wouldn't have invested in goons but uh certainly it's been funny today uh watching all birds have new life uh hope hopefully your portfolio isn't isn't

36:14 getting any ideas you know hey you know uh the supplements category is running away from us but we can pivot to AI compute but um but yeah walk give us uh I I wanted to have you on just to kind

36:27 of get an update on like consumer investing broadly >> can we start with like some background and >> how the fund was set up, how you got

36:33 into investing, all of that. >> Yeah, totally. Um, I started my career in investment banking, uh, joined TPG about 12 years ago, uh, in the consumer group and, and, you know, I think it was

36:49 an incredibly like formative time of learning what private investing was and and, you know, learning about consumer businesses. But what I was thematically excited about was really uninvestable

37:02 for us. I was seeing these incredible companies line the shelves of Whole Foods and Target that were getting more and more exciting every year, taking share of the companies that I had grown

37:12 up with. Uh, and you know, when we talked about them internally in our investment committee, the problem that we faced was they didn't consume enough capital for us to get our kind of $2300

37:23 million minimum check in on the way up. Y >> and we couldn't out bid Unilver or Mars on the way out. >> Yep.

37:30 >> And so my takeaway was like I'm in the wrong seat like I I got to be doing something in the earlier stage some be some part of of the early journey these companies. So

37:39 >> So wait double clicking on that trend that you see. I think everyone's familiar with the boom of I mean there were a bunch of different factors and I want to know your take on on all of

37:49 them. Like Whole Foods at one point had like local buying. So if you could go in and like talk to the local like the Whole Foods in your town, they could actually stock you. They didn't have

38:00 centralized buying. There was also the DTOC boom, uh online advertising, the influencer boom, celebrities getting the space. Like what were you identifying as the undercurrents of that broader trend

38:12 of like new products taking shelf st uh like space on the shelf? Yeah, I mean this was definitely like height of the DTOC boom and so what was being talked about in the technology industry and in

38:24 the press were companies frankly like Alberts and Gasper. >> Yeah. >> And I think that was distracting a lot of attention and capital away from what

38:32 I thought was the most interesting thing which was when you walk through the aisles of a grocery store, you see completely different things than you did 10 years ago.

38:40 >> You saw companies like Kind Bar taking enormous share and transacting with Mars. You saw companies like Dr. uh uh buy selling to Dr. Pepper Snapple for like $1.7 billion. The these were not

38:52 grabbing tech headlines. These were not grabbing traditional venture capital. Um but they were taking share of an absolutely enormous industry. I mean consumer package goods depending on

39:03 where you get the info from is like 7 to 10% of GDP. >> Yeah. Yeah. Bay is such a funny story because uh I mean it has a traditional startup founder in his basement making

39:12 the product grinding unique insight but uh during the DTOC boom they didn't have a DTOC website their website was just links to Amazon they never set up a first party e-commerce site because they

39:25 just didn't need to they went which can make sense for >> Oh it makes a ton of sense beverage specifically >> yeah exactly beverage is really

39:31 expensive Amazon has the the logistics for it um so yeah what what So walk me through the decision and how you actually positioned yourself to get in at the earlier stages.

39:41 >> Yeah, I mean I made a stop at a company called Circle Up. They had pivoted from helping emerging CPG companies raise capital to actually raising a fund. And um TPG invested in the fund. I kind of

39:54 put my hand up and said, "Hey, this sounds awesome. I want to be part of this." >> Um >> did we lose you?

40:02 >> We lost you. >> Oh no. >> It's called Nut Pods. that we eventually did I lose you guys? >> Yeah, just for a second

40:11 called NutPods that we >> Yes. We invested in a company called NutPods that we eventually sold to VMG and then invested in a company called Liquid IV that we pretty quickly turned

40:20 around and sold to Unilver um in about two and a half years and it showed me what the riskreward can look like. It showed me also that the early stage companies had a real pain point at Seed

40:30 and Series A. They needed not just like specific specialized capital comp firms who understood their journey um but also resources and common challenges for these companies look different from

40:42 early technology companies. It's like how do we do online growth marketing? How do we launch in retail? How do we scale a supply chain? How do we deal with uh not having all our eggs in the

40:52 basket of one contract manufacturer? Um traditional venture capital firms were not built to solve these problems. And so in 2019, I broke off and basically tried to build a proof of concept of

41:04 what a modern venture capital firm built to serve these companies could look like. Um that's what Selva Ventures is today. Um we're now investing out of our second fund and and that fund has been a

41:15 part of um like you see I said Grunes but also businesses like Onkin um Javi midday squares array to name a few. What's the uh sorry >> yeah what what what does bestin-class

41:28 look like today? Uh one of your one of your portfolio companies which I won't name because I don't think uh that it's public. I I was able to watch them go from basically zero to hundreds of

41:39 millions of revenue uh in the span of like I think like roughly four years something like that. Very very short period of time. Very small team. Is that like like is that kind of what you

41:52 expect out of out of out of a good investment or are there still some like you know kind of like slow burn uh kind of you know companies that that kind of like find that takeoff moment uh quite a

42:05 bit later. >> Yeah, there are there are longer journeys, there are shorter journeys. Gruns is probably the shortest one I've ever seen. I mean that business is like

42:13 32 months old now uh since since launching the consumers. I think what we do find is that the combination of online subscription which is uh for a great habitual personal care or

42:31 supplement business can be really really sticky like software like retention plus the scale of the best retailers out there. I'm talking Walmart, Target, Costco, Sephora. Um, you can build a

42:45 very very large business that doesn't consume a lot of capital in a pretty short period of time. >> And so when we talk short, like we underwrite our investments to 5 to 8

42:55 years, uh, you know, the the exits can certainly be shorter than what we've started to see in the technology markets of like longer dated IPOs. Yeah. Um, but you know, the the off-ramp for these

43:06 companies is traditionally uh, you know, like Grunes in the best-in-class way, an exit to a strategic once you're somewhere between one and $300 million in revenue. Um, and and that's something

43:17 if the flywheel online and offline is going, you don't have to wait too long for. >> Yeah, it seems like a I mean, it's a great it's a great outcome whenever you

43:25 see one of these uh, like unfold. I mean, Gruns is particularly fast, but there's a lot of examples of, you know, raising money carefully, deploying it, growing steadily, figuring out the

43:36 product, the supply chain, and then exiting to a strategic. We've seen that over and over and over again. Do you ever run into founders who are like, I'm going to take on Unilever. I'm going to

43:45 become the next Unilever. I'm never selling. And I'm going all >> I think everyone says that until they get an offer from Unilver at at at over a billion and then

43:53 >> but I I'm just wondering like >> we have it it's it's funny actually when I started this firm I I'd have a bunch of traditional VCs like send me pitch decks to be like what do you think and

44:03 and the subject line was like the next PNG or the next human. >> These are incredibly sophisticated organizations. They are so good at manufacturing, marketing, sales,

44:16 distribution, regulatory. Um, what they're not good at is innovating. >> And so the idea of like building a new one from scratch >> is kind of like

44:25 >> uh >> it's like you need to do the hard scale. >> Yeah. you need to do the innovative thing and do that really well while simultaneously doing it multiple times

44:35 and getting the the scale >> and the systems and the distribution dialed which >> I mean the one in our space that people naturally talk about is Harry's. They're

44:44 now called Mammoth Brands, but you know, they had a definitive agreement to be acquired by Edgewell, who owns Shik like six years ago, and it was blocked by the FTC. And yeah,

44:53 >> you know, now their only path is going public. And in order to go public, they need to basically build the modern PNG. And so, you know, they bought Codory, >> they bought um they bought a, you know,

45:04 personal care business called Lumi a few years ago and like they're probably the closest thing to it. Um but I think these like pure play fast growing disruptors are really what we focus on

45:13 because we feel like you know you take share you cause enough pain for these modern companies and you fit very well into the machine that they have built. >> Yeah.

45:21 >> Uh are you expecting chaos in the supplement category going forward after an exit like this? I'm assuming there's at least a hundred pretty smart entrepreneurs that that think, you know

45:34 what, I've always wanted to build a supplement company >> and uh start going after it. >> Uh I'd say like 2022 2023 when the market crashed. Uh there was a period of

45:48 time where we talked about how all the all the tourists left CPG Investing >> and it was sort of locals only and and >> I would say the space was sort of under capitalized. That's when that's when

45:59 that's when Grunes and and I know a number of your other winners like formed which is fitting >> that that tends to be a great time to form a company. Um also a hard time to

46:10 raise capital but you know the competitive dynamics benefit you. Um I really hope that we don't have a flood of halfbaked ideas backed by, you know, non-traditional investors coming in and

46:25 doing this the wrong way. I I feel like there's still a lot of scar tissue from the industry when traditional venture capital started backing BTOC brands in the mid2010s. And like obviously it's

46:36 ironic with the Albert's pivot today, but like I feel like I spend a decent amount of my time explaining to people why we don't invest in businesses like Alberts

46:45 >> and why CPG is fundamentally different than that. That direct to consumer is not the purpose. It's it's the products themselves and how much better they serve the consumer. Yeah, that makes

46:56 sense. >> Uh, one one thought is that I feel like a lot of VCs are paralyzed right now because they've invested uh, you know, significant amount of money into the

47:06 labs, but they want to invest in more companies because they have capital to deploy, but they're afraid to invest in the app layer and traditional software because of just AI disruption broadly.

47:17 And I think that that could that could uh lead at least some folks from uh from uh to deciding to hey maybe we should take a flyer in this let's let's just throw like 5 million bucks in this in

47:29 this CPG company you know >> uh Grunes is a good is a good comp for it you know why why not it's it's just you know so hopefully you don't >> if I were those folks by the way I'd be

47:40 looking at the technology stack of Grunes I mean Chad who you had on last week was a great he was a great interview like he he published publishes lot on on LinkedIn like all of his

47:50 vendors, all the technology solutions. >> I mean there is a huge opportunity to be the picks and shovels of this type of company that will not stop taking share from large CPG

48:01 >> and are willing to you know try out new AI tools or new technology tools. >> What what what outcomes have there really been in that because because again that that was like

48:11 a wildly popular category during the DTOC era too. It was like I'm going to invest in I'm going to invest in the brands and then I'm going to invest in the technology stack. And you had like

48:20 the Clavios of the world >> did well. Obviously Shopify has you know been been incredible but it's hard to think of a bunch of other >> examples that got out at actually a

48:33 venture scale. >> Yeah. None obviously come to mind although there's there's been some smaller attractive exits. I mean one one of the best like tech enabled Amazon

48:41 agencies sold yesterday. Um, and so like you know, you got to think about entry prices and the value creation to the early investors in these companies. They don't have to sell for billions of

48:50 dollars to be really interesting investments. >> Um, but you know, we see companies all the time that are just like changing the way these companies operate and reducing

49:00 the number of people that you need to run >> a CPG business that inter interfaces with the physical world. So you would think naturally would need more people.

49:08 Um, I think it's really >> Do you guys do any of the infrastructure or are you >> We don't We don't, but we we try and be pretty fluent in it. I love the I love

49:16 the focusing. Uh, >> it's basically like there's there's two companies a year that you need to find and back and you need to try to >> We're hunting for them.

49:24 >> Hunting for >> and uh just focus all your energy on that. >> So, I mean, on that hunt, uh, you said you you wouldn't back just a DTOC

49:33 company with, you know, decent growth metrics potentially. the product matters. What does that actually look like? Is it all your own taste? Are you doing surveys and panels and trying to

49:45 understand uh where the whites space is for a particular product? How durable that whites space is? Because every once in a while there's like a new c-acker that comes online and unlocks a new

49:55 stick pack or a new gummy format or something and then there's a boom around that and it feels differentiated, but really what you're looking at is like, oh, there's just a new piece of

50:03 machinery that's in a bunch of different c-ackers. So what's your process for actually understanding whether a company has a great product and will continue to uh be able to compound on the back of

50:14 like the quality of the product? >> Yeah, I mean I think you got to be pretty thoughtful about value proposition and uh a lot of new consumer value propositions for a CBG product are

50:25 like downstream of changes >> in how uh nutritional knowledge and human health plays out in our world. So uh you know GLP1s have a bunch of downstream effects. We don't just invest

50:39 in GLP1 companies. We invest in companies that ultimately take share because of a world where GLP1s are important. >> And so the first thing we're trying to

50:48 understand is like where is the where is the puck going in terms of human understanding and and therefore value proposition in the future. We're trying to find signal of great companies with

50:58 DOC and offline metrics and then most of our job frankly is figuring out what are the false positives like what are the reasons why a company might be growing really fast and efficiently that

51:08 ultimately won't translate to successful omni channel distribution and velocity and a successful acquisition. That was the thing with goons that that uh I think some people maybe

51:22 like were >> you know drove them to pass is that there had been that company on Amazon that had scaled to like 500 million or something like that in sales. I was

51:31 doing that. Yeah. Goalie just basically no value creation at all even though they had tons of sales and I think people kind of like wrote off gummies as a category.

51:41 >> Um and clearly that was >> you know wrong. Yeah, we were grateful for that misunderstanding. >> Sure. Uh what about uh the the temperature with LPS right now? I

51:53 imagine that you have a unique value proposition and LPS are watching you know so much like K-shaped winner take all dynamic in AI and it's such a complicated uh industry to allocate

52:07 towards. What are you hearing from LPs on appetite for uh for consumer package goods investing broadly? Yeah, I think it's a lot of curiosity. >> Um, you know, naturally these are things

52:19 that they see in their physical world and you know, when a when an outcome like Grunes crosses, but Grudin's not the only one, by the way. I mean, Poppy, Dr. Squatch, we've had actually like a

52:28 slew of billion plus dollar acquisitions in the past year in our industry. And so, you know, they see that in their news cycle. They see it at the grocery store. Uh, I think there's a there's a

52:36 curiosity moment like what's what's happening here and how does it work? And I think a little bit of that is trying to square that against what they've heard about the DTOC revolution not

52:47 working over the past 10 years. >> And so um I would say there's there's a waiting into the waters there's definitely anytime a new cycle of these acquisition hits like people start to

53:00 double click and try to understand it and spend time. I think what we found in our meetings specifically is folks appreciate the specialization in recognizing that this is different from

53:12 technology. So if we were a traditional firm that was trying to spend 15% of our time on it, I don't know that we could do a very good job on this. Us spending 100% of our time on it feels like, you

53:25 know, more comfort in their mind, but a little bit distant from what they usually do. >> Yeah, that makes a lot of sense. >> Yeah. And uh I think at this point like

53:35 if somebody starts a consumer brand and they are talented you they will get introduced to you some way or another and so you can kind of like meet every every great entrepreneur which I feel

53:47 like would be is basically impossible in like traditional tech investing. So >> that's the goal. I mean there's not a lot of people that I mean there's a few firms that we love and respect that do

53:56 this but like one of the reasons I started this firm is like there's no Benchmark Sequoia A16Z like if if you're if you're an entrepreneur out there like there's not that firm that you've always

54:09 dreamed of partnering with in in getting started and so you know eventually myself and a few of my peers decided like we we've got to go create that firm for them.

54:18 >> Amazing. >> Love it. Well, congratulations all. Thanks for coming on to break it down and have a great rest of your day. >> Good to see you. Great to see you guys.

54:25 >> We'll talk to you soon. >> Up next, we have Aaron Duza. He is the founder of Objection.AI and the enhanced games. He's in the waiting room and we'll bring him in to

54:36 the TV Ultradom. >> Keith, >> what's going on? >> Aaron, how are you doing? >> Uh, I'm great. Thanks for having me on

54:42 the show. >> Of course. Thanks for being here. Uh, do you want to give us a little bit of your background? you've done a lot in your time. I I'm super interested in enhanced

54:50 games and then we can go into objection.ai at some point, but uh how how are you introducing yourself these days as a multihyenet? >> Uh yeah. Uh so I'm a lawyer by training.

55:00 Uh when I was 24 years old, Peter Teal hired me to lead his litigation against Gawker Media >> involving the wrestler Hulk Hogan. Uh we won the largest invasion of privacy

55:09 judgment in history. Uh, it's the subject of the bestselling book Conspiracy by Ryan Holiday, forthcoming movie starring Ben Affleck and Matt Damon.

55:17 >> And, uh, >> there's a movie. There's a >> movie. >> There's a movie. Yeah. And, uh, since then, I've gone on to found nearly 12

55:23 companies. >> Uh, you know, most famous for the enhanced games, the quoteunquote steroids Olympics. Uh, but launched today, uh, my new one, Objection AI.

55:31 >> Okay. Uh, do you know who's going to play you in the movie yet? >> I don't know. It's, uh, you know, Hollywood is not like Silicon Valley. It takes them a very long time to make a

55:41 movie and it seems to go through a lot of different iterations. >> Yeah, it should be interesting. Uh well, let's uh I I would love an update on the enhanced games. Uh the the first event

55:50 is happening in late May. Is that correct? >> That's correct. In Las Vegas. >> Las Vegas. And and uh talk to me about the scale, the the the the

56:01 potential value, the goal with that project. Uh it certainly got a lot of uh a lot of attention. Everyone has a take on it. Uh >> yeah, the timing feels pretty good

56:10 considering it feels like more people than ever are enhancing themselves. >> Oh yeah, with GLP1s and stuff on which you know are some of them are banned, some are not in in traditional sporting

56:23 events, but >> yeah. But what yeah, what led you to the uh the enhanced games and and give us the update there. Uh yeah, I I'm I studied philosophy as an undergraduate

56:33 and I've always been interested in bioeththics and I read a paper by professor Julian Searescu who's a professor at the University of Oxford >> and he actually argued back in the9s for

56:42 an enhanced Olympic games >> and I learned that there were nearly half the athletes uh in the Olympics admit to using banned performance-enhancing drugs yet less

56:51 than 1% get caught. So there's this like real disconnect >> and at the same time things like peptides, TRT uh are becoming increasingly normal. Uh you know, even

57:02 people like Secretary Kennedy, you know, our our health minister in the United States is quite an advocate for human enhancements. And so I thought to myself, you know, why should we be uh uh

57:12 shackled by the ideas of the past and shouldn't we be able to unleash uh the full level of human potential uh using the best of science and technology? And that's where the idea of the enhanced

57:22 games came from. >> Yeah. Uh how many athletes have actually stepped forward and said that they want to participate? Like how how how big is the movement at this point? Obviously

57:31 the first games is happening. Do you want to put it on this similar like every two years cadence? Is there demand for more of a UFC like schedule? How do you think this all works out?

57:40 >> Uh it's it's the aim is for an annual schedule. Okay. Uh we're very pleased that the company uh is going to go public through a spa combination on the New York Stock Exchange uh in the coming

57:51 weeks. Obviously, I stepped down from being CEO a few months ago to focus on my new venture, so I can't speak to the uh exacts of the the spa. Um but a $ 1.2 billion valuation we're very happy

58:02 about. Um and ultimately uh it's not the number of athletes participating, it's the quality of athletes. So we have Olympic gold medalists, we have world record holders. And in fact, uh we've

58:13 already set our first world record in the 50 freestyle. >> No way. >> Which was set by Christian Gomev of Greece, uh in an exhibition event last

58:20 year. He swam faster than any man in history had up to the point in time. Uh and he had only been enhanced for a couple of weeks. And so >> to to show you how how much of a

58:30 difference that could make, Christian was 31 years old at the time, which arguably is about 10 years past his prime for a swimmer. >> Oh, interesting. Okay. Uh well take us

58:39 through objection AI. What's the uh the thesis? How do you uh like what what led you to start another company at this moment in time? >> Uh I believe that the fundamental

58:48 problem that we face in our society is truth. >> Uh there is no sense of uh an objective arbiter of truth in our society and this is something that has caused um you know

59:00 great societal decay. If we don't have a shared sense of truth we can't have a functioning civilization. And you know uh two decades ago we would have said the New York Times is the

59:09 arbiter of truth. >> And today you know the social platforms don't seem to care about it very much. AI uh you know juggernauts don't seem to care about it very much. And so I said

59:18 to myself what is the best way to find truth? Uh and truth is not a vibe. Truth is a process. And that process is very well documented in courts. Courts are viewed by Americans as being very

59:28 trustworthy entities versus the legacy news media in particular has seen a collapse in credibility. Uh 50 years ago, according to the Gallup poll, 70% of Americans trusted the media. Today,

59:40 that's down to only 30%. And so, the goal of objection AI is to create a uh system where anyone can challenge a claim made in the legacy news media. Uh independent investigators will then

59:53 investigate it. former CIA and FBI agents and then all that data is presented to an AI jury to analyze um to figure out if uh the original claims made by the journalists were true or

01:00:05 not. >> Interesting. Uh yeah, some something that's uh it feels like community notes have been uh a a good innovation for like truth online, but the big flaw is

01:00:18 that by the time >> a post gets like a >> like solid community note, oftentimes like a million people seen it already. They didn't know that that it that there

01:00:29 that there was >> Yeah. So I mean the the logical followup is uh is speed a problem here? Because I imagine that yeah I imagine that if you have to run a whole jury process and

01:00:40 have discovery and argue argument like the original claim could be baked into the society's like mind share before you have >> that's the fundamental problem about

01:00:52 news media today is that um false information spreads six times faster than true information. Uh and so the incentives for generating clickbait content uh is very pronounced and we've

01:01:03 known this for a very long period of time. And so by compressing the legal process which often takes 10 or 20 years and costs $10 million as we learned in the Hulk Hogan lawsuit down to something

01:01:14 driven through software and artificial intelligence down to a couple of days. Um we can adjudicate factual disputes much much quicker and much cheaper. Uh the whole process on objection can cost

01:01:25 as little as $2,000 uh and can be done in as little as 24 hours. >> So is the business model to sell directly to people that uh want to uh contest claims that are made on on the

01:01:36 internet? >> Yeah, exactly. So if uh the New York Times writes something inaccurate about uh you guys and your wonderful podcast, uh you can file an objection.

01:01:45 >> Okay. >> Uh then human investigators will investigate the story line by line, source by source. They'll call everyone quoted in the article.

01:01:53 >> Um, and then they'll present that information to an AI jury. Uh, and the original author, of course, has the opportunity to respond. >> Uh, and say, "Hey, my reporting was

01:02:02 good. It was high quality." But, you know, we live in the era of data. >> Uh, and I think it would be wonderful if every story published by the New York Times, including included the long form

01:02:11 recordings of each interview, right? I've done thousands of media interviews, >> journalists always record them, >> but they never publish them in full. uh and so being misqued or uh you know

01:02:23 anonymous source uh these are the tools that in particular print journalists use that have seen a massive degradation in trust. >> Yeah. Have you been following the

01:02:31 Satoshi Nakamoto story recently? That feels like a textbook example of something that's been disputed but it's very hard to disprove if you're being accused of being Satoshi. How have you

01:02:44 processed that particular story? >> Yeah. And so um courts are a very good methodology of finding truth. I think there are only two solid methodologies of finding truth. One is courts and the

01:02:55 other is the scientific method. >> Sure. >> And so if you take a scientific method approach >> um uh anonymous sources should never be

01:03:01 allowed. >> Right. So you can't say to a scientific publication a source told me this. You have to be able to replicate the experiment over and over.

01:03:09 >> Yeah. >> Right. Um or courts is the alternative method of truth finding is where you have two adversarial parties >> often arguing antithetical points of

01:03:18 view and what is truth. It's a really important question. It's almost the core question of philosophy. Well, in the court setting it is it is who has made the better argument, who has presented

01:03:30 more evidence and um and how coherently has that argument been made. And now with the magic of artificial intelligence, we can do all of that uh very quickly and very cheaply.

01:03:41 >> Yeah. H uh how do you think about tuning different models to actually give you uh unbiased results? It feels like uh every different model has slightly different flavors and and things that it likes and

01:03:57 dislikes and might see things different ways. Like these feel like subject it feels like a subjective technology. How do you get it to be impartial? Yeah. So that's a that's a great

01:04:06 question and that's exactly how we face these issues with human juries and human judges. >> Sure. >> Right. So um human judges are extremely

01:04:16 infallible. Uh according to a paper from professor Pner who's one of the leading scholars of law and economics at the University of Chicago. Uh AI applies the law 100% accurately. Human judges only

01:04:27 do it 52% of the time because human judges can be swayed by um whether they've had lunch or not, whether they're having a bad day, you know, whether um they have a savvy lawyer in

01:04:37 front of them. >> And then in the same way, we use a jury based system. >> Yeah. >> Uh five different models prompted to act

01:04:45 as if they were different personas of people based on um you know, a statistical sample of how everyday Americans behave themselves and demographic samples. uh and the models

01:04:57 have to find um you know a uh a majority opinion uh to to to pass a verdict. >> Uh are you thinking about integrations with social platforms? Jordy mentioned um the community notes system. Uh how do

01:05:14 you think about distributing uh findings once you actually have reached a conclusion? >> Yeah. So um this is the principal flaw of courts. So courts isue issue a

01:05:24 judgment. Yeah. Yeah, >> but they have no distribution mechanism. >> Uh and uh we have something called a fire blanket. So we have an algorithmic um uh posting system on X

01:05:35 >> so that every single claim that is under investigation, we immediately fire off a tweet that says this claim is under investigation, please see the full case file. Mhm.

01:05:45 >> And then when the similar claim is um uh retweeted at some later point in time after adjudication is complete, we then say um that claim is false or that claim is true. Please see the full analysis

01:05:57 that was done. So it intercepts uh the spread of disin disinformation as it is happening. >> Very cool. Jordy, anything else? >> Uh excited to follow along.

01:06:08 >> Yeah. Uh well, thank you so much for taking the time to come with Chat wanted to confirm though, you are not being held hostage right now, right? >> I am not being held hostage right now.

01:06:17 I'm in an undisclosed location. Okay. >> Uh because uh as someone who is often subject to um negative media reporting. I like to not show where I live. >> Makes sense. Makes sense. Uh well, good

01:06:30 luck and we will talk to you soon. Thank you so much for taking the time. >> Thanks for having me on the show. >> Have a good rest of your day. Um, in other news, uh, Uber is now going

01:06:40 back into robo taxis. Uh, Uber commits 10 billion to robo taxis and strategy shift. Uber's committed more than 10 billion dollars in buying thousands of autonomous vehicles and taking stakes in

01:06:52 their developers. Breaking from the asset like gig economy business model to avoid disruption from robo taxis. The ride hailing app has aggressively increased deal making over the last over

01:07:03 the past year, announcing partnerships in more than a dozen uh providers, including China's BYU and US-based Rivian as well. >> Here's the kicker. Yes.

01:07:11 >> As well as plans to launch robo taxi services in at least 15 cities in 2026. So, they're going to be putting Rivians on the road, >> I guess,

01:07:20 >> autonomously. >> Or maybe they'll do a deal with one of the other robo taxi providers. Rivian seems like I mean great cars really well loved.

01:07:29 >> Everybody says like the autopilot in Rivian is great. >> Yeah. >> But so it's also great in Tesla and we don't see

01:07:38 >> robo taxi scaling truly scaling yet. >> I don't know anyone that's that's ridden in a in a robo taxi >> but things are moving quickly and you know uh but it is 2026 right now. So

01:07:50 that is a very aggressive timeline to actually launch robo taxi services. But maybe that means more of like partnership with existing robo taxi providers. Uh we'll have to dig into it.

01:07:59 Uh and we'll talk more. >> Market likes it. Stock is up 6.8%. Yeah. Today. >> Yeah. Uh I mean the the the stock has been trading down as Whimo and Tesla

01:08:08 expanded services. It sold off. Uber sold off. And when Whimo raised 16 billion uh Uber sold off again and when Zuks expand planned major expansion, the company uh Uber sold off as well. Uh the

01:08:22 stock is down 23% in the past six months and investors are starting to get to get concerned about autonomous vehicles. So Uber is responding. Well, without further ado, we have Michael McNano from

01:08:33 Union Square Ventures now in the waiting room. Let's bring him in to the TVP and Ultradome. >> Let's hit the gong for you. >> We're going straight to the gong.

01:08:44 >> Oh man, I love that. I love that gong. Thank you guys. Thank you so much. Thanks for having me. >> Questions. uh re reintroduce yourself. Tell us where you were and where are you

01:08:54 now? >> Yeah, of course. I'm Michael Mcnano. Uh I am a GP at Union Square Ventures. Uh most recently >> a partner at Lightseed and then before

01:09:03 that uh co-founded Ankor, which sold to Spotify, and I'm very excited to see you guys again. Thanks for having me. >> Yeah. What uh what motivated the move? >> Did you just want to go to New York? You

01:09:14 want to work with Fred Wilson? like what was the what was the reason uh to jump over to Union Square? >> Well, I'm from New York. I've always been here. I've always lived on the East

01:09:23 Coast. I've always been somewhere in or around New York City and I've known USV forever. So, you know, I built Anchor here in New York City. Pitched them back in the day for our seed and series A and

01:09:35 uh they passed both times unfortunately. But >> laugh. >> Sorry. >> No, I I love it. I love it. got, you

01:09:45 know, got to know the team obviously and um after we sold Ankor to Spotify, became an LP in the funds and stayed close and uh >> just always loved their approach. You

01:09:55 know, USV is famously thesis driven, right? They've always been sort of willing to bet early on the stuff that looks weird, the stuff that looks funny, and I've always really appreciated that

01:10:05 approach. And so, uh late last year, they approached me and they said, "Hey, how about coming over to USV and joining us and joining the partnership?" and uh had to do it. So here I am.

01:10:16 >> Yeah. H how should I think about uh USV right now? How big is the firm? How big is the partnership? Uh it feels like a unique firm at a time when many firms are just going for insane scale.

01:10:30 >> Yeah. Building platforms. But it feels like it feels like Benchmark and USV are two two funds that that could have built platforms and you know have made the decision to you know stay stay true to

01:10:42 venture. >> Yeah. Yeah. I think I think this has always been USV's approach, right? It's been it's been a famously small partnership for a very long time. Small

01:10:50 in terms of the number of general partners. Um, and small in terms of the fund size relative to lots of other bigger platforms as you mentioned. And I think they've made it work because what

01:11:02 we talked about a little bit earlier, they've always been willing to have a thesis and have a point of view and go really really early when you know a lot of the other big firms and the big

01:11:11 platforms are chasing more consensus deals to their credit, right? I think the platforms have been very very successful at using you know large large vast quantities of capital uh and speed

01:11:22 as a weapon to to back the winners. But I think what USV has always always done well is said, you know what, we think the world is going in this direction. We're going to bet really really early.

01:11:32 Sometimes we'll get it wrong, but every once in a while we'll be one of the first investors in Coinbase or Twitter or [ __ ] And obviously for a fund of this size, that ends up having a massive

01:11:43 impact. And I think, you know, I think that that is the right playbook to be playing moving forward. Obviously AI is going to create a proliferation of startups like we've never seen before.

01:11:54 And I'm not actually sure it will be possible to see them all. And I think the only way you're really going to be able to have a great bet is if you know what you're looking for before you see

01:12:03 it. And that's always what USV has done. >> Uh yeah, I still am surprised when I look at the app store charts and see that we really just have LLMs in the charts and not much else. And it feels

01:12:18 like that has to that has to change uh at some point in the next in the in the next year or two and and uh yeah, fully expect that. So where where do you want to focus uh your time? What's exciting?

01:12:31 >> Yeah, you know, I've always been uh somebody that's been excited by great products. Um you know, I'm a product builder myself. You know, we mentioned Ankor. Uh I have another startup which

01:12:41 we've talked about on here, Obo. So I'm naturally drawn towards products great, you know, great product oriented founders. When I was at Lightseed, you know, I led deals like Sunno and

01:12:51 Granola, which I think for me have always fit that bill, but also, you know, I think take a little bit of an interesting approach that's relevant to building startups uh in AI moving

01:13:01 forward. Um, you know, Sunno is is a company that's taking a form of media and it's leveraging the democratization of that media to not just, you know, uh, optimize an existing workflow or

01:13:14 optimize an existing market. They're doing it to build a completely new format and unlock a whole new form of creativity for people. And so, I think we're going to see a lot of that moving

01:13:23 forward. I think AI is going to unlock use cases and applications that we can't really dream up. Now, maybe to your point about there only being like three LLMs at the top of the app store now.

01:13:34 Um, in fact, I I believe that software is starting to represent more and more uh a form of media, right? It's so easy to create this stuff. I'm sure you guys just like me and everyone watching are

01:13:45 building apps and creating agents every day. Think about what happened with video. Think about what happened with podcast, with text. It wasn't just about building the media. It was about the

01:13:54 enablement that goes under it, the platforms, the payment rails, the distribution. I think there's probably going to be a massive amount of enablement that goes into the massive

01:14:04 long tale of software about >> well said. Uh wanted to get your take on synthetic podcast. We saw Pomp launched a a a synthetic uh an AI generated podcast today called Best Stocks.

01:14:20 >> I'm assuming they talk about the best stocks. Uh but wanted to just get your kind of overall take. We've seen some other AI generated podcasts start to uh top the charts. What's your perspective

01:14:33 there? Not not not not a venture opportunity, but uh certainly I would say interesting. >> Yeah, look, I think it's I think it's super interesting. You know, back in the

01:14:42 day when when I was building Anchor uh inside of Spotify, we actually had a partnership with with WordPress um where if you had a WordPress blog, you could tap a button and it would immediately

01:14:53 turn the text and the blog content into a podcast, right? So, it was a way for the creators to get more and more distribution. And, you know, I think it was great. We saw a lot of demand from

01:15:02 the creators, but it may have been too early on the timeline in terms of the quality of the content and sort of the that uncanny valley. And I think that has a lot to

01:15:12 >> say. The voice models just were not good. Voice models were not good or we were using >> Exactly. The voice models were not that good yet. Obviously, they're a lot

01:15:22 better right now. 11 Labs creates phenomenal voice models. I don't know what this this podcast you mentioned is is using, but I think the closer and closer we get not only to great voice

01:15:31 quality, but also a humanlike experience for these hosts, whoever they are on this show, I think the closer we can get we can get to getting it to work. I mean, one of the reasons people tune in

01:15:42 to TBPN is not only to kind of hear the news and hear people speak, but it's to watch you guys, right? They like you guys as the hosts and they like the personality and the human aspect of you

01:15:52 guys. And so, um, I think the agents that are hosting these shows are probably going to have to get closer and closer to that end of the spectrum before it really takes off. Did you

01:16:02 explore any version of that WordPress to podcast workflow that would sort of on demand hire a voiceover artist? Was there any demand for that or did you ever explore that? We did explore that

01:16:16 and we you know it was one of those things where again at the time um it was it was going to be challenging to spin up the content for that >> sure

01:16:26 >> quickly enough such that we were confident that there would be enough demand to make it worth worth it. You know, I think with media and with publishing, people people really want

01:16:35 immediiacy, right? Um, we, you know, when we were first building Anchor, actually, the way that we went from being a social audio app to a podcasting platform is we found that all the people

01:16:45 that were publishing just inside the Ankor app said, "We want a podcast. We want this to be on Spotify. We want this to be on Apple." But there were no APIs at the time. So the way that we did that

01:16:55 was we actually had human beings uh sitting in our office and manually creating RSS feeds and posting those RSS feeds to Apple podcast in real time. And fortunately we were able to do that

01:17:07 quick enough you know within a couple of hours that it satisfied the creators. But I think you know at the time your idea what you're talking about now the gap just would have been too long. It

01:17:16 would have been days or weeks before uh the content was ever delivered. >> Yeah. uh have you have you reflected on um the just like like there's such incredible model progress and such

01:17:28 incredible AI functionality progress but I I the I would have expected to have found in in the same ways that the AI generated podcasts seem to be working and we've seen some audio stuff work I

01:17:42 would have expected to see like a substack that was AI generated text that got really popular and that seems somehow easier from an from just an AI capability perspective. There's less

01:17:55 steps in the chain, but it hasn't really broken through in that way. And I'm wondering if you've ever like grappled with that question of like why that hasn't uh why even like the simpler,

01:18:07 more condensed text. I don't even know if I follow I mean maybe I do, but I I don't know if I follow any uh Twitter accounts that are like fully AI generated news headlines

01:18:16 >> that you know. >> This was actually going to be my question to you. I mean, it's possible that that already exists and maybe these publications or these writers or these

01:18:23 journalists aren't really admitting it yet. I mean, I have to imagine a lot of the content we now consume on the internet is AI generated. We may just not know that it is.

01:18:31 >> Yeah, it feels like a lot of it is like the we're in the centaur period where uh you know, the human plus AI works well and so you you see people doing research and then processing it and adding their

01:18:43 own spin and twist. Alex Heath was talking about how he's a ton of AI in his writing process. He can he can say that because people are paying to subscribe to sources to get like net new

01:18:54 information that doesn't exist anywhere else, right? And so no one >> but I think that that only makes, you know, humanpowered content that more valuable. Again, not to keep bringing it

01:19:02 back to you guys. I mean, I think this is a reason that people like this and I think there's a reason that, you know, sports live sports viewership is at an all-time high and people are going to

01:19:11 concerts, right? I think I think people crave this uh this farm-totable human experience. >> Yeah, I I feel like you've done a good job of that with your content. Uh can

01:19:20 you sort of uh reintroduce it for folks who might not be fully familiar because uh the the the production quality is extremely high. Uh but it feels like you're sort of playing a different game

01:19:33 in terms of uh release cadence like making sure that everything is special and not formulaic. But how are you thinking about your own the the content that you're putting out these days?

01:19:43 >> To to be clear, I think you're referring to the podcast I was running at Lightseed called Out of Office, which which I'm no longer the host of now that I'm not at Lightseed. However, the

01:19:52 philosophy that we and I had for that I think holds true and I believe in it which is there's so much content out there on the internet and the tools have gotten so good at clipping and

01:20:02 mass-producing video content or you know two people sort of sitting in the same setting having the same style of conversation that you really have to do something different. You guys did

01:20:12 something different. There are a number of podcasts out there that are now doing something different. But one of the ideas that that I had that that we ran, what's that?

01:20:20 >> There's five total. >> There's there's about five uh maybe six. >> Yeah. >> Um the the the thing the idea that we had for out of office was,

01:20:30 >> you know, why does this conversation have to happen in a studio or why does it have to happen around a table? Um, how great is it to watch an episode of comedians and cars getting coffee and

01:20:40 watching these guys behind the wheel of an awesome car or in their favorite coffee shop or watching something like Anthony Bourdain, Parts Unknown, and watching these two iconic people travel

01:20:51 around a really iconic familiar place. And we thought, hey, can we bring that to the tech podcast? And so that was that that's out of office at Lightseed again. You know, no longer uh something

01:21:02 I'm involved with, but >> stay tuned because uh I do think, you know, I and maybe USV will have something similar in that vein uh coming soon. I actually just posted a little

01:21:12 bit of a teaser photo on my ex a few hours ago. Uh go check that out if you haven't already. But but look, I think the I think the the theme is like to break through right now and break

01:21:22 through the noise, you've got to do something that looks a little bit different and you have to do something really really high quality because the tools have gotten good enough there's a

01:21:31 baseline quality that you just get out of the box. So if you want to stand out, you actually have to go above that. >> Yeah. >> Jordy,

01:21:38 >> how many investments do you expect to make? You know, what percentage of investments do you expect to make in New York versus the West Coast? you know, listing off some of USV uh USV's iconic

01:21:48 investments. Of course, >> you know, the the Coinbases, the Twitters, etc. Many of them were on the West Coast. So, are you going to be over here a lot?

01:21:57 >> USV's always been a sort of oneoff New York ccentric firm, obviously, the namesake Union Square Ventures, but USV has also made a lot of money all over the world. You know, you just rattled

01:22:10 off some of the locations. When I was at Lightseed, I was based in New York and uh even though I was based in New York, I was making investments all over. I think I think most of my portfolio

01:22:21 actually was on the West Coast. Obviously uh had had um Suno, which we just mentioned in Boston, Granola in London, but a lot of them were in the West Coast. Going to continue to operate

01:22:31 that same way. Uh you know, we'll invest wherever the opportunities are, but uh the home base is going to stay in New York City. >> Yeah. What's this what's the secret to

01:22:40 uh getting good deal flow at the early stage? I feel like that's such a differentiator for Fred Wilson throughout his career. You uh are

01:22:50 teasing, you know, some sort of conversation. You've clearly been working with him for a while. Uh what do you think uh makes USV particularly differentiated in finding great

01:23:00 companies early on? I I know it sounds simple simple but I think it's a willingness to be wrong and and and and actually make predictions. I think so much of this industry is focused on

01:23:12 momentum and focused on consensus driven bets which again can be very very lucrative if you get in them and you have the capital to to fund them. Um, but I think what Fred and the team have

01:23:24 always been great at is having a conversation which lasts maybe not just one partner meeting but lasts weeks or months or in some cases years and along the way making some bets against that

01:23:35 idea and against that thesis which which may look wrong for a very very long period of time. You know, you mentioned Coinbase. USV famously made that really early Coinbase investment, but they had

01:23:45 invested in crypto before that, right? uh they had a strong thesis around crypto before that and it took it took some cycles for them to to gain conviction in in you know what they

01:23:56 ended up seeing in Coinbase. So I think it's about it's about engaging in honest discussion with your partners. It's about not being afraid to have a crazy idea to like the weird and uh and and to

01:24:10 keep that conversation going for a long term a long time. >> How are you thinking about wearables these days? It feels like the meta ray bands are having like an inflection

01:24:19 point. There's, you know, Apple's coming to market with stuff. There were a few startups that Aura Whoop have seen. >> It feels like it's uh maybe

01:24:29 undercovered, but have you processed any of that as like an interesting end point for uh technology broadly? >> I think there are a couple interesting aspects about it. Jordy, you mentioned

01:24:39 earlier at the top of the app store, we're seeing the same three apps now for, you know, the past two years or whatever. um you know hardware which I think has often been thought of uh as

01:24:48 too hard right you always hear the term like hardware is hard and so venture capitalists often ignore it you know we might want to rethink that a little bit hardware could be considered a wedge now

01:24:59 right maybe it's maybe it's actually a defensible layer where if where if you can actually have a successful product there that's going to be a lot harder for a massive foundation model lab to go

01:25:10 and replicate than you know leveraging their distribution for a new form of data collection or whatever the case may be. So I think there could be some interesting uh edge model or edge data

01:25:20 uh out on a hardware device that uh is pretty defensible. So that's something interesting I like about it. I think the other thing that's interesting about it is, you know, we've you guys have talked

01:25:31 a lot. I've talked a lot about how context is king and finding these edge data sources is really really unique. And that's obviously something that uh has been pretty fascinating about

01:25:41 granola, right? They're capturing these conversations that you can't really capture any other way or aren't being captured any other way. And so that provides a lot of model to or a lot of

01:25:50 value to the model. Hardware offers a similar opportunity, right? where um using hardware, whether it's the glasses, or maybe something else completely, a pen, uh an aura ring,

01:26:03 you're capturing an edge form of data that the labs can't really see unless they have that hardware. So, I I actually find hardware to be quite compelling at the moment, and I think it

01:26:14 actually is an area of opportunity. >> How are you seeing startup culture change in terms of like who's hiring? I'm thinking about hardware. I was reading this uh report maybe it was in

01:26:25 the journal or the financial times about how uh more and more students are choosing uh like electrical engineering, mechanical engineering over computer science because of the rise of AI that

01:26:36 can code very effectively and the job market changing and that feels like uh potentially a boom for hardware startups. Like you have to imagine hardware gets less hard if there's just

01:26:45 more hardware engineers and it's easier to staff up for that. Uh but I'm wondering if you're noticing any other changes around uh location or work life balance or in in person. We did the

01:26:57 COVID thing, we did full remote, then we went back full in person, then we go and hybrid. Uh like how how is how are the startups that you're interacting with like looking different than a decade

01:27:08 ago? I think the big difference that's happening right now and this feels like a very recent thing maybe past few months maybe you know past six months is

01:27:16 I think we're going to see a swing back towards the missiondriven company. I think you know we've seen a lot of capital flow into the ecosystem over the past few years and I think that that has

01:27:28 turned a lot of missionaries into mercenaries and by the way it's worked phenomenally well again we keep talking about the same you know two or three startups that are massively massively

01:27:37 valuable >> but I think we're also seeing a lot of churn right and a lot of attrition at these companies and I think it has to do with this missionbased thing right if

01:27:45 you if you think back maybe 5 years ago or 10 years ago and some of the behemoths that emerged from maybe the previous software and startup cycle. These companies were very very

01:27:55 missionoriented. They were all aligned around the same mission. They stayed incredibly lean, incredibly focused on what they were trying to accomplish. They left the politics and the [ __ ]

01:28:04 out of the office and they just focused on hitting that mission. And I think right now we're seeing a lot of people get burnt out after just chasing huge, huge paydays at incumbents or insanely

01:28:15 well- capitalized startups. And I think we're going to see the pendulum swing back in the other direction. >> Mhm. >> White pill.

01:28:22 >> White pill. >> Yeah. >> Uh how many last question for me uh just because you're the first person from Union Square Ventures to come on the

01:28:30 show. How many >> That's true. >> Yeah. >> How many how many how many uh partners are there? Like how big is the investing

01:28:37 team, I guess, is a better question. >> Um there's about there's about eight of us. Um and uh the whole team in general is under 20. >> Wow. So, we're a small team. Like I

01:28:47 said, we're all in one office >> and uh we talk a lot. Uh you know, when I was at Spotify, Gustav Sodstrom, who I think you've had on the show, >> uh had had this famous saying inside of

01:28:58 Spotify. Everyone at Spotify knows this saying. >> Gustaf says, >> "Talk is cheap, so you should talk a lot." And what he means by that is the

01:29:07 cost of getting something wrong is actually way more expensive than the time it takes to actually talk and align and earn the right to go invest or spend or bet on something. And what I've

01:29:17 always loved about USV is they have a similar philosophy. They talk a lot. It's a small team, but they spend a lot of time together forming their point of view on the world. And to your question

01:29:26 earlier, I think that's what's given them the edge. >> Yeah. Well, they're very very lucky to have you and uh excited to see what you guys do together. It's great to see you.

01:29:34 Thank you. You, too. And by the way, congrats to you guys. >> Thank you. >> Thank you. >> Yeah, we're very excited.

01:29:38 >> Uh come come uh come see us when you're when you're in LA and we'll do the same. I'd love to. >> We'll talk to you. We'll talk to you later. Have a great rest of your day.

01:29:46 >> You're the man. Thanks. Thanks, Jordy. >> Um speaking of Meta, Meta Platforms CEO Mark Zuckerberg reportedly moved his desk into the AI lab working directly with Alexander Wang and Natt Freriedman.

01:29:59 Zuckerberg is reportedly coding throughout the day. Um, there's a story in the New York Times about uh uh uh about AI sunglasses. I feel so sorry for my AI sunglasses. And it opens with this

01:30:13 anecdote about um trying to use the glasses to identify uh what is it? Some sort of uh bird. It says uh one afternoon on a sunny stroll, I stopped to admire a bright red cardinal singing

01:30:28 its heart out in a tree. Hey, Meta, I say. Uh, what kind of bird is chirping in that tree? My sunglasses make their little ding-dong noise, analyzing the world. Finally, they speak. I don't see

01:30:39 a bird in the tree or hear any chirping, they say. I point directly at the bird, which is still chirping. I don't see a bird in the tree where you're pointing, my sunglasses say cheerfully. Just bare

01:30:49 branches and sky. For several weeks, this is how it goes. The disorienting sense of chatter with a toddler who is drifting off into nap time. Look, it would be easy to dunk on my very

01:30:58 expensive, staggeringly incompetent uh glasses. Critiquing AI these days is like shooting fish in a barrel. And I mean poorly animated fish that keep sprouting human fingers inside that

01:31:07 barrel. Um and so yeah, it's a very interesting uh uh read because it's clearly like there's so many times when you're interacting with an old legacy model in a particular uh in a particular

01:31:19 endpoint where you're not getting the most frontier intelligence and it can really throw you off. Andre Karpathy had this whole take about people that used like early LLMs that would hallucinate

01:31:29 and haven't tried the latest coding models to really understand how powerful the technology is. There's this big division and so you sort of have to do both. Acknowledge that uh diffusion

01:31:39 takes time. Actually rolling these models out to a device like glasses uh takes time. >> Yeah. And it's interesting with meta because it feels like their glasses.

01:31:47 >> Yeah. >> I'm getting served a lot of videos. >> Oh yeah. People are using them as as as GoPros. >> Yeah. They're just cameras.

01:31:54 >> Yeah. As cameras. Um and and I know a lot of people that use them as AirPods replacements. Like they use them just to take phone calls, listen to music because then they don't have anything in

01:32:03 their ears and it's just more comfortable for them. They even have clear ones that they can wear on. Uh it doesn't really work on a plane because it's too loud. But uh when they're just

01:32:10 in the office. Um but actually getting the AI features into these devices is true. >> They have uh they have humor bench. >> Oh yeah.

01:32:19 >> Hey Meta, I said one day tell me a joke. >> Mhm. Why did the baseball go to the doctor? >> Why, Jordy? >> It had a little rund down in its batting

01:32:29 average. >> Run down. >> Uh, I don't really get it. >> Swing and a miss. >> Yeah, it might be better in this case

01:32:37 just to pull from the bank of vetted jokes. >> Yeah, you don't need to generate one. Siri did that early on. >> Look up. You can just look up some of

01:32:44 the best. >> No. When Siri initially launched, they had comedy writers write out a whole bunch of jokes. And when you ask Siri, tell me a joke, it would p just pull one

01:32:53 off the shelf that was handwritten by a human about Siri, aware of the context, aware of everything. I'm now I have triggered Siri, so I'm in trouble on my laptop. Uh but it is it is just very

01:33:05 interesting. Apple, of course, we we touched on this. Uh they Mark Urban has a report on the upcoming AI smart glasses. They'll come in several styles and colors. Uh a few of those frames

01:33:16 seem like they're direct competitors to WFarers. will be very interesting to see the ecosystem uh integration with Apple. Uh and Dan Primac has a take here. He says Apple isn't burning mountains of

01:33:26 cash on GPUs or investing billions into Frontier Labs, but it still may win the AI race. Success from the sidelines. Sort of a uh contrarian take at a time when Apple doesn't really want to talk

01:33:37 about AI right now. They're sort they're clearly in this rebuild. They don't want to talk about it, >> but they have partnerships with Open AI, Anthropic, and uh Gemini at this point.

01:33:47 They're using AI tools all over the company and it feels like they internally are starting to feel the AGI but at the same time have a very unique strategy of not overreaching and uh it

01:34:01 could really work out for them. So it's an exciting it's an exciting time and an exciting story to to follow. Well uh without further ado we have our next guest in the waiting room. Wade Foster

01:34:10 from Zapier. Zapier. Wade. How you doing? >> Good. How are you guys doing? We're good. Thanks so much for coming back to the show. Uh, how are things going? Give

01:34:22 us the general update on, uh, your company and then there's a million different things that we can talk about, but I'd be interested to know uh, what you're learning from your vantage point

01:34:31 as CEO of Zapier. >> Well, yeah, I, you know, we launched our Zapier SDK last week. That's probably the most exciting news. Congratulations. this uh you can install it inside of you

01:34:43 know cursor cloud code any coding agent you might use uh I use it I'm not an engineer and I basically built like an entire AI chief of staff on top of this team thing and uh you know runs in the

01:34:54 background I don't have to close my laptop uh or I can close my laptop lid and not worry about uh things breaking so uh it hooks into all 9,000 different tools and I have it running all over the

01:35:04 place so that that's probably the exciting news out of Zapier's land. Do you do you feel like uh the the vibe coding boom generally is more heavily tilted towards internal tools,

01:35:16 dashboards, reports, chief of staff, B2B applications because it feels like clearly people are consuming a lot of tokens. They're spending a lot on inference. The models clearly work. The

01:35:28 coding agents clearly work. At the same time, uh, I open up the app store and I'm not seeing the, "Oh, wow. Somebody vibecoded a Call of Duty competitor that's blowing up on the Steam charts,

01:35:40 right?" Like, we're just not in this like in this like everyone's talking about the the the the new app or the new Uber or the new game that's like been created much faster with with a leaner

01:35:53 team. But everyone has a story of we pulled forward our roadmap at our company. Yeah, we've definitely had a renaissance of internal tools internally. Uh we our marketing team ran

01:36:04 a hackathon recently. It's about 50 people on the marketing team. At the end of the week there was like 80 plus new internal tools. Most of these were like dashboards and you know data

01:36:13 visualizations and things like that that in the past marketers like especially are pretty analytical but they may not be like the best at like using SQL or running these things and you know

01:36:23 getting access to the data has been clumsy and hard and now it just feels like they've got a jetpack on where they can just go build these like really quick quick simple tools

01:36:32 >> that allows them to make like hyper specialized hyper customized campaigns uh because they can quickly run an analysis and see oh you know, uh, across the last month of like social posts,

01:36:43 these are the ones that took off. Uh, here's the common traits about them. So, let's figure out how to like tweak our next campaign for the next month to be more like this and less like that. Uh,

01:36:53 that type of analysis would have been really difficult for a marketer to do solo. Um, you know, in the past, now it's, you know, >> less than an hour of work. Yeah, I think

01:37:02 Terrence Tao had a the mathematician had a point about this where uh he was he was he was saying that like in his papers he will use AI agents to create new visualizations that would have taken

01:37:15 him multiple days to make. Now he but it's not like it's saving him time because in previous papers he just wouldn't have put the v visualization in. And so it's it's this it's this

01:37:26 element of like people just doing more with more. But I'm wondering like as you see, you know, so many companies have done this where there's a hackathon for the marketing department or some

01:37:36 organization and the the the the prompt can often be like replace yourself. And I'm wondering if you're seeing that actually happen or if it's more like the the competitive dynamic is everyone's

01:37:48 getting more leverage, doing more things, and just out of the 20 ideas that they have, they're able to do 15 instead of five. Yeah, I I definitely think it's more the latter right now.

01:37:59 Uh, you know, across Zapper, 100% of our employees are using AI daily. I would say this is like individual AI usage. People are individually more productive. >> But if you were to ask me, is the

01:38:11 company more productive? Institutionally, are we more productive? A lot harder to say yes to that. Yeah. >> And I think that this is where like the company's on the cutting edge, this

01:38:20 feels like the next thing that everybody's working on is how do we actually accelerate the institution? And this gets harder because you actually have to rethink how the company works.

01:38:29 Um to give you an example, we've gone from a world where code was expensive to now code is cheap. Yeah. In the world where code was expensive, you had all these processes up front to talk to

01:38:39 customers, to align on road maps, to figure out what the right thing to build was because if you chose the wrong thing, that was a really expensive mistake. And so all these humans and all

01:38:48 these processes exist up here. But when code is cheap, you can get rid of all that stuff. >> And that takes redesigning jobs or rethinking the human where the human

01:38:58 actually exists in the first place. >> If you're in YC, you no longer if you were in YC and you were about to talk to your customer, just cancel the call. Just don't you don't need to do it

01:39:07 anymore. It's all good. That's a old No, I'm kidding. No, it's a it's it's a very good point. It's like, hey, show the customer like that's the thing. It's like you don't need to show

01:39:18 >> Yeah. Yeah, it's like a non- tech founder in the past would like show up and like give them a survey or like ask them generically about the problem or something like that and you would get

01:39:26 some signal from that. But now a non-technical founder can literally show up and say like >> would like can you just use this? >> Yep.

01:39:34 >> Yeah. And see what happened and that gives you a lot more information in the past. And so it's just a much different like learning cycle. And I think comp like companies that are, you know, not

01:39:44 in YC, companies that have been around for a while have all these systems and processes that have been built up that have to be torn down and reassembled to work in the AI area. And that's where I

01:39:52 think the institutional AI really kicks in. >> Yeah. How have you been grappling with the idea of work slop? There was this a great cartoon early on where uh you know

01:40:02 the the the joke was take these three bullet points and turn it into an email. And then on the other side, somebody says, "Take this email and turn it into three bullet points." And people should

01:40:10 have just been sending three bullet points to each other the entire time. And I feel like we are hyper in that world where I can send you a, you know, a full essay, a deep research report, a

01:40:19 book if I want, a dashboard, a visualization, a 100page deck. And uh at the same time, sometimes, you know, the human intuition of knowing, okay, this was a good post, let's just do more of

01:40:31 that might be the right intuition. So, how have you grappled with uh you know fine-tuning the team on okay it's great everyone should be using AI but let's stay away from work slop

01:40:42 >> yeah you my uh co-founder Brian says you can delegate the work but you can't delegate the accountability and so you know if you're slinging this stuff you got to stand behind it's okay to present

01:40:51 AI author work I do that often often times I will say hey I was going back and forth with my AI friends >> here is what I found I have read this and I actually like stand behind it and

01:41:02 agree with this, >> but if you're just going to like, you know, throw a random prompt in and then pass it off as like your own work. >> Yeah.

01:41:10 >> That ain't that ain't cool. And so, like, we kind of try and coach people on that the kind of etiquette around that kind of stuff. Um >> Yeah.

01:41:17 >> Yeah. >> I I had that early on. Uh I I was working with somebody and they sent me something that would had clearly been, you know, hydrated by an LLM and I was

01:41:26 like, you you could just send me the prompt because I can actually imagine it exactly what it was. And like, yeah, if there's a fact that we need to look up, we can use it for knowledge retrieval.

01:41:35 But, uh, I I I actually don't need all of the hydration. You can just use this on the prompt. >> You guys you guys are remote company. How do do you think that gives you an

01:41:45 advantage in the in the AI era? Do you know what what are the ways? >> I think the thing the biggest advantage we have is every last bit of work exhaust is documented. So, all of the

01:41:57 stuff is inside of Slack. All of our meetings are recording. uh you know every last inch of work that happens there is a like a written trace of that and so we can put chat bots on top of

01:42:09 that we can put LLMs on top of that and that creates a whole bunch of institutional knowledge that accelerates the work so a new person coming in can literally figure out is there a standard

01:42:19 operating procedure for this is there a skill for this is there whatever to do this thing uh and you don't have to go like chase people down in offices and tap on shoulders and sort of hope that

01:42:28 the campfire wisdom like finds you. So, I do think remote companies have a big advantage because they do tend to have so much of the work um has a digital exhaust.

01:42:38 >> Yeah. Uh how how are you thinking about like uh the the volume of content? Are is it just like stuff everything in one large context window? Are there like pro are there agents that are going around

01:42:51 and like creating little rollups of things and there's processes for teams to boil things down? because even even just the explosion of like uh you know Zoom call recording and note-taking can

01:43:01 produce like so many transcripts and I've been sort of shocked by the slow speed of just search in every tool that I use because there's so many more words that when I search for receipt in my

01:43:16 email or something I get you know every single email possible because they all have so much text now >> so what we have done internally is we've built a company brain out that has uh

01:43:27 canonical data. So it exists at a couple different layers. There's a set of company data. This is like our company strategy, our company values, our ideal customer profile, things like that that

01:43:37 is curated by me and a handful of other people that sort of say, "Hey, this is the truth in these areas." >> Then there's team data and so every team internally has a similar version that

01:43:46 kind of cascades down. And then finally, folks have individual content that they've sort of used to supplement that that's private to them. So anytime someone is like talking to their AI,

01:43:55 they have this you know source of truth that has been curated then you know folks are know that they can pull in other additional content at any given time. And so for me you know if I wanted

01:44:07 to pull in a meeting transcript or a slack thread or something like that I would point the SDK at both those documents and say hey I want you to go review those against the backdrop of

01:44:15 this company brain. And so it sort of helps you manage the context window because you can take, you know, bite-sized chunks here and here, you know, have the like company brain as

01:44:24 like the backdrop to all that stuff and get better um insights versus just saying look at all of Slack or look at all the meeting notes. Um which that would just not be very effective because

01:44:34 there is a lot of noise inside of that. >> Yeah. Have you seen more uh have you seen acceleration either at the lower end below your average customer size or or bigger companies on boarding? Like I

01:44:48 I imagine that uh there are a lot of tailwinds right now for you. Uh but what's uh where are you seeing faster adoption or more interest? >> You know, I think small companies tend

01:44:58 to just move faster. They just have less bottlenecks on this type of stuff. Um that said, I have been somewhat surprised uh over the last couple years how fast enterprises have gotten onto

01:45:09 this stuff. Um you know, they still have more procurement hurdles and um you know uh uh boxes to check to really take off here, but they're not asleep at the wheel, which is kind of the meme is that

01:45:21 ah you know these enterprises move slow and don't make decisions da da da da. Um yeah, I think they just have more things that they considerations that they have to to do. But um I I do think smaller

01:45:31 companies generally just are moving a lot faster on this stuff. >> Are you are you feeling CPU poor? We've been seeing like with the with the explosion of agents and just more work

01:45:42 being done on the internet. I could imagine a lot of your customers submitting way more requests. There's an explosion in demand. And maybe there's two ways. One is just scale up your

01:45:52 servers, but the other one is maybe uh work on optimizations and rewrites. Now the company's been optimizing for over a decade now. So I imagine things are pretty optimized. But how have you been

01:46:03 processing just uh increased demand relative to uh you know just uh infrastructure? >> I think the most interesting place we've seen this is new usage patterns. So

01:46:14 agents you know interact with APIs different than how like a human might set something up. Uh and you're also able to deploy them faster and at a larger scale. And so, you know, when

01:46:26 we're hitting, you know, like I don't know, like let's use like Slack for example, like the way you might, you know, set up automation across your Slack channels like looks a lot

01:46:35 different than it did preai because you have new use cases and new patterns that you want to use that are more um uh just want more data. Like it just wants to look at more stuff. And so I I do think

01:46:48 that uh that's probably the the most interesting change is the the usage patterns are are are different in the AI world. >> Yeah. for some of the more like basic

01:46:57 workflows, what is the what is the pitch for using uh Zapier instead of vibe coding something that takes my LinkedIn post and emails it to me or dumps it in my Slack because that feels like

01:47:10 something that you could effectively oneshot, but then you get caught in who's going to maintenance that or who are you serving that? What happens when the API changes? like uh I feel like

01:47:21 there's a lot of uh excitement about oh I can vibe code this in an hour uh and maybe people aren't thinking about what it takes to maintain a service but how are you how are you uh reiterating the

01:47:32 benefits of being on Zapier >> I think the the fact that we maintain all this stuff is a huge advantage uh the other thing is it's storing your tokens very safely a lot of these vibe

01:47:44 coding tools will say hey just copy and paste your API key here and it goes into a plain text file uh that might get shipped up to GitHub and might get shipped somewhere else that's like crap,

01:47:53 we're in trouble. And so, you know, Zapier just tends to be a safer place to do this. Plus, you know, we have all the vibe coding uh capabilities as well, too. So, you know, hey, take take my

01:48:03 leads from this service and add them to that and d, you know, Zapier is able to do uh a lot of that as well. So, tends to be a little bit, you know, safer, more reliable place to to run these

01:48:12 types of automations. >> Yeah. uh timelines around fully autonomous companies where you can have an agent that you just kind of >> prompt it to uh you know this has been

01:48:25 an idea that's been around for a while. You know, you just say like figure out a way to make money selling software and it just goes off and it maybe makes some software and figures how out how to

01:48:35 market it. Uh I this already kind of exists in kind of the trading world, hedge fund world where they're creating algorithms that just go out and uh figure out ways to make money. But uh on

01:48:48 the software side, I'm curious given everything you know about, you know, automating business processes when you think it's really possible. I I to your point I do think for some

01:48:58 very simple things like it is pretty close trading you know whether you're actually good at it or not TBD but like pretty dang close there. >> Yeah.

01:49:08 >> Uh I also have a former Zappier employee this guy Nat Elias who made it has an open cl Yeah. he's an openclaw that you know started making money on courses uh and you know

01:49:22 basically was yeah openclaw was just like figuring out how to go do it uh and so uh you know it's like pretty close uh so you're starting to see >> there's also use cases like like I think

01:49:33 of like a simple app in the Shopify app store where you could just say like go compete with this app and then it's like pretty obvious where you need to advertise it and you can figure out the

01:49:45 equation between like you could just make the make a clone of the app and then figure out the equation of like what is the minimum amount that I need to charge in order to be able to spend

01:49:55 enough on user acquisition to like eke out some like very thin margin that covers the cost of inference. >> Totally. The thing I don't know is if it's truly going to be a zero person

01:50:05 company or not. Like it does still feel like you need a human to like supervise this thing to like you know when it goes off the ropes to actually have the initial idea. Uh, so you know, I don't

01:50:16 think we're at this dream where you like poke the >> Yeah, there's always gonna be Yeah, there's always going to be qualifiers. Even the one person one billion dollar

01:50:22 company that was in the New York Times, it's like okay, like he hired his brother and then also he had a bunch of contractors. And so there's never like even if you do create like an autonomous

01:50:34 business like if it's working at all then suddenly there becomes an economic incentive to maybe hey maybe I should spend an hour on it and then like well is it still really autonomous if you

01:50:43 spend an hour a week on it. >> Yeah. Well, and that's the thing I think is also going to make it hard for these things to be crazy pervasive is that if someone is being that successful,

01:50:54 there's another person that would look at the thing you're doing and say, "Well, I can do that, too, and let me go compete against your margins." >> Yeah.

01:51:01 >> How do you think about uh terminology? Jordy always gives this example of a company that had workflows and they just rebranded it agents and they didn't really change anything under the hood.

01:51:11 uh and it feels like there's immense pressure from investors and marketers to just use the latest lingo. Uh and sometimes that's useful because the capabilities change and so the

01:51:21 nomenclature should change. But we're in this weird continuum where there's there's workflows, AI workflows, agentic workflows, full AI agents, like are these meaningful definitions? How have

01:51:33 you been processing all of this since you're sort of in all categories? We definitely have a a slide that explains the difference between all three of the things you just said.

01:51:43 >> Yeah. >> Practically speaking though, they're all agents. You know, you know, I you know, I'm sure like somebody who is, you know, uh uh like a master wordsmith would

01:51:53 like, you know, try and debate the finer nuances it. But what I see in the market is practically what people are saying is an agent is a thing that does automation for me. Yeah. Whether it's purely purely

01:52:04 deterministic or whether it's purely agentic, it's kind of an agent at the end of the day. Now, you know, deterministic workflows have some advantages and disadvantages. Agentic

01:52:14 workflows have some advantages and disadvantages. As you start to go build these in production use cases, you probably should understand the difference between these things, but

01:52:24 practically speaking, we see customers showing up and they haven't really figured that stuff out yet. They're just like, I have a problem and I want that problem solved.

01:52:31 >> Yeah. Uh what about uh vibe coding? Like how how broad do you think this trend goes? I saw someone >> uh I think it was who was it downtown Josh Brown joking about how uh there

01:52:45 he's getting sent like a new thing every single day. Uh >> he gave the example of like somebody that makes an app that like displays their Spotify playlist nicely and he's

01:52:58 like you're not my child. Like I'm not going to spend time on this. I don't I don't owe you any time. Um but of course >> Yeah. I I'm just wondering how how you're processing like it it feels like

01:53:08 this year vibe coding is going very mainstream. A lot of people are toying with it. Uh what do you think retention looks like? What do you think the knock-on implications are of this? Uh

01:53:20 any like security concerns? Just how are you processing this idea that like the number of people that will have created software will probably like 10x this year?

01:53:28 >> I think it's very exciting. uh you have all these folks who have had ideas or coming up with ideas for problems to solve etc. But in the past those ideas have kind of been locked away because

01:53:40 they can only implement like a small piece of it and now with vibe coding it feels like you can do a lot more stuff and so I I think that's why we've seen such a surge is that everyone feels like

01:53:50 they can get these creative ideas out of themselves. I do think as an industry there's going to have to be a lot more stuff built out to make these things work in all the various um you know use

01:54:01 cases. I think one of the places Zapier is like very helpful is uh you know connecting to all your data sources and doing it in a secure way like we'll handle all your authentications clearly

01:54:10 and so that's a way that we can sort of uh you know play a really important role in how people go build out um you know these these infrastructure and it can move less from vibe into more trusted uh

01:54:23 you know infrastructure. >> Yeah. Yeah. Makes a lot of sense. Uh Jordy, anything else? >> No, this was great. >> Well, thank you so much for taking the

01:54:29 time to join us. Have a great rest of your week and we'll talk to you soon. Wade, >> good to see you. >> Have a good one. Uh before we bring in

01:54:36 our next guest, Kevin Walsh, who is the new uh Fed chair nominee, uh had a financial disclosure and has a ton of startup investments. He's in SpaceX and a whole bunch of other companies. uh

01:54:50 zero he's a one man DC machine >> brave the the browser cognition >> uh IP the tech enabled patent law firm >> uh dydx >> protocol

01:55:04 >> he's in a lot of stuff uh I think some of this is I think some of this is through funds that he's invested in but still it's uh it's a whole bunch of uh it's a whole bunch of companies uh and

01:55:16 it's interesting to to dig into he also owns a a horse racing stable, something like that. Did you see this? Uh, it also includes his role as a general partner in Vicarage Stable, a horse racing

01:55:28 operation. >> He he is invested in all sorts of things. So, he will be uh disclosing all of that. I'm sure people will dig in more as he uh goes towards the committee

01:55:38 vote. Um, but uh without further ado, we have our next guest in the waiting room. We have Anker from Kerry. is the founder and is here with an exciting M&A update. How are you doing?

01:55:52 >> I'm doing great. Looks like Looks like we both have some M&A to announce in the last couple of weeks. Yeah. >> Yes. Uh talk us first. Let's start uh >> let's start with the gong.

01:56:02 >> Let's start with the gong. Let's hit the gong for the deal. >> There we go. >> Now we can continue. But let's uh yeah let's talk about uh

01:56:14 the the company that you built the background maybe your background even before starting this company that was just acquired. >> Yeah absolutely before this I used to

01:56:23 run a company called teachable.com which helped people make money online for the first time. So it helped people create online courses and coaching and um had a successful exit there during the

01:56:33 pandemic. took a couple of years off trying to figure out what I wanted to build and then I started Kerry uh about three and a half years ago and the mission with Kerry was we help people

01:56:42 first make money online now we'll help them grow their net worth be smart about taxes um I think I came on the show last to talk about taxes so a lot of that stuff and now here we are three and a

01:56:52 half years later excited to share that we've been acquired by two separate companies >> yeah explain that that it feels very uncommon how did this happen what who's

01:57:02 going where the how did this like it's my second exit. I want to get acquired twice this time. The next company you might get four different

01:57:13 >> Yeah. >> Yeah. Twice the diligence, you know, nothing like like running two simultaneous M&A processes. Um but no, the overall company is bought by

01:57:21 Angelist, which is a platform I've had a long-standing relationship with. I, you know, my first company raised money on Angelist. I hired my a lot of my team there. I ran my funds there. Um they saw

01:57:31 the marketing engine we've built. they saw our ability to build and launch financial products and they wanted to buy us to build and launch new financial products to make the private markets

01:57:40 more accessible. >> Um, as they did this, you know, we obviously have built what I consider to be the best solo 401k self-employed retirement platform. They didn't really

01:57:50 have a logical kind of use for that asset. So, we partnered with a company called Lettuce Financial that does tax, bookkeeping, payroll, insurance for self-employed people. And that's where

01:58:00 we're selling the retirement platform. >> Okay. So it's almost two two separate acquisitions. >> So yeah, what does that look like from a customer perspective? I mean, maybe walk

01:58:09 me through the fir like the the actual go to market for the company while you were building it, what the last couple years looked like. Uh because then we can go into you know where what the

01:58:18 experience for the customers is like. >> Yeah. So uh our go to market which I think we we were quite good at is we never spent a single dollar on paid marketing. I think a lot of it was

01:58:27 content education. >> Um, teaching people about the insanity of the tax code, which is there's something fitting, by the way, on announcing our acquisition on April

01:58:35 15th. It was completely unintentional, >> but it's it's funny. It's funny how that happened. >> Um, but yeah, >> the amount the amount of times I would

01:58:42 read like one of your posts and then send it to my CPA and just be like, "Please make sure that we're doing >> following this. >> You're doing this."

01:58:50 >> So, yeah. I mean, was the was the marketing strategy go direct or were you doing I mean, it sounds like content education. >> Content education content work the best.

01:59:00 >> Um, we had a personal finance newsletter with over 100,000 people which worked quite well. >> Um, Twitter has always worked well. I I do think there's some percentage people

01:59:09 who follow me on Twitter are going to be relieved to see less tax content and a lot of buddies be like, "Dude, like Leo." uh but but look I think you know I'm

01:59:18 excited for the next chapter with the angelist where we will apply a lot of the same you know go to market to launch new products for the private markets um meanwhile lettuce is the platform stays

01:59:30 exactly the same customers will you know only get a better experience since lettuce allows people to also do taxes payroll health insurance for self-employed people I'll continue to

01:59:40 stay involved there as well um with more of my day-to-day time on Angelist but most of the teams ends up going to lettuce. >> Yeah. What was uh what was the founding

01:59:48 team like? Who did you hire? How big did the company get? Talk to me about like the shape of the company. >> Yeah, absolutely. So, we we got to about 25 people, about 4 million in ARR. Um

02:00:00 founding team had, you know, four four other co-founders >> and yeah, it was it was the business was at a point where was growing quite nicely where we got to about 250 million

02:00:10 in assets on the platform. Um, however, looking at all the things happening in the market today, you know, you look at it and I'm like, three and a half years in, four million RR, it's a good

02:00:19 business, but you look at some of these modern AI companies and you're like, wow, you know, it's it's a good business, not a not not sort of the crazy multiples you see these days.

02:00:28 >> Yeah. How do you think about the the the I mean, I guess like level set for me on the boom of the soloreneur like what have you seen there? What what what what has stuck out to you? And then I want to

02:00:38 talk about uh that in the context of Angelist. Yeah. So we stumbled upon this in my last company where for the first time we saw you know tens of millions of people

02:00:48 start a business online. I think marketplaces made it very easy for anyone to get attention and when you got attention you could start to monetize this. Mhm.

02:00:55 >> So saw that first happening at Teachable, but then kind of kept investing in the creator economy and seeing the growth of that that when it came time to launch the new business,

02:01:05 which is Carrie at the time, realized that like so many things are provided to you by your job like your retirement plan, your insurance, all of that. As a self-employed person, you may be

02:01:15 financially doing quite well, >> but you have to go figure it out for yourself. Mhm. >> Um, and the solo 401k specifically was one of those too good to be true sort of

02:01:24 personal finance things where it's a private 401k plan just for yourself. You can invest in literally any asset you want. Um, your money grows and compounds taxfree. You can use it all to

02:01:36 contribute to a Roth IRA. You can borrow money from it. You can get a tax credit for setting one up. I was reading this and I'm like this is insane. Like why why isn't anyone like doing anything

02:01:44 about it? So that's where we built Carrie where you know we kind of helped I think 4,000 separate people set up their retirement plans and custody their dollars and all of that.

02:01:53 >> Um and then within the angelist ecosystem, how do you see it feels like there's a continuation of the soloreneur boom vibe coding is obviously a big piece of that. Uh I I I definitely agree

02:02:07 with a lot of people that have tal come on the show and talked about this idea that uh maybe we're not at a oneperson 1 billion company yet, but uh just the ability to build something that is

02:02:17 software with a smaller leaner team sort of lends itself to maybe lower capital requirements, not needing to go the the traditional venture path because it might look more like a lifestyle

02:02:29 business. But I'm wondering how you think the financial markets will react to that dynamic. Yeah, absolutely. I think we're seeing a lot the rise of the one person business is only becoming

02:02:38 bigger, but the angelist acquisition was also we spent a lot of our time educating people on investing and >> you know being smarter with money and I think there's still a big opportunity to

02:02:51 make private markets more accessible. I mean we're seeing this with companies going public later and later so much of the wealth creation people are locked out of. I mean, you can

02:03:00 >> Yeah. >> And like, come on. You can you can buy prediction market contracts on how long a handshake will last. You can, you know, gamble on shitcoins. So, I don't

02:03:07 really buy the whole like we're protecting people angle. >> Sure. >> Um, so the idea with Angelist is we're going to spend some time and figure out

02:03:14 sort of how can we take some of this wealth creation that's historically been uh only for a very few people and make it more accessible, but in a way that's actually, you know, fundamentally good

02:03:26 and investor-friendly products. >> Yeah. Um what in in a perfect scenario, do you think that the uh the public funds that invest in private market companies

02:03:38 should be basically valued at 1x nav because we've seen a couple things go out and they get really highly valued and it feels like uh some sort of like okay the market's not efficient here.

02:03:50 Yeah, I mean I think there's there's a couple of very very big IPOs coming up that will that will determine I think like I know I'm going to sound dramatic but the future of the private markets in

02:03:58 a lot of ways because there is such a massive disconnect right now where >> you have so many fundamentally good companies in the public markets getting completely slaughtered. Uh meanwhile all

02:04:09 kinds of private businesses are are you know continuing to rip. So I think I think there's going to be a reckoning. I think you know companies are staying private longer. U but you know I mean

02:04:20 like I would I would imagine anthropic and open AI have unofficial markets that make them more traded than a lot of public securities. So like you know the the line is blurring. There are

02:04:31 effectively stock prices for a lot of these latest stage private companies. So I think it's a really interesting time. Um and it's to me inevitable that we allow private markets to access more of

02:04:40 this. >> Yeah. Makes sense. Uh well, I know you guys have some big news coming up, so I have a lot more questions, but we'll save it uh for when you guys are ready

02:04:50 to announce, which uh I'm looking forward to. But uh congratulations to the whole team. I think it's super smart to, you know, make this decision and I can't wait to see uh what you do at

02:05:01 Angelus. It's going to be incredible. >> Yep. Appreciate it. Thanks for having me on, guys. >> Thanks so much. We'll talk to you soon. Have a good day.

02:05:07 >> Byebye. Up next, we have Bailey Pumfleet from Cal.com. Cal.com is considering going closed as AI agents overwhelm the open- source ecosystem.

02:05:21 We're excited to have Bailey join us. How are you doing? >> What's going on? Welcome to the show. >> Hey, how's it going? Been a busy day. >> Yeah, very busy day. Uh, please

02:05:29 introduce yourself and the company. We've we've reacted to some Cal.com posts in the past, but uh it's a fascinating company. So take us through uh the shape of the business, a little

02:05:38 bit about yourself, and then we'll go into the decision today. >> Yeah, Calcon has been an open-source scheduling software. We've been around for like five years. The whole company

02:05:47 built around being open source. Yeah. Me and my co are huge fans of the open source space. And um yeah, today we we made the announcement that we're actually going to be closing source,

02:05:59 which is a a very tough decision and quite a controversial one. Before you before you continue, your audio keeps kind of cutting in and out. Do you have uh headphones or I don't know if you're

02:06:09 kind of covering your your mic at all. I don't know if you're picking that up. >> Yeah. Yeah, it sounds a little muffled. >> Hearing every other word. >> Oh dear. Is that sound any better?

02:06:17 >> That's a lot better actually. Whatever you did. >> That's a a Zoom a Zoom magic. >> Yeah, thank you. Um but yeah so um you know we we started this company as huge

02:06:28 believers in open source and um to a lot of shifts in AI um the whole sort of risk perspective has completely changed. AI is now able to break code at completely unimaginable speeds. It's the

02:06:43 one thing that nobody's really talking about. Um we've seen little drops about like anthropics mythos model and nobody has really taken the time to just kind of understand the ramifications which

02:06:56 things like that can have on not just open source but broader application security. >> Uh what was the business model uh in the prior era? How how if you're an open

02:07:07 source software uh how do you keep the business running? >> Fundamentally the business model has not changed at all. Um, so we've always been open source and the code has been open

02:07:17 and that's mainly for the things that the average person would need to be able to run their own you know scheduling service um on their own domain or something like that. Um, as a business,

02:07:28 we actually sell this software commercially and um, you know, open source is actually something that benefits us commercially because we can go to people and we can say, "Hey, you

02:07:37 can look at the source code and you can verify that we're not doing anything sketchy with your calendar data." >> Uh, what if any are the benefits of being open-source during the, you know,

02:07:51 AI agent boom? because I imagine that you are getting automated pull requests and vulnerability reports. Are there any silver linings that you know things you put in the in the pro column before you

02:08:05 realize that the con column overwhelmed the pros? >> Yeah, I think a lot of these things remain to be true that you know with open source everybody can audit your

02:08:13 code. Um so you know especially with AI producing a lot of slop nowadays um the one thing that we have going for us is that we have code which is written by humans and reviewed by humans and so it

02:08:26 definitely creates a lot of trust in that sense. Um it's just that um you know for us there's there's a lot of pros really. Um and we also just genuinely care about open source. We

02:08:39 care about trying to do the right thing with this business. we're going to make money and we're going to do our thing whether we're open source or not. And I think one of the common

02:08:46 misunderstandings um about this discussion is that it's some kind of like business decision um that it leads to greater profit for us. But um you know really we just always

02:08:57 try and do the right thing by our customers and and by our community. >> Yeah. Um talk about uh reputation farming attacks. I I haven't heard that much about this. Uh what is going on in

02:09:10 the open source ecosystem with reputation farming? >> Yeah. What do what do you mean by reputation farming specifically? I'm not >> specifically like like agents that are

02:09:21 trying to go and make lowquality contributions in order to uh you know uh earn some sort of reputation in the open source ecosystem so that they're more likely to see other poll requests uh

02:09:34 accepted. Yeah, I I asked for clarification there because there's actually a lot of different sort of like branches of reputation farming here. You have um you

02:09:44 have for instance like these people out here who are just trying to use AI to attack open source um to just like get cheap bounties. Um you get people who are using AI to make small contributions

02:09:55 to open source and maybe they might be trying to get open source bounties for developing code. Maybe the end goal in sight is to uh get a job at one of these sort of companies or something like

02:10:07 that, but you know, just like how we see a ton of AI slop on LinkedIn and things like that, um we're seeing a lot of AI slop on GitHub. Granted, for us that doesn't really affect everything that's

02:10:19 happened today. um we don't make any decisions because you know there are some like AI slop pull requests but that is something I'm hearing a lot from other projects um where it's really hard

02:10:32 for smaller teams to deal with just the sheer amount of review workload. >> How are is there I mean it's weird because you're already open source there's

02:10:41 always the possibility that a paying customer would say you know what I'm just going to self-host this. Uh so in some ways by being open- source you don't really face the competitive threat

02:10:52 of oh I'll just vibe code this software and I won't use something off the shelf or I won't pay you but is is there a business threat from AI? Is the business threat greater now that I mean obviously

02:11:05 the model capabilities are are greater but uh being closed source sort of incentivizes people to say hey if I want to get it for free I should vibe code it.

02:11:14 Yeah, I think the question about can vibe coding replace my SAS startup is, you know, the the hot thing right now. We feel pretty confident in our defense of that whether we're open or closed

02:11:24 source because scheduling is so fragile and so nuanced. Like if if you say, "Okay, I can build a basiculer in a weekend. I probably believe you. You probably can. But to build something the

02:11:36 scale of cow.com that actually works in all these enterprise use cases and things like that, it's a lot harder to be honest. And um you know, you're going to run into so many little hiccups that

02:11:47 just AI um you know, sort of vibe coding can't currently sort of hit. Yeah, it's it I I I mean I have to imagine that the models will be able to to create a good scheduling app, but it's more about I I

02:12:03 and I wonder if you agree with this, but it feels like it's more about the potential of uh just a company prioritizing their time because there's if there's so many other things and

02:12:13 you're spending your time rewriting and maintaining all of your custom in-house vibecoded tools, uh if you just pull something off the shelf, even if it just costs a you know, 20 bucks a month or

02:12:24 whatever. Um, you're just going to have more mind share towards, oh, the scheduler broke or it's down or it there's a security vulnerability, we need to patch it. Instead, you can go

02:12:35 focus on whatever your actual business is. And so, I imagine that the prioritization is a big factor there, too. >> Yeah. I mean, it's the same way.

02:12:43 Nobody's going to build their own Stripe for payment processing or you're probably not going to build intercom for your customer support. you absolutely can do that, but is it really worth it

02:12:52 at the end of the day? Um, for us, sort of our business model has never really relied on sort of gatekeeping anything. >> Um, but just more that bringing something out of the box and just

02:13:04 deploying it and getting selling is the most important thing to pretty much every founder. >> Yeah. Well, thank you so much for taking the time to come and explain it to us

02:13:12 and break it down. Good luck with the decision and uh and the reaction from the community. and one of my favorite.coms. >> It is a great.com, cal.com.

02:13:21 >> Thank you. >> Still underrated even even after all these years building on it. So, >> well, uh, have a great rest of your day. We'll talk to you soon. Have a good one,

02:13:29 B. >> Thanks, guys. >> Goodbye. >> Up next, we have Han Wong from Mint Lefi. He is the co-founder

02:13:35 >> and Alirds. The markets are closed, but Alberts is down almost 10% after hours >> off of the high >> ended at 17. Okay, that's pretty high.

02:13:47 That's a very big departure from it was what a $10 million company, $20 million company yesterday, and now it is over a hundred million dollar company. That is a massive gain. Uh so we'll see where

02:14:00 Allirds goes. They have a lot to prove, but we're rooting for them. Uh and we're also rooting for Minty. Let's bring in Han from Mintify. How are you doing? Welcome to the show.

02:14:09 >> I'm doing really, really well. Hey, thanks so much guys for having me on today. >> Thanks so much for coming on. >> Love the energy. Are you fired up? You

02:14:15 seem fired up. >> Oh, all birds uh proved to the rest of us that you can just do things. Yes. >> And uh that's the energy that we aspire for.

02:14:24 >> Indeed. Yeah. It was a it was a wild story. But we're not here to talk about Alberts anymore. Tell us about you. Uh give us your backstory and then tell us about the company and then we'll get

02:14:32 into the news. >> Yeah. Yeah. Absolutely. Uh so my name is Fawn. Uh one of the co-founders of Militifi. We founded the company uh in 2022.

02:14:44 uh really off of the simple idea that we wanted to >> thank you uh to help enable other builders. >> Sure.

02:14:53 >> Right. I've been a programmer since I was 11 years old and it's just basically been defining elements of my >> success. >> There you go. Um

02:15:02 >> I'm so curious by all the I know I love it. um and uh basically wanted to build a company enabling other developers because it was you know who I was and

02:15:13 who I fundamentally am >> and now cut forward a few years now powers you know the docs for companies like anthropic Microsoft Coinbase uh Open Claw Perplexity and now well over

02:15:27 20,000 others >> uh you know that now reaches over a 100 million people uh every single year which is uh you know something that we're you know incredibly proud of and

02:15:37 you know uh of the impact that we have. >> Yeah. So I mean fundamentally developer docs are text on an HTML website essentially but uh what's usually unique is the the harness and the environment

02:15:50 that that you know migrates any changes to the code or API endpoints onto those docs. What was the first approach to actually deliver something uh unique or more uh enterprise ready than say some

02:16:06 of just like the open-source like reverse engineering the URLs and just statically serving it which is what I think most people would be familiar with. Uh what was what was like the V1

02:16:16 like okay we have product market fit this is better than the status quo and then we'll go into the AI era. >> Absolutely. Uh initially when we started it was off a very simple idea that

02:16:28 anything on the market wasn't fundamentally uh built for developers >> right which is so ironic because it's the developers who are often maintaining the content. It was developers who are

02:16:38 often reading the content and everything that was out there was just kind of like static site builders that were, you know, often adhering to like a different audience. It felt like

02:16:48 >> and having personally, you know, suffered from so many bad docs out there, I was like, "Hey, look, like if we're going to go build one, let's go build the one that we always wish we

02:16:58 had." >> And let's make that great. >> Yeah. And it turns out those opinions uh that we kind of made into building this platform really resonated with a lot of

02:17:08 the industry >> right it started initially with you know like a few of our YC batchmates then grew to about a quarter of the entire YC batches

02:17:18 >> and then it grew eventually now to serving with some of the largest companies uh you know including Microsoft uh and others. >> So how do you think about integrating

02:17:28 AI? I imagine that there's there's more docs than ever that need to be written. Those docs need to be read by AI. But then also whenever a new endpoint is created, even if it's created very

02:17:42 quickly, it needs to be documented equally as quickly. Uh how have you uh integrated AI into the product? >> Yeah, uh many different ways, but I think it's really important to first

02:17:53 take a step back and understand the changing role of all of this. >> Right. And when we started the company in 22, it was a very simple idea. Hey, like docs are almost like, you know, you

02:18:05 can think of them almost like, you know, an instruction manual. >> Yeah. >> Right. Like, you know, when you assemble like, let's say, you know, Lego bricks

02:18:11 and like, you know, Lego kit, uh, you know, you have to read the assembly manual in order to figure out how these things work. It's written by people. >> You don't have to.

02:18:19 >> You can do the oldfashioned way. >> There you go. Uh, >> but I get your point. >> Yeah. But now it's really important to understand that 50% of the viewers for

02:18:30 the content is actually not humans anymore. It's actually AI. >> So we basically took a look uh across all of our data uh you know a few months back and we're like look you know we

02:18:40 felt the change in AI agents being the end users. What did that actually look like? >> So we went through proxied our viewers identified what are agents and what are

02:18:50 humans? And out of curiosity, um, uh, John Jord, I'm curious if you guys had a guess, like what percentage of traffic do you think now comes from agents versus humans?

02:18:59 >> Didn't you just say 50%. >> Oh, I just said 50%. >> I was think trick question. >> I was like, trick question. It's actually 500%.

02:19:08 >> 50/50 is an interesting place to be because I feel like it'll like it was probably 0% a couple years ago and it'll probably be 99.999% very quickly. Yeah, I would have I would

02:19:18 have >> 50% is the weirdass higher if you hadn't said. >> Yeah, totally. >> Yeah, literally it went from 15% about

02:19:25 12 months ago >> to about 50%. >> Wow. >> Uh a few months ago, and I would say now it's like closer to 60 70%.

02:19:32 >> Sure. >> Uh and so we have a very strong opinion that by the end of the year, to your point, it's going to start to look like 90 plus%.

02:19:40 >> Yeah. Yeah. And if for no if for no other reason than a a developer will just be using a chat app to interface and ask the questions that they want and have the chat app go to the particular

02:19:53 website pull everything in contextualize it at their level based on their memories based on those particular questions they asked instead of opening up 12 tabs and scrolling through a bunch

02:20:02 of different endpoints. >> Exactly. Exactly it. Um, and also if you think about even like what the like the developer work like cycle is nowadays, right? It's like I'm getting here to ask

02:20:13 cloud code to go, you know, v code my product, v code my app. >> And if for instance, I'm like, hey, let's go and use, you know, let's figure out how to implement stripe or a new

02:20:21 feature. >> Sure. >> Uh or an integration, it's going to the first thing it needs to do is actually crawl through the content to figure out

02:20:27 how it's done. >> Yeah. >> Right. And so to kind of tie it back into the, you know, Lego kit assembly manual, well, if you task any to go do

02:20:35 it, the first thing it's going to need to do is to read that instruction manual. >> Yeah. >> And so we view the change of content out

02:20:41 there not so much like a platform or like a website like it used to be, >> but like a crucial part of infrastructure for agents to understand how to implement, how to understand the

02:20:51 world, and how to even maybe even surface like uh you know uh whether or not should use your product. Yeah. >> Because of what it knows. Uh h how do you think about that? I mean you have

02:21:01 some huge customers like the biggest companies in the world at the same time like random like people that don't even have a business are like vibe coding software and do they need to be

02:21:14 releasing developer documentation? Will they be your customers in the future? Like is the long tail going to get longer or fatter or or or do you think this is is you're going to stay focused

02:21:25 on enterprise consolidation like the really really high traffic the important endpoints that get pulled off the shelf from agents consistently. >> Yeah, that's a really good question.

02:21:36 What we're seeing is a bit of both. Mhm. >> So, while it's more important to optimize for like the heavy hitters because those products are getting more usage than ever before

02:21:46 >> and to make sure that they're really well optimized for agents, it is also equally important for like your next twoerson uh you know YC startup or your billion dollar oneperson company to make

02:21:58 sure their product is also out there >> because in the age of AI where agents are making the decision >> how well it understands how your product works

02:22:07 right, is what informs of it of like whether or not should use your product at all. >> And so discoverability, >> right, making sure that your content is

02:22:17 out there uh available um is just more important than ever, especially in the age of where software is, you know, starting to get commoditized as well. >> Yeah. Tell us about the round. What

02:22:27 happened? >> Yes. Uh we raised uh series B. >> How much? >> How much? Uh, $45 million and a $500 million valuation.

02:22:39 >> Congratulations. >> Fantastic. >> I'm honored. I'm honored. I got the gong. >> Of course. Of course.

02:22:44 >> Of course. Uh, la last question for me. Uh, how how did you answer the SAS apocalypse question? Obviously, you guys are using a bunch of AI. You're building agents,

02:22:56 >> but I feel like that must have come up during the round, and I'm sure you had a good answer because you put it together. >> Yeah, of course. Um, so what we fundamentally view is that the SAS

02:23:07 apocalypse is fundamentally more of an enabler for us than anything else. >> As more products gets built because software is actually, you know, the cost of barriers is is cheaper these days,

02:23:20 things like discoverability, how well you expose your content out there is just far more important than ever, right? And this influx of companies being created, companies being

02:23:31 out there and making sure that they expose their information out to the world and agents, uh, has kind of what we've seen in our data, this massive tailwind of adoption for our product.

02:23:40 And now if we're here saying that like you know most of the viewers of your product or how to use your product or agents um you know like having every company enable that

02:23:52 >> uh is uh you know what we've seen as kind of just this big tailwind and explosion of of of use across the board and especially since MITFI as a company have taken this developer first approach

02:24:03 into building docs it actually was really beneficial for agents in actually spinning these things up faster than ever before as well. >> Yeah.

02:24:12 >> Yeah. >> So more more companies pulling it off the shelf and not uh and and not >> Yeah. There's more software companies and then also

02:24:20 >> an agent can just use Mintify to build >> docs. Very cool. >> And I think the really important thing to note is like even from the ground level uh we've only seen the adoption of

02:24:32 our product go up >> significantly in the age of agents. Interesting. And I think as more companies uh you know have more competing priorities and just more

02:24:42 things to do in the SAS apocalypse, I actually think the build argument is actually stronger than ever before to preserve focus what really matters. >> Yeah.

02:24:51 >> Um >> yeah. Yeah, that makes sense. >> Your uh I got to say your customer page is absolutely stacked. Got Coinbase, AT&T, Cognition, Browserbased,

02:25:01 Anthropic, Fidelity, Koshi, Decagon, >> Lovable. >> Yeah, it's everybody. >> PayPal, Perplexity. >> Yeah. And this is a good definition of

02:25:10 like, you know, you're an if you're accelerating revenue now in the revolution. Yeah. >> X. >> Wow. Amazing.

02:25:17 >> You're going to run out of companies soon. That's the bare case. You're going to run out of customers. >> Yeah. I like the design language there where the logos we'll have to pull it

02:25:24 up, but the the the logos have uh like these generated images behind them that have this like very cohesive style, but they all have slightly different flavors to each uh each logo. I I really like

02:25:36 the design. I thought it stuck out. >> Awesome. Well, great to meet you, Han. Chat loves you, too. Thanks for putting up uh with our sound effects. >> All right. Thanks so much, guys.

02:25:45 >> We'll talk to you later. >> See you soon. >> Have a good day. >> All right. We got to close with the farm people who are doing skitso edits now.

02:25:54 >> It's in the timeline. 4,000 people liked it. >> Uh, >> I missed this. >> You You missed this one. Look at this. I

02:26:01 I imagine this has >> Oh, this is the the pig pageant. I >> I've seen people direct their pigs with the with the little guides. The >> We have some SD Kid here.

02:26:11 >> Oh, it is SD Kid. There we go. It sounds like in that genre, but the the background is crazy. the the rotoscoping is extremely sloppy, but that is the essence of that. So, edit. Yeah. Give

02:26:23 you a headache. >> Enough of that. Enough of that. >> Uh, but TVPN is going to wrap for today. Yes. >> But our friend Marsh Yes.

02:26:32 >> has Jensen on his show. >> Yes. >> And I'm going to listen to that. >> Yeah. >> On my way home.

02:26:36 >> Go over there and listen to that. Uh, thank you for tuning in. We will see you tomorrow at 11 a.m. sharp. >> It's been an honor. Apple podcast and Spotify. Sign up for our newsletter,

02:26:44 tvpn.com, and we will see you tomorrow. >> Goodbye. >> We'll see you soon. Love you.

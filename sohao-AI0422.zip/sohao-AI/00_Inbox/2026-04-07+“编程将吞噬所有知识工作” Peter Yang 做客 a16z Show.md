视频链接：[https://www.youtube.com/watch?v=UE8jx4dvlSQ&list=WL&index=2&pp=iAQBsAgC](https://www.youtube.com/watch?v=UE8jx4dvlSQ&list=WL&index=2&pp=iAQBsAgC)
视频发布时间：2026-04-06
频道名：a16z

## 转录内容

00:00 interesting said software will eat the world. I I feel like coding will eat all knowledge work, right? And we're kind of going that direction already. >> The whole agent stack is emerging.

00:08 Identity, payments, marketing, even CLI versus MCP. Like all of these are really new things and I think a lot of the old playbook goes away. >> Yeah. It's a whole new world. I hope

00:19 more companies will stay small and I think the founders of this generation realize that like they want to stay as small as possible. >> Yeah. And instead of having like a 10

00:26 person product team, you have like a two or three person product team and you just have a bunch of a agents help help you. >> Yeah.

00:30 >> Someone tweeted that like the the job market is so bad that I can only pursue my dreams now or something like that. So like it's it's like you know it's like Yeah. So maybe you lost your job but

00:38 like now you can actually do your own thing% and have a shot at actually achieving it, you know? >> Yeah. >> All right. Welcome everyone. I've got my

00:50 friend Peter Yang here. Peter, welcome. >> Yeah. Great to be It's good to see you again. >> Yeah. Yeah. It's great to see you. Peter and I worked together at Credit Karma

00:57 >> for a brief stint. Um and then we went our separate ways and um you know, I rediscovered um Peter from his prolific posts on X and your YouTube and you know, you've got a little bit of a a

01:08 Clark Ken Superman thing going because you still got a day job, right? >> That's right. I still have a day job. Yes. >> Yeah. Can you share where?

01:13 >> Uh yeah, I work on Roblox as a PM. >> Amazing. Roblox and Dre Portfolio Company. >> Yes. >> One of my favorites. Um well,

01:20 incredible, man. Let's get right into it. Maybe I'll start with a softball fun question and then you know we're going to talk about everything in the claw ecosystem. We're going to talk about

01:26 coding agents. We're talking about a little bit about maybe what students should study advice and some of the things that you've talked about online. >> Yeah, sure.

01:34 >> Um maybe to start, what is the name of your Well, how many claws do you have? And tell me their names. >> Uh I only have one. I call her Zoe. >> Zoe.

01:41 >> But I have like multiple conversations going with her. >> Okay. >> Yeah. >> And why Zoe?

01:46 >> Um I I I have two girls and I was going to call my younger one Zoe and I did not. So I'm I call my open claw Zoe instead. >> I see. I see. Yes. Yeah. This is your

01:55 fallback plan. Peter, tell me a little bit about, you know, open claw, how you discovered it, um how you're using it today and and what you think the implications are.

02:04 >> Yeah, I was lucky to interview Peter Steinberger before he became super famous and the whole thing blew up. >> And um then right after I interview him, I I like set up the thing. It took

02:12 forever to set up. It was super janky. >> Um and and yeah, it does a lot of things for me. It like pulls analytics for me across um YouTube and like my Mercury banking account.

02:22 >> It um can update Google documents for me. It can build little web for me. But if I was honest with you, dude, like I mostly just talk to it through voice and get voice replies and like every other

02:32 day I asked you to give me like a pep pep talk like you know give me like like look look through all your memory and like give me some like deep insights that I I don't know about.

02:40 >> Okay. and and like it gave me like like I remember I was on a walk and it gave me like a three-minute pep talk that was like really amazing really amazing like it was something about like uh like oh

02:50 you're like talking to me about your career business and blah blah blah and like your your job but like just remember that your kids you know 74 are going to grow up very soon and they're

02:58 not going to want to spend time with you. >> Wow. >> So like you should really optimize for you know them instead.

03:03 >> Yeah that's really cool and I mean very cool but also something that all the language models could have done prior. Yeah. So what's the difference between this and in a use case like that?

03:11 >> Yeah, that's a very good question. So I don't know because I have it installed on Telegram. It just feels like more personal than using like cloud or chat GPT

03:19 >> and and and it just feels like something I can like text in bed. >> It's probably not very healthy, but like I text to it in bed. I I talk to it during my commute

03:27 >> and it feels like it feels more like a personal like like actual human. >> Yeah. Yeah. So then, so how much for you is OpenClaw about the kind of interface like pushing it to messaging and you

03:37 know maybe helping to trick our brain into feeling like hey this is a person or personesque thing >> um versus all the other components of the stack the self modification skills

03:46 directory um every all the all the rest >> I I think it's probably like 70 80% just like the per personable part of it because I mostly just talk to it and like you know through voice but I also

03:56 think like is it's something for first of all it is pretty janky it tends to forget things a Yeah. >> To keep reminding it. >> But like any kind of zany idea that I

04:05 have, I just have to talk to it and it can probably just do like like it's kind of just like >> um like the other day I was doing voice replies with it. I was like, "Hey, can

04:13 we just have a live phone call instead?" >> And and then I was like, "Okay, you you got to connect Twilio. You got to do all this stuff." And then okay, fine. I I went off and did it.

04:20 >> Yeah. >> And then we had a phone call. It called my phone. >> Oh, really? You have that set up? I've been dying to set that up. Okay.

04:25 >> It's not very good though. Like the latency is bad, but like the fact I was able to get it going is like pretty impressive. So it's kind of like any kind of crazy idea I have it can kind of

04:33 kind of do. >> And then in practice, how are you doing that? Are you asking it to write a skill on the fly? Are you discovering a skill? How much of the code gen are you

04:40 actually using? >> Um I mean I talk to in like a super casual way with like just just like a friend. So like hey you know hey Zoe can can like can I have a phone call like

04:49 okay you got to do that. I said okay fine I'll open my computer. I'll do all this stuff >> and then it's like give me a call and then we troubleshoot a little bit and

04:55 then it works. So like I with with cloud I have like very fancy prompts uh like very long prompts but with open cloud I just kind of text it. Yeah, it is >> really interesting. So we sort of

05:05 touched on a couple things actually. So one there's mobile messaging, >> there's the memory system. Um there's the sort of code generation component. Um

05:14 >> how much do you think the memory system like is it innovative because it's file based? You said that it forgets things but so do language models. Like do you think the memory system is well done?

05:23 Does it hold it back or does it enable it? I I I think the default memory system is actually not that great. >> Okay. >> Like the way I understand it works is

05:29 like just like a memory MD text file. Yes. And then every day per day. Per day, right? And every day it updates and it tends to forget things a lot. >> Yeah.

05:36 >> So So I actually installed this like three layer memory system that to be honest I don't fully understand but it has like >> that's fancy.

05:43 >> It has like Toby's QMD search tool. >> Okay. >> Uh so I installed that and and then install like a 2 GB thing and and then it got a little bit better.

05:52 >> Okay. Um, but I I said to remind it like I have to I had to put it into the agents MD like hey like before you answer any question from me like go through all your memory and like check

06:00 everything. >> Yeah. >> And it also tends to forget that it can do stuff like you know like can you update my Google doc? It's like oh I

06:06 can't do that. Yes. Yes you can. It's it's in your it's in your file. >> Yes. Yeah. >> So you have to remind it. Yeah. >> Yeah. Really interesting. Well well

06:12 maybe let's get into a little bit of the controversy. Um you know you'd said that apps will die claw is going to be everything and everywhere. I mean talk us through that that point of view.

06:21 >> Yeah. Yeah. Well, for first of all, I I I tweet all all kinds of random crap that's like not super well thought out. >> We take it all as fact. >> Yeah.

06:27 >> Yes. >> Um but I do think like um like ever since I set up all these apps like Mercury, MCP, and all this kind of crap on my open call, like I I don't actually

06:36 open those apps much anymore, you know. But I do agree with you like I I I think the ones that are going to die first or like maybe get less usage first is like apps that you're just opening to try to

06:46 complete a task. like you actually are trying to do something, you know, like apps that you don't need to like get entertainment can probably survive a little bit longer,

06:53 >> but like apps to complete a task like it's just way easier to text my agent to do it for me. >> Yeah. >> It's like it's like you have a really

06:59 good admin just to do stuff for it for you. >> Yeah. >> Yeah. >> And so how much are you finding has this

07:03 like reduced your smartphone usage outside of Modulo Open Claw? >> Yeah. Um, no. Because like I'm I'm like a Twitter addict, so I still use phone way too much. But yeah, in terms of

07:12 using those apps has definitely reduced it. >> Yeah. >> Yeah. Yeah. because you're not going to ask Zoe like, "Hey, read my X for me and

07:18 tell me what's interesting." >> I mean, it it sends me like a morning briefing of like the top two tweets and stuff that like trends, but but yeah, I I I still open X. I look through it.

07:27 >> Yeah. Yeah. You know, it's interesting because I've always had this theory that people open apps on their phone because they want to feel a feeling. >> Yeah.

07:32 >> You know, and I think of course there's some like functional set of needs which is why you open calendar or something, but I also think that, you know, WhatsApp is you want to feel connected

07:40 and Slack is you want to feel productive and of course, you know, Tik Tok is you want to feel entertained. So I do wonder with just one agent, how do you sort of do the context switching of like when

07:51 are you flirting, when are you getting done? I mean there you know in a sense app gives you a nice it sort of gives you a nice division of the intents.

07:58 >> Yeah, you don't get with Zoe. >> That's a good point. But I I do have multiple channels set up with Zoe in Telegram. Like one is just to random voice replies and the other one is we're

08:06 actually working on our project together. >> Oh, >> and another one I have like a public channel where like I'm giving that

08:11 demos. I don't want to reveal private information. Yes. So I have like multiple channels >> and is that um implemented as sub agents or

08:17 >> No, it's just some janky setup I I found online like you can set up a multiple Telegram channels and then I'm not sure if she actually remembers across context across the channels but like you can

08:26 have separate conversations at least. Got it. >> Yeah. >> And how how you know transparent are you with your agent? Like does they do they

08:33 see your personal email or >> uh I'm I'm like super transparent. Well I I I I did buy the Mac Mini and set up its own email. >> Okay. And but I gave it like read access

08:43 to my email and like calendar and uh I also gave it like right access to some docs. >> Yeah. >> But it can like scroll my entire drive

08:50 or something you know. >> Yeah. So >> how do you imagine open claw which it's sort of an architecture and a primitive. How does it get productized packaged for

08:58 the world? >> I mean I think that's what Peter Steinber is working out at OpenAI right. It's probably going to build something to chat GBT which everybody uses uh so

09:08 that chat GP can actually get stuff done for you and like maybe feels more human. >> Yeah, >> dude. Like let me rant about chat. >> Yeah. Yeah.

09:15 >> For some reason for some reason they they trained the model so that like at the end of every conversation is always like if you want I can also do X and Y. >> Yeah.

09:23 >> And I I got so annoyed about it that that kind of turned from Chad GPT. >> Oh really? >> Yeah. So so it probably increases their matrix but like it's just like super

09:30 annoying. It's like why don't just do it in the first place? Are you a cloud guy now? >> Yeah, I'm I'm a cloud guy now. But but I I I do use codeex uh to code.

09:38 >> Yeah. >> Yeah. >> You like codeex, you prefer it to cloud code or you use both? >> Um codeex when I want to try to build

09:43 something real and cloud code is when I'm just like vi vibing like very you know well it's interesting. I think they live at different points and you know there's a sort of space of trade-offs.

09:52 Yeah. >> Whereas I find um cloud code and opus 46 it's a little more chatty. It makes more assumptions but it can be more pleasant for a synchronous experience. Whereas

10:00 codecs, it really thinks hard and it's more often accurate. But sometimes it's sort of like being in a conversation where the other person pauses for like three minutes to think.

10:09 >> Yeah. >> You don't have to flow flow state, right? It's hard to get a flow like clock. Dude, I I tweeted the other day. Clock is almost like uh like a slot

10:16 machine. It's like it's like has different things each time. It's just like >> Oh, 100%. Look, I I do think that if you think remember we were talking about in

10:23 the old social networking era, it was variable scheduled rewards, right? That was the whole magic of it. like you open your Facebook feed and you know once in a while it's like boring boring oh my

10:31 god this is so exciting and I the coding agents have the exact same property also the time is variable so sometimes you get something in a second sometimes it takes five minutes so up to a certain

10:42 point I actually think that both of those things give it that casino like feeling >> yeah and and the other thing that's very different about the product strategy or

10:48 maybe it's just the way it works is like coding is kind of like self-explanatory >> and clock hole you have all this crazy you have like hooks and like skills and like you have to you have to plug in

10:57 If if you if you're not following Yeah. If you're not following X, you have no idea how do you customize this thing. >> Yeah. >> But once you customize it, you kind of

11:03 feel like it's part of you. So it's it's kind of hard to turn. >> It's interesting with uh so I've customized mine cuz also I read the long thing that Boris put up. Yeah.

11:10 >> But I will say that I think that you know cloud code a lot of the reasons that I enjoy it are just harness features. >> You know like for example if you cut an

11:20 image you have to paste it into a file before and then paste that file into codeex. Okay. You can't just take a subset of the screen, screenshot it, and then paste it directly into codeex the

11:30 same way you can with cloud code. >> Oh, really? Okay. >> So, just like little things like that. You know, cloud code added voice. It's a little bit janky right now, but it's

11:36 going in the right direction. So, they've just got a bunch of quality of life things. >> Yeah. >> You know, Cloud Code speaks to Claude

11:42 and Chrome. >> Okay. >> And Codex doesn't speak to Atlas. >> Got it. >> So, I think these are all things that

11:46 OpenAI will fix. Yeah. I think Codeex is actually a much better model. Um, but they don't exist today. >> Yeah. Yeah. They need to fix it. I mean, they're going to go all all in on

11:55 cohortex, I'm sure. >> Yeah. >> Talk to me about coding agents. Like, what's your general view? You know, do you think it's the end of SAS? Do you

12:01 think these are just a toy? >> Uh, well, first of all, I'm I'm I'm like not an engineer, so I'm like a novice. But I do hear that um >> like I was talking to some folks uh the

12:11 other day and like like a AI native star startup and they're basically trying trying to they have a bunch of vibe coders >> and a lot of vibeers are just trying to

12:19 build internal tools that replace their SAS that they're paying for. >> Really? So it's an actual company that's doing this. >> It's an actual company. Yeah,

12:25 >> it's an AI native company. >> Is it It's like one of the vi coding companies, like one of the more popular OS. >> Interesting.

12:30 >> Yeah, >> it's Oh, oh, I see. So they're actually an appgen company. >> They're appgen company and they they're paying for a bunch of SAS like uh and

12:36 they want to get rid of the payment. They want just buy by by coding internal tools >> by using Okay. So in that case that that they might be the most extreme form of

12:43 adopter because their own product is AppGen. So they should use Appgen for everything. I guess is your prediction though that the average company will churn off of Slack or Deal or you know

12:54 >> um I don't think I I I feel like Slack has a lot of legs because Slack can also be the place where you talk to the agents themselves. >> Uh but some of the other ones they are

13:03 pretty complicated you know so like it's kind of be hard to buy that kind of stuff >> but but I feel like if you have like an app like maybe Calendarly or like

13:10 something more simple >> Yeah. >> then why why why should I why should I pay for it? Like I just >> why should I pay for it though? The

13:15 counter point is that it's not that expensive. And do you really want to maintain your own Calendarly thing? >> Yeah. >> You know, versus pay 20 bucks a month.

13:23 It always gets updated. It's always up, you know, because there's just like a fixed amount of capacity that anyone in the organization is going to have for all this stuff.

13:29 >> Yeah. That that that's true. Unless you hire like dedicated viers like the startup does, right? Voicable stuff. >> But then it's like, you know, the cost benefit versus just paying for

13:36 >> Calendarly. Yeah. Yeah. Yeah. Yeah. Yeah. It's interesting about like for example like a lot of people are tweeting about Figma recently. >> Yeah. uh like like the stock is down and

13:45 like you know are are you going to survive? >> Yeah. >> And um >> I feel like the jury is out there like

13:51 it's kind of hard to say. Yeah. Uh I I I feel like all the designers are still on fake Figma but like as a designer you kind of need to learn how to vibe code otherwise you're going to like if you

14:00 don't know how to do Figma. >> Yeah. >> Like you're probably going to be like out of date >> in a couple years. Yeah.

14:05 >> My counterpoint to that is that I think that I've thought a lot about the sort of thinking tools versus making tools, right? The IDE was historically a making tool. Mhm.

14:12 >> It's a place for execution. I think it's migrating away from that. And now with execution going to zero, I think these sort of like multi- aent, you know, nextg ides, a lot of them are about

14:22 trying things >> and using the trial and error as a way to inform your thinking. Like a lot of times I'll just build a feature in a really naive way and I'll hammer the

14:30 coding agent until it works. Then I'll say, "Hey, write all the things that you would have done differently and I'll go back to the initial point and redo it." >> So I wonder if and I think Figma

14:40 actually does both. I think it's a place for design execution, but it's also an important place for design thinking. And I think that's their opportunity to be highly relevant in the new stack.

14:48 >> Yeah, I totally agree. I totally agree. Um, but I I I think A6Z has like uh you guys investing pencil or something. Pencil.dev. >> Speedrun did. Yeah.

14:57 >> Yeah. Speedrun. And like um >> yeah, Figma needs to like uh level up his AI tooling because you know like watching these agents collaborate with you and like do stuff is like very very

15:07 interesting. >> I know it's top of mind for them. Um yeah, what do you think are the most under discussed capabilities of coding agents? You know, what's what's

15:14 underhyped and maybe what's overhyped as well? >> This is probably not underhyped, but like but you know, like you know, I I I feel like ent software will eat the

15:21 world. I I feel like coding will eat all knowledge work, right? And we're kind of going that direction already. Like I I think lovable recently launched like today. Yeah.

15:28 >> That they can support everything and replic. >> Yeah. >> So, so yeah. So I and I feel like everyone's cha chasing this like and is

15:37 probably in the lead. >> Yeah. But like, you know, like I I don't want to use PowerPoint anymore. I don't want to like write a Google like I hate writing Google Docs, dude. Like my

15:44 entire life. >> Yeah. Yeah. So, so like but but but the other day I was writing my blog post and instead of just like typing it out, I was like, "Hey, let's let me just use

15:52 clock code and like you know, let me give you a bunch of feedback and you you write it for me." >> Yeah. >> And then you just keep the

15:58 >> um >> it it did the first 80%. The last 20% I had to manually like go in there like tweak tweak tweak stuff. >> Yeah.

16:04 >> But like that that's the way I work now. I I never start from zero. like I always get the first 80% from AI, >> right? >> Yeah.

16:11 >> Yeah. It's interesting, you know, if you look at there there are also like historical analoges of this. I think Satya said this um which is that Excel is the most powerful or most popular

16:20 programming language in the world. >> Yeah. >> And that it's sort of a programming language that millions and millions I mean 100 million plus people must know

16:26 maybe even more. Um and yet we don't think of it that way. It's a way to sort of describe and solve problems. >> Yeah. >> And I think coding agents are going to

16:35 be that of course times a thousand. Yeah. >> Where even things that feel subjective like writing Google docs can be represented in the coding domain in such

16:43 a way that it's more satisfying productive more to use agents to do it. >> Yeah. Because Excel was like popular because it's super appro approachable, right? Yes. And like coding agents the

16:52 code is basically gone like it's like appra just talking to some some agent and getting to do do stuff. So >> Yeah. Yeah. >> Yeah. Exactly.

16:58 >> It's going to be hu huge. Yeah. >> What do you think the future company looks like? Is it just a bunch of agents with a CEO? Is the CEO an agent? I mean, what is the role for people in a company

17:07 in the future? >> Okay. Well, I have some hot takes. So, we we both worked at uh some companies together and um >> Uhhuh.

17:13 >> Uh let let me give you a hot take, man. Maybe we cut this out, but like I feel like as a company gets bigger, >> it tends to get it tends to become like a shitty shittier place to work,

17:20 dude. Yeah. Like like because there's like a lot of people you have to align. >> I think that's axiomatic. Yeah. >> Right. And and I remember, you know, maybe I should mention this company, but

17:27 I remember our company used to have all these like OKR meetings and like I remember sitting in a room for like three hours talking about OKRs. I'm just like, dude, this is like wasting my

17:34 life. >> Yeah. So what where I'm going with this is I hope more companies will stay small and and I think the founders of this generation realize that like they want

17:41 to stay as small as possible. >> Yeah. >> Um and instead of having like a 10 person product team, you have like a two or three person product team and you

17:47 just have a bunch of agents help help you. >> Yeah. >> You know, because I I I think it's way easier to cross launch a line with a

17:52 agents than with with humans. >> Yeah. Yeah. Well, actually in a in a sense the agents actually because it takes the emotion out of it too. Like you can imagine if I sent my agent, you

18:01 sent your agent to go negotiate something. Yeah. >> And they came out with some conclusion. It's not emotional. >> It's not

18:07 >> for either of us. You know, >> it's very objective. Yeah. >> Yeah. Yeah. Exactly. Yeah. It's funny. You know, one of the things that we've been talking a bunch about is like

18:13 >> what is the procase for AI at work in terms of employee experience? And I think it's what you're describing, right? Like how do you increase the NPS of work? Yeah. So, if we like go all the

18:22 way back or even broadly the NPS of the human experience, right? Like think of the NPS of the day-to-day human in 10,000 BC when it's like just don't get eaten by the lion and that's like a good

18:31 day, right? Or you know maybe a 100 years ago it's like okay don't get killed at the factory >> um crushed by the the steam press or whatever else. And um and now a lot of

18:40 it is like h like just don't get sucked into some high emotion you know sort of negotiation with another VP's subordinate. Um >> yeah like a 50 me stack thread going

18:50 back and forth. >> Yeah. Exactly. And then eventually everyone's like, I don't want to tell the CEO. And eventually it goes there and it's just terrible. Um, so maybe the

18:57 future of this is that a lot of that emotional subjective work gets handled. >> Yeah. >> And we're sort of guiding the process but not in the middle of it in a way

19:05 that just doesn't suit us as humans. >> Yeah. Like you know, I I I lead a double life as a PM creator and like I feel like all the PMs actually just want to create products. They want to create

19:14 products and and >> well that's why we all got into it. You know, it's it's so interesting. I mean, Nicole talks about this all the time, but like every PM's sort of view view of

19:22 the ideal PM is the innovator, you know, like I came up with the new thing and it's like I sort of like had the big insight and it unlocked the product. >> Yeah.

19:30 >> I think the black pill is I don't think most PMs know how to do that. In fact, many companies have zero people that know how to do that at all in any function.

19:38 >> Yeah. So, nonetheless, I think PMs aspire to be able to do that and they should either do it and either be successful or maybe not successful and move to a different function. I I also

19:47 feel like my hot take is like uh like basically all the PMs I know are trying to vibe code at night on weekends. >> Yeah. >> And I feel like my hot take is that like

19:55 I feel like if you're actually unemployed like you probably have more time to be a builder and like to be innovative because you can actually like play all this stuff and like learn all

20:01 this stuff. >> A lot of PMs are trying to >> or maybe be an engineer in the team, you know? I used to be an engineer and I got sort of I don't know if I got forced to

20:08 be a PM. Maybe I also perceived PM as like being a little more high status when I joined Google. But then eventually you like this is terrible, you know, like you never really get the

20:18 satisfaction of actually shipping other than like you know once a quarter when you ship. >> I mean the PM skills of like talking to users and like trying to figure out what

20:25 to do like what problem to solve like those are very important still. >> Yeah. >> And and like but yeah, you got to wear multiple hats, dude. You got you got to

20:31 like go go go build a thing yourself, go prototype it and get some feedback and then maybe bring engineer along. >> How much do you think that everyone has to go as fast as you know I mean like

20:40 Gary was talking about stemmies and skipping sleep and 10 like you know GStack I mean is hey I mean is that like the default way that we all need to work or do you think there's a trade-off for

20:50 thoughtfulness? >> I I I think it's very easy now with all these AI tools just going like 10 different directions at once. >> Yeah. So sometimes you do have to slow

20:58 down and try to figure out where you want to go. >> Yeah. >> But I also believe that like u the traditional process where you like do

21:03 annual planning and like do all this like I just feel like that doesn't really work anymore, >> you know? >> Yeah. Yeah. And for the record, I love

21:10 Gary and I like think the world of him. So here's my view on that because I thought a bunch about that. You know who asked me this the other day? Hithan um who's really really impressed. Yeah. Ch.

21:18 Yeah. >> So we're talking about this like sort of productivity porn and everybody's got 20 agents running and 20 monitors and blah blah blah. And like I do think when it

21:26 comes to um fully realizing a local a sort of local maxima, you should go very fast, right? So let's say you kind of hill climb, you get to the bottom of a new

21:37 local maxima. I think with agents, you should be able to get to the top of that hill extremely fast, right? You have a new insight, build everything around the insight so it's fully expressed. But

21:47 then I think to get to the next, you know, the next sort of hill, >> you've got to probably slow down and almost stop and go touch grass and do whatever. Yeah.

21:54 >> So I think there's this combination of like fast and slow. That's probably the future way. >> Yeah, I think so. And and like you got to go on that random walk trying to find

22:01 hard market fit which take takes us a while, right? So it's not like >> Yeah. >> So we were talking before we started recording about some of the business in

22:08 a box platforms. >> Have you looked at them? Do you have a view? >> I've looked at post yet that we talked about like I don't know if the guy like

22:16 intentionally made it the opposite of AI slab or or is it kind of you >> I think so. Yes. Yes. >> That's funny. Well, I mean, I have a pretty big public presence, right? So, I

22:25 connect all my to to it. And then, um, I mean, it's it's definitely gives a good peak into what's possible, but like right now it's probably still pretty like early stage. Like, it's telling me

22:34 to run like fa Facebook ads. Like, >> why am I running Facebook ads? >> Yeah. >> You know, so >> I don't know. Yeah. Yeah. Yeah. I I

22:40 mean, I'm very excited about it because it does feel like it's a path for more people to build companies. Yeah. Even if they're single oneperson companies, you know, like if you think about how

22:49 competitive it is to build a billion dollar business, like the markets that support it, the number of people trying versus hundred million versus 10 million versus $100,000 TAM. Yeah.

22:58 >> Like maybe there are these pockets all over the country, all over the world where there are opportunities for $100,000 TAM products. Yeah. >> And that would change somebody's life.

23:07 Now, that's not an enterprise ventureback company, but that's okay. Yeah. So, I hope that whole thesis works because I do think it's a way to get more people to participate, you know.

23:15 >> Yeah. That that that's my plan for my kids, dude. Like I want them to just build like um bootstrap businesses in high school. >> Yeah.

23:21 >> And they can skip the whole college and like uh core corporate life. >> Yeah. >> Well, dude, I think this is like, you know, for 10 years there's this moral

23:28 panic about the kids want to be YouTubers. Yeah. You know, you're a YouTuber. >> Um you know, you know, in the in the vein of Mr. And and I think the like pro

23:36 case for that actually is that the kids wanted to be entrepreneurs or have agency. And the only channel for people if they weren't programmers was creating YouTube videos at least online.

23:45 >> Yeah. >> So if you're like an online native generation, you want to create something you're not a programmer, you make a YouTube show. Now you can make a lot

23:51 more than that. >> Yeah. You you can build whatever you want. Yeah. >> Exactly. >> So Exactly.

23:54 >> It'd be very exciting. Yeah. >> Yeah. Any other hot takes for us? >> I'm curious about your thoughts about this actually. Like so I feel like uh a lot of people are saying like agents

24:02 will interact with your product first, >> right? And and then you see all these great companies like uh building like APIs and MCPS. >> Mh.

24:10 >> But like how do how do you think about like you know you've been consumer for a while. So like consumer is like you got to get the user to come back and use your product, right?

24:18 >> Yeah. >> But but now like the user is like hey go send the agent to use So, so how do you think about retention and all this like basic stuff like how do you you know or

24:24 even like brand equity because the agent just like point some API like you know how do you >> yeah I don't okay so I think one of I don't know is the is the truth but um

24:33 there's I have a few thoughts so one I think that a lot of the sophistication sophistication that happened in consumer happened because we had to have indirect monetization

24:44 >> okay like we just were never charging consumers directly for these products which is why you got >> got ads and stuff >> ads and large scale networks and we all

24:52 obsessed with retention and engagement and whales and all of these things really really mattered because we didn't simply charge people for products. >> So I think one big thing that's actually

25:01 really helped in the AI era with that is that consumers are now excited to try new things. They're willing to pay they're willing to pay a really high price point.

25:07 >> Um there's also consumption revenue in consumer for the first time >> like token and stuff. >> Yeah. Yeah. For like tokens. You have your subscription plus your token. So

25:14 and then the actual like the sort of blessing in disguise is that there are real costs as well. you have these inference costs. So you're like, "Wow, we have to charge our customer on day

25:23 one." >> So I think one thing is that like the business model simplification I think will really help with a lot of what you're describing.

25:30 >> Two, I think that a lot of the products will have a sort of, you know, it'll have an API interface for your agents to interact with or for, you know, for transactional sort of wrote things.

25:39 Yeah. >> And then it'll have like a consumption based interface as well. >> So you can also imagine a like a mobile app where there's like the feed, but

25:46 then you can kind of turn it over to where the wires are. >> Mhm. And you can just ask for things to get done or you can just see the log of the things that got done.

25:53 >> Yeah, maybe people would do both, right? >> I mean, you can imagine Credit Karma where we worked, you know, like once in a while you want to just take a look at your score history and a few other maybe

26:00 credit card offers. I don't know. I mean, >> yeah. Yeah. If I get my score with all kind of credit card offers, I'll definitely do that.

26:04 >> Yeah, 100%. Exactly. >> On the other hand, like sometimes you want to just be like, yo, like can you just fix all my stuff or like what stuff did you fix this week? How much money

26:11 did I save? You know, >> got it. Got it. >> Yeah. >> It's definitely interesting. Yeah. >> But look, I also just think the whole

26:17 agent stack is emerging. identity, payments, marketing, we don't even even CLI versus MCP. Like all of these are really new things and I think a lot of the old playbook goes away.

26:28 >> Yeah, it's a whole new world and like in 2025 I thought agents was overhyped but now I think it's really coming like >> me too. I know it's just the word is frustrating because it gets so

26:37 overloaded. >> Yeah, there's like workflows like all this kind of >> Totally. I've been trying to just say like can we just say like model in a

26:43 loop? >> Yeah, exactly. Model that use tools in a loop. That's the best definition. Yeah. Yeah. >> But nobody likes to hear that. It's

26:48 Asians is much flashier, you know. >> Yeah, it's flashier. >> Yeah. >> My my hope is that um >> all all this stuff's like a lot of

26:54 people think like we're going to lose our jobs, which probably what will happen at some point, but like I hope all this stuff >> makes just makes like uh human work more

27:01 fun like our jobs more fun, >> you know? >> Dude, I don't think we're all going to lose our jobs. Like I really think the and we see this a lot of companies, you

27:07 know. So we look at a ton of companies and we've seen two different buckets. So >> one bucket is hey, we dramatically increase productivity for a person or a team. We see this in like recruiting,

27:17 >> but we couldn't do 100% of the job. So, we could do the phone screen, but we couldn't obviously, you know, show the candidate around the office or we could do the phone screen and we could like

27:26 answer all the questions about the company and we could even do the like comp negotiation, but we couldn't do the onboarding. >> Yeah.

27:31 >> The other style of company which we see which is maybe a decagon, right, or a happy robot is hey, we did 100% of a job like customer support. >> You know, the the customer called in,

27:40 they had a question, we hopefully resolved their query and then that's it. M and that is 100% automated. I'd say that that second group where you have 100% automation of a job function is

27:49 really rare. Almost every AI product AI native X or Y we see is able to provide dramatic lift but it's not able to do 100%. >> So last 10% use humans.

27:59 >> Yeah, it's still it's today anyway it's still humans that do that stuff and it's interesting too because the buyer looks at that as software as expensive software whereas in the case of

28:08 something like a happy robot docking Sierra they look at it as like cheap labor. M >> so I do think there's a different buyer mindset but because there's been this

28:15 difficulty of getting to 100% automation I think a lot of the efficiency gain shows up in just a different way probably not less jobs maybe we get like the European style 4 day work week maybe

28:25 companies get like twice as productive I have no idea >> yeah but but you don't think that like uh I I I feel like there's going to be a transition from like these like 10,000

28:34 plus people companies laying a lot of people off to hopefully like more smaller companies like solarreneurs and stuff like that >> I I think yes I think that they'll the

28:42 the sort of shape of the economy is going to change like the amount of concentration but I just don't think there's going to be less jobs. I think human ambition has no ceiling.

28:49 >> You know, human desire has no ceiling and just read any mildly interesting science fiction book >> like there's no way this is the peak expression of all the stuff that we want

28:57 and we need and we're going to convince ourselves and you know all the new things that you read about every day is these luxuries peptides and you know everybody is going to have all of that

29:05 stuff and want even more. You know, dude, I I saw a really good tweet about this. Like someone tweeted that like um the the job market is so bad that I can only pursue my dreams now or something

29:15 like that. So like it's it's like you know, it's like Yeah. So maybe you lost your job, but like now you can actually do your own thing. >> And have a shot at actually achieving

29:21 it, you know? >> Yeah. Yeah. >> Cool. >> Well, awesome, man. Maybe that's a good uh positive note to end on.

29:26 >> Yeah, that's good to know. Yeah. Cool. Good thing you do. Yeah. >> Thanks, Peter. Yeah. Thank

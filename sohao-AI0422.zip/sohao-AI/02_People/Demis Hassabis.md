---
type: person
name: Demis Hassabis
company: Google
role: Google DeepMind CEO / 联合创始人
date: 2026-04-20
status: 进行中
themes:
  - AGI
  - AI for Science
  - AI安全
markets:
  - "[[05_Markets/AI基础设施与数据中心市场]]"
  - "[[05_Markets/机器人与物理世界智能市场]]"
core_beliefs:
  - AGI 的标准是具备人类心智的全部认知能力。
  - AI 首先应被看作推动科学、医学与能源突破的终极工具。
  - 未来几年最关键的瓶颈仍是算力、实验速度以及持续学习能力。
keywords:
  - AGI
  - compute
  - continual learning
  - memory systems
  - cautious optimism
important_quotes:
  - AGI 是具备人类心智全部认知能力的系统。
  - 未来五年内出现 AGI 的概率很高。
prediction_style: 长周期目标 + 概率分布判断 + bottleneck 导向
change_log:
  - 2010 年前后，DeepMind 内部把 AGI 时间预估在约 20 年后。
  - 2026-04 的公开表述是未来 5 年内有很大概率出现 AGI。
related_companies:
  - "[[03_Companies/Google]]"
related_products: []
related_markets:
  - "[[05_Markets/AI基础设施与数据中心市场]]"
  - "[[05_Markets/机器人与物理世界智能市场]]"
source_notes:
  - "[[01_Sources/2026-04-07+德米斯·哈萨比斯：为什么通用人工智能比工业革命更重要？人工智能的瓶颈在哪里？]]"
  - "[[01_Sources/2026-04-13+谷歌DeepMind总裁谈人工智能、权力、上帝以及未来展望 《经济学人》]]"
summary: Demis Hassabis 当前最稳定的研究主线，是把 AGI 理解为一套完整的人类级认知系统，并把 AI for Science 视作其最重要的正外部性；在方法上，他持续把算力、持续学习、记忆系统与长期规划看成下一阶段关键瓶颈。
my_take: ""
tags:
  - ai
  - person
  - deepmind
  - agi
---

# Demis Hassabis

## 一、人物简介
- 公司：Google / Google DeepMind
- 职位：Google DeepMind CEO / 联合创始人
- 关注方向：AGI、AI for Science、AI 安全、持续学习与记忆系统

## 二、核心思想
1. AGI 不是单点能力突破，而是“具备人类全部认知能力”的系统级目标。
2. AI 最重要的长期价值，不只是替代劳动，而是加速科学、医学、能源与材料突破。
3. 现阶段模型仍缺少持续学习、长期规划、稳定记忆与一致性，这些缺口比单纯“再大一点的模型”更值得长期跟踪。

## 三、他反复强调的关键词
- AGI
- 算力
- 持续学习
- 记忆系统
- 科学发现

## 四、判断框架
### 1. 他最重视什么
他最重视的是“能否把 AGI 做成真正可靠的科学工具”，而不只是更强的聊天或演示能力。

### 2. 他如何理解 AI 的发展路径
他的路径判断很稳定：基础模型仍会继续扩展，但下一步真正的跃迁点，在持续学习、记忆架构、长期规划和一致性上。

### 3. 他如何理解竞争、产品和商业化
他认为未来优势会更集中在既有算力、又能发明新算法的前沿实验室；开放模型会持续存在，但大概率会落后于绝对前沿一步。

## 五、重要原话或代表性表达
> AGI 是具备人类心智全部认知能力的系统。

> 未来五年内出现 AGI 的概率很高。

## 六、观点变化
### 过去怎么说
DeepMind 在 2010 年前后内部就把 AGI 时间粗略估在约 20 年后。

### 现在怎么说
他在 2026-04 的访谈中明确说，未来 5 年内出现 AGI 有很大概率。

### 有没有明显转向
没有明显转向，更像是长期时间表正在被逐步兑现；真正增加的是对最低安全标准、国际协调和审计机制的公开强调。

## 七、相关公司
- [[03_Companies/Google]]

## 八、相关产品
- 暂无独立产品卡

## 九、相关市场
- [[05_Markets/AI基础设施与数据中心市场]]
- [[05_Markets/机器人与物理世界智能市场]]

## 十、来源笔记
- [[01_Sources/2026-04-07+德米斯·哈萨比斯：为什么通用人工智能比工业革命更重要？人工智能的瓶颈在哪里？]]
- [[01_Sources/2026-04-13+谷歌DeepMind总裁谈人工智能、权力、上帝以及未来展望 《经济学人》]]

## 十一、我的判断
这类人物最值得长期跟踪的地方，在于他如何把“AI for Science”的愿景持续翻译成组织、算力和产品路线。
他的思想会直接影响 Google 的 AI 研究方向，也会影响外界对 AGI 时间表、算力瓶颈和最低安全标准的理解。

---
type: person
name: Aaron Levie
company: Box
role: 创始人 / CEO
date: 2026-04-22
status: 进行中
themes:
  - SaaS重构
  - enterprise AI
  - agent workflows
markets:
  - "[[05_Markets/AI代理与企业知识工作市场]]"
core_beliefs:
  - 代理不会立刻移除人类，而是改变人类进入工作流的位置。
  - 企业工作流需要按 agent 重写，而不是沿用为人设计的旧流程。
  - 软件价值会更多向 headless APIs、业务逻辑和可治理数据层迁移。
keywords:
  - headless software
  - agent operator
  - workflow redesign
  - APIs
  - unstructured data
important_quotes:
  - 工作流需要为代理重写，而不是为人重写。
prediction_style: 企业工作流导向 + 基础设施约束导向
change_log:
  - 2026-04 的公开表达明显更强调软件 headless 化与 agent-ready APIs。
related_companies:
  - "[[03_Companies/Box]]"
related_products: []
related_markets:
  - "[[05_Markets/AI代理与企业知识工作市场]]"
source_notes:
  - "[[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]"
  - "[[01_Sources/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]"
summary: 当前来源把 Aaron Levie 呈现为最早系统化讨论“企业工作流如何被 agent 重写”的 SaaS 领导者之一。他的重点不是模型跑分，而是 API、数据、治理、human-in-the-loop 和企业改造成本。
my_take: ""
tags:
  - ai
  - person
  - saas
  - agent
---

# Aaron Levie

## 一、人物简介
- 公司：Box
- 职位：创始人 / CEO
- 关注方向：企业软件、代理工作流、API 化、数据治理

## 二、核心思想
1. AI 不会立刻把人完全拿出流程，而是把人移动到更靠后、更高杠杆的位置。
2. 企业真正的难点不是“有没有模型”，而是工作流、数据和权限体系是否适合 agent。
3. 软件价值不会简单归零，而会更多转向 headless APIs、业务逻辑、合规和数据骨干层。

## 三、他反复强调的关键词
- workflow redesign
- headless
- APIs
- agent operator
- unstructured data

## 四、判断框架
### 1. 他最重视什么
他最重视的是，企业要获得 agent 红利，必须重构流程、数据和系统连接方式，而不是只买一个聊天入口。

### 2. 他如何理解 AI 的发展路径
他的路径判断是：coding 只是最先爆发的一类工作，真正的大机会在传统行业和大型企业把 agent 接进现实流程之后。

### 3. 他如何理解竞争、产品和商业化
他认为下一轮 SaaS 竞争，不只是谁有按钮，而是谁有更好的 API、数据位置、业务逻辑和 agent-ready 平台能力。

## 五、重要原话或代表性表达
> 工作流需要为代理重写，而不是为人重写。

## 六、观点变化
### 过去怎么说
更早的对谈里，他已经在讲 OpenAI / Anthropic 向企业知识工作收敛。

### 现在怎么说
最新来源里，他进一步把焦点转向 headless software、agent operator、API 层价值和企业数据准备度。

### 有没有明显转向
没有根本转向，更像是从“AI 会进入企业”推进到了“企业到底该怎么重构”。

## 七、相关公司
- [[03_Companies/Box]]

## 八、相关产品
- 暂无独立产品卡

## 九、相关市场
- [[05_Markets/AI代理与企业知识工作市场]]

## 十、来源笔记
- [[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]
- [[01_Sources/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]

## 十一、我的判断
这类人物最值得长期跟踪的地方，是他能持续把抽象 AI 讨论翻译成企业流程、系统接口和预算结构的问题。
他的思想会直接影响 SaaS 行业如何理解 agent 时代的软件价值转移。

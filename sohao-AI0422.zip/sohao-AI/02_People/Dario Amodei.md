---
type: person
name: Dario Amodei
company: Anthropic
role: 联合创始人 / CEO
date: 2026-04-22
status: 进行中
themes:
  - AI安全
  - frontier model
  - enterprise AI
markets:
  - "[[05_Markets/AI代理与企业知识工作市场]]"
core_beliefs:
  - 在高风险 AI 系统里，安全不应被速度牺牲。
  - 研究能力与产品化能力必须并存，但研究优先级不能被完全商业压力吞没。
  - 高价值 AI 公司的长期竞争，最终会落到企业级落地和可持续经营上。
keywords:
  - safety
  - research first
  - enterprise
  - speed vs safety
important_quotes: []
prediction_style: 安全导向 + 研究优先 + 商业化收敛
change_log:
  - 2021 年从 OpenAI 分化出来，公开叙事聚焦安全与研究。
  - 2026-04 的外部来源已把 Anthropic 视为企业级前沿 AI 的核心玩家之一。
related_companies:
  - "[[03_Companies/Anthropic]]"
related_products:
  - "[[04_Products/Claude Cowork]]"
related_markets:
  - "[[05_Markets/AI代理与企业知识工作市场]]"
source_notes:
  - "[[01_Sources/2026-04-21+人类学案例研究：克劳德的崛起]]"
summary: 当前来源把 Dario Amodei 呈现为把“安全高于速度”推到组织决策层的人物之一。他的重要性不只在技术判断，也在于他把 Anthropic 从研究实验室推进到企业级 AI 竞争主舞台。
my_take: ""
tags:
  - ai
  - person
  - anthropic
  - safety
---

# Dario Amodei

## 一、人物简介
- 公司：Anthropic
- 职位：联合创始人 / CEO
- 关注方向：AI 安全、前沿模型研究、企业级商业化

## 二、核心思想
1. 在高风险 AI 领域，安全问题不能被“先上线再修复”的软件逻辑轻易覆盖。
2. 当 stakes 足够高时，研究导向与安全讨论必须优先进入组织决策。
3. 真正可持续的 frontier AI 公司，不只是能力更强，也要走到企业级落地和更健康的经营结构。

## 三、他反复强调的关键词
- 安全
- 研究
- 企业
- 速度与质量张力
- 前沿模型

## 四、判断框架
### 1. 他最重视什么
他最重视的是，当 AI 能力影响面足够大时，安全与研究方向不能完全服从短期速度。

### 2. 他如何理解 AI 的发展路径
从当前来源看，他更像相信“研究实验室 + 产品化 + 企业级落地”三者联动，而不是单纯靠 consumer 爆发完成全部扩张。

### 3. 他如何理解竞争、产品和商业化
外部来源把 Anthropic 的路径概括成：以安全研究起家，但最终在企业级 AI 里正面参与商业竞争。

## 五、重要原话或代表性表达
> 当前来源没有直接提供可安全引用的 Dario 原话。

## 六、观点变化
### 过去怎么说
来源中的早期叙事是：对 OpenAI 的速度与风险权衡不满，因此离开并另起公司。

### 现在怎么说
到 2026-04 的外部观察里，Dario 所代表的路线已经不只是“安全批评者”，而是企业级 frontier AI 的实际竞争者。

### 有没有明显转向
当前可见的变化，不是从安全转向商业，而是把安全立场逐步延展成完整公司战略与商业竞争力。

## 七、相关公司
- [[03_Companies/Anthropic]]

## 八、相关产品
- [[04_Products/Claude Cowork]]

## 九、相关市场
- [[05_Markets/AI代理与企业知识工作市场]]

## 十、来源笔记
- [[01_Sources/2026-04-21+人类学案例研究：克劳德的崛起]]

## 十一、我的判断
这类人物最值得长期跟踪的地方，是他如何把“安全优先”真正转成产品、商业模式和组织执行，而不只是道德叙事。
他的思想会直接影响 Anthropic 的对齐姿态、企业化路径，以及外界对“研究优先公司能否赢得商业竞争”的判断。

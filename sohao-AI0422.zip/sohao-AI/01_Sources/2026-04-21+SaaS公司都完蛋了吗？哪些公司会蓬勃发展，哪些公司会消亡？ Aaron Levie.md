﻿---
type: 来源
title: "SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie"
date: "2026-04-20"
status: 已拆解
summary: "Aaron Levie 在这条来源里系统讨论了 agent 如何重写企业工作流、为什么软件会 headless 化、为什么 API 与数据骨干层会重新变得更重要，以及 SaaS 行业在 agent 时代的价值迁移。"
my_take: ""
source_notes: []
related_notes:
  - "[[00_Inbox/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]"
  - "[[02_People/Aaron Levie]]"
  - "[[03_Companies/Box]]"
  - "[[05_Markets/AI代理与企业知识工作市场]]"
tags:
  - 来源
  - AI研究
  - Inbox迁移
source_type: "视频转录"
source_url: "https://www.youtube.com/watch?v=qrxQikecJL0&list=WL&index=4&pp=iAQBsAgC"
author: "20VC with Harry Stebbings"
---

# SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie

## 一、来源信息
- 来源名称：20VC with Harry Stebbings
- 日期：2026-04-20
- 链接：[原始链接](https://www.youtube.com/watch?v=qrxQikecJL0&list=WL&index=4&pp=iAQBsAgC)
- 原始文件：[[00_Inbox/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]

## 二、内容摘要
1. Aaron Levie 认为，agent 不会立刻拿掉人，而是改变人进入工作流的位置。
2. 他强调企业的核心问题是 workflow redesign、API readiness、数据碎片和 legacy system 改造，而不只是模型选型。
3. 他还明确提出了 headless software、agent operator、agent security / eval 等新方向。

## 三、可拆解对象
### 人物
- [[02_People/Aaron Levie]]

### 公司
- [[03_Companies/Box]]

### 产品
- 暂未单独拆出产品卡

### 市场
- [[05_Markets/AI代理与企业知识工作市场]]

## 四、初步信号
- 这条内容的主价值不在单一产品，而在 SaaS 与 enterprise AI 的底层重构逻辑。
- 它特别适合补充“AI代理与企业知识工作市场”的系统性判断。

## 五、我的判断
这条内容更像人物思想、公司动作、产品更新，还是市场反馈？
它值不值得继续拆成结构化对象？

## 六、原始转录
- 见：[[00_Inbox/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]

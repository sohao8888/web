---
type: 公司
name: "Anthropic"
date: "2026-04-20"
status: 进行中
summary: "当前多条来源把 Anthropic 描述为一家同时在模型发布、企业化增长、代理产品化和对齐研究上快速推进的公司。"
my_take: ""
source_notes:
  - "[[01_Sources/2026-04-19+萨姆·奥特曼的攻击、亚马逊与星链之争，以及 Opus 4.7 的真正含义 #248]]"
  - "[[01_Sources/2026-04-06+Anthropic 如何利用 Claude 实现自身增长的自动化（以及为什么旧的策略已经过时）]]"
  - "[[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]"
  - "[[01_Sources/2026-04-12+Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡]]"
  - "[[01_Sources/2026-04-17+Claude Opus 4.7 太疯狂了——这是目前为止最好的型号吗？]]"
  - "[[01_Sources/2026-04-10+什么是托管代理？]]"
  - "[[01_Sources/2026-04-21+人类学案例研究：克劳德的崛起]]"
related_notes:
  - "[[02_People/Dario Amodei]]"
  - "[[04_Products/Claude Opus 4.7]]"
  - "[[04_Products/Claude Cowork]]"
  - "[[04_Products/Claude Managed Agents]]"
  - "[[05_Markets/AI基础设施与数据中心市场]]"
  - "[[05_Markets/AI代理与企业知识工作市场]]"
tags:
  - 公司
  - AI研究
  - 模型发布
  - 对齐
  - Agent
company_type: "AI 模型公司"
region: ""
stage: "持续发布"
---

# 公司研究卡

## 公司概况

- 公司类型：AI 模型公司
- 所在地区：本来源未直接说明
- 发展阶段：持续发布

## 核心战略

- 通过新版本模型迭代强化在 agent 工作流、长上下文和图像理解场景中的表现。
- 控制方式上更强调用 prompt 替代过去更显式的参数旋钮。
- 在产品发布之外，持续推进模型对齐研究。
- 明显押注 enterprise 与 coding 作为商业化突破口，再向更广泛的知识工作代理扩展。
- 开始把 Claude 直接用于公司内部增长自动化，把模型能力反向用在自身商业系统里。
- 在产品和模型之间采用相互牵引的方式推进，即产品需求影响训练方向，模型新能力反过来塑造产品。
- 新来源还显示，Anthropic 正在把 agent runtime 本身做成产品层，包括 sessions、environments、memory、MCP 和多代理协作。
- 新来源还补充了其成立背景：从 OpenAI 分化出来后，Anthropic 一开始被定位成更研究导向、更强调安全的实验室。

## 关键事件

- 来源提到 Anthropic 发布了 Opus 4.7。
- 来源提到 Anthropic 在近期发布了“较弱模型监督较强模型”的对齐研究论文。
- 来源提到 Anthropic 从约 10 亿美元 ARR 增长到约 190 亿美元 ARR 的速度极快。
- 来源提到其增长团队推动 `cash` 项目，用 Claude 自动化增长实验。
- 来源提到 Anthropic 让 Claude Cowork 成为企业知识工作代理的代表性产品之一。
- 来源提到公司对 Mythos 与 Glass Wing 的处理方式，体现其在能力释放与安全约束之间的取舍。
- 来源还提到其推出 Managed Agents 套件，说明其产品化边界正在从模型调用扩展到可托管的代理执行系统。
- 新来源还把它的发展路径概括为：研究实验室起步，随后推出 Claude 1、2、3、3.5、Claude Code，并进一步把企业市场作为核心主战场。

## 组织与能力

- 当前来源突出的是其产品迭代速度和对齐研究能力。
- 在对谈语境中，其被放在企业级 agent 使用与 frontier model 竞争框架下观察。
- 新来源进一步表明，其组织能力同时体现在研究、推理、算力、Claude Code、增长和 go-to-market 的联动。
- 来源中还显示，其对“本地优先代理”“skills”“memory harness”等产品设计细节已有较成熟认知。

## 商业化进展

- 本来源未直接展开其收费方式或收入结构。
- 可以确认的是，其产品更新已经围绕实际工作流与更高使用预算展开。
- 来源中将其描述为 enterprise 与 coding 路线上增长极快的公司。
- 来源显示，其商业化不只靠 API，也在通过 Cowork 这样的代理产品切入更广的企业工作流。
- 新来源进一步表明，其商业化正在增加一层“代理运行时 / 托管执行”能力，而不只卖单次模型推理。
- 新来源还明确把 Claude Pro、Claude Code 与企业客户结合在一起描述，说明其收入结构已不只是研究能力外溢，而是多层产品同时驱动。

## 证据来源

- [[01_Sources/2026-04-19+萨姆·奥特曼的攻击、亚马逊与星链之争，以及 Opus 4.7 的真正含义 #248|来源：萨姆·奥特曼的攻击、亚马逊与星链之争，以及 Opus 4.7 的真正含义 #248]]
- [[01_Sources/2026-04-06+Anthropic 如何利用 Claude 实现自身增长的自动化（以及为什么旧的策略已经过时）|来源：Anthropic 如何利用 Claude 实现自身增长的自动化（以及为什么旧的策略已经过时）]]
- [[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie|来源：OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]
- [[01_Sources/2026-04-12+Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡|来源：Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡]]
- [[01_Sources/2026-04-17+Claude Opus 4.7 太疯狂了——这是目前为止最好的型号吗？|来源：Claude Opus 4.7 太疯狂了——这是目前为止最好的型号吗？]]
- [[01_Sources/2026-04-10+什么是托管代理？|来源：什么是托管代理？]]
- [[01_Sources/2026-04-21+人类学案例研究：克劳德的崛起|来源：人类学案例研究：克劳德的崛起]]

## 我的判断

- 暂不补充额外判断，等待更多官方发布说明与企业采用案例来源。

## 待验证问题

- “prompt 取代参数旋钮”会不会成为更广泛的模型交互趋势。
- 其对齐研究能否转化为更可验证的产品差异。

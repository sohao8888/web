---
type: 公司
name: "Notion"
date: "2026-04-20"
status: 进行中
summary: "当前来源把 Notion 描述为一家正在把自己从协作文档工具升级为企业工作的 system of record，并试图把 AI 能力包装成可权限控制、可落地、可长期运行的工作流产品。"
my_take: ""
source_notes:
  - "[[01_Sources/2026-04-16+Notion AI 内幕：自定义代理背后的 5 次重建 — Simon Last 和 Sarah Sachs，Notion]]"
related_notes:
  - "[[04_Products/Notion AI]]"
  - "[[05_Markets/AI代理与企业知识工作市场]]"
tags:
  - 公司
  - AI研究
  - Notion
  - Agent
  - 企业软件
company_type: "协作软件 / AI 工作流平台"
region: ""
stage: "AI 原生重构中"
---

# 公司研究卡

## 公司概况

- 公司类型：协作软件 / AI 工作流平台
- 所在地区：本来源未直接说明
- 发展阶段：AI 原生重构中

## 核心战略

- 把 Notion 定位成“企业工作的最佳 system of record”，而不是单一的 AI 包装层。
- 用自定义代理、会议纪要、检索与权限系统，把 AI 变成工作流中的常驻能力，而不是一次性问答。
- 保持模型开放策略：和前沿实验室合作，支持 MCP，不把“自研基础模型”当作当前核心能力。
- 组织上采用“不要逆流而上”的产品方法：能力没成熟时反复重建，能力一旦成熟就迅速产品化。

## 关键事件

- 来源明确提到，自定义代理是其历史上最成功的一次 launch 之一，在免费试用和转化上表现最强。
- Notion 团队自 2022 年末起，围绕 agent 能力至少重建了 4 到 5 次。
- 来源还提到，Meeting Notes 已经成为强增长杠杆，并带来大量新的数据捕获和搜索负载。

## 组织与能力

- 其核心能力不只是做 UI，而是理解协作、权限、工作流和知识组织。
- 来源表明，Notion AI 团队非常强调低 ego、可重写、愿意删除旧代码与旧 harness 的工程文化。
- 它的组织能力也体现在：既能和前沿模型公司合作，又能把这些能力翻译成企业用户真正能用的产品。

## 商业模式

- 当前来源没有给出完整价格表，但明确提到“免费 3 个月”对 launch 有明显帮助。
- 来源显示其 AI 商业化更像是在现有 workspace / enterprise 体系之上叠加更强能力，而不是单独卖一个纯模型服务。
- 对企业侧而言，价值不只是生成内容，而是减少整理、搜索、跟进和权限协调的人力成本。

## 证据来源

- [[01_Sources/2026-04-16+Notion AI 内幕：自定义代理背后的 5 次重建 — Simon Last 和 Sarah Sachs，Notion|来源：Notion AI 内幕：自定义代理背后的 5 次重建 — Simon Last 和 Sarah Sachs，Notion]]

## 我的判断

- 暂不补充额外判断，等待更多企业采购和付费层级资料。

## 待验证问题

- Notion 能否把“system of record”优势真正转成 AI 时代的长期防守位。
- 自定义代理与 Meeting Notes，会不会从功能增长点进一步变成新的核心付费层。

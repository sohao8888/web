---
type: 公司
name: "Box"
date: "2026-04-22"
status: 进行中
summary: "当前来源把 Box 描述为一家试图把自己从文档存储与协作平台，升级为 agent 时代的内容骨干层与工作流平台的公司。其核心赌注不只是 UI，而是 headless API、内容治理、合规和 agent 可用性。"
my_take: ""
source_notes:
  - "[[01_Sources/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]"
related_notes:
  - "[[02_People/Aaron Levie]]"
  - "[[05_Markets/AI代理与企业知识工作市场]]"
tags:
  - 公司
  - AI研究
  - SaaS
  - Box
  - Agent
company_type: "企业内容平台 / SaaS"
region: ""
stage: "向 agent-ready 内容平台转型"
---

# 公司研究卡

## 公司概况

- 公司类型：企业内容平台 / SaaS
- 所在地区：本来源未直接说明
- 发展阶段：向 agent-ready 内容平台转型

## 核心战略

- 把软件从“按钮界面”转向“headless APIs + agent 工作流”的基础层。
- 强调内容数据、权限、合规和业务逻辑依然重要，不会因为 agent 出现而消失。
- 通过新的 plan tier 把工作流自动化、业务流程能力和 agent 产品打包进更高价值层。

## 关键事件

- 来源明确提到，Box 已推出围绕 agent 与 workflow capability 的新 plan tier。
- 来源还提到，agent 正在成为 Box 这类内容平台的新增长驱动，并被 Aaron Levie 描述为带来了收入增长再加速。
- 在产品方向上，来源把 Box 定位成适合处理 FINRA 合规文档、内容自动化和后台工作流的平台。

## 组织与能力

- Box 的优势不只在内容存储，而在内容背后的权限、合规、业务逻辑与跨系统工作流。
- 来源特别强调，Box 的“headless 版本”早就存在，因此它在 agent 时代并不是从零开始。
- 其新挑战是让 agent 真正能稳定找到正确文档、读懂内容，并在受监管环境中执行流程。

## 商业模式

- 当前来源显示，Box 的商业化正在往更高 plan tier 推进，而 agent 是其中核心卖点之一。
- 不是单独按聊天入口收费，而是把 agent 嵌入更完整的工作流与内容自动化能力中。
- 价值衡量逻辑也在变化：如果 agent 使用频次比人高出 100 倍甚至 1000 倍，平台层机会反而可能更大。

## 证据来源

- [[01_Sources/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie|来源：SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]

## 我的判断

- 暂不补充额外判断，等待更多 Box 官方 agent 产品资料。

## 待验证问题

- Box 能否把“内容骨干层”优势真正转成 agent 时代的长期护城河。
- 它的新 plan tier 是否足以稳定支撑 agent 带来的 ARPU 提升与增长再加速。

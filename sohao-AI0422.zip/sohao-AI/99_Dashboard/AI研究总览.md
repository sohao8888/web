---
type: 总览
title: AI研究总览
date: "2026-04-19"
status: 启用
summary: 用于总览 AI 趋势与 AI 商业形态研究进度的入口页。
my_take: ""
source_notes: []
related_notes: []
tags:
  - 仪表盘
  - AI研究
---

# AI研究总览

## 入口

- 收件箱：`00_Inbox`
- 来源库：`01_Sources`
- 人物：`02_People`
- 公司：`03_Companies`
- 产品：`04_Products`
- 市场：`05_Markets`
- 主题：`06_Themes`
- 日报：`_Daily`
- 周报：`07_Weekly`
- 判断：`08_Theses`
- 记忆：`80_Memory`
- 模板：`90_Templates`

## 今日待处理来源

- [ ] 将今日新增材料先收进 `00_Inbox`
- [ ] 整理为 `01_Sources` 中的 source note
- [ ] 从 source note 拆解对象卡
- [ ] 判断是否需要更新 theme 或 thesis

## 最近更新的人物

- 在这里维护近期重点人物卡链接

## 最近更新的公司

- 在这里维护近期重点公司卡链接

## 最近更新的产品

- 在这里维护近期重点产品卡链接

## 最近更新的市场

- 在这里维护近期重点市场卡链接

## 最新 thesis 判断

- [[08_Theses/进化系统|进化系统]]

## 本周研究提醒

- 先来源，后拆卡，最后沉淀判断
- 原始来源与个人判断必须分开
- 优先补全已有对象，避免重复建档

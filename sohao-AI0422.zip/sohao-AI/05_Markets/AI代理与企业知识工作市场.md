---
type: 市场
name: "AI代理与企业知识工作市场"
date: "2026-04-20"
status: 进行中
summary: "当前来源共同指向一个清晰趋势：AI 代理正在从编码助手升级为企业知识工作代理，真正的增量市场不只是开发者，而是更广泛的知识工作者。"
my_take: ""
source_notes:
  - "[[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]"
  - "[[01_Sources/2026-04-12+Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡]]"
  - "[[01_Sources/2026-04-16+Notion AI 内幕：自定义代理背后的 5 次重建 — Simon Last 和 Sarah Sachs，Notion]]"
  - "[[01_Sources/2026-04-10+什么是托管代理？]]"
  - "[[01_Sources/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]"
related_notes:
  - "[[03_Companies/Anthropic]]"
  - "[[03_Companies/Box]]"
  - "[[03_Companies/OpenAI]]"
  - "[[03_Companies/Notion]]"
  - "[[02_People/Aaron Levie]]"
  - "[[04_Products/Claude Cowork]]"
  - "[[04_Products/Notion AI]]"
  - "[[04_Products/Claude Managed Agents]]"
tags:
  - 市场
  - AI研究
  - 代理
  - 企业软件
  - 知识工作
scope: "企业知识工作中的 AI 代理、工具调用与长期执行"
timeframe: "2026-04"
---

# 市场研究卡

## 市场定义

- 观察范围：AI 代理在法律、销售、营销、研究等知识工作中的替代与增强作用。
- 观察周期：2026-04 当前来源窗口

## 关键变化

- OpenAI 与 Anthropic 的产品路线开始从不同起点收敛到同一类 general purpose agent。
- 市场重心从“会不会写代码”转向“能不能接住更广泛知识工作”。
- 代理的核心能力开始包含：工具调用、脚本执行、本地文件访问、长期任务执行与任务拆解。
- 随着执行成本下降，产品价值的瓶颈更偏向 trust、taste、验证与工作流整合。
- 新来源进一步表明，市场竞争正在从“模型能力”延伸到“谁能提供可权限控制、可后台运行、可长期记忆的代理系统”。
- 自定义代理、meeting notes、managed sessions、MCP、memory 和 grader 回路，正在成为新一轮产品原语。
- Aaron Levie 的新来源进一步说明，企业端真正的瓶颈正在从模型本身转向 workflow redesign、API readiness、legacy system 改造和 human-in-the-loop 设计。
- “agent operator” 这类新角色开始出现，说明市场正在长出新的实施层与服务层。

## 客户

- 企业中的知识工作者。
- 法律、销售、营销、研究、生命科学等专业岗位。
- 需要把 agent 嵌入实际工作流的团队与组织。
- 需要把 agent 嵌进自己应用或内部平台的开发者与平台团队。

## 收费方式

- 当前来源没有给出完整统一的收费模型。
- 可以确认的是，tokens 仍然不便宜，因此市场更优先落在 ROI 容易成立的 enterprise 场景。
- 从来源推断，商业化会更多围绕企业席位、工具接入和工作流价值展开，但具体计费尚需更多来源验证。
- 新来源还透露出两种新增变现路径：一是基于 workspace 的试用转化与企业增购，二是基于代理运行时的开发者 / 平台能力收费，但具体价格尚未披露。
- 新来源还补充了一层变化：token 预算可能会从传统 IT 预算迁移到更常规的 OPEX 支出里，这说明 agent 费用正在更像业务运营成本。

## 替代逻辑

- 从聊天机器人，替代到可执行任务的知识工作代理。
- 从单一 coding assistant，替代到 general purpose knowledge worker agent。
- 从纯人工执行，替代到“人类设目标、AI 先跑一轮、人工审核与收敛”的协作模式。

## 商业反馈

- 来源中嘉宾认为，很多企业已把 ChatGPT 作为内部标准 LLM。
- Cowork 等产品被视为推动市场重新定价企业软件价值的重要信号。
- 市场对代理的需求正在从 curiosity 转向明确的效率诉求。
- Notion 把自定义代理描述为其最成功的试用与转化 launch 之一，说明企业用户开始为“可落地工作流”而不是纯能力演示买单。
- 新来源还显示，部分企业场景里代理发起的搜索已经多于人工搜索，说明 agent 正在改变上游数据与检索流量结构。
- Aaron Levie 的来源则强调，真正的大企业落地不会一蹴而就，因为数据碎片、老旧系统和审计要求会直接限制 agent 的表现。

## 竞争格局

- OpenAI 和 Anthropic 正在争夺企业知识工作入口。
- 产品竞争不再只看模型本身，也看本地访问、skills、memory、trust onboarding 和长期执行体验。
- SaaS 厂商开始面临来自通用代理平台的横向侵蚀压力。
- 新来源表明，竞争正在分成两层：模型 / 运行时平台层，与工作流 / 权限 / 系统记录层。
- Anthropic 这类模型公司开始往托管执行层走；Notion 这类应用公司则试图把 agent 做进 system of record。
- 另一条竞争线也在变清晰：像 Box 这样的 SaaS 平台正在押注“成为 agent 最愿意工作的数据与内容骨干层”。
- 新来源还提示了 agent observability / evaluation / security 可能成为独立基础设施层。

## 阶段判断

- 基于当前来源，这个市场处在“从 coding niche 向 enterprise-wide knowledge work 扩张”的早期加速阶段。
- 真正的大市场还未完全展开，但方向已经从“聊天”明确转向“执行”。
- 更具体地说，这个市场已经从“单轮问答”进入“后台执行 + 权限治理 + 长期上下文”的早期基础设施竞争阶段。
- 再进一步看，它也在进入“系统升级与实施成本开始显性化”的阶段，不再只是演示 agent 能力，而是要重构企业真实流程。

## 证据来源

- [[01_Sources/2026-04-09+OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie|来源：OpenAI 与 Anthropic 的直接对决 + 智能体的未来——嘉宾：Aaron Levie]]
- [[01_Sources/2026-04-12+Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡|来源：Anthropic 的 Felix Rieseberg：Claude Cowork、Mythos 和 SaaS 的消亡]]
- [[01_Sources/2026-04-16+Notion AI 内幕：自定义代理背后的 5 次重建 — Simon Last 和 Sarah Sachs，Notion|来源：Notion AI 内幕：自定义代理背后的 5 次重建 — Simon Last 和 Sarah Sachs，Notion]]
- [[01_Sources/2026-04-10+什么是托管代理？|来源：什么是托管代理？]]
- [[01_Sources/2026-04-21+SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie|来源：SaaS公司都完蛋了吗？哪些公司会蓬勃发展，哪些公司会消亡？ Aaron Levie]]

## 我的判断

- 暂不补充额外判断，等待更多企业付费和 adoption 数据。

## 待验证问题

- 这个市场会先被通用平台代理吃下，还是被垂直 agent 产品分走。
- tokens 成本下降后，竞争会更多回到 taste、trust 还是工作流深度。

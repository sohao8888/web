import { normalizePath } from "obsidian";
import { computeCoverLayout } from "./layout";
import { getCoverPreset } from "./presets";
import {
  COVER_HEIGHT,
  COVER_WIDTH,
  type CoverLayout,
  type CoverPreset,
  type ExportCoverOptions,
  type ExportCoverResult,
} from "./types";

export async function exportCoverAsPng(
  options: ExportCoverOptions,
): Promise<ExportCoverResult> {
  const { app, draft, settings } = options;
  const preset = getCoverPreset(draft.presetId);
  const layout = computeCoverLayout(draft, preset, false);
  const canvas = document.createElement("canvas");
  canvas.width = COVER_WIDTH;
  canvas.height = COVER_HEIGHT;
  const ctx = canvas.getContext("2d");

  if (!ctx) {
    throw new Error("Cover Maker cannot initialize the export canvas.");
  }

  drawCover(ctx, preset, layout);

  const exportFolder = normalizeExportFolder(settings.exportFolder);
  await ensureFolder(app, exportFolder);
  const filename = await buildUniqueFilename(
    app,
    exportFolder,
    draft.title.trim() || "cover-maker",
  );
  const path = normalizePath(`${exportFolder}/${filename}`);
  const blob = await canvasToBlob(canvas);
  const data = await blob.arrayBuffer();

  await app.vault.adapter.writeBinary(path, data);

  return {
    path,
    filename,
  };
}

export function drawCover(
  ctx: CanvasRenderingContext2D,
  preset: CoverPreset,
  layout: CoverLayout,
): void {
  drawBackground(ctx, preset);
  drawDecorations(ctx, preset);
  drawTagRows(ctx, preset, layout);
  drawTitle(ctx, preset, layout);
}

function drawBackground(ctx: CanvasRenderingContext2D, preset: CoverPreset): void {
  const gradient = ctx.createLinearGradient(0, 0, COVER_WIDTH, COVER_HEIGHT);
  gradient.addColorStop(0, preset.background[0]);
  gradient.addColorStop(0.58, preset.background[1]);
  gradient.addColorStop(1, preset.background[2]);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, COVER_WIDTH, COVER_HEIGHT);

  if (preset.id === "minimal") {
    drawCircleGlow(ctx, 770, 180, 210, preset.accentSoft, 0.9);
    drawCircleGlow(ctx, 690, 1060, 160, "rgba(255, 255, 255, 0.36)", 0.6);
    ctx.fillStyle = preset.accentColor;
    ctx.fillRect(80, 1030, 220, 4);
    ctx.strokeStyle = "rgba(17, 26, 34, 0.12)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(730, 190, 170, 0, Math.PI * 2);
    ctx.stroke();
  }

  if (preset.id === "tech") {
    drawCircleGlow(ctx, 720, 180, 250, "rgba(121, 239, 255, 0.18)", 1);
    drawGrid(ctx, "rgba(121, 239, 255, 0.12)", 44, 0.5);
    ctx.fillStyle = "rgba(121, 239, 255, 0.16)";
    ctx.fillRect(78, 1038, 280, 4);
    ctx.strokeStyle = "rgba(121, 239, 255, 0.18)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(560, 0);
    ctx.lineTo(900, 340);
    ctx.stroke();
  }

  if (preset.id === "knowledge") {
    ctx.strokeStyle = "rgba(47, 111, 255, 0.15)";
    ctx.lineWidth = 2;
    roundedRectPath(ctx, 58, 54, 784, 1092, 34);
    ctx.stroke();
    ctx.fillStyle = "rgba(47, 111, 255, 0.1)";
    roundedRectPath(ctx, 58, 54, 180, 12, 999);
    ctx.fill();
    drawCircleGlow(ctx, 760, 160, 170, preset.accentSoft, 1);
  }

  if (preset.id === "business") {
    const barGradient = ctx.createLinearGradient(58, 70, 58, 1130);
    barGradient.addColorStop(0, "rgba(215, 181, 118, 0.9)");
    barGradient.addColorStop(1, "rgba(215, 181, 118, 0.18)");
    ctx.fillStyle = barGradient;
    roundedRectPath(ctx, 58, 70, 8, 1060, 999);
    ctx.fill();
    drawCircleGlow(ctx, 760, 220, 220, "rgba(255, 255, 255, 0.08)", 1);
    ctx.strokeStyle = "rgba(215, 181, 118, 0.14)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(92, 1040);
    ctx.lineTo(820, 1040);
    ctx.stroke();
  }

  if (preset.id === "magazine") {
    drawCircleGlow(ctx, 760, 180, 200, preset.accentSoft, 0.9);
    ctx.fillStyle = "rgba(194, 86, 61, 0.14)";
    ctx.beginPath();
    ctx.moveTo(0, 940);
    ctx.lineTo(420, 860);
    ctx.lineTo(900, 1080);
    ctx.lineTo(900, 1200);
    ctx.lineTo(0, 1200);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(194, 86, 61, 0.2)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(760, 190, 154, 0, Math.PI * 2);
    ctx.stroke();
  }
}

function drawDecorations(ctx: CanvasRenderingContext2D, preset: CoverPreset): void {
  if (preset.id !== "tech" && preset.id !== "business") {
    return;
  }

  ctx.save();
  ctx.globalAlpha = preset.id === "tech" ? 0.2 : 0.08;
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(770, 186, 2, 0, Math.PI * 2);
  ctx.arc(790, 214, 2, 0, Math.PI * 2);
  ctx.arc(752, 230, 1.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawTagRows(
  ctx: CanvasRenderingContext2D,
  preset: CoverPreset,
  layout: CoverLayout,
): void {
  if (layout.tagRows.length === 0) {
    return;
  }

  ctx.save();
  ctx.font = `650 ${layout.tagFontSize}px ${preset.fontFamily}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  for (const row of layout.tagRows) {
    for (const chip of row.chips) {
      ctx.fillStyle = preset.tagBackground;
      roundedRectPath(ctx, chip.x, chip.y, chip.width, chip.height, chip.height / 2);
      ctx.fill();

      ctx.strokeStyle = preset.tagBorderColor;
      ctx.lineWidth = 2;
      roundedRectPath(ctx, chip.x, chip.y, chip.width, chip.height, chip.height / 2);
      ctx.stroke();

      ctx.fillStyle = preset.tagTextColor;
      ctx.fillText(chip.text, chip.x + chip.width / 2, chip.y + chip.height / 2 + 1);
    }
  }

  ctx.restore();
}

function drawTitle(
  ctx: CanvasRenderingContext2D,
  preset: CoverPreset,
  layout: CoverLayout,
): void {
  if (layout.titleLines.length === 0) {
    return;
  }

  ctx.save();
  ctx.textBaseline = "top";
  ctx.textAlign = "left";

  if (preset.id === "tech" || preset.id === "business") {
    ctx.shadowColor = preset.shadowColor;
    ctx.shadowBlur = 20;
    ctx.shadowOffsetY = 10;
  }

  for (const line of layout.titleLines) {
    for (const glyph of line.glyphs) {
      ctx.font = `${preset.titleWeight} ${glyph.fontSize}px ${preset.fontFamily}`;
      ctx.fillStyle = glyph.color;
      ctx.fillText(glyph.text, glyph.x, glyph.y);
    }
  }

  ctx.restore();
}

function drawCircleGlow(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  color: string,
  opacity: number,
): void {
  const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
  gradient.addColorStop(0, color);
  gradient.addColorStop(1, "rgba(255, 255, 255, 0)");

  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawGrid(
  ctx: CanvasRenderingContext2D,
  color: string,
  step: number,
  alpha: number,
): void {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;

  for (let x = 0; x <= COVER_WIDTH; x += step) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, COVER_HEIGHT);
    ctx.stroke();
  }

  for (let y = 0; y <= COVER_HEIGHT; y += step) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(COVER_WIDTH, y);
    ctx.stroke();
  }

  ctx.restore();
}

function roundedRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
): void {
  const safeRadius = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + safeRadius, y);
  ctx.arcTo(x + width, y, x + width, y + height, safeRadius);
  ctx.arcTo(x + width, y + height, x, y + height, safeRadius);
  ctx.arcTo(x, y + height, x, y, safeRadius);
  ctx.arcTo(x, y, x + width, y, safeRadius);
  ctx.closePath();
}

function normalizeExportFolder(value: string): string {
  return value.trim().replace(/^\/+|\/+$/g, "") || "Cover Maker Exports";
}

async function ensureFolder(app: ExportCoverOptions["app"], folderPath: string): Promise<void> {
  const parts = normalizePath(folderPath).split("/").filter(Boolean);
  let currentPath = "";

  for (const part of parts) {
    currentPath = currentPath ? `${currentPath}/${part}` : part;
    const exists = await app.vault.adapter.exists(currentPath);
    if (!exists) {
      await app.vault.createFolder(currentPath);
    }
  }
}

async function buildUniqueFilename(
  app: ExportCoverOptions["app"],
  folderPath: string,
  rawTitle: string,
): Promise<string> {
  const baseTitle = sanitizeFilename(rawTitle).slice(0, 40) || "cover-maker";
  const timestamp = createTimestamp();
  let candidate = `${baseTitle}-${timestamp}.png`;
  let counter = 1;

  while (await app.vault.adapter.exists(normalizePath(`${folderPath}/${candidate}`))) {
    candidate = `${baseTitle}-${timestamp}-${counter}.png`;
    counter += 1;
  }

  return candidate;
}

function sanitizeFilename(value: string): string {
  return value.trim().replace(/[\\/:*?"<>|]/g, "").replace(/\s+/g, "-");
}

function createTimestamp(): string {
  const now = new Date();
  const parts = [
    now.getFullYear().toString(),
    `${now.getMonth() + 1}`.padStart(2, "0"),
    `${now.getDate()}`.padStart(2, "0"),
    `${now.getHours()}`.padStart(2, "0"),
    `${now.getMinutes()}`.padStart(2, "0"),
    `${now.getSeconds()}`.padStart(2, "0"),
  ];

  return parts.join("");
}

function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error("Cover Maker failed to export PNG data."));
        return;
      }

      resolve(blob);
    }, "image/png");
  });
}

import { Notice, Plugin, WorkspaceLeaf } from "obsidian";
import { exportCoverAsPng } from "./exporter";
import { getCoverPreset } from "./presets";
import {
  CoverMakerSettingTab,
  createDefaultData,
  sanitizePluginData,
} from "./settings";
import {
  applyTitleStyleToRange,
  clearTitleStyleRange,
  normalizeTitleStyleSpans,
  remapTitleStyleSpans,
} from "./title-style-utils";
import { getTypographyPreset } from "./typography-presets";
import type {
  CoverDraft,
  CoverMakerSettings,
  CoverTemplate,
  ExportCoverResult,
  TitleStyleSpan,
} from "./types";
import { COVER_MAKER_VIEW_TYPE, CoverMakerView } from "./view";

interface SetDraftOptions {
  refresh?: boolean;
  persist?: boolean;
}

export default class CoverMakerPlugin extends Plugin {
  private data = createDefaultData();
  private persistTimer: number | null = null;

  get draft(): CoverDraft {
    return this.data.draft;
  }

  get templates(): CoverTemplate[] {
    return this.data.templates;
  }

  get settings(): CoverMakerSettings {
    return this.data.settings;
  }

  async onload(): Promise<void> {
    await this.loadPluginData();

    this.registerView(
      COVER_MAKER_VIEW_TYPE,
      (leaf) => new CoverMakerView(leaf, this),
    );

    this.addRibbonIcon("image-file", "Open Cover Maker封面", async () => {
      await this.activateView();
    });

    this.addCommand({
      id: "open-cover-maker-sidebar",
      name: "打开 Cover Maker 侧栏",
      callback: async () => {
        await this.activateView();
      },
    });

    this.addCommand({
      id: "export-cover-maker-png",
      name: "导出当前封面为 PNG",
      callback: async () => {
        await this.activateView();
        await this.exportCurrentDraft();
      },
    });

    this.addSettingTab(new CoverMakerSettingTab(this.app, this));
  }

  async onunload(): Promise<void> {
    if (this.persistTimer !== null) {
      window.clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }

    await this.flushPersist();
    await this.app.workspace.detachLeavesOfType(COVER_MAKER_VIEW_TYPE);
  }

  async activateView(): Promise<WorkspaceLeaf | null> {
    const { workspace } = this.app;
    let leaf = workspace.getLeavesOfType(COVER_MAKER_VIEW_TYPE)[0] ?? null;

    if (!leaf) {
      leaf = workspace.getRightLeaf(false) ?? null;
    }

    if (!leaf) {
      new Notice("无法打开 Cover Maker 右侧栏。");
      return null;
    }

    await leaf.setViewState({
      type: COVER_MAKER_VIEW_TYPE,
      active: true,
    });

    workspace.revealLeaf(leaf);
    return leaf;
  }

  setDraft(patch: Partial<CoverDraft>, options: SetDraftOptions = {}): void {
    const nextDraft = {
      ...this.data.draft,
      ...patch,
    };

    nextDraft.titleStyles = normalizeTitleStyleSpans(nextDraft.title, nextDraft.titleStyles);
    this.data.draft = nextDraft;

    if (options.persist !== false) {
      this.schedulePersist();
    }

    if (options.refresh !== false) {
      this.refreshOpenViews();
    }
  }

  updateTitle(nextTitle: string, options: SetDraftOptions = {}): void {
    const currentTitle = this.data.draft.title;
    const titleStyles = remapTitleStyleSpans(currentTitle, nextTitle, this.data.draft.titleStyles);

    this.setDraft(
      {
        title: nextTitle,
        titleStyles,
      },
      options,
    );
  }

  applyTitleColor(start: number, end: number, color: string): void {
    this.applyTitleStyles(start, end, {
      color,
    });
  }

  applyTitleSizeScale(start: number, end: number, sizeScale: number): void {
    this.applyTitleStyles(start, end, {
      sizeScale,
    });
  }

  clearTitleStyles(start: number, end: number): void {
    if (start >= end) {
      return;
    }

    this.setDraft(
      {
        titleStyles: clearTitleStyleRange(
          this.data.draft.title,
          this.data.draft.titleStyles,
          start,
          end,
        ),
      },
      {
        refresh: true,
        persist: true,
      },
    );
  }

  async updateSettings(patch: Partial<CoverMakerSettings>): Promise<void> {
    this.data.settings = {
      ...this.data.settings,
      ...patch,
    };

    await this.flushPersist();
    this.refreshOpenViews();
  }

  async saveCurrentAsTemplate(inputName?: string): Promise<CoverTemplate> {
    const now = Date.now();
    const name = this.buildTemplateName(inputName);
    const existing = this.data.templates.find((template) => template.name === name);

    if (existing) {
      existing.title = this.data.draft.title;
      existing.tagInput = this.data.draft.tagInput;
      existing.presetId = this.data.draft.presetId;
      existing.typographyId = this.data.draft.typographyId;
      existing.lineSpacingId = this.data.draft.lineSpacingId;
      existing.letterSpacingId = this.data.draft.letterSpacingId;
      existing.titleStyles = cloneTitleStyles(this.data.draft.titleStyles);
      existing.updatedAt = now;
      await this.flushPersist();
      this.refreshOpenViews();
      new Notice(`已更新模板：${existing.name}`);
      return existing;
    }

    const template: CoverTemplate = {
      id: `template-${now}-${Math.random().toString(36).slice(2, 8)}`,
      name,
      title: this.data.draft.title,
      tagInput: this.data.draft.tagInput,
      presetId: this.data.draft.presetId,
      typographyId: this.data.draft.typographyId,
      lineSpacingId: this.data.draft.lineSpacingId,
      letterSpacingId: this.data.draft.letterSpacingId,
      titleStyles: cloneTitleStyles(this.data.draft.titleStyles),
      createdAt: now,
      updatedAt: now,
    };

    this.data.templates = [template, ...this.data.templates];
    await this.flushPersist();
    this.refreshOpenViews();
    new Notice(`模板已保存：${template.name}`);
    return template;
  }

  async applyTemplate(templateId: string): Promise<void> {
    const template = this.data.templates.find((item) => item.id === templateId);
    if (!template) {
      return;
    }

    this.data.draft = {
      title: template.title,
      tagInput: template.tagInput,
      presetId: template.presetId,
      typographyId: template.typographyId,
      lineSpacingId: template.lineSpacingId,
      letterSpacingId: template.letterSpacingId,
      titleStyles: cloneTitleStyles(template.titleStyles),
    };

    await this.flushPersist();
    this.refreshOpenViews();
    new Notice(`已应用模板：${template.name}`);
  }

  async updateTemplate(templateId: string): Promise<void> {
    const template = this.data.templates.find((item) => item.id === templateId);
    if (!template) {
      return;
    }

    template.title = this.data.draft.title;
    template.tagInput = this.data.draft.tagInput;
    template.presetId = this.data.draft.presetId;
    template.typographyId = this.data.draft.typographyId;
    template.lineSpacingId = this.data.draft.lineSpacingId;
    template.letterSpacingId = this.data.draft.letterSpacingId;
    template.titleStyles = cloneTitleStyles(this.data.draft.titleStyles);
    template.updatedAt = Date.now();
    await this.flushPersist();
    this.refreshOpenViews();
    new Notice(`模板已更新：${template.name}`);
  }

  async deleteTemplate(templateId: string): Promise<void> {
    const template = this.data.templates.find((item) => item.id === templateId);
    this.data.templates = this.data.templates.filter((item) => item.id !== templateId);
    await this.flushPersist();
    this.refreshOpenViews();

    if (template) {
      new Notice(`已删除模板：${template.name}`);
    }
  }

  async exportCurrentDraft(): Promise<ExportCoverResult | null> {
    if (!this.data.draft.title.trim()) {
      new Notice("请先输入封面标题。");
      return null;
    }

    const preset = getCoverPreset(this.data.draft.presetId);

    try {
      const result = await exportCoverAsPng({
        app: this.app,
        draft: this.data.draft,
        settings: this.data.settings,
      });

      new Notice(`已导出 ${preset.name} 封面：${result.path}`);
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : "导出封面失败。";
      new Notice(message);
      throw error;
    }
  }

  refreshOpenViews(): void {
    const leaves = this.app.workspace.getLeavesOfType(COVER_MAKER_VIEW_TYPE);
    for (const leaf of leaves) {
      if (leaf.view instanceof CoverMakerView) {
        leaf.view.refresh();
      }
    }
  }

  private async loadPluginData(): Promise<void> {
    const raw = await this.loadData();
    this.data = sanitizePluginData(raw);
  }

  private applyTitleStyles(
    start: number,
    end: number,
    patch: {
      color?: string | null;
      sizeScale?: number | null;
    },
  ): void {
    if (start >= end) {
      return;
    }

    this.setDraft(
      {
        titleStyles: applyTitleStyleToRange(
          this.data.draft.title,
          this.data.draft.titleStyles,
          start,
          end,
          patch,
        ),
      },
      {
        refresh: true,
        persist: true,
      },
    );
  }

  private schedulePersist(): void {
    if (this.persistTimer !== null) {
      window.clearTimeout(this.persistTimer);
    }

    this.persistTimer = window.setTimeout(() => {
      void this.flushPersist();
    }, 240);
  }

  private async flushPersist(): Promise<void> {
    if (this.persistTimer !== null) {
      window.clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }

    await this.saveData(this.data);
  }

  private buildTemplateName(inputName?: string): string {
    const trimmed = inputName?.trim();
    if (trimmed) {
      return trimmed;
    }

    const title = this.data.draft.title.trim();
    if (title) {
      return title.slice(0, 18);
    }

    return `${getCoverPreset(this.data.draft.presetId).name}-${getTypographyPreset(this.data.draft.typographyId).name}`;
  }
}

function cloneTitleStyles(spans: TitleStyleSpan[]): TitleStyleSpan[] {
  return spans.map((span) => ({ ...span }));
}

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => CoverMakerPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian4 = require("obsidian");

// exporter.ts
var import_obsidian = require("obsidian");

// types.ts
var COVER_WIDTH = 900;
var COVER_HEIGHT = 1200;

// text-spacing-presets.ts
var LINE_SPACING_PRESETS = [
  { id: "tight", name: "\u7D27\u51D1", scale: 0.92 },
  { id: "standard", name: "\u6807\u51C6", scale: 1 },
  { id: "comfortable", name: "\u8212\u9002", scale: 1.08 },
  { id: "relaxed", name: "\u5BBD\u677E", scale: 1.16 },
  { id: "poster", name: "\u6D77\u62A5", scale: 1.24 }
];
var LETTER_SPACING_PRESETS = [
  { id: "compact", name: "\u7D27\u5BC6", em: -0.03 },
  { id: "normal", name: "\u6807\u51C6", em: 0 },
  { id: "open", name: "\u8F7B\u5C55", em: 0.02 },
  { id: "wide", name: "\u8212\u5C55", em: 0.04 },
  { id: "headline", name: "\u6807\u9898\u611F", em: 0.07 }
];
var LINE_SPACING_LOOKUP = new Map(
  LINE_SPACING_PRESETS.map((preset) => [preset.id, preset])
);
var LETTER_SPACING_LOOKUP = new Map(
  LETTER_SPACING_PRESETS.map((preset) => [preset.id, preset])
);
function getLineSpacingPreset(id) {
  var _a;
  return (_a = LINE_SPACING_LOOKUP.get(id)) != null ? _a : LINE_SPACING_PRESETS[1];
}
function getLetterSpacingPreset(id) {
  var _a;
  return (_a = LETTER_SPACING_LOOKUP.get(id)) != null ? _a : LETTER_SPACING_PRESETS[1];
}
function isLineSpacingPresetId(value) {
  return LINE_SPACING_LOOKUP.has(value);
}
function isLetterSpacingPresetId(value) {
  return LETTER_SPACING_LOOKUP.has(value);
}

// title-style-utils.ts
function buildStyledTitleChars(title, spans) {
  const styles = expandTitleStyles(title, spans);
  return Array.from(title).map((char, index) => {
    var _a, _b, _c;
    return {
      char,
      color: (_a = styles[index]) == null ? void 0 : _a.color,
      sizeScale: (_c = (_b = styles[index]) == null ? void 0 : _b.sizeScale) != null ? _c : 1
    };
  });
}
function normalizeTitleStyleSpans(title, spans) {
  return compressTitleStyles(expandTitleStyles(title, spans));
}
function applyTitleStyleToRange(title, spans, start, end, patch) {
  if (start >= end) {
    return normalizeTitleStyleSpans(title, spans);
  }
  const styles = expandTitleStyles(title, spans);
  for (let index = start; index < end && index < styles.length; index += 1) {
    if (patch.color !== void 0) {
      if (patch.color === null) {
        delete styles[index].color;
      } else {
        styles[index].color = normalizeColor(patch.color);
      }
    }
    if (patch.sizeScale !== void 0) {
      if (patch.sizeScale === null || patch.sizeScale === 1) {
        delete styles[index].sizeScale;
      } else {
        styles[index].sizeScale = patch.sizeScale;
      }
    }
  }
  return compressTitleStyles(styles);
}
function clearTitleStyleRange(title, spans, start, end) {
  return applyTitleStyleToRange(title, spans, start, end, {
    color: null,
    sizeScale: null
  });
}
function remapTitleStyleSpans(previousTitle, nextTitle, spans) {
  if (previousTitle === nextTitle) {
    return normalizeTitleStyleSpans(nextTitle, spans);
  }
  const previousStyles = expandTitleStyles(previousTitle, spans);
  const nextStyles = Array.from({ length: nextTitle.length }, () => ({}));
  let prefix = 0;
  while (prefix < previousTitle.length && prefix < nextTitle.length && previousTitle[prefix] === nextTitle[prefix]) {
    nextStyles[prefix] = { ...previousStyles[prefix] };
    prefix += 1;
  }
  let previousSuffix = previousTitle.length - 1;
  let nextSuffix = nextTitle.length - 1;
  while (previousSuffix >= prefix && nextSuffix >= prefix && previousTitle[previousSuffix] === nextTitle[nextSuffix]) {
    nextStyles[nextSuffix] = { ...previousStyles[previousSuffix] };
    previousSuffix -= 1;
    nextSuffix -= 1;
  }
  return compressTitleStyles(nextStyles);
}
function expandTitleStyles(title, spans) {
  const length = title.length;
  const styles = Array.from({ length }, () => ({}));
  for (const span of spans) {
    const start = clamp(span.start, 0, length);
    const end = clamp(span.end, 0, length);
    if (start >= end) {
      continue;
    }
    for (let index = start; index < end; index += 1) {
      if (span.color) {
        styles[index].color = normalizeColor(span.color);
      }
      if (span.sizeScale && span.sizeScale !== 1) {
        styles[index].sizeScale = span.sizeScale;
      }
    }
  }
  return styles;
}
function compressTitleStyles(styles) {
  const spans = [];
  let currentStart = -1;
  let currentStyle = null;
  const flush = (end) => {
    if (currentStart === -1 || !currentStyle) {
      return;
    }
    spans.push({
      start: currentStart,
      end,
      color: currentStyle.color,
      sizeScale: currentStyle.sizeScale
    });
    currentStart = -1;
    currentStyle = null;
  };
  for (let index = 0; index < styles.length; index += 1) {
    const style = styles[index];
    if (!style.color && !style.sizeScale) {
      flush(index);
      continue;
    }
    if (currentStart === -1) {
      currentStart = index;
      currentStyle = { ...style };
      continue;
    }
    if (isSameStyle(currentStyle, style)) {
      continue;
    }
    flush(index);
    currentStart = index;
    currentStyle = { ...style };
  }
  flush(styles.length);
  return spans;
}
function isSameStyle(left, right) {
  return (left == null ? void 0 : left.color) === right.color && (left == null ? void 0 : left.sizeScale) === right.sizeScale;
}
function normalizeColor(value) {
  return value.trim() || "#111111";
}
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

// typography-presets.ts
var TYPOGRAPHY_PRESETS = [
  {
    id: "balanced",
    name: "\u5E73\u8861\u7248\u5F0F",
    titleAlign: "left",
    titleWidthScale: 1,
    titleFontMaxScale: 1,
    titleFontMinScale: 1,
    titleLineHeightScale: 1,
    titleMaxLines: 4,
    titleVerticalBias: 0.28,
    titleTopShift: 0,
    sidePaddingShift: 0,
    tagTopShift: 0,
    tagAlign: "left",
    tagWidthScale: 1,
    tagFontScale: 1,
    tagMaxRows: 3
  },
  {
    id: "impact",
    name: "\u51B2\u51FB\u5927\u5B57",
    titleAlign: "left",
    titleWidthScale: 0.9,
    titleFontMaxScale: 1.14,
    titleFontMinScale: 1.06,
    titleLineHeightScale: 0.94,
    titleMaxLines: 3,
    titleVerticalBias: 0.18,
    titleTopShift: 44,
    sidePaddingShift: 0,
    tagTopShift: 0,
    tagAlign: "left",
    tagWidthScale: 0.94,
    tagFontScale: 1,
    tagMaxRows: 3
  },
  {
    id: "airy",
    name: "\u7559\u767D\u6D77\u62A5",
    titleAlign: "left",
    titleWidthScale: 0.86,
    titleFontMaxScale: 0.96,
    titleFontMinScale: 0.94,
    titleLineHeightScale: 1.08,
    titleMaxLines: 4,
    titleVerticalBias: 0.08,
    titleTopShift: 118,
    sidePaddingShift: 18,
    tagTopShift: 8,
    tagAlign: "left",
    tagWidthScale: 0.88,
    tagFontScale: 0.96,
    tagMaxRows: 3
  },
  {
    id: "centered",
    name: "\u5C45\u4E2D\u6742\u5FD7",
    titleAlign: "center",
    titleWidthScale: 1.04,
    titleFontMaxScale: 1.02,
    titleFontMinScale: 1,
    titleLineHeightScale: 1.02,
    titleMaxLines: 5,
    titleVerticalBias: 0.16,
    titleTopShift: 56,
    sidePaddingShift: 0,
    tagTopShift: 4,
    tagAlign: "center",
    tagWidthScale: 1.02,
    tagFontScale: 0.98,
    tagMaxRows: 3
  },
  {
    id: "compact",
    name: "\u7D27\u51D1\u4FE1\u606F",
    titleAlign: "left",
    titleWidthScale: 1.08,
    titleFontMaxScale: 0.92,
    titleFontMinScale: 0.92,
    titleLineHeightScale: 0.95,
    titleMaxLines: 5,
    titleVerticalBias: 0.34,
    titleTopShift: -8,
    sidePaddingShift: -8,
    tagTopShift: -2,
    tagAlign: "left",
    tagWidthScale: 1.06,
    tagFontScale: 0.94,
    tagMaxRows: 4
  }
];
var TYPOGRAPHY_LOOKUP = new Map(
  TYPOGRAPHY_PRESETS.map((preset) => [preset.id, preset])
);
function getTypographyPreset(id) {
  var _a;
  return (_a = TYPOGRAPHY_LOOKUP.get(id)) != null ? _a : TYPOGRAPHY_PRESETS[0];
}
function isTypographyPresetId(value) {
  return TYPOGRAPHY_LOOKUP.has(value);
}

// layout.ts
var PREVIEW_PLACEHOLDER_TITLE = "Enter your cover title";
var MEASURE_CANVAS = document.createElement("canvas");
var MEASURE_CONTEXT = MEASURE_CANVAS.getContext("2d");
function parseTags(tagInput) {
  const seen = /* @__PURE__ */ new Set();
  const tags = [];
  for (const rawTag of tagInput.split(/[,\n，]+/)) {
    const tag = rawTag.trim();
    if (!tag || seen.has(tag)) {
      continue;
    }
    seen.add(tag);
    tags.push(tag);
  }
  return tags.slice(0, 18);
}
function computeCoverLayout(draft, preset, usePreviewPlaceholder = false) {
  const ctx = getMeasureContext();
  const layoutPreset = resolveLayoutPreset(preset, draft);
  const tags = parseTags(draft.tagInput);
  const tagLayout = buildTagLayout(tags, layoutPreset, ctx);
  const titleTop = Math.max(
    layoutPreset.titleTop,
    layoutPreset.tagTop + tagLayout.totalHeight + 64
  );
  const availableHeight = Math.max(
    260,
    COVER_HEIGHT - layoutPreset.bottomPadding - titleTop
  );
  const titleText = usePreviewPlaceholder ? getPreviewTitle(draft.title) : draft.title;
  const titleStyles = usePreviewPlaceholder && !draft.title.trim() ? [] : draft.titleStyles;
  const titleLayout = buildTitleLayout(
    titleText,
    titleStyles,
    layoutPreset,
    titleTop,
    availableHeight,
    ctx
  );
  return {
    titleText,
    titleLines: titleLayout.lines,
    titleFontSize: titleLayout.fontSize,
    titleLineHeight: titleLayout.lineHeight,
    titleLetterSpacing: titleLayout.letterSpacing,
    titleHeight: titleLayout.height,
    titleWidth: layoutPreset.titleWidth,
    titleAlign: layoutPreset.titleAlign,
    tagRows: tagLayout.rows,
    tagFontSize: tagLayout.fontSize,
    tagAreaHeight: tagLayout.totalHeight,
    tags
  };
}
function getPreviewTitle(title) {
  return title.trim() || PREVIEW_PLACEHOLDER_TITLE;
}
function getMeasureContext() {
  if (!MEASURE_CONTEXT) {
    throw new Error("Cover Maker cannot initialize the text measuring canvas.");
  }
  return MEASURE_CONTEXT;
}
function resolveLayoutPreset(preset, draft) {
  const typography = getTypographyPreset(draft.typographyId);
  const lineSpacing = getLineSpacingPreset(draft.lineSpacingId);
  const letterSpacing = getLetterSpacingPreset(draft.letterSpacingId);
  return {
    fontFamily: preset.fontFamily,
    textColor: preset.textColor,
    titleAlign: typography.titleAlign,
    titleWeight: preset.titleWeight,
    titleWidth: Math.max(
      420,
      Math.round(preset.titleWidth * typography.titleWidthScale)
    ),
    titleFontMax: Math.max(
      preset.titleFontMin,
      Math.round(preset.titleFontMax * typography.titleFontMaxScale)
    ),
    titleFontMin: Math.max(
      42,
      Math.round(preset.titleFontMin * typography.titleFontMinScale)
    ),
    titleLineHeightScale: typography.titleLineHeightScale * lineSpacing.scale,
    titleLetterSpacingEm: letterSpacing.em,
    titleMaxLines: typography.titleMaxLines,
    titleVerticalBias: typography.titleVerticalBias,
    titleTop: preset.titleTop + typography.titleTopShift,
    sidePadding: Math.max(48, preset.sidePadding + typography.sidePaddingShift),
    bottomPadding: preset.bottomPadding,
    tagTop: Math.max(56, preset.tagTop + typography.tagTopShift),
    tagFontMax: Math.max(
      16,
      Math.round(preset.tagFontMax * typography.tagFontScale)
    ),
    tagFontMin: Math.max(
      14,
      Math.round(preset.tagFontMin * typography.tagFontScale)
    ),
    tagMaxRows: typography.tagMaxRows,
    tagGapX: preset.tagGapX,
    tagGapY: preset.tagGapY,
    tagPaddingX: preset.tagPaddingX,
    tagPaddingY: preset.tagPaddingY,
    tagMaxWidth: Math.max(
      360,
      Math.round(preset.tagMaxWidth * typography.tagWidthScale)
    ),
    tagAlign: typography.tagAlign
  };
}
function buildTagLayout(tags, preset, ctx) {
  if (tags.length === 0) {
    return {
      rows: [],
      fontSize: preset.tagFontMax,
      totalHeight: 0
    };
  }
  for (let fontSize = preset.tagFontMax; fontSize >= preset.tagFontMin; fontSize -= 2) {
    const rows = tryLayoutTags(tags, preset, fontSize, ctx);
    if (rows.length <= preset.tagMaxRows) {
      return finalizeTagRows(rows, preset, fontSize);
    }
  }
  return finalizeTagRows(
    tryLayoutTags(tags, preset, preset.tagFontMin, ctx),
    preset,
    preset.tagFontMin
  );
}
function tryLayoutTags(tags, preset, fontSize, ctx) {
  ctx.font = `650 ${fontSize}px ${preset.fontFamily}`;
  const chipHeight = fontSize + preset.tagPaddingY * 2;
  const maxTextWidth = Math.max(
    96,
    preset.tagMaxWidth - preset.tagPaddingX * 2 - 10
  );
  const rows = [];
  let currentRow = { chips: [] };
  for (let index = 0; index < tags.length; index += 1) {
    const chip = createMeasuredChip(
      tags[index],
      preset,
      chipHeight,
      maxTextWidth,
      ctx
    );
    if (currentRow.chips.length === 0) {
      currentRow.chips.push(chip);
      continue;
    }
    const nextWidth = getRowWidth(currentRow, preset) + preset.tagGapX + chip.width;
    if (nextWidth <= preset.tagMaxWidth) {
      currentRow.chips.push(chip);
      continue;
    }
    rows.push(currentRow);
    if (rows.length >= preset.tagMaxRows) {
      const hiddenCount = tags.length - index;
      addOverflowChip(rows[rows.length - 1], hiddenCount, preset, chipHeight, ctx);
      return rows;
    }
    currentRow = { chips: [chip] };
  }
  if (currentRow.chips.length > 0) {
    rows.push(currentRow);
  }
  return rows;
}
function createMeasuredChip(text, preset, chipHeight, maxTextWidth, ctx) {
  const clippedText = ellipsizePlainText(text, maxTextWidth, ctx);
  const width = Math.min(
    preset.tagMaxWidth,
    Math.ceil(ctx.measureText(clippedText).width) + preset.tagPaddingX * 2
  );
  return {
    text: clippedText,
    width,
    height: chipHeight
  };
}
function addOverflowChip(row, hiddenCount, preset, chipHeight, ctx) {
  let hidden = hiddenCount;
  let overflowChip = createMeasuredChip(
    `+${hidden}`,
    preset,
    chipHeight,
    preset.tagMaxWidth,
    ctx
  );
  while (row.chips.length > 0 && getRowWidth(row, preset) + preset.tagGapX + overflowChip.width > preset.tagMaxWidth) {
    row.chips.pop();
    hidden += 1;
    overflowChip = createMeasuredChip(
      `+${hidden}`,
      preset,
      chipHeight,
      preset.tagMaxWidth,
      ctx
    );
  }
  row.chips.push(overflowChip);
}
function finalizeTagRows(rows, preset, fontSize) {
  const finalizedRows = rows.slice(0, preset.tagMaxRows).map((row, rowIndex) => {
    const rowWidth = getRowWidth(row, preset);
    const startX = preset.tagAlign === "center" ? Math.max(preset.sidePadding, Math.round((COVER_WIDTH - rowWidth) / 2)) : preset.sidePadding;
    const y = preset.tagTop + rowIndex * (fontSize + preset.tagPaddingY * 2 + preset.tagGapY);
    let currentX = startX;
    const chips = row.chips.map((chip, chipIndex) => {
      if (chipIndex > 0) {
        currentX += preset.tagGapX;
      }
      const layoutChip = {
        text: chip.text,
        x: currentX,
        y,
        width: chip.width,
        height: chip.height
      };
      currentX += chip.width;
      return layoutChip;
    });
    return {
      chips,
      width: rowWidth,
      y,
      height: fontSize + preset.tagPaddingY * 2
    };
  });
  const totalHeight = finalizedRows.length ? finalizedRows[finalizedRows.length - 1].y + finalizedRows[finalizedRows.length - 1].height - preset.tagTop : 0;
  return {
    rows: finalizedRows,
    fontSize,
    totalHeight
  };
}
function getRowWidth(row, preset) {
  return row.chips.reduce((total, chip) => total + chip.width, 0) + Math.max(0, row.chips.length - 1) * preset.tagGapX;
}
function buildTitleLayout(title, titleStyles, preset, titleTop, availableHeight, ctx) {
  var _a, _b;
  const minimumFontSize = Math.max(32, Math.round(preset.titleFontMin * 0.72));
  for (let fontSize = preset.titleFontMax; fontSize >= minimumFontSize; fontSize -= 4) {
    const letterSpacing2 = fontSize * preset.titleLetterSpacingEm;
    const rawLines2 = wrapStyledTitle(
      title,
      titleStyles,
      preset,
      fontSize,
      letterSpacing2,
      ctx
    );
    const clippedLines2 = clipStyledLines(
      rawLines2,
      preset,
      fontSize,
      letterSpacing2,
      ctx
    );
    const totalHeight2 = clippedLines2.reduce((sum, line) => sum + line.height, 0);
    if (clippedLines2.length <= preset.titleMaxLines && totalHeight2 <= availableHeight && clippedLines2.length > 0) {
      return {
        lines: placeTitleLines(
          clippedLines2,
          preset,
          titleTop,
          availableHeight,
          totalHeight2,
          letterSpacing2
        ),
        fontSize,
        lineHeight: clippedLines2[0].height,
        letterSpacing: letterSpacing2,
        height: totalHeight2
      };
    }
  }
  const fallbackFontSize = minimumFontSize;
  const letterSpacing = fallbackFontSize * preset.titleLetterSpacingEm;
  const rawLines = wrapStyledTitle(
    title,
    titleStyles,
    preset,
    fallbackFontSize,
    letterSpacing,
    ctx
  );
  const clippedLines = clipStyledLines(
    rawLines,
    preset,
    fallbackFontSize,
    letterSpacing,
    ctx
  );
  const totalHeight = clippedLines.reduce((sum, line) => sum + line.height, 0);
  return {
    lines: placeTitleLines(
      clippedLines,
      preset,
      titleTop,
      availableHeight,
      totalHeight,
      letterSpacing
    ),
    fontSize: fallbackFontSize,
    lineHeight: (_b = (_a = clippedLines[0]) == null ? void 0 : _a.height) != null ? _b : Math.round(fallbackFontSize * 1.1),
    letterSpacing,
    height: totalHeight
  };
}
function wrapStyledTitle(title, titleStyles, preset, baseFontSize, letterSpacing, ctx) {
  var _a;
  const styledChars = buildStyledTitleChars(title, titleStyles);
  const lines = [];
  let currentLine = createEmptyLine();
  const pushLine = () => {
    const finalized = finalizeInternalLine(
      currentLine,
      letterSpacing,
      preset.titleLineHeightScale
    );
    if (finalized) {
      lines.push(finalized);
    }
    currentLine = createEmptyLine();
  };
  for (const styledChar of styledChars) {
    if (styledChar.char === "\n") {
      pushLine();
      continue;
    }
    const isWhitespace = /\s/.test(styledChar.char);
    if (currentLine.glyphs.length === 0 && isWhitespace) {
      continue;
    }
    const glyph = createGlyph(
      styledChar.char,
      (_a = styledChar.color) != null ? _a : preset.textColor,
      baseFontSize * styledChar.sizeScale,
      preset.fontFamily,
      preset.titleWeight,
      ctx
    );
    const nextWidth = currentLine.width + (currentLine.glyphs.length > 0 ? letterSpacing : 0) + glyph.width;
    if (currentLine.glyphs.length > 0 && nextWidth > preset.titleWidth && !isWhitespace) {
      pushLine();
    }
    if (currentLine.glyphs.length === 0 && isWhitespace) {
      continue;
    }
    currentLine.glyphs.push(glyph);
    currentLine.width = calculateLineWidth(currentLine.glyphs, letterSpacing);
    currentLine.maxFontSize = Math.max(currentLine.maxFontSize, glyph.fontSize);
  }
  pushLine();
  return lines;
}
function clipStyledLines(lines, preset, baseFontSize, letterSpacing, ctx) {
  if (lines.length <= preset.titleMaxLines) {
    return lines;
  }
  const visibleLines = lines.slice(0, preset.titleMaxLines - 1);
  const overflowGlyphs = trimLeadingWhitespace(
    lines.slice(preset.titleMaxLines - 1).flatMap((line) => line.glyphs)
  );
  const ellipsis = createGlyph(
    "\u2026",
    preset.textColor,
    baseFontSize,
    preset.fontFamily,
    preset.titleWeight,
    ctx
  );
  const trimmedGlyphs = [];
  for (const glyph of overflowGlyphs) {
    const candidate = [...trimmedGlyphs, glyph];
    const widthWithEllipsis = calculateLineWidth(candidate, letterSpacing) + (candidate.length > 0 ? letterSpacing : 0) + ellipsis.width;
    if (widthWithEllipsis > preset.titleWidth && trimmedGlyphs.length > 0) {
      break;
    }
    trimmedGlyphs.push(glyph);
  }
  while (trimmedGlyphs.length > 0 && calculateLineWidth(trimmedGlyphs, letterSpacing) + (trimmedGlyphs.length > 0 ? letterSpacing : 0) + ellipsis.width > preset.titleWidth) {
    trimmedGlyphs.pop();
  }
  const clippedGlyphs = trimTrailingWhitespace([...trimmedGlyphs]);
  clippedGlyphs.push(ellipsis);
  const clippedLine = finalizeInternalLine(
    {
      glyphs: clippedGlyphs,
      text: "",
      width: 0,
      maxFontSize: 0,
      height: 0
    },
    letterSpacing,
    preset.titleLineHeightScale
  );
  if (!clippedLine) {
    return visibleLines;
  }
  return [...visibleLines, clippedLine];
}
function placeTitleLines(lines, preset, titleTop, availableHeight, totalHeight, letterSpacing) {
  let currentY = titleTop + Math.max(0, Math.round((availableHeight - totalHeight) * preset.titleVerticalBias));
  return lines.map((line) => {
    const startX = preset.titleAlign === "center" ? Math.round((COVER_WIDTH - line.width) / 2) : preset.sidePadding;
    let currentX = startX;
    const glyphs = line.glyphs.map((glyph, index) => {
      if (index > 0) {
        currentX += letterSpacing;
      }
      const placed = {
        text: glyph.text,
        x: currentX,
        y: currentY + Math.round((line.maxFontSize - glyph.fontSize) * 0.72),
        width: glyph.width,
        color: glyph.color,
        fontSize: glyph.fontSize
      };
      currentX += glyph.width;
      return placed;
    });
    const placedLine = {
      text: line.text,
      width: line.width,
      height: line.height,
      maxFontSize: line.maxFontSize,
      glyphs
    };
    currentY += line.height;
    return placedLine;
  });
}
function createGlyph(text, color, fontSize, fontFamily, fontWeight, ctx) {
  ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;
  return {
    text,
    color,
    fontSize,
    width: ctx.measureText(text).width
  };
}
function createEmptyLine() {
  return {
    glyphs: [],
    text: "",
    width: 0,
    maxFontSize: 0,
    height: 0
  };
}
function finalizeInternalLine(line, letterSpacing, lineHeightScale) {
  const glyphs = trimTrailingWhitespace([...line.glyphs]);
  if (glyphs.length === 0) {
    return null;
  }
  const maxFontSize = glyphs.reduce(
    (max, glyph) => Math.max(max, glyph.fontSize),
    0
  );
  return {
    glyphs,
    text: glyphs.map((glyph) => glyph.text).join(""),
    width: calculateLineWidth(glyphs, letterSpacing),
    maxFontSize,
    height: Math.round(
      maxFontSize * getTitleLineHeightRatio(maxFontSize, lineHeightScale)
    )
  };
}
function trimLeadingWhitespace(glyphs) {
  while (glyphs.length > 0 && /^\s$/.test(glyphs[0].text)) {
    glyphs.shift();
  }
  return glyphs;
}
function trimTrailingWhitespace(glyphs) {
  while (glyphs.length > 0 && /^\s$/.test(glyphs[glyphs.length - 1].text)) {
    glyphs.pop();
  }
  return glyphs;
}
function calculateLineWidth(glyphs, letterSpacing) {
  return glyphs.reduce((total, glyph) => total + glyph.width, 0) + Math.max(0, glyphs.length - 1) * letterSpacing;
}
function ellipsizePlainText(text, maxWidth, ctx) {
  if (ctx.measureText(text).width <= maxWidth) {
    return text;
  }
  const ellipsis = "\u2026";
  let result = "";
  for (const char of Array.from(text)) {
    const candidate = `${result}${char}`;
    if (ctx.measureText(`${candidate}${ellipsis}`).width > maxWidth) {
      break;
    }
    result = candidate;
  }
  return result ? `${result}${ellipsis}` : ellipsis;
}
function getTitleLineHeightRatio(fontSize, scale) {
  let base = 1.16;
  if (fontSize >= 108) {
    base = 1.08;
  } else if (fontSize >= 84) {
    base = 1.12;
  }
  return base * scale;
}

// presets.ts
var DISPLAY_FONT_STACK = '"HarmonyOS Sans SC","PingFang SC","Source Han Sans SC","Microsoft YaHei","Noto Sans SC",sans-serif';
var COVER_PRESETS = [
  {
    id: "minimal",
    name: "\u6781\u7B80\u98CE",
    description: "\u514B\u5236\u7559\u767D\uFF0C\u9002\u5408\u77E5\u8BC6\u89C2\u70B9\u548C\u5546\u4E1A\u6458\u8981\u3002",
    fontFamily: DISPLAY_FONT_STACK,
    titleAlign: "left",
    titleWeight: 820,
    titleWidth: 720,
    titleFontMax: 126,
    titleFontMin: 58,
    titleMaxLines: 4,
    titleVerticalBias: 0.28,
    titleTop: 302,
    topPadding: 84,
    sidePadding: 80,
    bottomPadding: 98,
    tagTop: 92,
    tagFontMax: 28,
    tagFontMin: 20,
    tagMaxRows: 3,
    tagGapX: 12,
    tagGapY: 14,
    tagPaddingX: 18,
    tagPaddingY: 10,
    tagMaxWidth: 740,
    tagAlign: "left",
    background: ["#fcfbf7", "#f6f2e9", "#ebe5d8"],
    textColor: "#111a22",
    accentColor: "#2a6f63",
    accentSoft: "rgba(42, 111, 99, 0.15)",
    accentMuted: "rgba(17, 26, 34, 0.08)",
    tagBackground: "rgba(255, 255, 255, 0.78)",
    tagTextColor: "#1f3033",
    tagBorderColor: "rgba(17, 26, 34, 0.12)",
    shadowColor: "rgba(17, 26, 34, 0.12)"
  },
  {
    id: "tech",
    name: "\u79D1\u6280\u611F",
    description: "\u6DF1\u8272\u9713\u8679\u5E95\uFF0C\u9002\u5408 AI\u3001\u4EA7\u54C1\u548C\u589E\u957F\u4E3B\u9898\u3002",
    fontFamily: DISPLAY_FONT_STACK,
    titleAlign: "left",
    titleWeight: 820,
    titleWidth: 734,
    titleFontMax: 122,
    titleFontMin: 58,
    titleMaxLines: 4,
    titleVerticalBias: 0.26,
    titleTop: 320,
    topPadding: 82,
    sidePadding: 78,
    bottomPadding: 98,
    tagTop: 92,
    tagFontMax: 28,
    tagFontMin: 20,
    tagMaxRows: 3,
    tagGapX: 12,
    tagGapY: 14,
    tagPaddingX: 18,
    tagPaddingY: 10,
    tagMaxWidth: 744,
    tagAlign: "left",
    background: ["#07131f", "#0d2031", "#132b42"],
    textColor: "#f4fbff",
    accentColor: "#79efff",
    accentSoft: "rgba(121, 239, 255, 0.16)",
    accentMuted: "rgba(121, 239, 255, 0.08)",
    tagBackground: "rgba(7, 22, 35, 0.42)",
    tagTextColor: "#d7fbff",
    tagBorderColor: "rgba(121, 239, 255, 0.35)",
    shadowColor: "rgba(0, 0, 0, 0.28)"
  },
  {
    id: "knowledge",
    name: "\u77E5\u8BC6\u5361\u7247\u98CE",
    description: "\u8F7B\u76C8\u5361\u7247\u611F\uFF0C\u9002\u5408\u65B9\u6CD5\u8BBA\u548C\u6559\u7A0B\u578B\u5C01\u9762\u3002",
    fontFamily: DISPLAY_FONT_STACK,
    titleAlign: "left",
    titleWeight: 800,
    titleWidth: 708,
    titleFontMax: 120,
    titleFontMin: 56,
    titleMaxLines: 4,
    titleVerticalBias: 0.25,
    titleTop: 312,
    topPadding: 84,
    sidePadding: 80,
    bottomPadding: 100,
    tagTop: 94,
    tagFontMax: 27,
    tagFontMin: 19,
    tagMaxRows: 3,
    tagGapX: 12,
    tagGapY: 14,
    tagPaddingX: 18,
    tagPaddingY: 10,
    tagMaxWidth: 732,
    tagAlign: "left",
    background: ["#f8fbff", "#edf4ff", "#e2ecff"],
    textColor: "#13233e",
    accentColor: "#2f6fff",
    accentSoft: "rgba(47, 111, 255, 0.14)",
    accentMuted: "rgba(19, 35, 62, 0.08)",
    tagBackground: "rgba(255, 255, 255, 0.84)",
    tagTextColor: "#28406f",
    tagBorderColor: "rgba(47, 111, 255, 0.24)",
    shadowColor: "rgba(16, 36, 76, 0.12)"
  },
  {
    id: "business",
    name: "\u6DF1\u8272\u5546\u52A1\u98CE",
    description: "\u6DF1\u8272\u57FA\u5E95\u52A0\u91D1\u8272\u5F3A\u8C03\uFF0C\u9002\u5408\u5546\u4E1A\u3001\u8D8B\u52BF\u4E0E\u7B56\u7565\u5185\u5BB9\u3002",
    fontFamily: DISPLAY_FONT_STACK,
    titleAlign: "left",
    titleWeight: 820,
    titleWidth: 696,
    titleFontMax: 122,
    titleFontMin: 58,
    titleMaxLines: 4,
    titleVerticalBias: 0.3,
    titleTop: 324,
    topPadding: 84,
    sidePadding: 92,
    bottomPadding: 100,
    tagTop: 96,
    tagFontMax: 26,
    tagFontMin: 19,
    tagMaxRows: 3,
    tagGapX: 12,
    tagGapY: 14,
    tagPaddingX: 18,
    tagPaddingY: 10,
    tagMaxWidth: 700,
    tagAlign: "left",
    background: ["#101317", "#1a1f26", "#262c35"],
    textColor: "#f7f1e8",
    accentColor: "#d7b576",
    accentSoft: "rgba(215, 181, 118, 0.14)",
    accentMuted: "rgba(255, 255, 255, 0.06)",
    tagBackground: "rgba(255, 255, 255, 0.05)",
    tagTextColor: "#f4d8a3",
    tagBorderColor: "rgba(215, 181, 118, 0.28)",
    shadowColor: "rgba(0, 0, 0, 0.3)"
  },
  {
    id: "magazine",
    name: "\u6742\u5FD7\u98CE",
    description: "\u66F4\u504F editorial\uFF0C\u9002\u5408\u89C2\u70B9\u6807\u9898\u548C\u4F20\u64AD\u578B\u9009\u9898\u3002",
    fontFamily: DISPLAY_FONT_STACK,
    titleAlign: "center",
    titleWeight: 820,
    titleWidth: 760,
    titleFontMax: 128,
    titleFontMin: 58,
    titleMaxLines: 5,
    titleVerticalBias: 0.22,
    titleTop: 336,
    topPadding: 84,
    sidePadding: 70,
    bottomPadding: 104,
    tagTop: 96,
    tagFontMax: 27,
    tagFontMin: 19,
    tagMaxRows: 3,
    tagGapX: 12,
    tagGapY: 14,
    tagPaddingX: 18,
    tagPaddingY: 10,
    tagMaxWidth: 760,
    tagAlign: "center",
    background: ["#f9f4ee", "#f1e7db", "#eadfd1"],
    textColor: "#191613",
    accentColor: "#c2563d",
    accentSoft: "rgba(194, 86, 61, 0.15)",
    accentMuted: "rgba(25, 22, 19, 0.08)",
    tagBackground: "rgba(255, 250, 246, 0.82)",
    tagTextColor: "#6c362a",
    tagBorderColor: "rgba(194, 86, 61, 0.24)",
    shadowColor: "rgba(25, 22, 19, 0.14)"
  }
];
var PRESET_LOOKUP = new Map(
  COVER_PRESETS.map((preset) => [preset.id, preset])
);
function getCoverPreset(id) {
  var _a;
  return (_a = PRESET_LOOKUP.get(id)) != null ? _a : COVER_PRESETS[0];
}
function isCoverPresetId(value) {
  return PRESET_LOOKUP.has(value);
}

// exporter.ts
async function exportCoverAsPng(options) {
  const { app, draft, settings } = options;
  const preset = getCoverPreset(draft.presetId);
  const layout = computeCoverLayout(draft, preset, false);
  const canvas = document.createElement("canvas");
  canvas.width = COVER_WIDTH;
  canvas.height = COVER_HEIGHT;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    throw new Error("Cover Maker cannot initialize the export canvas.");
  }
  drawCover(ctx, preset, layout);
  const exportFolder = normalizeExportFolder(settings.exportFolder);
  await ensureFolder(app, exportFolder);
  const filename = await buildUniqueFilename(
    app,
    exportFolder,
    draft.title.trim() || "cover-maker"
  );
  const path = (0, import_obsidian.normalizePath)(`${exportFolder}/${filename}`);
  const blob = await canvasToBlob(canvas);
  const data = await blob.arrayBuffer();
  await app.vault.adapter.writeBinary(path, data);
  return {
    path,
    filename
  };
}
function drawCover(ctx, preset, layout) {
  drawBackground(ctx, preset);
  drawDecorations(ctx, preset);
  drawTagRows(ctx, preset, layout);
  drawTitle(ctx, preset, layout);
}
function drawBackground(ctx, preset) {
  const gradient = ctx.createLinearGradient(0, 0, COVER_WIDTH, COVER_HEIGHT);
  gradient.addColorStop(0, preset.background[0]);
  gradient.addColorStop(0.58, preset.background[1]);
  gradient.addColorStop(1, preset.background[2]);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, COVER_WIDTH, COVER_HEIGHT);
  if (preset.id === "minimal") {
    drawCircleGlow(ctx, 770, 180, 210, preset.accentSoft, 0.9);
    drawCircleGlow(ctx, 690, 1060, 160, "rgba(255, 255, 255, 0.36)", 0.6);
    ctx.fillStyle = preset.accentColor;
    ctx.fillRect(80, 1030, 220, 4);
    ctx.strokeStyle = "rgba(17, 26, 34, 0.12)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(730, 190, 170, 0, Math.PI * 2);
    ctx.stroke();
  }
  if (preset.id === "tech") {
    drawCircleGlow(ctx, 720, 180, 250, "rgba(121, 239, 255, 0.18)", 1);
    drawGrid(ctx, "rgba(121, 239, 255, 0.12)", 44, 0.5);
    ctx.fillStyle = "rgba(121, 239, 255, 0.16)";
    ctx.fillRect(78, 1038, 280, 4);
    ctx.strokeStyle = "rgba(121, 239, 255, 0.18)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(560, 0);
    ctx.lineTo(900, 340);
    ctx.stroke();
  }
  if (preset.id === "knowledge") {
    ctx.strokeStyle = "rgba(47, 111, 255, 0.15)";
    ctx.lineWidth = 2;
    roundedRectPath(ctx, 58, 54, 784, 1092, 34);
    ctx.stroke();
    ctx.fillStyle = "rgba(47, 111, 255, 0.1)";
    roundedRectPath(ctx, 58, 54, 180, 12, 999);
    ctx.fill();
    drawCircleGlow(ctx, 760, 160, 170, preset.accentSoft, 1);
  }
  if (preset.id === "business") {
    const barGradient = ctx.createLinearGradient(58, 70, 58, 1130);
    barGradient.addColorStop(0, "rgba(215, 181, 118, 0.9)");
    barGradient.addColorStop(1, "rgba(215, 181, 118, 0.18)");
    ctx.fillStyle = barGradient;
    roundedRectPath(ctx, 58, 70, 8, 1060, 999);
    ctx.fill();
    drawCircleGlow(ctx, 760, 220, 220, "rgba(255, 255, 255, 0.08)", 1);
    ctx.strokeStyle = "rgba(215, 181, 118, 0.14)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(92, 1040);
    ctx.lineTo(820, 1040);
    ctx.stroke();
  }
  if (preset.id === "magazine") {
    drawCircleGlow(ctx, 760, 180, 200, preset.accentSoft, 0.9);
    ctx.fillStyle = "rgba(194, 86, 61, 0.14)";
    ctx.beginPath();
    ctx.moveTo(0, 940);
    ctx.lineTo(420, 860);
    ctx.lineTo(900, 1080);
    ctx.lineTo(900, 1200);
    ctx.lineTo(0, 1200);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(194, 86, 61, 0.2)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(760, 190, 154, 0, Math.PI * 2);
    ctx.stroke();
  }
}
function drawDecorations(ctx, preset) {
  if (preset.id !== "tech" && preset.id !== "business") {
    return;
  }
  ctx.save();
  ctx.globalAlpha = preset.id === "tech" ? 0.2 : 0.08;
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(770, 186, 2, 0, Math.PI * 2);
  ctx.arc(790, 214, 2, 0, Math.PI * 2);
  ctx.arc(752, 230, 1.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
function drawTagRows(ctx, preset, layout) {
  if (layout.tagRows.length === 0) {
    return;
  }
  ctx.save();
  ctx.font = `650 ${layout.tagFontSize}px ${preset.fontFamily}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  for (const row of layout.tagRows) {
    for (const chip of row.chips) {
      ctx.fillStyle = preset.tagBackground;
      roundedRectPath(ctx, chip.x, chip.y, chip.width, chip.height, chip.height / 2);
      ctx.fill();
      ctx.strokeStyle = preset.tagBorderColor;
      ctx.lineWidth = 2;
      roundedRectPath(ctx, chip.x, chip.y, chip.width, chip.height, chip.height / 2);
      ctx.stroke();
      ctx.fillStyle = preset.tagTextColor;
      ctx.fillText(chip.text, chip.x + chip.width / 2, chip.y + chip.height / 2 + 1);
    }
  }
  ctx.restore();
}
function drawTitle(ctx, preset, layout) {
  if (layout.titleLines.length === 0) {
    return;
  }
  ctx.save();
  ctx.textBaseline = "top";
  ctx.textAlign = "left";
  if (preset.id === "tech" || preset.id === "business") {
    ctx.shadowColor = preset.shadowColor;
    ctx.shadowBlur = 20;
    ctx.shadowOffsetY = 10;
  }
  for (const line of layout.titleLines) {
    for (const glyph of line.glyphs) {
      ctx.font = `${preset.titleWeight} ${glyph.fontSize}px ${preset.fontFamily}`;
      ctx.fillStyle = glyph.color;
      ctx.fillText(glyph.text, glyph.x, glyph.y);
    }
  }
  ctx.restore();
}
function drawCircleGlow(ctx, x, y, radius, color, opacity) {
  const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
  gradient.addColorStop(0, color);
  gradient.addColorStop(1, "rgba(255, 255, 255, 0)");
  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
function drawGrid(ctx, color, step, alpha) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  for (let x = 0; x <= COVER_WIDTH; x += step) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, COVER_HEIGHT);
    ctx.stroke();
  }
  for (let y = 0; y <= COVER_HEIGHT; y += step) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(COVER_WIDTH, y);
    ctx.stroke();
  }
  ctx.restore();
}
function roundedRectPath(ctx, x, y, width, height, radius) {
  const safeRadius = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + safeRadius, y);
  ctx.arcTo(x + width, y, x + width, y + height, safeRadius);
  ctx.arcTo(x + width, y + height, x, y + height, safeRadius);
  ctx.arcTo(x, y + height, x, y, safeRadius);
  ctx.arcTo(x, y, x + width, y, safeRadius);
  ctx.closePath();
}
function normalizeExportFolder(value) {
  return value.trim().replace(/^\/+|\/+$/g, "") || "Cover Maker Exports";
}
async function ensureFolder(app, folderPath) {
  const parts = (0, import_obsidian.normalizePath)(folderPath).split("/").filter(Boolean);
  let currentPath = "";
  for (const part of parts) {
    currentPath = currentPath ? `${currentPath}/${part}` : part;
    const exists = await app.vault.adapter.exists(currentPath);
    if (!exists) {
      await app.vault.createFolder(currentPath);
    }
  }
}
async function buildUniqueFilename(app, folderPath, rawTitle) {
  const baseTitle = sanitizeFilename(rawTitle).slice(0, 40) || "cover-maker";
  const timestamp = createTimestamp();
  let candidate = `${baseTitle}-${timestamp}.png`;
  let counter = 1;
  while (await app.vault.adapter.exists((0, import_obsidian.normalizePath)(`${folderPath}/${candidate}`))) {
    candidate = `${baseTitle}-${timestamp}-${counter}.png`;
    counter += 1;
  }
  return candidate;
}
function sanitizeFilename(value) {
  return value.trim().replace(/[\\/:*?"<>|]/g, "").replace(/\s+/g, "-");
}
function createTimestamp() {
  const now = /* @__PURE__ */ new Date();
  const parts = [
    now.getFullYear().toString(),
    `${now.getMonth() + 1}`.padStart(2, "0"),
    `${now.getDate()}`.padStart(2, "0"),
    `${now.getHours()}`.padStart(2, "0"),
    `${now.getMinutes()}`.padStart(2, "0"),
    `${now.getSeconds()}`.padStart(2, "0")
  ];
  return parts.join("");
}
function canvasToBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error("Cover Maker failed to export PNG data."));
        return;
      }
      resolve(blob);
    }, "image/png");
  });
}

// settings.ts
var import_obsidian2 = require("obsidian");
var DEFAULT_SETTINGS = {
  exportFolder: "Cover Maker Exports"
};
var DEFAULT_DRAFT = {
  title: "AI \u65F6\u4EE3\u7684\u7B2C\u4E8C\u589E\u957F\u66F2\u7EBF",
  tagInput: "AI \u5546\u4E1A,\u77E5\u8BC6 IP,\u89C6\u9891\u53F7\u5C01\u9762",
  presetId: "tech",
  typographyId: "balanced",
  lineSpacingId: "standard",
  letterSpacingId: "normal",
  titleStyles: []
};
function createDefaultData() {
  return {
    draft: { ...DEFAULT_DRAFT },
    templates: [],
    settings: { ...DEFAULT_SETTINGS }
  };
}
function sanitizePluginData(raw) {
  const value = raw;
  const defaults = createDefaultData();
  return {
    draft: sanitizeDraft(value == null ? void 0 : value.draft, defaults.draft),
    templates: sanitizeTemplates(value == null ? void 0 : value.templates),
    settings: sanitizeSettings(value == null ? void 0 : value.settings, defaults.settings)
  };
}
function sanitizeDraft(raw, fallback) {
  const title = typeof (raw == null ? void 0 : raw.title) === "string" ? raw.title : fallback.title;
  const presetId = typeof (raw == null ? void 0 : raw.presetId) === "string" && isCoverPresetId(raw.presetId) ? raw.presetId : fallback.presetId;
  const typographyId = typeof (raw == null ? void 0 : raw.typographyId) === "string" && isTypographyPresetId(raw.typographyId) ? raw.typographyId : fallback.typographyId;
  const lineSpacingId = typeof (raw == null ? void 0 : raw.lineSpacingId) === "string" && isLineSpacingPresetId(raw.lineSpacingId) ? raw.lineSpacingId : fallback.lineSpacingId;
  const letterSpacingId = typeof (raw == null ? void 0 : raw.letterSpacingId) === "string" && isLetterSpacingPresetId(raw.letterSpacingId) ? raw.letterSpacingId : fallback.letterSpacingId;
  return {
    title,
    tagInput: typeof (raw == null ? void 0 : raw.tagInput) === "string" ? raw.tagInput : fallback.tagInput,
    presetId,
    typographyId,
    lineSpacingId,
    letterSpacingId,
    titleStyles: sanitizeTitleStyles(title, raw == null ? void 0 : raw.titleStyles)
  };
}
function sanitizeTemplates(raw) {
  if (!Array.isArray(raw)) {
    return [];
  }
  return raw.map((item) => sanitizeTemplate(item)).filter((template) => Boolean(template)).sort((left, right) => right.updatedAt - left.updatedAt);
}
function sanitizeTemplate(raw) {
  if (!raw || typeof raw !== "object") {
    return null;
  }
  const title = typeof raw.title === "string" ? raw.title : "";
  const presetId = typeof raw.presetId === "string" && isCoverPresetId(raw.presetId) ? raw.presetId : DEFAULT_DRAFT.presetId;
  const typographyId = typeof raw.typographyId === "string" && isTypographyPresetId(raw.typographyId) ? raw.typographyId : DEFAULT_DRAFT.typographyId;
  const lineSpacingId = typeof raw.lineSpacingId === "string" && isLineSpacingPresetId(raw.lineSpacingId) ? raw.lineSpacingId : DEFAULT_DRAFT.lineSpacingId;
  const letterSpacingId = typeof raw.letterSpacingId === "string" && isLetterSpacingPresetId(raw.letterSpacingId) ? raw.letterSpacingId : DEFAULT_DRAFT.letterSpacingId;
  const name = typeof raw.name === "string" ? raw.name.trim() : "";
  if (!name) {
    return null;
  }
  const createdAt = typeof raw.createdAt === "number" ? raw.createdAt : Date.now();
  const updatedAt = typeof raw.updatedAt === "number" ? raw.updatedAt : createdAt;
  return {
    id: typeof raw.id === "string" && raw.id ? raw.id : `template-${createdAt}`,
    name,
    title,
    tagInput: typeof raw.tagInput === "string" ? raw.tagInput : "",
    presetId,
    typographyId,
    lineSpacingId,
    letterSpacingId,
    titleStyles: sanitizeTitleStyles(title, raw.titleStyles),
    createdAt,
    updatedAt
  };
}
function sanitizeTitleStyles(title, raw) {
  if (!Array.isArray(raw)) {
    return [];
  }
  const spans = raw.map((item) => sanitizeTitleStyleSpan(item)).filter((item) => Boolean(item));
  return normalizeTitleStyleSpans(title, spans);
}
function sanitizeTitleStyleSpan(raw) {
  if (!raw || typeof raw !== "object") {
    return null;
  }
  const span = raw;
  if (typeof span.start !== "number" || typeof span.end !== "number") {
    return null;
  }
  const result = {
    start: span.start,
    end: span.end
  };
  if (typeof span.color === "string" && span.color.trim()) {
    result.color = span.color.trim();
  }
  if (typeof span.sizeScale === "number" && Number.isFinite(span.sizeScale)) {
    result.sizeScale = span.sizeScale;
  }
  return result;
}
function sanitizeSettings(raw, fallback) {
  var _a;
  return {
    exportFolder: normalizeExportFolder2((_a = raw == null ? void 0 : raw.exportFolder) != null ? _a : fallback.exportFolder)
  };
}
function normalizeExportFolder2(value) {
  const trimmed = value.trim().replace(/^\/+|\/+$/g, "");
  return trimmed ? (0, import_obsidian2.normalizePath)(trimmed) : DEFAULT_SETTINGS.exportFolder;
}
var CoverMakerSettingTab = class extends import_obsidian2.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Cover Maker\u5C01\u9762" });
    containerEl.createEl("p", {
      text: "\u5C01\u9762\u5BFC\u51FA\u9ED8\u8BA4\u5199\u5165\u5F53\u524D\u5E93\u4E2D\u7684\u6307\u5B9A\u6587\u4EF6\u5939\u3002\u56E0\u4E3A Obsidian \u5B98\u65B9 API \u6CA1\u6709\u7EDF\u4E00\u7684\u7CFB\u7EDF\u53E6\u5B58\u4E3A\u5BF9\u8BDD\u6846\uFF0C\u8FD9\u91CC\u4F18\u5148\u91C7\u7528\u5E93\u5185\u5BFC\u51FA\u8DEF\u5F84\u3002",
      cls: "cm-settings-note"
    });
    new import_obsidian2.Setting(containerEl).setName("PNG \u5BFC\u51FA\u76EE\u5F55").setDesc("\u76F8\u5BF9\u5F53\u524D Vault \u7684\u6587\u4EF6\u5939\u8DEF\u5F84\uFF0C\u4F8B\u5982 Cover Maker Exports/AI Covers").addText((text) => {
      text.setPlaceholder(DEFAULT_SETTINGS.exportFolder).setValue(this.plugin.settings.exportFolder).onChange(async (value) => {
        await this.plugin.updateSettings({
          exportFolder: normalizeExportFolder2(value)
        });
      });
    });
  }
};

// view.ts
var import_obsidian3 = require("obsidian");
var TITLE_COLOR_SWATCHES = [
  "#111827",
  "#0f766e",
  "#2563eb",
  "#7c3aed",
  "#c2410c",
  "#dc2626"
];
var TITLE_SIZE_PRESETS = [
  { id: "sm", name: "\u504F\u5C0F", scale: 0.88 },
  { id: "base", name: "\u9ED8\u8BA4", scale: 1 },
  { id: "md", name: "\u504F\u5927", scale: 1.14 },
  { id: "lg", name: "\u5927\u5B57", scale: 1.3 },
  { id: "xl", name: "\u5F3A\u8C03", scale: 1.48 }
];
var COVER_MAKER_VIEW_TYPE = "cover-maker-view";
var CoverMakerView = class extends import_obsidian3.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.resizeObserver = null;
    this.plugin = plugin;
  }
  getViewType() {
    return COVER_MAKER_VIEW_TYPE;
  }
  getDisplayText() {
    return "Cover Maker\u5C01\u9762";
  }
  getIcon() {
    return "image-file";
  }
  async onOpen() {
    this.buildView();
    this.refresh();
    this.attachResizeObserver();
  }
  async onClose() {
    var _a;
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    this.resizeObserver = null;
  }
  refresh() {
    this.syncInputsFromState();
    this.renderPresetGrid();
    this.renderTypographyGrid();
    this.renderLineSpacingGrid();
    this.renderLetterSpacingGrid();
    this.renderTemplateList();
    this.renderSelectionInfo();
    this.renderPreview();
    this.statusEl.setText(`\u5BFC\u51FA\u76EE\u5F55\uFF1A${this.plugin.settings.exportFolder}`);
  }
  buildView() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("cm-view-root");
    const root = contentEl.createDiv({ cls: "cm-view" });
    const header = root.createDiv({ cls: "cm-panel-header" });
    header.createEl("h2", {
      text: "Cover Maker\u5C01\u9762",
      cls: "cm-panel-title"
    });
    header.createEl("p", {
      text: "\u4E3A\u89C6\u9891\u53F7\u548C\u516C\u4F17\u53F7\u56FE\u6587\u5FEB\u901F\u751F\u6210 900\xD71200 \u7684\u7AD6\u7248\u77E5\u8BC6\u5C01\u9762\u3002",
      cls: "cm-panel-subtitle"
    });
    const titleField = root.createDiv({ cls: "cm-section" });
    titleField.createEl("label", { text: "\u5C01\u9762\u6807\u9898", cls: "cm-field-label" });
    this.titleInput = titleField.createEl("textarea", {
      cls: "cm-textarea cm-title-input",
      attr: {
        rows: "4",
        placeholder: "\u8F93\u5165\u4E3B\u6807\u9898\uFF0C\u9884\u89C8\u4F1A\u7ACB\u5373\u66F4\u65B0"
      }
    });
    this.titleInput.addEventListener("input", () => {
      this.plugin.updateTitle(this.titleInput.value, { refresh: false });
      this.renderSelectionInfo();
      this.renderPreview();
    });
    this.titleInput.addEventListener("select", () => this.renderSelectionInfo());
    this.titleInput.addEventListener("keyup", () => this.renderSelectionInfo());
    this.titleInput.addEventListener("mouseup", () => this.renderSelectionInfo());
    const styleEditor = root.createDiv({ cls: "cm-section" });
    styleEditor.createEl("label", { text: "\u6807\u9898\u5C40\u90E8\u6837\u5F0F", cls: "cm-field-label" });
    this.selectionInfoEl = styleEditor.createDiv({ cls: "cm-selection-note" });
    const colorWrap = styleEditor.createDiv({ cls: "cm-subsection" });
    colorWrap.createEl("div", {
      text: "\u5C40\u90E8\u989C\u8272",
      cls: "cm-subsection-title"
    });
    const swatches = colorWrap.createDiv({ cls: "cm-color-swatches" });
    for (const color of TITLE_COLOR_SWATCHES) {
      const swatch = swatches.createEl("button", {
        cls: "cm-color-swatch"
      });
      swatch.type = "button";
      swatch.style.background = color;
      swatch.addEventListener("click", () => this.applyTitleColor(color));
    }
    const customColorRow = colorWrap.createDiv({ cls: "cm-inline-row" });
    this.customColorInput = customColorRow.createEl("input", {
      cls: "cm-color-input",
      attr: {
        type: "color",
        value: "#2563eb"
      }
    });
    const applyCustomColorButton = customColorRow.createEl("button", {
      text: "\u5E94\u7528\u81EA\u5B9A\u4E49\u989C\u8272",
      cls: "cm-button cm-button-small"
    });
    applyCustomColorButton.addEventListener("click", () => {
      this.applyTitleColor(this.customColorInput.value);
    });
    const sizeWrap = styleEditor.createDiv({ cls: "cm-subsection" });
    sizeWrap.createEl("div", {
      text: "\u5C40\u90E8\u5B57\u53F7",
      cls: "cm-subsection-title"
    });
    const sizeGrid = sizeWrap.createDiv({ cls: "cm-choice-grid" });
    for (const preset of TITLE_SIZE_PRESETS) {
      const button = sizeGrid.createEl("button", {
        text: preset.name,
        cls: "cm-preset-card"
      });
      button.type = "button";
      button.addEventListener("click", () => {
        this.applyTitleSize(preset.scale);
      });
    }
    const clearStyleButton = styleEditor.createEl("button", {
      text: "\u6E05\u9664\u9009\u4E2D\u6837\u5F0F",
      cls: "cm-button cm-button-small"
    });
    clearStyleButton.addEventListener("click", () => {
      const selection = this.getTitleSelection();
      if (!selection) {
        new import_obsidian3.Notice("\u8BF7\u5148\u5728\u6807\u9898\u4E2D\u9009\u4E2D\u8981\u6E05\u9664\u6837\u5F0F\u7684\u6587\u5B57\u3002");
        return;
      }
      this.plugin.clearTitleStyles(selection.start, selection.end);
      this.renderSelectionInfo();
    });
    const tagField = root.createDiv({ cls: "cm-section" });
    tagField.createEl("label", { text: "\u6807\u7B7E", cls: "cm-field-label" });
    tagField.createEl("p", {
      text: "\u652F\u6301\u82F1\u6587\u9017\u53F7\u3001\u4E2D\u6587\u9017\u53F7\u6216\u6362\u884C\u5206\u9694\u591A\u4E2A\u6807\u7B7E\u3002",
      cls: "cm-field-hint"
    });
    this.tagInput = tagField.createEl("textarea", {
      cls: "cm-textarea",
      attr: {
        rows: "3",
        placeholder: "\u4F8B\u5982\uFF1AAI \u5546\u4E1A, \u89C6\u9891\u53F7\u589E\u957F, \u77E5\u8BC6 IP"
      }
    });
    this.tagInput.addEventListener("input", () => {
      this.plugin.setDraft({ tagInput: this.tagInput.value }, { refresh: false });
      this.renderPreview();
    });
    const presetSection = root.createDiv({ cls: "cm-section" });
    presetSection.createEl("label", { text: "\u89C6\u89C9\u98CE\u683C", cls: "cm-field-label" });
    this.presetGrid = presetSection.createDiv({ cls: "cm-preset-grid" });
    const typographySection = root.createDiv({ cls: "cm-section" });
    typographySection.createEl("label", { text: "\u6587\u5B57\u6392\u7248\u4E3B\u9898", cls: "cm-field-label" });
    this.typographyGrid = typographySection.createDiv({ cls: "cm-preset-grid" });
    const spacingSection = root.createDiv({ cls: "cm-section" });
    spacingSection.createEl("label", { text: "\u6587\u5B57\u7EC6\u8282", cls: "cm-field-label" });
    const lineSpacingWrap = spacingSection.createDiv({ cls: "cm-subsection" });
    lineSpacingWrap.createEl("div", {
      text: "\u884C\u8DDD\u9009\u62E9",
      cls: "cm-subsection-title"
    });
    this.lineSpacingGrid = lineSpacingWrap.createDiv({ cls: "cm-choice-grid" });
    const letterSpacingWrap = spacingSection.createDiv({ cls: "cm-subsection" });
    letterSpacingWrap.createEl("div", {
      text: "\u5B57\u95F4\u8DDD\u9009\u62E9",
      cls: "cm-subsection-title"
    });
    this.letterSpacingGrid = letterSpacingWrap.createDiv({ cls: "cm-choice-grid" });
    const actionRow = root.createDiv({ cls: "cm-button-row" });
    const exportButton = actionRow.createEl("button", {
      text: "\u5BFC\u51FA PNG",
      cls: "cm-button cm-button-primary"
    });
    exportButton.addEventListener("click", async () => {
      try {
        const result = await this.plugin.exportCurrentDraft();
        if (!result) {
          return;
        }
        this.statusEl.setText(`\u5DF2\u5BFC\u51FA\uFF1A${result.path}`);
      } catch (error) {
        const message = error instanceof Error ? error.message : "\u5BFC\u51FA\u5C01\u9762\u5931\u8D25\u3002";
        this.statusEl.setText(message);
        new import_obsidian3.Notice(message);
      }
    });
    const previewSection = root.createDiv({ cls: "cm-section" });
    previewSection.createEl("label", { text: "\u5B9E\u65F6\u9884\u89C8", cls: "cm-field-label" });
    this.previewShell = previewSection.createDiv({ cls: "cm-preview-shell" });
    this.previewStage = this.previewShell.createDiv({ cls: "cm-preview-stage" });
    const templateSection = root.createDiv({ cls: "cm-section" });
    const templateHead = templateSection.createDiv({ cls: "cm-template-head" });
    templateHead.createEl("label", { text: "\u5E38\u7528\u6A21\u677F", cls: "cm-field-label" });
    templateHead.createEl("span", {
      text: "\u4FDD\u5B58\u5F53\u524D\u6807\u9898\u3001\u6807\u7B7E\u3001\u98CE\u683C\u548C\u6587\u5B57\u53C2\u6570\u7EC4\u5408",
      cls: "cm-field-hint"
    });
    const templateActions = templateSection.createDiv({ cls: "cm-template-create" });
    this.templateNameInput = templateActions.createEl("input", {
      cls: "cm-input",
      attr: {
        type: "text",
        placeholder: "\u6A21\u677F\u540D\u79F0\uFF0C\u4F8B\u5982 AI \u7206\u6B3E\u5C01\u9762"
      }
    });
    const saveTemplateButton = templateActions.createEl("button", {
      text: "\u4FDD\u5B58\u5F53\u524D\u4E3A\u6A21\u677F",
      cls: "cm-button"
    });
    saveTemplateButton.addEventListener("click", async () => {
      const template = await this.plugin.saveCurrentAsTemplate(this.templateNameInput.value);
      this.templateNameInput.value = template.name;
      this.statusEl.setText(`\u6A21\u677F\u5DF2\u4FDD\u5B58\uFF1A${template.name}`);
    });
    this.templateList = templateSection.createDiv({ cls: "cm-template-list" });
    this.statusEl = root.createDiv({ cls: "cm-status" });
  }
  syncInputsFromState() {
    const { draft } = this.plugin;
    if (this.titleInput.value !== draft.title) {
      this.titleInput.value = draft.title;
    }
    if (this.tagInput.value !== draft.tagInput) {
      this.tagInput.value = draft.tagInput;
    }
  }
  renderPresetGrid() {
    this.renderChoiceButtons(
      this.presetGrid,
      COVER_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name
      })),
      this.plugin.draft.presetId,
      (id) => {
        this.plugin.setDraft({ presetId: id }, { refresh: false });
        this.renderPresetGrid();
        this.renderPreview();
      }
    );
  }
  renderTypographyGrid() {
    this.renderChoiceButtons(
      this.typographyGrid,
      TYPOGRAPHY_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name
      })),
      this.plugin.draft.typographyId,
      (id) => {
        this.plugin.setDraft({ typographyId: id }, { refresh: false });
        this.renderTypographyGrid();
        this.renderPreview();
      }
    );
  }
  renderLineSpacingGrid() {
    this.renderChoiceButtons(
      this.lineSpacingGrid,
      LINE_SPACING_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name
      })),
      this.plugin.draft.lineSpacingId,
      (id) => {
        this.plugin.setDraft({ lineSpacingId: id }, { refresh: false });
        this.renderLineSpacingGrid();
        this.renderPreview();
      }
    );
  }
  renderLetterSpacingGrid() {
    this.renderChoiceButtons(
      this.letterSpacingGrid,
      LETTER_SPACING_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name
      })),
      this.plugin.draft.letterSpacingId,
      (id) => {
        this.plugin.setDraft({ letterSpacingId: id }, { refresh: false });
        this.renderLetterSpacingGrid();
        this.renderPreview();
      }
    );
  }
  renderChoiceButtons(container, items, selectedId, onSelect) {
    container.empty();
    for (const item of items) {
      const button = container.createEl("button", {
        cls: `cm-preset-card${item.id === selectedId ? " is-active" : ""}`
      });
      button.type = "button";
      button.createEl("span", { text: item.name, cls: "cm-preset-name" });
      button.addEventListener("click", () => onSelect(item.id));
    }
  }
  renderSelectionInfo() {
    const selection = this.getTitleSelection();
    if (!selection) {
      this.selectionInfoEl.setText("\u5148\u5728\u6807\u9898\u8F93\u5165\u6846\u91CC\u9009\u4E2D\u4E00\u6BB5\u6587\u5B57\uFF0C\u518D\u5355\u72EC\u8BBE\u7F6E\u989C\u8272\u548C\u5B57\u53F7\u3002");
      return;
    }
    const selectedText = this.titleInput.value.slice(selection.start, selection.end).replace(/\s+/g, " ");
    const previewText = selectedText.length > 18 ? `${selectedText.slice(0, 18)}\u2026` : selectedText;
    this.selectionInfoEl.setText(`\u5F53\u524D\u5DF2\u9009 ${selection.end - selection.start} \u4E2A\u5B57\u7B26\uFF1A${previewText}`);
  }
  getTitleSelection() {
    var _a, _b;
    const start = (_a = this.titleInput.selectionStart) != null ? _a : 0;
    const end = (_b = this.titleInput.selectionEnd) != null ? _b : 0;
    if (start === end) {
      return null;
    }
    return { start, end };
  }
  applyTitleColor(color) {
    const selection = this.getTitleSelection();
    if (!selection) {
      new import_obsidian3.Notice("\u8BF7\u5148\u5728\u6807\u9898\u4E2D\u9009\u4E2D\u8981\u4FEE\u6539\u989C\u8272\u7684\u6587\u5B57\u3002");
      return;
    }
    this.plugin.applyTitleColor(selection.start, selection.end, color);
    this.renderSelectionInfo();
  }
  applyTitleSize(scale) {
    const selection = this.getTitleSelection();
    if (!selection) {
      new import_obsidian3.Notice("\u8BF7\u5148\u5728\u6807\u9898\u4E2D\u9009\u4E2D\u8981\u4FEE\u6539\u5B57\u53F7\u7684\u6587\u5B57\u3002");
      return;
    }
    this.plugin.applyTitleSizeScale(selection.start, selection.end, scale);
    this.renderSelectionInfo();
  }
  renderPreview() {
    if (!this.previewStage) {
      return;
    }
    this.previewStage.empty();
    const preset = getCoverPreset(this.plugin.draft.presetId);
    const layout = computeCoverLayout(this.plugin.draft, preset, true);
    const availableWidth = this.previewShell.clientWidth > 16 ? this.previewShell.clientWidth - 8 : 280;
    const scale = Math.min(1, availableWidth / COVER_WIDTH);
    const width = Math.round(COVER_WIDTH * scale);
    const height = Math.round(COVER_HEIGHT * scale);
    this.previewStage.style.width = `${width}px`;
    this.previewStage.style.height = `${height}px`;
    const coverEl = this.previewStage.createDiv({ cls: "cm-cover-preview" });
    coverEl.setAttribute("data-preset", preset.id);
    coverEl.style.width = `${width}px`;
    coverEl.style.height = `${height}px`;
    coverEl.style.setProperty("--cm-bg-1", preset.background[0]);
    coverEl.style.setProperty("--cm-bg-2", preset.background[1]);
    coverEl.style.setProperty("--cm-bg-3", preset.background[2]);
    coverEl.style.setProperty("--cm-text-color", preset.textColor);
    coverEl.style.setProperty("--cm-accent-color", preset.accentColor);
    coverEl.style.setProperty("--cm-accent-soft", preset.accentSoft);
    coverEl.style.setProperty("--cm-accent-muted", preset.accentMuted);
    coverEl.style.setProperty("--cm-tag-bg", preset.tagBackground);
    coverEl.style.setProperty("--cm-tag-text", preset.tagTextColor);
    coverEl.style.setProperty("--cm-tag-border", preset.tagBorderColor);
    coverEl.style.setProperty("--cm-font-display", preset.fontFamily);
    coverEl.style.setProperty("--cm-shadow-color", preset.shadowColor);
    coverEl.style.setProperty("--cm-grid-size", `${Math.max(16, 44 * scale)}px`);
    coverEl.createDiv({ cls: "cm-cover-surface" });
    coverEl.createDiv({ cls: "cm-cover-orbit" });
    coverEl.createDiv({ cls: "cm-cover-grid" });
    coverEl.createDiv({ cls: "cm-cover-stripe" });
    coverEl.createDiv({ cls: "cm-cover-corner" });
    coverEl.createDiv({ cls: "cm-cover-outline" });
    const tagLayer = coverEl.createDiv({ cls: "cm-cover-layer" });
    for (const row of layout.tagRows) {
      for (const chip of row.chips) {
        const chipEl = tagLayer.createDiv({ cls: "cm-cover-tag" });
        chipEl.setText(chip.text);
        chipEl.style.left = `${chip.x * scale}px`;
        chipEl.style.top = `${chip.y * scale}px`;
        chipEl.style.width = `${chip.width * scale}px`;
        chipEl.style.height = `${chip.height * scale}px`;
        chipEl.style.fontSize = `${layout.tagFontSize * scale}px`;
        chipEl.style.borderRadius = `${chip.height * scale}px`;
      }
    }
    const titleLayer = coverEl.createDiv({ cls: "cm-cover-title-layer" });
    titleLayer.style.fontFamily = preset.fontFamily;
    titleLayer.style.fontWeight = `${preset.titleWeight}`;
    for (const line of layout.titleLines) {
      for (const glyph of line.glyphs) {
        const glyphEl = titleLayer.createDiv({ cls: "cm-cover-title-glyph" });
        glyphEl.setText(glyph.text);
        glyphEl.style.left = `${glyph.x * scale}px`;
        glyphEl.style.top = `${glyph.y * scale}px`;
        glyphEl.style.fontSize = `${glyph.fontSize * scale}px`;
        glyphEl.style.color = glyph.color;
      }
    }
  }
  renderTemplateList() {
    this.templateList.empty();
    if (this.plugin.templates.length === 0) {
      this.templateList.createEl("div", {
        text: "\u8FD8\u6CA1\u6709\u4FDD\u5B58\u6A21\u677F\uFF0C\u5148\u505A\u4E00\u4E2A\u4F60\u5E38\u7528\u7684\u5C01\u9762\u7EC4\u5408\u5427\u3002",
        cls: "cm-empty-state"
      });
      return;
    }
    for (const template of this.plugin.templates) {
      const item = this.templateList.createDiv({ cls: "cm-template-item" });
      const meta = item.createDiv({ cls: "cm-template-meta" });
      meta.createEl("strong", { text: template.name, cls: "cm-template-name" });
      meta.createEl("span", {
        text: `${getCoverPreset(template.presetId).name} \xB7 ${getTypographyPreset(template.typographyId).name} \xB7 ${getLineSpacingPreset(template.lineSpacingId).name}\u884C\u8DDD \xB7 ${getLetterSpacingPreset(template.letterSpacingId).name}\u5B57\u8DDD \xB7 ${template.titleStyles.length} \u6BB5\u5C40\u90E8\u6837\u5F0F \xB7 ${formatDate(template.updatedAt)}`,
        cls: "cm-template-subtle"
      });
      const snippet = item.createEl("div", { cls: "cm-template-snippet" });
      snippet.setText(template.title || "\u65E0\u6807\u9898\u6A21\u677F");
      const actions = item.createDiv({ cls: "cm-template-actions" });
      const applyButton = actions.createEl("button", {
        text: "\u5E94\u7528",
        cls: "cm-button cm-button-small"
      });
      applyButton.addEventListener("click", async () => {
        await this.plugin.applyTemplate(template.id);
        this.renderSelectionInfo();
        this.statusEl.setText(`\u5DF2\u5E94\u7528\u6A21\u677F\uFF1A${template.name}`);
      });
      const updateButton = actions.createEl("button", {
        text: "\u66F4\u65B0",
        cls: "cm-button cm-button-small"
      });
      updateButton.addEventListener("click", async () => {
        await this.plugin.updateTemplate(template.id);
        this.statusEl.setText(`\u6A21\u677F\u5DF2\u66F4\u65B0\uFF1A${template.name}`);
      });
      const deleteButton = actions.createEl("button", {
        text: "\u5220\u9664",
        cls: "cm-button cm-button-small cm-button-danger"
      });
      deleteButton.addEventListener("click", async () => {
        await this.plugin.deleteTemplate(template.id);
        this.statusEl.setText(`\u6A21\u677F\u5DF2\u5220\u9664\uFF1A${template.name}`);
      });
    }
  }
  attachResizeObserver() {
    var _a;
    if (typeof ResizeObserver === "undefined" || !this.previewShell) {
      return;
    }
    (_a = this.resizeObserver) == null ? void 0 : _a.disconnect();
    this.resizeObserver = new ResizeObserver(() => this.renderPreview());
    this.resizeObserver.observe(this.previewShell);
  }
};
function formatDate(timestamp) {
  const date = new Date(timestamp);
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  const hour = `${date.getHours()}`.padStart(2, "0");
  const minute = `${date.getMinutes()}`.padStart(2, "0");
  return `${month}-${day} ${hour}:${minute}`;
}

// main.ts
var CoverMakerPlugin = class extends import_obsidian4.Plugin {
  constructor() {
    super(...arguments);
    this.data = createDefaultData();
    this.persistTimer = null;
  }
  get draft() {
    return this.data.draft;
  }
  get templates() {
    return this.data.templates;
  }
  get settings() {
    return this.data.settings;
  }
  async onload() {
    await this.loadPluginData();
    this.registerView(
      COVER_MAKER_VIEW_TYPE,
      (leaf) => new CoverMakerView(leaf, this)
    );
    this.addRibbonIcon("image-file", "Open Cover Maker\u5C01\u9762", async () => {
      await this.activateView();
    });
    this.addCommand({
      id: "open-cover-maker-sidebar",
      name: "\u6253\u5F00 Cover Maker \u4FA7\u680F",
      callback: async () => {
        await this.activateView();
      }
    });
    this.addCommand({
      id: "export-cover-maker-png",
      name: "\u5BFC\u51FA\u5F53\u524D\u5C01\u9762\u4E3A PNG",
      callback: async () => {
        await this.activateView();
        await this.exportCurrentDraft();
      }
    });
    this.addSettingTab(new CoverMakerSettingTab(this.app, this));
  }
  async onunload() {
    if (this.persistTimer !== null) {
      window.clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }
    await this.flushPersist();
    await this.app.workspace.detachLeavesOfType(COVER_MAKER_VIEW_TYPE);
  }
  async activateView() {
    var _a, _b;
    const { workspace } = this.app;
    let leaf = (_a = workspace.getLeavesOfType(COVER_MAKER_VIEW_TYPE)[0]) != null ? _a : null;
    if (!leaf) {
      leaf = (_b = workspace.getRightLeaf(false)) != null ? _b : null;
    }
    if (!leaf) {
      new import_obsidian4.Notice("\u65E0\u6CD5\u6253\u5F00 Cover Maker \u53F3\u4FA7\u680F\u3002");
      return null;
    }
    await leaf.setViewState({
      type: COVER_MAKER_VIEW_TYPE,
      active: true
    });
    workspace.revealLeaf(leaf);
    return leaf;
  }
  setDraft(patch, options = {}) {
    const nextDraft = {
      ...this.data.draft,
      ...patch
    };
    nextDraft.titleStyles = normalizeTitleStyleSpans(nextDraft.title, nextDraft.titleStyles);
    this.data.draft = nextDraft;
    if (options.persist !== false) {
      this.schedulePersist();
    }
    if (options.refresh !== false) {
      this.refreshOpenViews();
    }
  }
  updateTitle(nextTitle, options = {}) {
    const currentTitle = this.data.draft.title;
    const titleStyles = remapTitleStyleSpans(currentTitle, nextTitle, this.data.draft.titleStyles);
    this.setDraft(
      {
        title: nextTitle,
        titleStyles
      },
      options
    );
  }
  applyTitleColor(start, end, color) {
    this.applyTitleStyles(start, end, {
      color
    });
  }
  applyTitleSizeScale(start, end, sizeScale) {
    this.applyTitleStyles(start, end, {
      sizeScale
    });
  }
  clearTitleStyles(start, end) {
    if (start >= end) {
      return;
    }
    this.setDraft(
      {
        titleStyles: clearTitleStyleRange(
          this.data.draft.title,
          this.data.draft.titleStyles,
          start,
          end
        )
      },
      {
        refresh: true,
        persist: true
      }
    );
  }
  async updateSettings(patch) {
    this.data.settings = {
      ...this.data.settings,
      ...patch
    };
    await this.flushPersist();
    this.refreshOpenViews();
  }
  async saveCurrentAsTemplate(inputName) {
    const now = Date.now();
    const name = this.buildTemplateName(inputName);
    const existing = this.data.templates.find((template2) => template2.name === name);
    if (existing) {
      existing.title = this.data.draft.title;
      existing.tagInput = this.data.draft.tagInput;
      existing.presetId = this.data.draft.presetId;
      existing.typographyId = this.data.draft.typographyId;
      existing.lineSpacingId = this.data.draft.lineSpacingId;
      existing.letterSpacingId = this.data.draft.letterSpacingId;
      existing.titleStyles = cloneTitleStyles(this.data.draft.titleStyles);
      existing.updatedAt = now;
      await this.flushPersist();
      this.refreshOpenViews();
      new import_obsidian4.Notice(`\u5DF2\u66F4\u65B0\u6A21\u677F\uFF1A${existing.name}`);
      return existing;
    }
    const template = {
      id: `template-${now}-${Math.random().toString(36).slice(2, 8)}`,
      name,
      title: this.data.draft.title,
      tagInput: this.data.draft.tagInput,
      presetId: this.data.draft.presetId,
      typographyId: this.data.draft.typographyId,
      lineSpacingId: this.data.draft.lineSpacingId,
      letterSpacingId: this.data.draft.letterSpacingId,
      titleStyles: cloneTitleStyles(this.data.draft.titleStyles),
      createdAt: now,
      updatedAt: now
    };
    this.data.templates = [template, ...this.data.templates];
    await this.flushPersist();
    this.refreshOpenViews();
    new import_obsidian4.Notice(`\u6A21\u677F\u5DF2\u4FDD\u5B58\uFF1A${template.name}`);
    return template;
  }
  async applyTemplate(templateId) {
    const template = this.data.templates.find((item) => item.id === templateId);
    if (!template) {
      return;
    }
    this.data.draft = {
      title: template.title,
      tagInput: template.tagInput,
      presetId: template.presetId,
      typographyId: template.typographyId,
      lineSpacingId: template.lineSpacingId,
      letterSpacingId: template.letterSpacingId,
      titleStyles: cloneTitleStyles(template.titleStyles)
    };
    await this.flushPersist();
    this.refreshOpenViews();
    new import_obsidian4.Notice(`\u5DF2\u5E94\u7528\u6A21\u677F\uFF1A${template.name}`);
  }
  async updateTemplate(templateId) {
    const template = this.data.templates.find((item) => item.id === templateId);
    if (!template) {
      return;
    }
    template.title = this.data.draft.title;
    template.tagInput = this.data.draft.tagInput;
    template.presetId = this.data.draft.presetId;
    template.typographyId = this.data.draft.typographyId;
    template.lineSpacingId = this.data.draft.lineSpacingId;
    template.letterSpacingId = this.data.draft.letterSpacingId;
    template.titleStyles = cloneTitleStyles(this.data.draft.titleStyles);
    template.updatedAt = Date.now();
    await this.flushPersist();
    this.refreshOpenViews();
    new import_obsidian4.Notice(`\u6A21\u677F\u5DF2\u66F4\u65B0\uFF1A${template.name}`);
  }
  async deleteTemplate(templateId) {
    const template = this.data.templates.find((item) => item.id === templateId);
    this.data.templates = this.data.templates.filter((item) => item.id !== templateId);
    await this.flushPersist();
    this.refreshOpenViews();
    if (template) {
      new import_obsidian4.Notice(`\u5DF2\u5220\u9664\u6A21\u677F\uFF1A${template.name}`);
    }
  }
  async exportCurrentDraft() {
    if (!this.data.draft.title.trim()) {
      new import_obsidian4.Notice("\u8BF7\u5148\u8F93\u5165\u5C01\u9762\u6807\u9898\u3002");
      return null;
    }
    const preset = getCoverPreset(this.data.draft.presetId);
    try {
      const result = await exportCoverAsPng({
        app: this.app,
        draft: this.data.draft,
        settings: this.data.settings
      });
      new import_obsidian4.Notice(`\u5DF2\u5BFC\u51FA ${preset.name} \u5C01\u9762\uFF1A${result.path}`);
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : "\u5BFC\u51FA\u5C01\u9762\u5931\u8D25\u3002";
      new import_obsidian4.Notice(message);
      throw error;
    }
  }
  refreshOpenViews() {
    const leaves = this.app.workspace.getLeavesOfType(COVER_MAKER_VIEW_TYPE);
    for (const leaf of leaves) {
      if (leaf.view instanceof CoverMakerView) {
        leaf.view.refresh();
      }
    }
  }
  async loadPluginData() {
    const raw = await this.loadData();
    this.data = sanitizePluginData(raw);
  }
  applyTitleStyles(start, end, patch) {
    if (start >= end) {
      return;
    }
    this.setDraft(
      {
        titleStyles: applyTitleStyleToRange(
          this.data.draft.title,
          this.data.draft.titleStyles,
          start,
          end,
          patch
        )
      },
      {
        refresh: true,
        persist: true
      }
    );
  }
  schedulePersist() {
    if (this.persistTimer !== null) {
      window.clearTimeout(this.persistTimer);
    }
    this.persistTimer = window.setTimeout(() => {
      void this.flushPersist();
    }, 240);
  }
  async flushPersist() {
    if (this.persistTimer !== null) {
      window.clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }
    await this.saveData(this.data);
  }
  buildTemplateName(inputName) {
    const trimmed = inputName == null ? void 0 : inputName.trim();
    if (trimmed) {
      return trimmed;
    }
    const title = this.data.draft.title.trim();
    if (title) {
      return title.slice(0, 18);
    }
    return `${getCoverPreset(this.data.draft.presetId).name}-${getTypographyPreset(this.data.draft.typographyId).name}`;
  }
};
function cloneTitleStyles(spans) {
  return spans.map((span) => ({ ...span }));
}

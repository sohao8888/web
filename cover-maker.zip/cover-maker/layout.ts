import {
  COVER_HEIGHT,
  COVER_WIDTH,
  type CoverDraft,
  type CoverLayout,
  type CoverPreset,
  type TagRowLayout,
  type TitleGlyphLayout,
  type TitleLineLayout,
} from "./types";
import {
  getLetterSpacingPreset,
  getLineSpacingPreset,
} from "./text-spacing-presets";
import { buildStyledTitleChars } from "./title-style-utils";
import { getTypographyPreset } from "./typography-presets";

const PREVIEW_PLACEHOLDER_TITLE = "Enter your cover title";
const MEASURE_CANVAS = document.createElement("canvas");
const MEASURE_CONTEXT = MEASURE_CANVAS.getContext("2d");

interface MeasuredChip {
  text: string;
  width: number;
  height: number;
}

interface TempChipRow {
  chips: MeasuredChip[];
}

interface TagLayoutResult {
  rows: TagRowLayout[];
  fontSize: number;
  totalHeight: number;
}

interface ResolvedLayoutPreset {
  fontFamily: string;
  textColor: string;
  titleAlign: "left" | "center";
  titleWeight: number;
  titleWidth: number;
  titleFontMax: number;
  titleFontMin: number;
  titleLineHeightScale: number;
  titleLetterSpacingEm: number;
  titleMaxLines: number;
  titleVerticalBias: number;
  titleTop: number;
  sidePadding: number;
  bottomPadding: number;
  tagTop: number;
  tagFontMax: number;
  tagFontMin: number;
  tagMaxRows: number;
  tagGapX: number;
  tagGapY: number;
  tagPaddingX: number;
  tagPaddingY: number;
  tagMaxWidth: number;
  tagAlign: "left" | "center";
}

interface InternalGlyph {
  text: string;
  color: string;
  fontSize: number;
  width: number;
}

interface InternalLine {
  glyphs: InternalGlyph[];
  text: string;
  width: number;
  maxFontSize: number;
  height: number;
}

interface TitleLayoutResult {
  lines: TitleLineLayout[];
  fontSize: number;
  lineHeight: number;
  letterSpacing: number;
  height: number;
}

export function parseTags(tagInput: string): string[] {
  const seen = new Set<string>();
  const tags: string[] = [];

  for (const rawTag of tagInput.split(/[,\n，]+/)) {
    const tag = rawTag.trim();
    if (!tag || seen.has(tag)) {
      continue;
    }

    seen.add(tag);
    tags.push(tag);
  }

  return tags.slice(0, 18);
}

export function computeCoverLayout(
  draft: CoverDraft,
  preset: CoverPreset,
  usePreviewPlaceholder = false,
): CoverLayout {
  const ctx = getMeasureContext();
  const layoutPreset = resolveLayoutPreset(preset, draft);
  const tags = parseTags(draft.tagInput);
  const tagLayout = buildTagLayout(tags, layoutPreset, ctx);
  const titleTop = Math.max(
    layoutPreset.titleTop,
    layoutPreset.tagTop + tagLayout.totalHeight + 64,
  );
  const availableHeight = Math.max(
    260,
    COVER_HEIGHT - layoutPreset.bottomPadding - titleTop,
  );
  const titleText = usePreviewPlaceholder
    ? getPreviewTitle(draft.title)
    : draft.title;
  const titleStyles = usePreviewPlaceholder && !draft.title.trim()
    ? []
    : draft.titleStyles;
  const titleLayout = buildTitleLayout(
    titleText,
    titleStyles,
    layoutPreset,
    titleTop,
    availableHeight,
    ctx,
  );

  return {
    titleText,
    titleLines: titleLayout.lines,
    titleFontSize: titleLayout.fontSize,
    titleLineHeight: titleLayout.lineHeight,
    titleLetterSpacing: titleLayout.letterSpacing,
    titleHeight: titleLayout.height,
    titleWidth: layoutPreset.titleWidth,
    titleAlign: layoutPreset.titleAlign,
    tagRows: tagLayout.rows,
    tagFontSize: tagLayout.fontSize,
    tagAreaHeight: tagLayout.totalHeight,
    tags,
  };
}

function getPreviewTitle(title: string): string {
  return title.trim() || PREVIEW_PLACEHOLDER_TITLE;
}

function getMeasureContext(): CanvasRenderingContext2D {
  if (!MEASURE_CONTEXT) {
    throw new Error("Cover Maker cannot initialize the text measuring canvas.");
  }

  return MEASURE_CONTEXT;
}

function resolveLayoutPreset(
  preset: CoverPreset,
  draft: CoverDraft,
): ResolvedLayoutPreset {
  const typography = getTypographyPreset(draft.typographyId);
  const lineSpacing = getLineSpacingPreset(draft.lineSpacingId);
  const letterSpacing = getLetterSpacingPreset(draft.letterSpacingId);

  return {
    fontFamily: preset.fontFamily,
    textColor: preset.textColor,
    titleAlign: typography.titleAlign,
    titleWeight: preset.titleWeight,
    titleWidth: Math.max(
      420,
      Math.round(preset.titleWidth * typography.titleWidthScale),
    ),
    titleFontMax: Math.max(
      preset.titleFontMin,
      Math.round(preset.titleFontMax * typography.titleFontMaxScale),
    ),
    titleFontMin: Math.max(
      42,
      Math.round(preset.titleFontMin * typography.titleFontMinScale),
    ),
    titleLineHeightScale: typography.titleLineHeightScale * lineSpacing.scale,
    titleLetterSpacingEm: letterSpacing.em,
    titleMaxLines: typography.titleMaxLines,
    titleVerticalBias: typography.titleVerticalBias,
    titleTop: preset.titleTop + typography.titleTopShift,
    sidePadding: Math.max(48, preset.sidePadding + typography.sidePaddingShift),
    bottomPadding: preset.bottomPadding,
    tagTop: Math.max(56, preset.tagTop + typography.tagTopShift),
    tagFontMax: Math.max(
      16,
      Math.round(preset.tagFontMax * typography.tagFontScale),
    ),
    tagFontMin: Math.max(
      14,
      Math.round(preset.tagFontMin * typography.tagFontScale),
    ),
    tagMaxRows: typography.tagMaxRows,
    tagGapX: preset.tagGapX,
    tagGapY: preset.tagGapY,
    tagPaddingX: preset.tagPaddingX,
    tagPaddingY: preset.tagPaddingY,
    tagMaxWidth: Math.max(
      360,
      Math.round(preset.tagMaxWidth * typography.tagWidthScale),
    ),
    tagAlign: typography.tagAlign,
  };
}

function buildTagLayout(
  tags: string[],
  preset: ResolvedLayoutPreset,
  ctx: CanvasRenderingContext2D,
): TagLayoutResult {
  if (tags.length === 0) {
    return {
      rows: [],
      fontSize: preset.tagFontMax,
      totalHeight: 0,
    };
  }

  for (let fontSize = preset.tagFontMax; fontSize >= preset.tagFontMin; fontSize -= 2) {
    const rows = tryLayoutTags(tags, preset, fontSize, ctx);
    if (rows.length <= preset.tagMaxRows) {
      return finalizeTagRows(rows, preset, fontSize);
    }
  }

  return finalizeTagRows(
    tryLayoutTags(tags, preset, preset.tagFontMin, ctx),
    preset,
    preset.tagFontMin,
  );
}

function tryLayoutTags(
  tags: string[],
  preset: ResolvedLayoutPreset,
  fontSize: number,
  ctx: CanvasRenderingContext2D,
): TempChipRow[] {
  ctx.font = `650 ${fontSize}px ${preset.fontFamily}`;
  const chipHeight = fontSize + preset.tagPaddingY * 2;
  const maxTextWidth = Math.max(
    96,
    preset.tagMaxWidth - preset.tagPaddingX * 2 - 10,
  );
  const rows: TempChipRow[] = [];
  let currentRow: TempChipRow = { chips: [] };

  for (let index = 0; index < tags.length; index += 1) {
    const chip = createMeasuredChip(
      tags[index],
      preset,
      chipHeight,
      maxTextWidth,
      ctx,
    );

    if (currentRow.chips.length === 0) {
      currentRow.chips.push(chip);
      continue;
    }

    const nextWidth = getRowWidth(currentRow, preset) + preset.tagGapX + chip.width;
    if (nextWidth <= preset.tagMaxWidth) {
      currentRow.chips.push(chip);
      continue;
    }

    rows.push(currentRow);

    if (rows.length >= preset.tagMaxRows) {
      const hiddenCount = tags.length - index;
      addOverflowChip(rows[rows.length - 1], hiddenCount, preset, chipHeight, ctx);
      return rows;
    }

    currentRow = { chips: [chip] };
  }

  if (currentRow.chips.length > 0) {
    rows.push(currentRow);
  }

  return rows;
}

function createMeasuredChip(
  text: string,
  preset: ResolvedLayoutPreset,
  chipHeight: number,
  maxTextWidth: number,
  ctx: CanvasRenderingContext2D,
): MeasuredChip {
  const clippedText = ellipsizePlainText(text, maxTextWidth, ctx);
  const width = Math.min(
    preset.tagMaxWidth,
    Math.ceil(ctx.measureText(clippedText).width) + preset.tagPaddingX * 2,
  );

  return {
    text: clippedText,
    width,
    height: chipHeight,
  };
}

function addOverflowChip(
  row: TempChipRow,
  hiddenCount: number,
  preset: ResolvedLayoutPreset,
  chipHeight: number,
  ctx: CanvasRenderingContext2D,
): void {
  let hidden = hiddenCount;
  let overflowChip = createMeasuredChip(
    `+${hidden}`,
    preset,
    chipHeight,
    preset.tagMaxWidth,
    ctx,
  );

  while (
    row.chips.length > 0 &&
    getRowWidth(row, preset) + preset.tagGapX + overflowChip.width > preset.tagMaxWidth
  ) {
    row.chips.pop();
    hidden += 1;
    overflowChip = createMeasuredChip(
      `+${hidden}`,
      preset,
      chipHeight,
      preset.tagMaxWidth,
      ctx,
    );
  }

  row.chips.push(overflowChip);
}

function finalizeTagRows(
  rows: TempChipRow[],
  preset: ResolvedLayoutPreset,
  fontSize: number,
): TagLayoutResult {
  const finalizedRows: TagRowLayout[] = rows
    .slice(0, preset.tagMaxRows)
    .map((row, rowIndex) => {
      const rowWidth = getRowWidth(row, preset);
      const startX = preset.tagAlign === "center"
        ? Math.max(preset.sidePadding, Math.round((COVER_WIDTH - rowWidth) / 2))
        : preset.sidePadding;
      const y =
        preset.tagTop + rowIndex * (fontSize + preset.tagPaddingY * 2 + preset.tagGapY);
      let currentX = startX;

      const chips = row.chips.map((chip, chipIndex) => {
        if (chipIndex > 0) {
          currentX += preset.tagGapX;
        }

        const layoutChip = {
          text: chip.text,
          x: currentX,
          y,
          width: chip.width,
          height: chip.height,
        };

        currentX += chip.width;
        return layoutChip;
      });

      return {
        chips,
        width: rowWidth,
        y,
        height: fontSize + preset.tagPaddingY * 2,
      };
    });

  const totalHeight = finalizedRows.length
    ? finalizedRows[finalizedRows.length - 1].y +
        finalizedRows[finalizedRows.length - 1].height -
        preset.tagTop
    : 0;

  return {
    rows: finalizedRows,
    fontSize,
    totalHeight,
  };
}

function getRowWidth(row: TempChipRow, preset: ResolvedLayoutPreset): number {
  return row.chips.reduce((total, chip) => total + chip.width, 0) +
    Math.max(0, row.chips.length - 1) * preset.tagGapX;
}

function buildTitleLayout(
  title: string,
  titleStyles: CoverDraft["titleStyles"],
  preset: ResolvedLayoutPreset,
  titleTop: number,
  availableHeight: number,
  ctx: CanvasRenderingContext2D,
): TitleLayoutResult {
  const minimumFontSize = Math.max(32, Math.round(preset.titleFontMin * 0.72));

  for (let fontSize = preset.titleFontMax; fontSize >= minimumFontSize; fontSize -= 4) {
    const letterSpacing = fontSize * preset.titleLetterSpacingEm;
    const rawLines = wrapStyledTitle(
      title,
      titleStyles,
      preset,
      fontSize,
      letterSpacing,
      ctx,
    );
    const clippedLines = clipStyledLines(
      rawLines,
      preset,
      fontSize,
      letterSpacing,
      ctx,
    );
    const totalHeight = clippedLines.reduce((sum, line) => sum + line.height, 0);

    if (
      clippedLines.length <= preset.titleMaxLines &&
      totalHeight <= availableHeight &&
      clippedLines.length > 0
    ) {
      return {
        lines: placeTitleLines(
          clippedLines,
          preset,
          titleTop,
          availableHeight,
          totalHeight,
          letterSpacing,
        ),
        fontSize,
        lineHeight: clippedLines[0].height,
        letterSpacing,
        height: totalHeight,
      };
    }
  }

  const fallbackFontSize = minimumFontSize;
  const letterSpacing = fallbackFontSize * preset.titleLetterSpacingEm;
  const rawLines = wrapStyledTitle(
    title,
    titleStyles,
    preset,
    fallbackFontSize,
    letterSpacing,
    ctx,
  );
  const clippedLines = clipStyledLines(
    rawLines,
    preset,
    fallbackFontSize,
    letterSpacing,
    ctx,
  );
  const totalHeight = clippedLines.reduce((sum, line) => sum + line.height, 0);

  return {
    lines: placeTitleLines(
      clippedLines,
      preset,
      titleTop,
      availableHeight,
      totalHeight,
      letterSpacing,
    ),
    fontSize: fallbackFontSize,
    lineHeight: clippedLines[0]?.height ?? Math.round(fallbackFontSize * 1.1),
    letterSpacing,
    height: totalHeight,
  };
}

function wrapStyledTitle(
  title: string,
  titleStyles: CoverDraft["titleStyles"],
  preset: ResolvedLayoutPreset,
  baseFontSize: number,
  letterSpacing: number,
  ctx: CanvasRenderingContext2D,
): InternalLine[] {
  const styledChars = buildStyledTitleChars(title, titleStyles);
  const lines: InternalLine[] = [];
  let currentLine = createEmptyLine();

  const pushLine = (): void => {
    const finalized = finalizeInternalLine(
      currentLine,
      letterSpacing,
      preset.titleLineHeightScale,
    );
    if (finalized) {
      lines.push(finalized);
    }

    currentLine = createEmptyLine();
  };

  for (const styledChar of styledChars) {
    if (styledChar.char === "\n") {
      pushLine();
      continue;
    }

    const isWhitespace = /\s/.test(styledChar.char);
    if (currentLine.glyphs.length === 0 && isWhitespace) {
      continue;
    }

    const glyph = createGlyph(
      styledChar.char,
      styledChar.color ?? preset.textColor,
      baseFontSize * styledChar.sizeScale,
      preset.fontFamily,
      preset.titleWeight,
      ctx,
    );

    const nextWidth =
      currentLine.width +
      (currentLine.glyphs.length > 0 ? letterSpacing : 0) +
      glyph.width;

    if (currentLine.glyphs.length > 0 && nextWidth > preset.titleWidth && !isWhitespace) {
      pushLine();
    }

    if (currentLine.glyphs.length === 0 && isWhitespace) {
      continue;
    }

    currentLine.glyphs.push(glyph);
    currentLine.width = calculateLineWidth(currentLine.glyphs, letterSpacing);
    currentLine.maxFontSize = Math.max(currentLine.maxFontSize, glyph.fontSize);
  }

  pushLine();
  return lines;
}

function clipStyledLines(
  lines: InternalLine[],
  preset: ResolvedLayoutPreset,
  baseFontSize: number,
  letterSpacing: number,
  ctx: CanvasRenderingContext2D,
): InternalLine[] {
  if (lines.length <= preset.titleMaxLines) {
    return lines;
  }

  const visibleLines = lines.slice(0, preset.titleMaxLines - 1);
  const overflowGlyphs = trimLeadingWhitespace(
    lines.slice(preset.titleMaxLines - 1).flatMap((line) => line.glyphs),
  );
  const ellipsis = createGlyph(
    "…",
    preset.textColor,
    baseFontSize,
    preset.fontFamily,
    preset.titleWeight,
    ctx,
  );
  const trimmedGlyphs: InternalGlyph[] = [];

  for (const glyph of overflowGlyphs) {
    const candidate = [...trimmedGlyphs, glyph];
    const widthWithEllipsis =
      calculateLineWidth(candidate, letterSpacing) +
      (candidate.length > 0 ? letterSpacing : 0) +
      ellipsis.width;

    if (widthWithEllipsis > preset.titleWidth && trimmedGlyphs.length > 0) {
      break;
    }

    trimmedGlyphs.push(glyph);
  }

  while (
    trimmedGlyphs.length > 0 &&
    calculateLineWidth(trimmedGlyphs, letterSpacing) +
      (trimmedGlyphs.length > 0 ? letterSpacing : 0) +
      ellipsis.width >
      preset.titleWidth
  ) {
    trimmedGlyphs.pop();
  }

  const clippedGlyphs = trimTrailingWhitespace([...trimmedGlyphs]);
  clippedGlyphs.push(ellipsis);

  const clippedLine = finalizeInternalLine(
    {
      glyphs: clippedGlyphs,
      text: "",
      width: 0,
      maxFontSize: 0,
      height: 0,
    },
    letterSpacing,
    preset.titleLineHeightScale,
  );

  if (!clippedLine) {
    return visibleLines;
  }

  return [...visibleLines, clippedLine];
}

function placeTitleLines(
  lines: InternalLine[],
  preset: ResolvedLayoutPreset,
  titleTop: number,
  availableHeight: number,
  totalHeight: number,
  letterSpacing: number,
): TitleLineLayout[] {
  let currentY =
    titleTop +
    Math.max(0, Math.round((availableHeight - totalHeight) * preset.titleVerticalBias));

  return lines.map((line) => {
    const startX = preset.titleAlign === "center"
      ? Math.round((COVER_WIDTH - line.width) / 2)
      : preset.sidePadding;
    let currentX = startX;
    const glyphs: TitleGlyphLayout[] = line.glyphs.map((glyph, index) => {
      if (index > 0) {
        currentX += letterSpacing;
      }

      const placed: TitleGlyphLayout = {
        text: glyph.text,
        x: currentX,
        y: currentY + Math.round((line.maxFontSize - glyph.fontSize) * 0.72),
        width: glyph.width,
        color: glyph.color,
        fontSize: glyph.fontSize,
      };

      currentX += glyph.width;
      return placed;
    });

    const placedLine: TitleLineLayout = {
      text: line.text,
      width: line.width,
      height: line.height,
      maxFontSize: line.maxFontSize,
      glyphs,
    };

    currentY += line.height;
    return placedLine;
  });
}

function createGlyph(
  text: string,
  color: string,
  fontSize: number,
  fontFamily: string,
  fontWeight: number,
  ctx: CanvasRenderingContext2D,
): InternalGlyph {
  ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;

  return {
    text,
    color,
    fontSize,
    width: ctx.measureText(text).width,
  };
}

function createEmptyLine(): InternalLine {
  return {
    glyphs: [],
    text: "",
    width: 0,
    maxFontSize: 0,
    height: 0,
  };
}

function finalizeInternalLine(
  line: InternalLine,
  letterSpacing: number,
  lineHeightScale: number,
): InternalLine | null {
  const glyphs = trimTrailingWhitespace([...line.glyphs]);
  if (glyphs.length === 0) {
    return null;
  }

  const maxFontSize = glyphs.reduce(
    (max, glyph) => Math.max(max, glyph.fontSize),
    0,
  );

  return {
    glyphs,
    text: glyphs.map((glyph) => glyph.text).join(""),
    width: calculateLineWidth(glyphs, letterSpacing),
    maxFontSize,
    height: Math.round(
      maxFontSize * getTitleLineHeightRatio(maxFontSize, lineHeightScale),
    ),
  };
}

function trimLeadingWhitespace(glyphs: InternalGlyph[]): InternalGlyph[] {
  while (glyphs.length > 0 && /^\s$/.test(glyphs[0].text)) {
    glyphs.shift();
  }

  return glyphs;
}

function trimTrailingWhitespace(glyphs: InternalGlyph[]): InternalGlyph[] {
  while (glyphs.length > 0 && /^\s$/.test(glyphs[glyphs.length - 1].text)) {
    glyphs.pop();
  }

  return glyphs;
}

function calculateLineWidth(glyphs: InternalGlyph[], letterSpacing: number): number {
  return glyphs.reduce((total, glyph) => total + glyph.width, 0) +
    Math.max(0, glyphs.length - 1) * letterSpacing;
}

function ellipsizePlainText(
  text: string,
  maxWidth: number,
  ctx: CanvasRenderingContext2D,
): string {
  if (ctx.measureText(text).width <= maxWidth) {
    return text;
  }

  const ellipsis = "…";
  let result = "";

  for (const char of Array.from(text)) {
    const candidate = `${result}${char}`;
    if (ctx.measureText(`${candidate}${ellipsis}`).width > maxWidth) {
      break;
    }

    result = candidate;
  }

  return result ? `${result}${ellipsis}` : ellipsis;
}

function getTitleLineHeightRatio(fontSize: number, scale: number): number {
  let base = 1.16;

  if (fontSize >= 108) {
    base = 1.08;
  } else if (fontSize >= 84) {
    base = 1.12;
  }

  return base * scale;
}

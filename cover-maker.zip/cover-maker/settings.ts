import { App, PluginSettingTab, Setting, normalizePath } from "obsidian";
import type CoverMakerPlugin from "./main";
import { isCoverPresetId } from "./presets";
import {
  isLetterSpacingPresetId,
  isLineSpacingPresetId,
} from "./text-spacing-presets";
import { normalizeTitleStyleSpans } from "./title-style-utils";
import { isTypographyPresetId } from "./typography-presets";
import type {
  CoverDraft,
  CoverMakerData,
  CoverMakerSettings,
  CoverTemplate,
  TitleStyleSpan,
} from "./types";

export const DEFAULT_SETTINGS: CoverMakerSettings = {
  exportFolder: "Cover Maker Exports",
};

export const DEFAULT_DRAFT: CoverDraft = {
  title: "AI 时代的第二增长曲线",
  tagInput: "AI 商业,知识 IP,视频号封面",
  presetId: "tech",
  typographyId: "balanced",
  lineSpacingId: "standard",
  letterSpacingId: "normal",
  titleStyles: [],
};

export function createDefaultData(): CoverMakerData {
  return {
    draft: { ...DEFAULT_DRAFT },
    templates: [],
    settings: { ...DEFAULT_SETTINGS },
  };
}

export function sanitizePluginData(raw: unknown): CoverMakerData {
  const value = raw as Partial<CoverMakerData> | null | undefined;
  const defaults = createDefaultData();

  return {
    draft: sanitizeDraft(value?.draft, defaults.draft),
    templates: sanitizeTemplates(value?.templates),
    settings: sanitizeSettings(value?.settings, defaults.settings),
  };
}

function sanitizeDraft(
  raw: Partial<CoverDraft> | null | undefined,
  fallback: CoverDraft,
): CoverDraft {
  const title = typeof raw?.title === "string" ? raw.title : fallback.title;
  const presetId = typeof raw?.presetId === "string" && isCoverPresetId(raw.presetId)
    ? raw.presetId
    : fallback.presetId;
  const typographyId =
    typeof raw?.typographyId === "string" && isTypographyPresetId(raw.typographyId)
      ? raw.typographyId
      : fallback.typographyId;
  const lineSpacingId =
    typeof raw?.lineSpacingId === "string" && isLineSpacingPresetId(raw.lineSpacingId)
      ? raw.lineSpacingId
      : fallback.lineSpacingId;
  const letterSpacingId =
    typeof raw?.letterSpacingId === "string" && isLetterSpacingPresetId(raw.letterSpacingId)
      ? raw.letterSpacingId
      : fallback.letterSpacingId;

  return {
    title,
    tagInput: typeof raw?.tagInput === "string" ? raw.tagInput : fallback.tagInput,
    presetId,
    typographyId,
    lineSpacingId,
    letterSpacingId,
    titleStyles: sanitizeTitleStyles(title, raw?.titleStyles),
  };
}

function sanitizeTemplates(raw: unknown): CoverTemplate[] {
  if (!Array.isArray(raw)) {
    return [];
  }

  return raw
    .map((item) => sanitizeTemplate(item as Partial<CoverTemplate> | null | undefined))
    .filter((template): template is CoverTemplate => Boolean(template))
    .sort((left, right) => right.updatedAt - left.updatedAt);
}

function sanitizeTemplate(
  raw: Partial<CoverTemplate> | null | undefined,
): CoverTemplate | null {
  if (!raw || typeof raw !== "object") {
    return null;
  }

  const title = typeof raw.title === "string" ? raw.title : "";
  const presetId = typeof raw.presetId === "string" && isCoverPresetId(raw.presetId)
    ? raw.presetId
    : DEFAULT_DRAFT.presetId;
  const typographyId =
    typeof raw.typographyId === "string" && isTypographyPresetId(raw.typographyId)
      ? raw.typographyId
      : DEFAULT_DRAFT.typographyId;
  const lineSpacingId =
    typeof raw.lineSpacingId === "string" && isLineSpacingPresetId(raw.lineSpacingId)
      ? raw.lineSpacingId
      : DEFAULT_DRAFT.lineSpacingId;
  const letterSpacingId =
    typeof raw.letterSpacingId === "string" && isLetterSpacingPresetId(raw.letterSpacingId)
      ? raw.letterSpacingId
      : DEFAULT_DRAFT.letterSpacingId;
  const name = typeof raw.name === "string" ? raw.name.trim() : "";

  if (!name) {
    return null;
  }

  const createdAt = typeof raw.createdAt === "number" ? raw.createdAt : Date.now();
  const updatedAt = typeof raw.updatedAt === "number" ? raw.updatedAt : createdAt;

  return {
    id: typeof raw.id === "string" && raw.id ? raw.id : `template-${createdAt}`,
    name,
    title,
    tagInput: typeof raw.tagInput === "string" ? raw.tagInput : "",
    presetId,
    typographyId,
    lineSpacingId,
    letterSpacingId,
    titleStyles: sanitizeTitleStyles(title, raw.titleStyles),
    createdAt,
    updatedAt,
  };
}

function sanitizeTitleStyles(title: string, raw: unknown): TitleStyleSpan[] {
  if (!Array.isArray(raw)) {
    return [];
  }

  const spans = raw
    .map((item) => sanitizeTitleStyleSpan(item))
    .filter((item): item is TitleStyleSpan => Boolean(item));

  return normalizeTitleStyleSpans(title, spans);
}

function sanitizeTitleStyleSpan(raw: unknown): TitleStyleSpan | null {
  if (!raw || typeof raw !== "object") {
    return null;
  }

  const span = raw as Partial<TitleStyleSpan>;
  if (typeof span.start !== "number" || typeof span.end !== "number") {
    return null;
  }

  const result: TitleStyleSpan = {
    start: span.start,
    end: span.end,
  };

  if (typeof span.color === "string" && span.color.trim()) {
    result.color = span.color.trim();
  }

  if (typeof span.sizeScale === "number" && Number.isFinite(span.sizeScale)) {
    result.sizeScale = span.sizeScale;
  }

  return result;
}

function sanitizeSettings(
  raw: Partial<CoverMakerSettings> | null | undefined,
  fallback: CoverMakerSettings,
): CoverMakerSettings {
  return {
    exportFolder: normalizeExportFolder(raw?.exportFolder ?? fallback.exportFolder),
  };
}

export function normalizeExportFolder(value: string): string {
  const trimmed = value.trim().replace(/^\/+|\/+$/g, "");
  return trimmed ? normalizePath(trimmed) : DEFAULT_SETTINGS.exportFolder;
}

export class CoverMakerSettingTab extends PluginSettingTab {
  plugin: CoverMakerPlugin;

  constructor(app: App, plugin: CoverMakerPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl("h2", { text: "Cover Maker封面" });
    containerEl.createEl("p", {
      text: "封面导出默认写入当前库中的指定文件夹。因为 Obsidian 官方 API 没有统一的系统另存为对话框，这里优先采用库内导出路径。",
      cls: "cm-settings-note",
    });

    new Setting(containerEl)
      .setName("PNG 导出目录")
      .setDesc("相对当前 Vault 的文件夹路径，例如 Cover Maker Exports/AI Covers")
      .addText((text) => {
        text
          .setPlaceholder(DEFAULT_SETTINGS.exportFolder)
          .setValue(this.plugin.settings.exportFolder)
          .onChange(async (value) => {
            await this.plugin.updateSettings({
              exportFolder: normalizeExportFolder(value),
            });
          });
      });
  }
}

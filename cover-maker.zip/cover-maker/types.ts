import type { App } from "obsidian";

export const COVER_WIDTH = 900;
export const COVER_HEIGHT = 1200;

export type CoverPresetId =
  | "minimal"
  | "tech"
  | "knowledge"
  | "business"
  | "magazine";

export type TypographyPresetId =
  | "balanced"
  | "impact"
  | "airy"
  | "centered"
  | "compact";

export type LineSpacingPresetId =
  | "tight"
  | "standard"
  | "comfortable"
  | "relaxed"
  | "poster";

export type LetterSpacingPresetId =
  | "compact"
  | "normal"
  | "open"
  | "wide"
  | "headline";

export interface TitleStyleSpan {
  start: number;
  end: number;
  color?: string;
  sizeScale?: number;
}

export interface CoverDraft {
  title: string;
  tagInput: string;
  presetId: CoverPresetId;
  typographyId: TypographyPresetId;
  lineSpacingId: LineSpacingPresetId;
  letterSpacingId: LetterSpacingPresetId;
  titleStyles: TitleStyleSpan[];
}

export interface CoverTemplate {
  id: string;
  name: string;
  title: string;
  tagInput: string;
  presetId: CoverPresetId;
  typographyId: TypographyPresetId;
  lineSpacingId: LineSpacingPresetId;
  letterSpacingId: LetterSpacingPresetId;
  titleStyles: TitleStyleSpan[];
  createdAt: number;
  updatedAt: number;
}

export interface CoverMakerSettings {
  exportFolder: string;
}

export interface CoverMakerData {
  draft: CoverDraft;
  templates: CoverTemplate[];
  settings: CoverMakerSettings;
}

export interface CoverPreset {
  id: CoverPresetId;
  name: string;
  description: string;
  fontFamily: string;
  titleAlign: "left" | "center";
  titleWeight: number;
  titleWidth: number;
  titleFontMax: number;
  titleFontMin: number;
  titleMaxLines: number;
  titleVerticalBias: number;
  titleTop: number;
  topPadding: number;
  sidePadding: number;
  bottomPadding: number;
  tagTop: number;
  tagFontMax: number;
  tagFontMin: number;
  tagMaxRows: number;
  tagGapX: number;
  tagGapY: number;
  tagPaddingX: number;
  tagPaddingY: number;
  tagMaxWidth: number;
  tagAlign: "left" | "center";
  background: [string, string, string];
  textColor: string;
  accentColor: string;
  accentSoft: string;
  accentMuted: string;
  tagBackground: string;
  tagTextColor: string;
  tagBorderColor: string;
  shadowColor: string;
}

export interface TypographyPreset {
  id: TypographyPresetId;
  name: string;
  titleAlign: "left" | "center";
  titleWidthScale: number;
  titleFontMaxScale: number;
  titleFontMinScale: number;
  titleLineHeightScale: number;
  titleMaxLines: number;
  titleVerticalBias: number;
  titleTopShift: number;
  sidePaddingShift: number;
  tagTopShift: number;
  tagAlign: "left" | "center";
  tagWidthScale: number;
  tagFontScale: number;
  tagMaxRows: number;
}

export interface LineSpacingPreset {
  id: LineSpacingPresetId;
  name: string;
  scale: number;
}

export interface LetterSpacingPreset {
  id: LetterSpacingPresetId;
  name: string;
  em: number;
}

export interface TitleLineLayout {
  text: string;
  width: number;
  height: number;
  maxFontSize: number;
  glyphs: TitleGlyphLayout[];
}

export interface TitleGlyphLayout {
  text: string;
  x: number;
  y: number;
  width: number;
  color: string;
  fontSize: number;
}

export interface TagChipLayout {
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface TagRowLayout {
  chips: TagChipLayout[];
  width: number;
  y: number;
  height: number;
}

export interface CoverLayout {
  titleText: string;
  titleLines: TitleLineLayout[];
  titleFontSize: number;
  titleLineHeight: number;
  titleLetterSpacing: number;
  titleHeight: number;
  titleWidth: number;
  titleAlign: "left" | "center";
  tagRows: TagRowLayout[];
  tagFontSize: number;
  tagAreaHeight: number;
  tags: string[];
}

export interface ExportCoverOptions {
  app: App;
  draft: CoverDraft;
  settings: CoverMakerSettings;
}

export interface ExportCoverResult {
  path: string;
  filename: string;
}

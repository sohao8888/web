import type { TitleStyleSpan } from "./types";

export interface StyledTitleChar {
  char: string;
  color?: string;
  sizeScale: number;
}

interface MutableCharStyle {
  color?: string;
  sizeScale?: number;
}

interface TitleStylePatch {
  color?: string | null;
  sizeScale?: number | null;
}

export function buildStyledTitleChars(
  title: string,
  spans: TitleStyleSpan[],
): StyledTitleChar[] {
  const styles = expandTitleStyles(title, spans);

  return Array.from(title).map((char, index) => ({
    char,
    color: styles[index]?.color,
    sizeScale: styles[index]?.sizeScale ?? 1,
  }));
}

export function normalizeTitleStyleSpans(
  title: string,
  spans: TitleStyleSpan[],
): TitleStyleSpan[] {
  return compressTitleStyles(expandTitleStyles(title, spans));
}

export function applyTitleStyleToRange(
  title: string,
  spans: TitleStyleSpan[],
  start: number,
  end: number,
  patch: TitleStylePatch,
): TitleStyleSpan[] {
  if (start >= end) {
    return normalizeTitleStyleSpans(title, spans);
  }

  const styles = expandTitleStyles(title, spans);

  for (let index = start; index < end && index < styles.length; index += 1) {
    if (patch.color !== undefined) {
      if (patch.color === null) {
        delete styles[index].color;
      } else {
        styles[index].color = normalizeColor(patch.color);
      }
    }

    if (patch.sizeScale !== undefined) {
      if (patch.sizeScale === null || patch.sizeScale === 1) {
        delete styles[index].sizeScale;
      } else {
        styles[index].sizeScale = patch.sizeScale;
      }
    }
  }

  return compressTitleStyles(styles);
}

export function clearTitleStyleRange(
  title: string,
  spans: TitleStyleSpan[],
  start: number,
  end: number,
): TitleStyleSpan[] {
  return applyTitleStyleToRange(title, spans, start, end, {
    color: null,
    sizeScale: null,
  });
}

export function remapTitleStyleSpans(
  previousTitle: string,
  nextTitle: string,
  spans: TitleStyleSpan[],
): TitleStyleSpan[] {
  if (previousTitle === nextTitle) {
    return normalizeTitleStyleSpans(nextTitle, spans);
  }

  const previousStyles = expandTitleStyles(previousTitle, spans);
  const nextStyles: MutableCharStyle[] = Array.from({ length: nextTitle.length }, () => ({}));

  let prefix = 0;
  while (
    prefix < previousTitle.length &&
    prefix < nextTitle.length &&
    previousTitle[prefix] === nextTitle[prefix]
  ) {
    nextStyles[prefix] = { ...previousStyles[prefix] };
    prefix += 1;
  }

  let previousSuffix = previousTitle.length - 1;
  let nextSuffix = nextTitle.length - 1;
  while (
    previousSuffix >= prefix &&
    nextSuffix >= prefix &&
    previousTitle[previousSuffix] === nextTitle[nextSuffix]
  ) {
    nextStyles[nextSuffix] = { ...previousStyles[previousSuffix] };
    previousSuffix -= 1;
    nextSuffix -= 1;
  }

  return compressTitleStyles(nextStyles);
}

function expandTitleStyles(
  title: string,
  spans: TitleStyleSpan[],
): MutableCharStyle[] {
  const length = title.length;
  const styles: MutableCharStyle[] = Array.from({ length }, () => ({}));

  for (const span of spans) {
    const start = clamp(span.start, 0, length);
    const end = clamp(span.end, 0, length);
    if (start >= end) {
      continue;
    }

    for (let index = start; index < end; index += 1) {
      if (span.color) {
        styles[index].color = normalizeColor(span.color);
      }

      if (span.sizeScale && span.sizeScale !== 1) {
        styles[index].sizeScale = span.sizeScale;
      }
    }
  }

  return styles;
}

function compressTitleStyles(styles: MutableCharStyle[]): TitleStyleSpan[] {
  const spans: TitleStyleSpan[] = [];
  let currentStart = -1;
  let currentStyle: MutableCharStyle | null = null;

  const flush = (end: number): void => {
    if (currentStart === -1 || !currentStyle) {
      return;
    }

    spans.push({
      start: currentStart,
      end,
      color: currentStyle.color,
      sizeScale: currentStyle.sizeScale,
    });
    currentStart = -1;
    currentStyle = null;
  };

  for (let index = 0; index < styles.length; index += 1) {
    const style = styles[index];
    if (!style.color && !style.sizeScale) {
      flush(index);
      continue;
    }

    if (currentStart === -1) {
      currentStart = index;
      currentStyle = { ...style };
      continue;
    }

    if (isSameStyle(currentStyle, style)) {
      continue;
    }

    flush(index);
    currentStart = index;
    currentStyle = { ...style };
  }

  flush(styles.length);
  return spans;
}

function isSameStyle(
  left: MutableCharStyle | null,
  right: MutableCharStyle,
): boolean {
  return left?.color === right.color && left?.sizeScale === right.sizeScale;
}

function normalizeColor(value: string): string {
  return value.trim() || "#111111";
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

# Cover Maker封面

Cover Maker封面 是一个本地优先的 Obsidian 插件，用来快速生成适合视频号和公众号图文封面的竖版图片。

## 功能

- 固定输出 `900×1200` PNG
- 右侧栏实时编辑和预览
- 标题自动换行并动态调整字号
- 标签支持逗号分隔、多行自动换行
- 内置 5 种风格预设
- 支持保存和复用常用模板
- 纯本地导出，无需后端服务

## 目录结构

```text
cover-maker/
├─ main.js
├─ main.ts
├─ view.ts
├─ layout.ts
├─ presets.ts
├─ exporter.ts
├─ settings.ts
├─ types.ts
├─ styles.css
├─ manifest.json
├─ package.json
├─ tsconfig.json
├─ esbuild.config.mjs
├─ version-bump.mjs
├─ versions.json
└─ README.md
```

## 安装

1. 把整个目录放到你的 Vault 下的 [`.obsidian/plugins/cover-maker`](/F:/AI/.obsidian/plugins/cover-maker)。
2. 在该目录运行 `npm install`。
3. 运行 `npm run build` 生成 `main.js`。
4. 打开 Obsidian，进入“第三方插件”，启用 `Cover Maker封面`。

## 本地开发

1. 进入插件目录：`cd .obsidian/plugins/cover-maker`
2. 安装依赖：`npm install`
3. 开发监听：`npm run dev`
4. 在 Obsidian 里重新加载插件即可查看改动

## 使用方式

1. 点击左侧功能区图标，或运行命令“打开 Cover Maker 侧栏”
2. 在右侧栏输入标题、标签并选择风格
3. 预览区会以 900×1200 比例实时更新
4. 点击“导出 PNG”后，文件会写入插件设置里的导出目录
5. 如果要复用当前组合，可以输入模板名并保存

## 已知限制

- 当前版本导出到 Vault 内部文件夹，不弹出系统“另存为”窗口。这是因为 Obsidian 官方插件 API 没有统一的跨平台系统保存对话框。
- 预览基于 DOM，导出基于 Canvas，同一排版引擎驱动，视觉会高度一致，但极个别阴影和渐变细节可能存在轻微差异。
- 为了保证右侧栏体验和 PNG 导出路径稳定，`manifest.json` 默认设置为桌面端插件。

## 后续可扩展方向

- 支持上传背景图和局部蒙版
- 根据标题关键词自动推荐配色
- 从当前笔记标题或 frontmatter 自动提取内容
- 批量生成多套封面变体
- 增加品牌角标、栏目名、副标题等模块

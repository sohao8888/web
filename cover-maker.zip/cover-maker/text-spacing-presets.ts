import type {
  LetterSpacingPreset,
  LetterSpacingPresetId,
  LineSpacingPreset,
  LineSpacingPresetId,
} from "./types";

export const LINE_SPACING_PRESETS: LineSpacingPreset[] = [
  { id: "tight", name: "紧凑", scale: 0.92 },
  { id: "standard", name: "标准", scale: 1 },
  { id: "comfortable", name: "舒适", scale: 1.08 },
  { id: "relaxed", name: "宽松", scale: 1.16 },
  { id: "poster", name: "海报", scale: 1.24 },
];

export const LETTER_SPACING_PRESETS: LetterSpacingPreset[] = [
  { id: "compact", name: "紧密", em: -0.03 },
  { id: "normal", name: "标准", em: 0 },
  { id: "open", name: "轻展", em: 0.02 },
  { id: "wide", name: "舒展", em: 0.04 },
  { id: "headline", name: "标题感", em: 0.07 },
];

const LINE_SPACING_LOOKUP = new Map<LineSpacingPresetId, LineSpacingPreset>(
  LINE_SPACING_PRESETS.map((preset) => [preset.id, preset]),
);

const LETTER_SPACING_LOOKUP = new Map<LetterSpacingPresetId, LetterSpacingPreset>(
  LETTER_SPACING_PRESETS.map((preset) => [preset.id, preset]),
);

export function getLineSpacingPreset(id: LineSpacingPresetId): LineSpacingPreset {
  return LINE_SPACING_LOOKUP.get(id) ?? LINE_SPACING_PRESETS[1];
}

export function getLetterSpacingPreset(id: LetterSpacingPresetId): LetterSpacingPreset {
  return LETTER_SPACING_LOOKUP.get(id) ?? LETTER_SPACING_PRESETS[1];
}

export function isLineSpacingPresetId(value: string): value is LineSpacingPresetId {
  return LINE_SPACING_LOOKUP.has(value as LineSpacingPresetId);
}

export function isLetterSpacingPresetId(value: string): value is LetterSpacingPresetId {
  return LETTER_SPACING_LOOKUP.has(value as LetterSpacingPresetId);
}

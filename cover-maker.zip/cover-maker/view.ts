import { ItemView, Notice, WorkspaceLeaf } from "obsidian";
import { computeCoverLayout } from "./layout";
import { COVER_PRESETS, getCoverPreset } from "./presets";
import {
  getLetterSpacingPreset,
  getLineSpacingPreset,
  LETTER_SPACING_PRESETS,
  LINE_SPACING_PRESETS,
} from "./text-spacing-presets";
import { getTypographyPreset, TYPOGRAPHY_PRESETS } from "./typography-presets";
import type CoverMakerPlugin from "./main";
import { COVER_HEIGHT, COVER_WIDTH } from "./types";

const TITLE_COLOR_SWATCHES = [
  "#111827",
  "#0f766e",
  "#2563eb",
  "#7c3aed",
  "#c2410c",
  "#dc2626",
];

const TITLE_SIZE_PRESETS = [
  { id: "sm", name: "偏小", scale: 0.88 },
  { id: "base", name: "默认", scale: 1 },
  { id: "md", name: "偏大", scale: 1.14 },
  { id: "lg", name: "大字", scale: 1.3 },
  { id: "xl", name: "强调", scale: 1.48 },
];

export const COVER_MAKER_VIEW_TYPE = "cover-maker-view";

export class CoverMakerView extends ItemView {
  plugin: CoverMakerPlugin;
  private titleInput!: HTMLTextAreaElement;
  private tagInput!: HTMLTextAreaElement;
  private presetGrid!: HTMLDivElement;
  private typographyGrid!: HTMLDivElement;
  private lineSpacingGrid!: HTMLDivElement;
  private letterSpacingGrid!: HTMLDivElement;
  private selectionInfoEl!: HTMLDivElement;
  private customColorInput!: HTMLInputElement;
  private previewShell!: HTMLDivElement;
  private previewStage!: HTMLDivElement;
  private templateNameInput!: HTMLInputElement;
  private templateList!: HTMLDivElement;
  private statusEl!: HTMLDivElement;
  private resizeObserver: ResizeObserver | null = null;

  constructor(leaf: WorkspaceLeaf, plugin: CoverMakerPlugin) {
    super(leaf);
    this.plugin = plugin;
  }

  getViewType(): string {
    return COVER_MAKER_VIEW_TYPE;
  }

  getDisplayText(): string {
    return "Cover Maker封面";
  }

  getIcon(): string {
    return "image-file";
  }

  async onOpen(): Promise<void> {
    this.buildView();
    this.refresh();
    this.attachResizeObserver();
  }

  async onClose(): Promise<void> {
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
  }

  refresh(): void {
    this.syncInputsFromState();
    this.renderPresetGrid();
    this.renderTypographyGrid();
    this.renderLineSpacingGrid();
    this.renderLetterSpacingGrid();
    this.renderTemplateList();
    this.renderSelectionInfo();
    this.renderPreview();
    this.statusEl.setText(`导出目录：${this.plugin.settings.exportFolder}`);
  }

  private buildView(): void {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("cm-view-root");

    const root = contentEl.createDiv({ cls: "cm-view" });
    const header = root.createDiv({ cls: "cm-panel-header" });
    header.createEl("h2", {
      text: "Cover Maker封面",
      cls: "cm-panel-title",
    });
    header.createEl("p", {
      text: "为视频号和公众号图文快速生成 900×1200 的竖版知识封面。",
      cls: "cm-panel-subtitle",
    });

    const titleField = root.createDiv({ cls: "cm-section" });
    titleField.createEl("label", { text: "封面标题", cls: "cm-field-label" });
    this.titleInput = titleField.createEl("textarea", {
      cls: "cm-textarea cm-title-input",
      attr: {
        rows: "4",
        placeholder: "输入主标题，预览会立即更新",
      },
    });
    this.titleInput.addEventListener("input", () => {
      this.plugin.updateTitle(this.titleInput.value, { refresh: false });
      this.renderSelectionInfo();
      this.renderPreview();
    });
    this.titleInput.addEventListener("select", () => this.renderSelectionInfo());
    this.titleInput.addEventListener("keyup", () => this.renderSelectionInfo());
    this.titleInput.addEventListener("mouseup", () => this.renderSelectionInfo());

    const styleEditor = root.createDiv({ cls: "cm-section" });
    styleEditor.createEl("label", { text: "标题局部样式", cls: "cm-field-label" });
    this.selectionInfoEl = styleEditor.createDiv({ cls: "cm-selection-note" });

    const colorWrap = styleEditor.createDiv({ cls: "cm-subsection" });
    colorWrap.createEl("div", {
      text: "局部颜色",
      cls: "cm-subsection-title",
    });
    const swatches = colorWrap.createDiv({ cls: "cm-color-swatches" });
    for (const color of TITLE_COLOR_SWATCHES) {
      const swatch = swatches.createEl("button", {
        cls: "cm-color-swatch",
      });
      swatch.type = "button";
      swatch.style.background = color;
      swatch.addEventListener("click", () => this.applyTitleColor(color));
    }

    const customColorRow = colorWrap.createDiv({ cls: "cm-inline-row" });
    this.customColorInput = customColorRow.createEl("input", {
      cls: "cm-color-input",
      attr: {
        type: "color",
        value: "#2563eb",
      },
    });
    const applyCustomColorButton = customColorRow.createEl("button", {
      text: "应用自定义颜色",
      cls: "cm-button cm-button-small",
    });
    applyCustomColorButton.addEventListener("click", () => {
      this.applyTitleColor(this.customColorInput.value);
    });

    const sizeWrap = styleEditor.createDiv({ cls: "cm-subsection" });
    sizeWrap.createEl("div", {
      text: "局部字号",
      cls: "cm-subsection-title",
    });
    const sizeGrid = sizeWrap.createDiv({ cls: "cm-choice-grid" });
    for (const preset of TITLE_SIZE_PRESETS) {
      const button = sizeGrid.createEl("button", {
        text: preset.name,
        cls: "cm-preset-card",
      });
      button.type = "button";
      button.addEventListener("click", () => {
        this.applyTitleSize(preset.scale);
      });
    }

    const clearStyleButton = styleEditor.createEl("button", {
      text: "清除选中样式",
      cls: "cm-button cm-button-small",
    });
    clearStyleButton.addEventListener("click", () => {
      const selection = this.getTitleSelection();
      if (!selection) {
        new Notice("请先在标题中选中要清除样式的文字。");
        return;
      }

      this.plugin.clearTitleStyles(selection.start, selection.end);
      this.renderSelectionInfo();
    });

    const tagField = root.createDiv({ cls: "cm-section" });
    tagField.createEl("label", { text: "标签", cls: "cm-field-label" });
    tagField.createEl("p", {
      text: "支持英文逗号、中文逗号或换行分隔多个标签。",
      cls: "cm-field-hint",
    });
    this.tagInput = tagField.createEl("textarea", {
      cls: "cm-textarea",
      attr: {
        rows: "3",
        placeholder: "例如：AI 商业, 视频号增长, 知识 IP",
      },
    });
    this.tagInput.addEventListener("input", () => {
      this.plugin.setDraft({ tagInput: this.tagInput.value }, { refresh: false });
      this.renderPreview();
    });

    const presetSection = root.createDiv({ cls: "cm-section" });
    presetSection.createEl("label", { text: "视觉风格", cls: "cm-field-label" });
    this.presetGrid = presetSection.createDiv({ cls: "cm-preset-grid" });

    const typographySection = root.createDiv({ cls: "cm-section" });
    typographySection.createEl("label", { text: "文字排版主题", cls: "cm-field-label" });
    this.typographyGrid = typographySection.createDiv({ cls: "cm-preset-grid" });

    const spacingSection = root.createDiv({ cls: "cm-section" });
    spacingSection.createEl("label", { text: "文字细节", cls: "cm-field-label" });

    const lineSpacingWrap = spacingSection.createDiv({ cls: "cm-subsection" });
    lineSpacingWrap.createEl("div", {
      text: "行距选择",
      cls: "cm-subsection-title",
    });
    this.lineSpacingGrid = lineSpacingWrap.createDiv({ cls: "cm-choice-grid" });

    const letterSpacingWrap = spacingSection.createDiv({ cls: "cm-subsection" });
    letterSpacingWrap.createEl("div", {
      text: "字间距选择",
      cls: "cm-subsection-title",
    });
    this.letterSpacingGrid = letterSpacingWrap.createDiv({ cls: "cm-choice-grid" });

    const actionRow = root.createDiv({ cls: "cm-button-row" });
    const exportButton = actionRow.createEl("button", {
      text: "导出 PNG",
      cls: "cm-button cm-button-primary",
    });
    exportButton.addEventListener("click", async () => {
      try {
        const result = await this.plugin.exportCurrentDraft();
        if (!result) {
          return;
        }

        this.statusEl.setText(`已导出：${result.path}`);
      } catch (error) {
        const message = error instanceof Error ? error.message : "导出封面失败。";
        this.statusEl.setText(message);
        new Notice(message);
      }
    });

    const previewSection = root.createDiv({ cls: "cm-section" });
    previewSection.createEl("label", { text: "实时预览", cls: "cm-field-label" });
    this.previewShell = previewSection.createDiv({ cls: "cm-preview-shell" });
    this.previewStage = this.previewShell.createDiv({ cls: "cm-preview-stage" });

    const templateSection = root.createDiv({ cls: "cm-section" });
    const templateHead = templateSection.createDiv({ cls: "cm-template-head" });
    templateHead.createEl("label", { text: "常用模板", cls: "cm-field-label" });
    templateHead.createEl("span", {
      text: "保存当前标题、标签、风格和文字参数组合",
      cls: "cm-field-hint",
    });

    const templateActions = templateSection.createDiv({ cls: "cm-template-create" });
    this.templateNameInput = templateActions.createEl("input", {
      cls: "cm-input",
      attr: {
        type: "text",
        placeholder: "模板名称，例如 AI 爆款封面",
      },
    });
    const saveTemplateButton = templateActions.createEl("button", {
      text: "保存当前为模板",
      cls: "cm-button",
    });
    saveTemplateButton.addEventListener("click", async () => {
      const template = await this.plugin.saveCurrentAsTemplate(this.templateNameInput.value);
      this.templateNameInput.value = template.name;
      this.statusEl.setText(`模板已保存：${template.name}`);
    });

    this.templateList = templateSection.createDiv({ cls: "cm-template-list" });
    this.statusEl = root.createDiv({ cls: "cm-status" });
  }

  private syncInputsFromState(): void {
    const { draft } = this.plugin;

    if (this.titleInput.value !== draft.title) {
      this.titleInput.value = draft.title;
    }

    if (this.tagInput.value !== draft.tagInput) {
      this.tagInput.value = draft.tagInput;
    }
  }

  private renderPresetGrid(): void {
    this.renderChoiceButtons(
      this.presetGrid,
      COVER_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name,
      })),
      this.plugin.draft.presetId,
      (id) => {
        this.plugin.setDraft({ presetId: id }, { refresh: false });
        this.renderPresetGrid();
        this.renderPreview();
      },
    );
  }

  private renderTypographyGrid(): void {
    this.renderChoiceButtons(
      this.typographyGrid,
      TYPOGRAPHY_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name,
      })),
      this.plugin.draft.typographyId,
      (id) => {
        this.plugin.setDraft({ typographyId: id }, { refresh: false });
        this.renderTypographyGrid();
        this.renderPreview();
      },
    );
  }

  private renderLineSpacingGrid(): void {
    this.renderChoiceButtons(
      this.lineSpacingGrid,
      LINE_SPACING_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name,
      })),
      this.plugin.draft.lineSpacingId,
      (id) => {
        this.plugin.setDraft({ lineSpacingId: id }, { refresh: false });
        this.renderLineSpacingGrid();
        this.renderPreview();
      },
    );
  }

  private renderLetterSpacingGrid(): void {
    this.renderChoiceButtons(
      this.letterSpacingGrid,
      LETTER_SPACING_PRESETS.map((preset) => ({
        id: preset.id,
        name: preset.name,
      })),
      this.plugin.draft.letterSpacingId,
      (id) => {
        this.plugin.setDraft({ letterSpacingId: id }, { refresh: false });
        this.renderLetterSpacingGrid();
        this.renderPreview();
      },
    );
  }

  private renderChoiceButtons(
    container: HTMLDivElement,
    items: Array<{ id: string; name: string }>,
    selectedId: string,
    onSelect: (id: string) => void,
  ): void {
    container.empty();

    for (const item of items) {
      const button = container.createEl("button", {
        cls: `cm-preset-card${item.id === selectedId ? " is-active" : ""}`,
      });
      button.type = "button";
      button.createEl("span", { text: item.name, cls: "cm-preset-name" });
      button.addEventListener("click", () => onSelect(item.id));
    }
  }

  private renderSelectionInfo(): void {
    const selection = this.getTitleSelection();
    if (!selection) {
      this.selectionInfoEl.setText("先在标题输入框里选中一段文字，再单独设置颜色和字号。");
      return;
    }

    const selectedText = this.titleInput.value.slice(selection.start, selection.end).replace(/\s+/g, " ");
    const previewText = selectedText.length > 18 ? `${selectedText.slice(0, 18)}…` : selectedText;
    this.selectionInfoEl.setText(`当前已选 ${selection.end - selection.start} 个字符：${previewText}`);
  }

  private getTitleSelection():
    | {
        start: number;
        end: number;
      }
    | null {
    const start = this.titleInput.selectionStart ?? 0;
    const end = this.titleInput.selectionEnd ?? 0;

    if (start === end) {
      return null;
    }

    return { start, end };
  }

  private applyTitleColor(color: string): void {
    const selection = this.getTitleSelection();
    if (!selection) {
      new Notice("请先在标题中选中要修改颜色的文字。");
      return;
    }

    this.plugin.applyTitleColor(selection.start, selection.end, color);
    this.renderSelectionInfo();
  }

  private applyTitleSize(scale: number): void {
    const selection = this.getTitleSelection();
    if (!selection) {
      new Notice("请先在标题中选中要修改字号的文字。");
      return;
    }

    this.plugin.applyTitleSizeScale(selection.start, selection.end, scale);
    this.renderSelectionInfo();
  }

  private renderPreview(): void {
    if (!this.previewStage) {
      return;
    }

    this.previewStage.empty();
    const preset = getCoverPreset(this.plugin.draft.presetId);
    const layout = computeCoverLayout(this.plugin.draft, preset, true);
    const availableWidth = this.previewShell.clientWidth > 16
      ? this.previewShell.clientWidth - 8
      : 280;
    const scale = Math.min(1, availableWidth / COVER_WIDTH);
    const width = Math.round(COVER_WIDTH * scale);
    const height = Math.round(COVER_HEIGHT * scale);

    this.previewStage.style.width = `${width}px`;
    this.previewStage.style.height = `${height}px`;

    const coverEl = this.previewStage.createDiv({ cls: "cm-cover-preview" });
    coverEl.setAttribute("data-preset", preset.id);
    coverEl.style.width = `${width}px`;
    coverEl.style.height = `${height}px`;
    coverEl.style.setProperty("--cm-bg-1", preset.background[0]);
    coverEl.style.setProperty("--cm-bg-2", preset.background[1]);
    coverEl.style.setProperty("--cm-bg-3", preset.background[2]);
    coverEl.style.setProperty("--cm-text-color", preset.textColor);
    coverEl.style.setProperty("--cm-accent-color", preset.accentColor);
    coverEl.style.setProperty("--cm-accent-soft", preset.accentSoft);
    coverEl.style.setProperty("--cm-accent-muted", preset.accentMuted);
    coverEl.style.setProperty("--cm-tag-bg", preset.tagBackground);
    coverEl.style.setProperty("--cm-tag-text", preset.tagTextColor);
    coverEl.style.setProperty("--cm-tag-border", preset.tagBorderColor);
    coverEl.style.setProperty("--cm-font-display", preset.fontFamily);
    coverEl.style.setProperty("--cm-shadow-color", preset.shadowColor);
    coverEl.style.setProperty("--cm-grid-size", `${Math.max(16, 44 * scale)}px`);

    coverEl.createDiv({ cls: "cm-cover-surface" });
    coverEl.createDiv({ cls: "cm-cover-orbit" });
    coverEl.createDiv({ cls: "cm-cover-grid" });
    coverEl.createDiv({ cls: "cm-cover-stripe" });
    coverEl.createDiv({ cls: "cm-cover-corner" });
    coverEl.createDiv({ cls: "cm-cover-outline" });

    const tagLayer = coverEl.createDiv({ cls: "cm-cover-layer" });
    for (const row of layout.tagRows) {
      for (const chip of row.chips) {
        const chipEl = tagLayer.createDiv({ cls: "cm-cover-tag" });
        chipEl.setText(chip.text);
        chipEl.style.left = `${chip.x * scale}px`;
        chipEl.style.top = `${chip.y * scale}px`;
        chipEl.style.width = `${chip.width * scale}px`;
        chipEl.style.height = `${chip.height * scale}px`;
        chipEl.style.fontSize = `${layout.tagFontSize * scale}px`;
        chipEl.style.borderRadius = `${chip.height * scale}px`;
      }
    }

    const titleLayer = coverEl.createDiv({ cls: "cm-cover-title-layer" });
    titleLayer.style.fontFamily = preset.fontFamily;
    titleLayer.style.fontWeight = `${preset.titleWeight}`;

    for (const line of layout.titleLines) {
      for (const glyph of line.glyphs) {
        const glyphEl = titleLayer.createDiv({ cls: "cm-cover-title-glyph" });
        glyphEl.setText(glyph.text);
        glyphEl.style.left = `${glyph.x * scale}px`;
        glyphEl.style.top = `${glyph.y * scale}px`;
        glyphEl.style.fontSize = `${glyph.fontSize * scale}px`;
        glyphEl.style.color = glyph.color;
      }
    }
  }

  private renderTemplateList(): void {
    this.templateList.empty();

    if (this.plugin.templates.length === 0) {
      this.templateList.createEl("div", {
        text: "还没有保存模板，先做一个你常用的封面组合吧。",
        cls: "cm-empty-state",
      });
      return;
    }

    for (const template of this.plugin.templates) {
      const item = this.templateList.createDiv({ cls: "cm-template-item" });
      const meta = item.createDiv({ cls: "cm-template-meta" });
      meta.createEl("strong", { text: template.name, cls: "cm-template-name" });
      meta.createEl("span", {
        text: `${getCoverPreset(template.presetId).name} · ${getTypographyPreset(template.typographyId).name} · ${getLineSpacingPreset(template.lineSpacingId).name}行距 · ${getLetterSpacingPreset(template.letterSpacingId).name}字距 · ${template.titleStyles.length} 段局部样式 · ${formatDate(template.updatedAt)}`,
        cls: "cm-template-subtle",
      });

      const snippet = item.createEl("div", { cls: "cm-template-snippet" });
      snippet.setText(template.title || "无标题模板");

      const actions = item.createDiv({ cls: "cm-template-actions" });

      const applyButton = actions.createEl("button", {
        text: "应用",
        cls: "cm-button cm-button-small",
      });
      applyButton.addEventListener("click", async () => {
        await this.plugin.applyTemplate(template.id);
        this.renderSelectionInfo();
        this.statusEl.setText(`已应用模板：${template.name}`);
      });

      const updateButton = actions.createEl("button", {
        text: "更新",
        cls: "cm-button cm-button-small",
      });
      updateButton.addEventListener("click", async () => {
        await this.plugin.updateTemplate(template.id);
        this.statusEl.setText(`模板已更新：${template.name}`);
      });

      const deleteButton = actions.createEl("button", {
        text: "删除",
        cls: "cm-button cm-button-small cm-button-danger",
      });
      deleteButton.addEventListener("click", async () => {
        await this.plugin.deleteTemplate(template.id);
        this.statusEl.setText(`模板已删除：${template.name}`);
      });
    }
  }

  private attachResizeObserver(): void {
    if (typeof ResizeObserver === "undefined" || !this.previewShell) {
      return;
    }

    this.resizeObserver?.disconnect();
    this.resizeObserver = new ResizeObserver(() => this.renderPreview());
    this.resizeObserver.observe(this.previewShell);
  }
}

function formatDate(timestamp: number): string {
  const date = new Date(timestamp);
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  const hour = `${date.getHours()}`.padStart(2, "0");
  const minute = `${date.getMinutes()}`.padStart(2, "0");
  return `${month}-${day} ${hour}:${minute}`;
}
